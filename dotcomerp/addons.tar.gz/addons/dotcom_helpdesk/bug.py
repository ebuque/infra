# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2014 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_licence')
import base64
import gnupg
import os
import re

message_submitted = '''
</BR>
</br>
A submissão do bug com referencia [ref] foi actualizada com os dados:
</br></br>
Referencia: <b>[ref]</b> </br>
Titulo: <b>[name]</b></br>
data: <b>[data]</b></br>
Reportado Por: <b>[reported_by]</b></br>

Estado: <b>[state]</b></br>

Notas: <b>[notes]</b></br>
<hr>
<img src="http://www.dotcom.co.mz/dotcomerp/resources/logo.png" alt="DotComERP">

'''

message_tech = '''
</br>
Novo bug com referencia [ref] disponivel para suporte técnico:
</br>
</br>
Prioridade: <b><i>[prioridade]</i></b> </br>
Referencia: <b>[ref]</b> </br>
Titulo: <b>[name]</b></br>
data: <b>[data]</b></br>
Reportado Por: <b>[user_id] - [reported_by]</b></br>
<hr>
<b>Notas do cliente: </b></br>
[notes]</br>
<hr>
<b>Comentários:</b></br>
[comment]
</br></br>
<hr>
<img src="http://www.dotcom.co.mz/dotcomerp/resources/logo.png" alt="DotComERP">
'''

message_aval='''
</br>
Bug com referencia [ref] foi actualizado:
</br></br>
Referencia: <b>[ref]</b> </br>
Titulo: <b>[name]</b></br>
data: <b>[data]</b></br>
Reportado Por: <b>[reported_by]</b></br>

Estado: <b>[state]</b></br>

Notas: <b>[notes]</b></br>
<hr>

</br>
Comentários: <b>[comment]</b></br>
<hr>
<img src="http://www.dotcom.co.mz/dotcomerp/resources/logo.png" alt="DotComERP">
'''

def parse_message(self, message, values={}):
	res = message
	estado = {'draft':'Em Rascunho','submitted':'Submetido','avaliation':'Em Avaliação','tech':'Departamento Técnico','resolved':'Resolvido','archived':'Arquivado'}
	prioridades = {'5':'Muito Baixa','4':'Baixa','3':'Normal','2':'Alta','1':'Muito Alta','0':'Urgente'}

	for each in values:
		campo = values.get(each, '')
		if type(campo) not in [str, unicode]:
			if type(campo) == tuple:
				campo = '%s' % str(campo and campo[1] or '')
			else:
				campo = str('%s' % values.get(each, ''))
		if each == 'state':
			campo = estado.get(campo, '')
		#
		#if each == 'prioridade':
		#	campo = prioridades.get(campo, '')
		each = '[%s]' % each
		res = res.replace(each, campo)
	logger.info('\n\n\nFINAL RESULT: %s' % res)
	return res

class dotcom_area(osv.osv):
	_name = 'helpdesk.area'
	_description = 'Aplicações'
	_columns = {
				'ref': fields.char('Ref',size=10, required=True),
				'name': fields.char('Nome',size=90, required=True),
				'aplicacao_id': fields.many2one('helpdesk.aplicacao', 'Aplicação'),
	}
dotcom_area()

class dotcom_applicacao(osv.osv):
	_name = 'helpdesk.aplicacao'
	_description = 'Aplicações'
	_columns = {
				'ref': fields.char('Ref',size=10, required=True),
				'name': fields.char('Nome',size=90, required=True),
				'area_ids': fields.one2many('helpdesk.area','aplicacao_id','Áreas'),
	}
dotcom_applicacao()

class dotcom_prioridade(osv.osv):
	_name = 'helpdesk.prioridade'
	_description = 'Aplicações'
	_columns = {
				'ref': fields.char('Ref',size=10, required=True),
				'name': fields.char('Nome',size=90, required=True),
	}
dotcom_prioridade()

class helpdesk_bug(osv.osv):
	
	def _send_mail(self, cr, uid, server = None,message_to = [], mail_message='', subject='',report=[], attachs = [],images=[], context=None):
		if context is None:
			context = {}
		if not server:
			servers = self.pool.get('email.smtpclient').search(cr, uid, [('state','=','confirm')],order='prioridade')
			server = servers and servers[0]
		if server:
			if message_to:
				receivers = []
				for each in message_to:
					if each and self._check_mail(cr, uid, each):
						receivers.append(each)
				if receivers:
					self.pool.get('email.smtpclient').send_email(cr, uid, server, receivers, subject, body=str(mail_message), attachments=attachs, reports=report,images=images)
			return True
		else:
			raise osv.except_osv(_('Acção Inválida !'), _('Servidor de email não definido !'))
			return False
	
	def _default_user(self, cr, uid, context=None):
		if context is None:
			context = {}
		user = self.pool.get('res.users').browse(cr, uid, uid)
		return user and user.name or ''
	
	def _default_prioridade(self, cr, uid, context=None):
		if context is None:
			context = {}
		#normal = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_helpdesk','prioridade_3')
		#normal_id = normal and normal.id or False
		return 3
	
	def _default_email(self, cr, uid, context=None):
		if context is None:
			context = {}
		user = self.pool.get('res.users').browse(cr, uid, uid)
		return user and user.user_email or ''
	
	def _get_ref(self, cr, uid, context=None):
		if context is None:
			context = {}
		result = self.search(cr, uid, [], count=True,context=context)
		result = str(result + 1)
		a = len(result)
		if a<5:
			rem = 5 - a
			zeros = []
			while rem>0:
				zeros.append('0')
				rem = rem - 1
			string = ''.join(zeros) + result
		else:
			string = result
		temp = 'HELP/%s' % string
		return temp
	
	def _check_mail(self, cr, uid, email):
		if re.match("^[a-zA-Z0-9._%-]+@[a-zA-Z0-9._%-]+.[a-zA-Z]{2,6}$", email or ''):
			return True
		else:
			raise osv.except_osv(_('Acção Inválida !'), _('Endereço de email inválido !'))

	_name = 'helpdesk.bug'
	_description = 'Submissão de Erros para suporte'
	_columns = {
				'ref': fields.char('Ref',size=10, required=True, readonly=True),
				'name': fields.char('Descrição',size=250, required=True),
				'notes': fields.text('Comentários', readonly=True, states={'draft':[('readonly',False)]}),
				'data': fields.date('Data'),
				'aplicacao_id': fields.many2one('helpdesk.aplicacao', 'Aplicação', required=True),
				'area_id': fields.many2one('helpdesk.area', 'Área', required=True),
				'user_id': fields.many2one('res.users','Usuário', readonly=True),
				'reported_by': fields.char('Reportado Por', size=250),
				
				'notify_email': fields.boolean('Notificar por email'),
				'email': fields.char('Email', size=250),
				
				'state': fields.selection([('draft','Em Rascunho'),('submitted','Submetido'),('tech','Departamento Técnico'),('avaliation','Em Avaliação'),('resolved','Resolvido'),('archived','Arquivado')],'Estado', select=True),
				'type': fields.selection([('bug','Bug'),('support','Suporte'),('wish','Wishlist')],'Tipo', select=True, required=True),
				
				'on_avaliation': fields.boolean('Em Avaliação'),
				'on_tech': fields.boolean('No Departamento Técnico'),
				'on_resolved': fields.boolean('Resolvido'),
				'on_archived': fields.boolean('Arquivado'),
				
				#'prioridade': fields.selection([(5,'Muito Baixa'),(4,'Baixa'),(3,'Normal'),(2,'Alta'),(1,'Muito Alta'),(0,'Urgente')],'Prioridade',readonly=True, states={'submitted':[('readonly',False)]}),
				'prioridade': fields.many2one('helpdesk.prioridade', 'Prioridade', required=True),
				
				'message': fields.text('Mensagem',readonly=True,states={'submitted':[('readonly',False)],'tech':[('readonly',False)],'avaliation':[('readonly',False)]}),
				'comment': fields.text('Comentários',readonly=True,states={'submitted':[('readonly',False)],'avaliation':[('readonly',False)]}),
				'color': fields.integer('Color'),

	}
	
	_defaults = {
		'state': 'draft',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'user_id': lambda s, cr, u, c: u,
		'reported_by': lambda s, cr, u, c: s._default_user(cr, u, context=c),
		'email': lambda s, cr, u, c: s._default_email(cr, u, context=c),
		'notify_email': True,
		'ref': lambda s, cr, u, c: s._get_ref(cr, u, context=c),
		'prioridade': lambda s, cr, u, c: s._default_prioridade(cr, u, context=c),
	}
	
	def submit(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for bug in self.browse(cr, uid, ids):
			email = ''
			recepients = []
			if bug.notify_email and bug.on_avaliation:
				email = bug and bug.email or ''
				self._check_mail(cr, uid, email)
				recepients.append(email)
			mensagem = message_submitted
			res = self.read(cr, uid, bug and bug.id)
			res['state'] = 'submitted'
			
			grupo_avaliadores = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_helpdesk','helpdesk_avaliation')
			for avaliador in grupo_avaliadores.users:
				email_avaliador = avaliador and avaliador.user_email or False
				if email_avaliador:
					recepients.append(email_avaliador)
			
			assunto = 'Bug DotcomERP %s' % bug and bug.ref or ''
			parsed_message = parse_message(self, mensagem, values=res)
			
			self._send_mail(cr, uid, message_to=recepients, mail_message=parsed_message, subject=assunto, context=context)
			
		self.write(cr, uid, ids, {'state':'submitted'})
		return True
	
	def send_tech(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for bug in self.browse(cr, uid, ids):
			res = self.read(cr, uid, bug.id)
			res['state'] = 'on_tech'
			mail_partner = ''
			if bug.notify_email and bug.on_tech:
				mail_partner = bug and bug.email or ''
				mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
				parsed_message = parse_message(self, message_submitted, values=res)
				self._send_mail(cr, uid, message_to=mail_partner, mail_message=parsed_message, subject=mail_subject, context=context)
			
			recepients = []
			grupo_tecnicos = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_helpdesk','helpdesk_technician')
			for tecnico in grupo_tecnicos.users:
				email_tecnico = tecnico and tecnico.user_email or False
				if email_tecnico:
					recepients.append(email_tecnico)
			
			mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
			message = parse_message(self, message_tech, values=res)
			self._send_mail(cr, uid, message_to=recepients, mail_message=message, subject=mail_subject, context=context)
		self.write(cr, uid, ids, {'state':'tech'})
		return True
	
	def send_avaliation(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for bug in self.browse(cr, uid, ids):
			res = self.read(cr, uid, bug.id)
			res['state'] = 'avaliation'
			mail_partner = ''
			if bug.notify_email and bug.on_avaliation:
				mail_partner = bug and bug.email or ''
				mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
				parsed_message = parse_message(self, message_submitted, values=res)
				self._send_mail(cr, uid, message_to=mail_partner, mail_message=parsed_message, subject=mail_subject, context=context)
			
			recepients = []
			grupo_avaliadores = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_helpdesk','helpdesk_avaliation')
			for tecnico in grupo_avaliadores.users:
				email_tecnico = tecnico and tecnico.user_email or False
				if email_tecnico:
					recepients.append(email_tecnico)
			
			mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
			message = parse_message(self, message_aval, values=res)
			self._send_mail(cr, uid, message_to=recepients, mail_message=message, subject=mail_subject, context=context)
		self.write(cr, uid, ids, {'state':'avaliation'})
		return True
	
	def resolved(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for bug in self.browse(cr, uid, ids):
			res = self.read(cr, uid, bug.id)
			res['state'] = 'resolved'
			mail_partner = ''
			if bug.notify_email and bug.on_resolved:
				mail_partner = bug and bug.email or ''
				mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
				parse_messaged = parse_message(self, message_submitted, values=res)
				self._send_mail(cr, uid, message_to=mail_partner, mail_message=parse_messaged, subject=mail_subject, context=context)
		self.write(cr, uid, ids, {'state':'resolved'})
		return True
	
	def unresolved(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for bug in self.browse(cr, uid, ids):
			res = self.read(cr, uid, bug.id)
			res['state'] = 'archived'
			mail_partner = ''
			if bug.notify_email and bug.on_archived:
				mail_partner = bug and bug.email or ''
				mail_subject = 'Bug DotcomERP %s' % bug and bug.ref or ''
				parse_messaged = parse_message(self, message_submitted, values=res)
				self._send_mail(cr, uid, message_to=mail_partner, mail_message=parse_messaged, subject=mail_subject, context=context)
		self.write(cr, uid, ids, {'state':'archived'})
		return True
	
	def copy(self, cr, uid, id, default=None, context=None):
		if default is None:
			default = {}
		default['ref'] = self._get_ref(cr, uid, context=context)
		default['state'] = 'draft'
		return super(helpdesk_bug, self).copy(cr, uid, id, default, context)
	
helpdesk_bug()