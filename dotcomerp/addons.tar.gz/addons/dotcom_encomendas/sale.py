# -*- coding: utf-8 -*-

#  DotComERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from dotcom_doc import validator
import logging
logger = logging.getLogger('DOTCOM_DEBUGGING')

def perc(part, whole):
    a = 0
    try:
        a = float(part)/100 * float(whole)
    except ZeroDivisionError:
        a = 0
    return a

class dotcom_venda_linha(osv.osv):
    _name = 'dotcom.venda.linha'
    _inherit = 'dotcom.venda.linha'
    _columns = {'gpa': fields.float('GPA', readonly=True)}
    
dotcom_venda_linha()

class dotcom_venda(osv.osv):
    _name = 'dotcom.venda'
    _inherit = 'dotcom.venda'
    _columns = {
                    'numero_encomenda': fields.char('Numero de Encomenda', size=30,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'ordem_encomenda': fields.char('Ordem de Encomenda', size=30,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'nota_entrega': fields.char('Nota de Entrega nº', size=30,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    
                    'nome_entrega': fields.char('Nome', size=250,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'contacto_entrega': fields.char('Contacto', size=250,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'morada_entrega': fields.char('Morada', size=250,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'telefone_entrega': fields.char('Telefone', size=30,readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    
                    'data_encomenda': fields.date('Data de Encomenda',readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    'data_entrega': fields.date('Data de Entrega',readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                    
                    'transporte_encomenda': fields.selection([('car','Estrada'),('sea','Marítimo'),('plane','Aéreo'),('train','Comboio')],'Tipo de Transporte', select=True, readonly=True, states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
                }
    
    _defaults = {
                    'transporte_encomenda': 'car',
                    'data_entrega': lambda *a: time.strftime('%Y-%m-%d'),
                    'data_encomenda': lambda *a: time.strftime('%Y-%m-%d'),
                }
    
    def on_change_partner(self, cr, uid, ids, partner_id,partner_type, allow_unidentified_partner, company_id,context=None):
        if context is None:
            context = {}
        vals = {}
        vals = super(dotcom_venda, self).on_change_partner(cr, uid, ids, partner_id, partner_type, allow_unidentified_partner, company_id, context=context).get('value', {})
        if partner_id:
            partner = self.pool.get('res.partner').browse(cr, uid, partner_id)
            addr = self.pool.get('res.partner').address_get(cr, uid, [partner_id], ['delivery']) or None
            if not addr['delivery']:
                addr = self.pool.get('res.partner').address_get(cr, uid, [partner_id], ['default']) or None
            address_id = addr and addr.get('delivery', False)
            if not address_id:
                address_id = addr and addr.get('default', False)
            if address_id:
                address = self.pool.get('res.partner.address').browse(cr, uid, address_id)
                
                vals['nome_entrega'] = partner and partner.name or ''
                vals['contacto_entrega'] = address and address.name or ''
                vals['morada_entrega'] = address and address.street or ''
                vals['telefone_entrega'] = address and address.phone or ''
                
        return {'value': vals}
    
    def compute(self, cr, uid, doc_id, context=None):
        if context is None:
            context = {}
        result = super(dotcom_venda, self).compute(cr, uid, doc_id, context=context)
        document = self.browse(cr, uid, doc_id, context=context)
        if document:
            total_gpa = 0
            totals = {}
            vat = 0
            iva_gpa = 0
            for line in document.sales_lines:
                ##
                #   Modo do Cálculo do GPA, e update do valor Total Líquido
                ##
                gpa = line.gpa
                total_liquido = line.line_total - gpa
                logger.info('\n\n Novo TOTAL LIQUIDO %s  :  line TOTAL %s' % (total_liquido, line.line_total))
                self.pool.get('dotcom.venda.linha').write(cr, uid, line.id, {'gpa':gpa, 'line_total':total_liquido})
                total_gpa += gpa
                totals [line.id] = total_liquido
                
                logger.info('\n\n Novo GPA: %s' % gpa)
                
                ##
                #   Actualizaçao de campos com o novo desconto(GPA), ex: Cálculo de IVA, Total do Documento, Total de Descontos
                ##
                qty = line.qty
                preco_sem_iva = line.unit_price or 0
                unit_price = line.unit_price or 0
                tax_id = line.tax_id.id
                
                if line.iva_incluido:
                    preco_sem_iva = self._get_preco_sem_iva(cr ,uid, tax_id, unit_price,  context=context)
                valor_sem_iva = qty*preco_sem_iva
                desconto = line.desconto_linha or 0
                desconto_comercial = line.desconto_comercial or 0
                iva = line.tax_id.tax or 0
                valor_iva = perc(iva, valor_sem_iva - desconto_comercial - desconto - gpa)
                vat += valor_iva
                iva_gpa += perc(iva, gpa)
            
            ##
            #   Escrita de campos com o novo desconto(GPA), ex: Total de IVA, Total do Documento, Total de Descontos
            ##
            document_total = document.total_document - total_gpa - iva_gpa
            discounts = document.total_discount + total_gpa
            res = {'total_discount': discounts, 'total_document': document_total, 'total_vat': vat}
            self.write(cr, uid, doc_id, res)
        
            purchase_iva_obj = self.pool.get('dotcom.venda.iva')
            for iva_summary in document.taxes_ids:
                purchase_iva_obj.unlink(cr,uid,iva_summary.id)
            result_taxes = {}
            
            ##
            #   UPDATE da tabela de Resumod de IVa
            ##
            for line in document.sales_lines:

                tax_id = line.tax_id.id
                tax_id_key = str(tax_id)
                line_total = totals.get(line.id, 0)
                
                if result_taxes.has_key(tax_id_key):
                    result_amount = result_taxes.get(tax_id_key) or 0
                    result_taxes[tax_id_key] = result_amount + line_total
                else:
                    result_taxes[tax_id_key] = line_total
                    
            for key in result_taxes.keys():
                tax = self.pool.get('iva.iva').browse(cr,uid,int(key))
                vat_ammount = result_taxes.get(key)
                base_amount = 0
                if tax and (vat_ammount != 0):
                    iva = tax.tax/100
                    base_amount = vat_ammount*iva
                self.pool.get('dotcom.venda.iva').create(cr,uid,{'iva_id':int(key),'venda_id': document.id,'vat_base': validator.decimal_precision(cr,uid,result_taxes.get(key)),'vat_amount': validator.decimal_precision(cr,uid,base_amount)})
        return result
    
    ##
    #   Objective:
    #       Write the values using the correct pattern, i.e:
    #           If its receivable: write values in positive
    #           elif its payable: Write values in negative
    ##
    def validate(self, cr, uid, doc_id, context=None):
        if context is None:
            context = {}
        res = super(dotcom_venda, self).validate(cr, uid, doc_id, context=context)
        document = self.browse(cr, uid, doc_id, context=context)
        if document:
            if document.doc_type.pagar_receber == 'receivable':
                signal = 1
            else:
                signal = -1
            for line in document.sales_lines:
                lines_write = {}
                lines_write['gpa'] = self.pattern(cr,uid,signal * abs(line.gpa))
                self.pool.get('dotcom.venda.linha').write(cr,uid,line.id,lines_write)
        return res
    
    def run_reset(self, cr, uid, doc_id, context=None):
        if context is None:
            context = {}
        res = super(dotcom_venda, self).run_reset(cr, uid, doc_id, context=context)
        documento = self.browse(cr,uid,doc_id,context)
        if documento:
            for line in documento.sales_lines:
                linen = {}
                linen['gpa'] = abs(line.gpa or 0)
                self.pool.get('dotcom.venda.linha').write(cr, uid, line.id, linen)
        return res
    
dotcom_venda()