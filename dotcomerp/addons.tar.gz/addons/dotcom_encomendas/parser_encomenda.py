# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################

import time
import base64
import os
import logging
import pooler
import jasper_reports
from dotcom_doc import JasperDataParser
from osv import osv,fields 
from datetime import datetime, timedelta

logger = logging.getLogger('dotcom_vendas_report')

class jasper_encomendas_venda(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_encomendas_venda, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        venda = pool.get('dotcom.venda').browse(cr,uid,ids and ids[0], context=context)
        
        total_peso_bruto = 0
        total_peso_liquido = 0
        total_volume = 0
        
        for linha in venda.sales_lines:
            product = linha.prod_id
            peso_bruto = product and product.weight or 0
            peso_liquido = product and product.weight_net or 0
            volume = product and product.volume or 0
            qty = abs(linha.qty)
            
            total_volume += volume * qty
            total_peso_liquido += peso_liquido * qty
            total_peso_bruto += peso_bruto * qty
        
        return {
                'VOLUME': str(total_volume),
                'PESO_LIQUIDO': str(total_peso_liquido),
                'PESO_BRUTO': str(total_peso_bruto)
                }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result = []
        venda_id = None
        if not context:
            context = {}

        venda = pool.get('dotcom.venda').browse(cr,uid,ids[0], context=context)
        
        licenca_obj = pool.get('dotcom.licence')
        licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
 
        company = venda.company_id
        company_name = company.name or ''
        company_id = company.id or None
        company_id = str(company_id)
        company_street = company.street or ''
        company_phone = company.phone or ''
        company_fax = company.fax or ''
        company_tin = company.partner_id.nuit or ''
        company_city = company.city or ''
        company_email = company.email or ''
        company_web = company.website or ''
        logo_temp = ''
        
        exchanged_currency = ''
        exchanged_total = ''
        
        me = company.partner_id.id
        counter = 0
        
        banco_1 = ''
        conta_1 = ''
        nib_1 = ''
        moeda_1 = ''
        
        banco_2 = ''
        conta_2 = ''
        nib_2 = ''
        moeda_2 = ''
        
        accounts = pool.get('res.partner.bank').search(cr,uid,[('partner_id','=',me),('footer','=',True)],limit=2)
        if accounts and len(accounts)>0:
            for account in accounts:
                counter = counter + 1
                if counter == 1:
                    conta = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_1 = conta.bank_name or ''
                    conta_1 = conta.acc_number or ''
                    nib_1 = conta.nib or ''
                    moeda_1 = conta.currency_id.name or ''
                    continue
                elif counter == 2:
                    acc = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_2 = acc.bank_name or ''
                    conta_2 = acc.acc_number or ''
                    nib_2 = acc.nib or ''
                    moeda_2 = acc.currency_id.name or ''
                    break
                else:
                    break

        logo_temp = company.logo or ''
        
        product_logo = ''      
        if company.product_logo:
            product_logo = 'product_logo_'+company_id+'.png'
            prod_logo = base64.b64decode(str(company.product_logo).decode('latin-1'))
            pathfinder = '/opt/dotcomerp/server/openerp/addons/dotcom_doc/report2/logos/'+'product_logo_'+company_id+'.png'
            fich = open(pathfinder, 'w+')
            try:
                fich.write(prod_logo)
            finally:
                fich.close()
        
        partner_name = venda.partner_name or ''
        parent_partner_name = ''
        if venda.partner_id.parent_id:
            parent_partner_name = venda.partner_id.parent_id.name
        partner_address = venda.partner_address or ''
        partner_tin = venda.partner_nuit_name or ''
        
        doc_date = venda.document_date
        doc_due_date = venda.due_date
        doc_payterm = venda.payment_term_id.name or ''
        doc_currency_name = venda.doc_currency.name or ''
        doc_type_name = venda.doc_type.name or ''
        doc_number = venda.document_number or ''
        partner_phone = venda.partner_id.phone or ''
        
        doc_currency_symbol = venda.doc_currency.symbol or ''
        doc_subtotal = venda.lines_sum or 0
        doc_discount = venda.total_discount or 0
        doc_total = venda.total_document or 0
        doc_vat = venda.total_vat or 0
        desconto_comercial_perc = venda.desconto or ''
        
        extra_data = venda.extra_data or False
        should_print = venda.pagamento_directo or False
        
        if (extra_data and should_print) == True:
            extra_data = 'PRINT'
        elif ((extra_data==False) and (should_print==True)):
            extra_data = 'extenso'
        else:
            extra_data = ''

        extenso = venda.total_amount_str or ''
        banco_ref = venda.banco_id and venda.banco_id.bic or ''
        banco_nome = venda.banco_id and venda.banco_id.name or ''
        banco = '%s - %s' % (banco_ref, banco_nome)
        transaccao = venda.transaction or ''
        metodo = venda.payment_method and venda.payment_method.name
        
        segunda = venda.seg_via or False
        
        notes = venda.notes or ''
        
        _report = venda.doc_type.desc
        if _report:
            notes = notes + '\n%s' % _report or ''
        
        taxas = []
        
        isento_base = 0
        isento_amount = 0
        
        normal_vat_base = 0
        normal_vat_amount = 0
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        desconto_comercial = venda.desconto_comercial or 0
        
        if venda.print_other_currency and venda.alternative_currency:
            doc_currency = venda.alternative_currency
            alternative_amount = venda.alternative_currency_value or 0
            exchanged_currency = doc_currency.name or ''
            exchanged_total = doc_total/alternative_amount
        
        motivo_isencao = ''
        for line in venda.taxes_ids:
            if line.iva_id.tax==0:
                isento_base = isento_base + line.vat_base or 0
                isento_amount = isento_amount + line.vat_amount or 0
                motivo_isencao = venda.iva_isento and venda.iva_isento.name or ''
            else:
                normal_vat_base = normal_vat_base + line.vat_base or 0
                normal_vat_amount = normal_vat_amount + line.vat_amount or 0
                
        user = venda.user_id and venda.user_id.name or ''
        
        print_labels = []
        if venda.only_original:
            labe = venda.impressao and venda.impressao.name or ''
            print_labels = [labe]
        else:
            for print_label in venda.doc_type.prints_ids:
                print_labels.append(print_label.name or '')
        
        if not print_labels:
            raise osv.except_osv('Acção Inválida !', 'Não foram definidas vias de impressão!')

        #distribuidor_name = ''
        #distribuidor_street = ''
        #distribuidor_phone = ''
        #distribuidor_fax = ''
        #distribuidor_tin = ''
        #distribuidor_city = ''
        #distribuidor_web = ''
        #distribuidor_email = ''
        #distribuidor = venda.company_id and venda.company_id.supplier_id
        #if distribuidor:
        #    distribuidor_name = distribuidor.name or ''
        #    distribuidor_tin = distribuidor.nuit or ''
        #    distribuidor_web = distribuidor.website or ''
        #    addr = self.pool.get('res.partner').address_get(cr, uid, [distribuidor.id], ['default']) or None
        #    address_id = addr and addr.get('default', False)
        #    if address_id:
        #        address = self.pool.get('res.partner.address').browse(cr, uid, address_id)
        #        distribuidor_street = address.street or ''
        #        distribuidor_phone = address.phone or ''
        #        distribuidor_fax = address.fax or ''
        #        distribuidor_city = address.city or ''
        #        distribuidor_email = address.email or ''
        #    
        entrega_encomenda = venda.numero_encomenda or ''
        entrega_ordem = venda.ordem_encomenda or ''
        entrega_numero = venda.nota_entrega or ''
        
        transporte = {'car':'Por Estrada','sea':'Marítimo','plane':'Aéreo','train':'Comboio'}
        entrega_transporte = transporte.get(venda.transporte_encomenda, '')
        
        entrega_data = ''
        entrega_encomenda_data = ''
        if venda.data_entrega:
            entrega_data = datetime.strptime(venda.data_entrega, '%Y-%m-%d').strftime('%d/%m/%Y')
        if venda.data_encomenda:
            entrega_encomenda_data = datetime.strptime(venda.data_encomenda, '%Y-%m-%d').strftime('%d/%m/%Y')
        
        delivery_name = venda.nome_entrega or ''
        delivery_contact = venda.contacto_entrega or ''
        delivery_address = venda.morada_entrega or ''
        delivery_phone = venda.telefone_entrega or ''
        
        partner_logo = ''
        #if company and company.supplier_logo:
        #    partner_logo = company.supplier_logo
        #    
        doc_gpa = 0
        for line in venda.sales_lines:
            doc_gpa += line.gpa or 0
        
        doc_discount = doc_discount - doc_gpa

        for label in print_labels:
            for line in venda.sales_lines:
                line_prod_code = line.prod_id.default_code or ''
                line_prod_desc = line.prod_desc or line.prod_id.name  or ''
                line_unit = line.prod_uom and line.prod_uom.name or ''
                line_qty = line.qty or 0
                line_unit_price = line.unit_price or 0
                line_desc = line.discount_pct or 0
                line_tax = line.tax_id.tax or 0
                line_total = line.line_total or 0
                line_notes = line.notes or ''
                line_gpa = line.gpa or 0
                
                if line.iva_incluido:
                    valor_iva = 0
                    valor_iva_total = 0
                    imposto = line.tax_id.tax or 0
                    valor_iva_total = (line.qty*line.unit_price)-((line.qty*line.unit_price)/(imposto/100+1))
                    valor_iva = (line.unit_price)-((line.unit_price)/(imposto/100+1))
                    
                    iva_id = line.tax_id.id
                    line_unit_price = self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, iva_id, line_unit_price,  context=context)
                
                data = {
                        'print_name': label,
                        'COMPANY_LOGO' : logo_temp,
                        'product_logo': product_logo,
                        'licenca': licenca,
                        'company_name' : company_name,
                        'path': os.getcwd(),
                        'company_street' : company_street,
                        'company_phone' : company_phone,
                        'company_fax' : company_fax,
                        'company_tin' : company_tin,
                        'company_city' : company_city,
                        'company_email': company_email,
                        'company_web': company_web,
                        
                        'parent_partner': parent_partner_name,
                        'partner_name' : partner_name,
                        'partner_address' : partner_address,
                        'partner_tin' : partner_tin,
                        'partner_phone': partner_phone,
                        
                        'doc_date' : doc_date,
                        'doc_due_date' : doc_due_date,
                        'doc_payterm' : doc_payterm,
                        'doc_currency_name' : doc_currency_name,
                        'doc_type_name' : doc_type_name,
                        'doc_number' : doc_number,
                        'desconto_comercial_perc': desconto_comercial_perc,
                        
                        'line_prod_code' : line_prod_code,
                        'line_prod_desc' : line_prod_desc,
                        'line_unit' : line_unit,
                        'line_qty' : abs(line_qty),
                        'line_unit_price' : abs(line_unit_price),
                        'line_desc' : line_desc,
                        'line_tax' : abs(line_tax),
                        'line_total' : abs(line_total),
                        'line_note': line_notes,
                        'line_gpa': line_gpa,

                        'doc_currency_symbol' : doc_currency_symbol,
                        'doc_subtotal' : abs(doc_subtotal),
                        'doc_discount' : abs(doc_discount),
                        'doc_total' : abs(doc_total),
                        'doc_vat' : abs(doc_vat),
                        
                        'iva_isento_base': abs(isento_base),
                        'iva_isento_amount': abs(isento_amount),
                        'iva_17_base': abs(normal_vat_base),
                        'iva_17_amount': abs(normal_vat_amount),
                        
                        'notes': notes,
                        
                        'banco': banco_1,
                        'conta': conta_1,
                        'nib': nib_1,
                        'moeda': moeda_1,
                        
                        'banco_1': banco_2,
                        'conta_1': conta_2,
                        'nib_1': nib_2,
                        'moeda_1': moeda_2,
                        'print_date': now,
                        'desconto_comercial':desconto_comercial,
                        
                        'extra': extra_data,
                        'extenso': extenso,
                        'banco_tr': banco,
                        'transaccao': transaccao,
                        'metodo_pagamento': metodo,
                        
                        'exchanged_total': exchanged_total,
                        'exchanged_currency': exchanged_currency,
                        
                        'user': user,
                        
                        'motivo_isencao': motivo_isencao,
                        
                        'delivery_name': delivery_name,
                        'delivery_contact': delivery_contact,
                        'delivery_address': delivery_address,
                        'delivery_phone': delivery_phone,
                        #
                        #'distribuidor_fax': distribuidor_fax,
                        #'distribuidor_name': distribuidor_name,
                        #'distribuidor_street': distribuidor_street,
                        #'distribuidor_phone': distribuidor_phone,
                        #'distribuidor_tin': distribuidor_tin,
                        #'distribuidor_city': distribuidor_city,
                        #'distribuidor_web': distribuidor_web,
                        #'distribuidor_email': distribuidor_email,
                        
                        'entrega_encomenda': entrega_encomenda,
                        'entrega_ordem': entrega_ordem,
                        'entrada_numero': entrega_numero,
                        'entrada_transporte': entrega_transporte,
                        'entrada_data': entrega_data,
                        'entrada_encomenda_data': entrega_encomenda_data,
                        
                        #'PARTNER_LOGO': partner_logo,
                        'doc_gpa': doc_gpa,
                }
                result.append(data)
        print result
        return result

jasper_reports.report_jasper('report.encomenda_venda_report','dotcom.venda',parser=jasper_encomendas_venda)
