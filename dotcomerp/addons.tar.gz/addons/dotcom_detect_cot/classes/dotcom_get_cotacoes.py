# -*- coding: utf-8 -*-
from osv import fields,osv
from tools.translate import _
from lxml import etree
import time
from datetime import datetime,timedelta
import netsvc
import string
import logging

logger = logging.getLogger('DOTCOM_DEBUGGING')

class dotcom_get_cotacoes(osv.osv):
		
	_name='dotcom.get.cotacoes'
	_columns={
		'doc_type': fields.many2one('documento.tipo','Document Type'),
		'documents_ids': fields.one2many('dotcom.get.cotacoes.linha','parent',"Documents",readonly=True),
	
	}
	
	def carregar_cotacoes(self, cr, uid, ids,context=None):
		for document in self.browse(cr,uid,ids):
			linhas_to_remove=self.pool.get('dotcom.get.cotacoes.linha').search(cr,uid,[])
			self.pool.get('dotcom.get.cotacoes.linha').unlink(cr,uid,linhas_to_remove)
			logger.info('\n Entrou carregar_cotacoes')
			
				
			linhas_cotacao_ids = self.pool.get('dotcom.venda.linha').search(cr,uid,[])
			linhas_cotacao_obj=self.pool.get('dotcom.venda.linha').browse(cr,uid,linhas_cotacao_ids)
			
			produtos_ids=self.pool.get('product.product').search(cr,uid,[])
			produtos_objs=self.pool.get('product.product').browse(cr,uid,produtos_ids)
			logger.info('\n Terminou Carregamento de Documentos e Produtos')
			for linha in linhas_cotacao_obj:
				existe=False
				for product in produtos_objs:
					if linha.prod_id  == product.id:
						existe=True
						break
				if existe == False:
					vals={
							'venda_id':linha.document_top.id,
							'prod_id':linha.prod_id.id,
							'prod_desc':linha.prod_desc,
							'parent':document.id,
					}
					logger.info('\nProduto\n\n%s' % vals)
						
					self.pool.get('dotcom.get.cotacoes.linha').create(cr,uid,vals)
					
		return True
dotcom_get_cotacoes()

class dotcom_get_cotacoes_linha(osv.osv):
		
	_name='dotcom.get.cotacoes.linha'
	_columns={
		'parent':fields.many2one('dotcom.get.cotacoes','parent'),
		'venda_id': fields.many2one('dotcom.venda','Sale Document'),
		'prod_id':fields.integer('prod_id'),
		'prod_desc':fields.char('Descricao',size=64),
	}

dotcom_get_cotacoes_linha()