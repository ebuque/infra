{
    "name": "Web/URL widget",
    "description":
        """
        
        After installation of this module user can able to select multiple records in one2many field and delete them 
        in one time. 
        After installation of this module, restart OpenERP server in order to get effect of this module.
        We will wait for your valuable feedback to info@emiprotechnologies.com
        For support in OpenERP, please contact us on, support@emiprotechnologies.com
        --------------------
        
        For our different video's on OpenERP, please visit following link,

        http://www.emiprotechnologies.com/OpenERP/Video
        
        --------------------

        """,
    "version": "1.0",
    "author" : "Emipro Technologies",
    "website" : "http://www.emiprotechnologies.com",
    "category" : "Tools",
    "depends" : ["web"],
    "js": [
        "static/src/js/view_form.js",
    ],
    "images": ['images/web_url.png'],
    "auto_install": False,
}
