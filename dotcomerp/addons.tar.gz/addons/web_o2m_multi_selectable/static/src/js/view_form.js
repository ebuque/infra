openerp.web_o2m_multi_selectable = function(openerp) {
    var _t = openerp.web._t,
       _lt = openerp.web._lt;
    var QWeb = openerp.web.qweb;

openerp.web.form.FieldOne2Many = openerp.web.form.FieldOne2Many.extend({
	// Added by Hiren Vora @ Emipro Technologies
	multi_selection : true
});
}
