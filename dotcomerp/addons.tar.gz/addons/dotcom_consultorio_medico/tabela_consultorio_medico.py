# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields, osv
from datetime import datetime, timedelta
import time
import datetime
from tools.translate import _
import binascii
import tools
import pooler
import logging
from validators import validator
from lxml import etree

from dateutil import parser

logger = logging.getLogger('DOTCOM_DEBUGGING')


def _lista_especialidades_domain(self,cr,uid,context=None): # Método para listar as especialidades dos médicos
	if context is None:
		context={}

	obj_lista_especialidades = self.pool.get('dotcom.consutorio.especialidades').search(cr,uid,[])
	lista_especialidades = []

	for elemento in obj_lista_especialidades:
		especialidade = self.pool.get('dotcom.consutorio.especialidades').browse(cr,uid,elemento)
		nome_especialidade = especialidade.especialidade
		lista_especialidades.append((especialidade.id,nome_especialidade))

	return lista_especialidades


class dotcom_consultorio(osv.osv):
	_name = 'dotcom.consutorio'
	_columns={
		'referencia' : fields.char("Referência",size=64, readonly=True),
		'data_consulta' : fields.date("Data da Consulta", required=True, readonly=True, states={'rascunho':[('readonly',False)],'edicao':[('readonly',False)]}),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear',"Ano Fiscal", required=False, readonly=True),
		'especialidade' : fields.many2one('dotcom.consutorio.especialidades',"Especialidade", required=True, readonly=True, states={'rascunho':[('readonly',False)],'edicao':[('readonly',False)]}),
		'dominio_especialidade' : fields.selection(_lista_especialidades_domain),
		'lista_medicos_por_especialidade': fields.many2many('dotcom.consutorio.medicos','rel_consulta_medicos','medicos_id','consutas_id'),
		'paciente_info':fields.many2one('dotcom.consutorio.pacientes',"Paciente", required=True, readonly=True, states={'rascunho':[('readonly',False)],'edicao':[('readonly',False)]}),
		'data_de_nascimento':fields.date("Data de Nascimento", readonly=True),
		'idade_paciente':fields.integer("Idade (Anos)",readonly=True),

		'state': fields.selection([
            ('rascunho','Rascunho'), 
            ('marcado','Marcado'),
            ('facturado','Facturado'),
            ('edicao','Edição'),
            ('cancelado','Cancelado')],
            "Estado", required=True)
	}

	_defaults={
		'state': lambda *a:'rascunho',
        'data_consulta': lambda *a:time.strftime('%Y-%m-%d'),
        'ano_fiscal_id': lambda self,cr,uid,context:self.atribuir_ano_fiscal_default(cr,uid,context)
    }

	
	def emitir(self,cr,uid,ids,ano_fiscal_id,context=None): # Método para emitir a marcação da consulta
		if context is None:
			context={}

		prefixo = "CONSULTA"
		for formulario in self.browse(cr,uid,ids):
			anos_fiscais_ids=self.pesquisa_ano_fiscal(cr,uid,formulario.data_consulta,context)
			self.write(cr,uid,ids,{'ano_fiscal_id':anos_fiscais_ids[0]})
			anos_fiscais = self.pool.get('configuration.fiscalyear').browse(cr,uid,anos_fiscais_ids[0])
			registos_ids = self.pool.get('dotcom.consutorio').search(cr,uid,[])
			referencia=validator.referenciador(cr,uid,anos_fiscais,registos_ids,prefixo,context)

			logger.info('IDADE PACIENTE: %s' %str(formulario.idade_paciente))

			ano_nascimento_paciente=self.obter_ano_nascimento(cr,uid,formulario.paciente_info.id,context)

			idade_actual_paciente = self.obter_idade(cr,uid,formulario.paciente_info.id,context)

			self.write(cr,uid,ids,{'state':'marcado', 'referencia':referencia,'data_de_nascimento':ano_nascimento_paciente, 'idade_paciente':idade_actual_paciente})

		return True

	def editar(self,cr,uid,ids,context=None): # Método para editar a marcação da consulta (voltar para rascunho)
		if context is None:
			context={}

		self.write(cr,uid,ids,{'state':'edicao'})

		return True

	def obter_info_facturacao(self,cr,uid,paciente,context=None):
		if context is None:
			context={}

		obj_paciente=self.pool.get("dotcom.consutorio.pacientes").browse(cr,uid,paciente)
		nome_paciente = obj_paciente.nome
		entidade_a_facturar_id = obj_paciente.entidade_a_facturar.id

		obj_parceiro = self.pool.get("res.partner").browse(cr,uid,entidade_a_facturar_id)

		nome_parceiro = obj_parceiro.name
		nuit_parceiro = obj_parceiro.nuit
		

		nota_factura = "Consulta do Colaborador: " + nome_paciente
		partner='customer'

		obj_user_logado = self.pool.get("res.users").browse(cr,uid,uid)

		user_logado_empresa_id = obj_user_logado.company_id

		obj_dados_empresa=self.pool.get("res.company").browse(cr,uid,user_logado_empresa_id)

		tipo_documento_facturacao_consultorio = obj_dados_empresa.tipo_documento_consultorio
		sequencia_padrao_facturacao_consultorio = obj_dados_empresa.sequencia_id_consultorio

		cabecalho_venda = {
                       
        				'partner_id':entidade_a_facturar_id,
						'partner_address_id':2,
              			'partner_type':partner,
                		'partner_name':nome_parceiro,
                		'partner_address':"Av. das Amendoas, 546",
						'partner_nuit_name':nuit_parceiro,
						'doc_type':tipo_documento_facturacao_consultorio,
						'document_date':"02-11-2016",
						'due_date':"02-11-2016",
						'payment_term_id':1,
						'sequence_id':sequencia_padrao_facturacao_consultorio,
						'doc_state':'draft',
						'state':'draft',
						'total_vat':17,
						'lines_sum':100,
						'total_document':117,
						'notes':nota_factura
        	}

		return cabecalho_venda


	def facturar(self,cr,uid,ids,context=None): # Método para gerar factura da consulta
		if context is None:
			context={}

		cabec_venda = {}
		for formulario in self.browse(cr,uid,ids):
			cabec_venda = self.obter_info_facturacao(cr,uid,formulario.paciente_info.id,context)




		#venda_cabec = self.pool.get('dotcom.venda').create(cr,uid,cabec_venda)

		#self.write(cr,uid,ids,{'state':'facturado'})


		# Informação para a facturação
		return {
        		'type': 'ir.actions.act_window',
        		'name': 'Emissão de Documento de Venda',
        		'view_mode': 'form',
        		'view_type': 'form',
        		'res_model': 'dotcom.venda',
        		'target': 'new',
				'nodestroy': True,
				#'context': context.update({'doc_type':1}, )
				#'context':{'doc_type':1,'document_date':"02-11-2016",'due_date':"02-11-2016"}
				'context': {
							'default_doc_type': cabec_venda['doc_type'],
							'default_partner_type': cabec_venda['partner_type'],
							'deafult_sequence_id': cabec_venda['sequence_id'],
							'default_partner_id': cabec_venda['partner_id'],



							},
    			}

	def cancelar(self,cr,uid,ids,context=None): # Método para Cancelar
		if context is None:
			context={}

		self.write(cr,uid,ids,{'state':'cancelado'})

		return True


	def atribuir_ano_fiscal_default(self,cr,uid,context=None): # Método que atribui o ano fiscal
		if context is None:
			context={}

		data_hoje = datetime.datetime.now().strftime('%Y-%m-%d');

		anos_fiscais_ids=self.pool.get("configuration.fiscalyear").search(cr,uid,[
                                                                                ('date_start','<=',data_hoje),
                                                                                ('date_stop','>=',data_hoje)])
		ano_fiscal_actual = anos_fiscais_ids[0]

		return ano_fiscal_actual


	def verificar_disponibilidade(self,cr,uid,ids,context=None): # Métoto por desenvolver para continuar a desenvolver !!!!!!!!!!
		if context is None:
			context={}

		for documento in self.browse(cr,uid,ids):

			medicos_ids=self.pool.get('dotcom.consutorio.medicos').search(cr,uid,[('especialidade','=',documento.especialidade.id)])
			logger.info('MEDICOS DISPONIVEIS %s' %str(medicos_ids))
			self.write(cr,uid,ids,{'lista_medicos_por_especialidade':[(medicos_ids,5)]})

		return True

	def on_change_data(self,cr,uid,ids,data,context=None): # Método onchange para prencher o ano fiscal
		if context is None:
			context={}

		anos_fiscais_ids=self.pesquisa_ano_fiscal(cr,uid,data,context)

		if len(anos_fiscais_ids)<=0:
			raise osv.except_osv(_('Acção inválida'),('Ano Fiscal não existe'))

		return {'value':{'ano_fiscal_id':anos_fiscais_ids[0]}}

	def pesquisa_ano_fiscal(self,cr,uid,data,context=None): # Médodo para pesquisar o ano fiscal de acordo com a data
		if context is None:
			context={}

		anos_fiscais_ids=self.pool.get("configuration.fiscalyear").search(cr,uid,[
                                                                                ('date_start','<=',data),
                                                                                ('date_stop','>=',data)])

		return anos_fiscais_ids

	def obter_ano_nascimento(self,cr,uid,paciente,context=None): # Método para ir buscar o ano de nascimento na DB
		if context is None:
			context={}

		obj_paciente=self.pool.get("dotcom.consutorio.pacientes").browse(cr,uid,paciente)

		ano_nascimento=obj_paciente.data_de_nascimento

		return ano_nascimento

	def obter_idade(self,cr,uid,paciente,context=None): # Método para calcular a idade
		if context is None:
			context={}

		data_actual = datetime.datetime.now()
		ano_actual = data_actual.year

		ano_nascimento = self.obter_ano_nascimento(cr,uid,paciente,context)

		data_de_nascimento_paciente = datetime.datetime.strptime(ano_nascimento, "%Y-%m-%d")

		ano_nascimento_paciente = data_de_nascimento_paciente.year

		idade_actual = ano_actual - ano_nascimento_paciente

		return idade_actual

	def on_change_paciente(self,cr,uid,ids,paciente,context=None): # Método para o prencher a data de nascimento e idade do paciente
		if context is None:
			context={}

		idade_do_paciente = self.obter_idade(cr,uid,paciente,context)

		data_de_nascimento = self.obter_ano_nascimento(cr,uid,paciente,context)

		return {'value':{'data_de_nascimento':data_de_nascimento,'idade_paciente':idade_do_paciente}}


dotcom_consultorio()# Fim da Classe
