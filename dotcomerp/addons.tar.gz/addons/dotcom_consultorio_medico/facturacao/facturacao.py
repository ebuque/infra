# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('definicoe_defaults_wizards')


class dotcom_consultorio_conf_venda(osv.osv):
    _name = 'res.company'
    _inherit = 'res.company'
    _columns={
        'tipo_documento_consultorio': fields.many2one('documento.tipo','Tipo de Documento', required=True, ),
        'prod_id_consultorio': fields.many2one('product.product','Produto',domain=[('sale_ok','=',True)], required=True,),
        'prod_desc_consultorio': fields.char('Descrição do Produto',size=128,  required=True),
        'doc_state_consultorio':fields.selection([('rascunho','Rascunho'),('emitido','Emitido')],'Doc. Estado',required=True),
        'sequencia_id_consultorio':fields.many2one('dotcom.sequence','Sequência',),
        #'configuracao':fields.one2many('res.company','wizard_id','Configurações',)
    }


    def on_click_alvar(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        val={}
        for documento in self.browse(cr,uid,ids):
            #tipo_doc=
            val={
                'tipo_documento':documento.tipo_documento.id,
                'prod_id':documento.prod_id.id,
                'prod_desc':documento.prod_desc,
            }
            logger.info('PRAZO %s' % str(val))
            
        object=self.pool.get('res.company')
        identificadores=object.search(cr,uid,[])
        #if identificadores and len(identificadores)>0:
        #    for definicao in identificadores:
        object.unlink(cr,uid,identificadores)
        #self.pool.get('res.company').create(cr,uid,val)
        return True
    
    
    def on_change_produto(self,cr,uid,ids,produto,context=None):
        if context is None:
            context={}
        produto=self.pool.get('product.product').browse(cr,uid,produto)
        val={'prod_desc':produto.name}
        logger.info('DESC %s' % str(val))
        return{'value':val}
        
dotcom_consultorio_conf_venda()