{
    "name": "Hello",
    "category": "Hidden",
    "description":
        """
        OpenERP Web example module.
        """,
    "version": "2.0",
    "depends": [],
    "js": ["static/*/*.js", "static/*/js/*.js"],
    "css": [],
    'active': False,
    'web_preload': False,
}
