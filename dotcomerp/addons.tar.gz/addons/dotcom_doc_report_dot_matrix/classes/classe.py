# -*- coding: utf-8 -*-
from osv import fields,osv
from tools.translate import _
from lxml import etree
import time
from datetime import datetime,timedelta
import netsvc
import string
import logging

logger = logging.getLogger('DOTCOM_DEBUGGING')

class dotcom_classe_dot_matrix(osv.osv):
        
    _name='dotcom.classe.dot.matrix'
    _columns={
        'nome': fields.char('Nome',size=32),
       
    }
dotcom_classe_dot_matrix()