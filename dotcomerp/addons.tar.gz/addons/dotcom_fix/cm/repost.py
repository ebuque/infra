# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import osv, fields
import logging
logger = logging.getLogger('FIX:')
import time

from tools.translate import _

class dotcom_fix_repost_sales(osv.osv):
    _name = 'dotcom.fix.recibo.aug'
    _columns = {'recibo_ids': fields.many2many('dotcom.recebimento','dotcom_fix_recibos_ve_rel', 'fix_id', 'recibo_id', 'Recibos')}
    
    def search(self, cr, uid, ids , context={}):
        src = self.pool.get('dotcom.venda').search(cr, uid, [('partner_id','=',155),('state','!=','done')])
        saldo = 0.0
        total = 0.0
        lista = []
        # 
        pendentes2 = self.pool.get('dotcom.venda.pendente').search(cr, uid, [('venda_id','in',src)])
        for one in self.pool.get('dotcom.venda.pendente').browse(cr, uid,pendentes2):
            total += one.amount_remaining or 0.0
        # 
        for each in self.pool.get('dotcom.venda').browse(cr, uid, src):
            valor_pagamentos = 0.0
            for pagamentos in each.pagamento_ids:
                if pagamentos.state != 'cancel':
                    valor_pagamentos += pagamentos.payed_amount or 0.0
                else:
                    pass
            if valor_pagamentos <> each.total_document or 0.0:
                pendentes = self.pool.get('dotcom.venda.pendente').search(cr, uid, [('venda_id','=',each.id)])
                
                if pendentes:
                    pendentes_obj = self.pool.get('dotcom.venda.pendente').browse(cr, uid, pendentes and pendentes[0])
                    # total += pendentes_obj.amount_remaining
                    if pendentes_obj.amount_remaining <> each.total_document - valor_pagamentos:
                        logger.info('\n\n%s' % each.document_number)
                else:
                    lista.append(each.document_number)
        logger.info('\nLISTA no pendentes: %s\n\nTOTAL: %s' % (lista,total))
        # logger.info('Saldo: %s\nLISTA: %s' % (saldo, lista))
    
    def processar(self,cr, uid, ids, context=None):
        if context is None:
            context = {}
        
        this = self.browse(cr,uid, ids and ids[0])
        for pagamento in this.recibo_ids:
            excesso = 0.0
            self.pool.get('dotcom.recebimento').write(cr,uid, pagamento.id,{'valor_excesso': True})
            for linha in pagamento.receivable_linhas:
                saldo = linha.temp_real_remaining or 0.0
                total = linha.temp_document_total_amount or 0.0
                linha_id = linha.id
                
                if saldo > total:
                    saldo = saldo/2
                    res = {}
                    res['real_remaining'] = saldo
                    res['amount_remaining'] = saldo
                    res['temp_real_remaining'] = saldo
                    res['allow_excesso'] = True
                    self.pool.get('dotcom.recebimento.linha').write(cr, uid, [linha_id], res)
                    
                    if linha.amount_payed > saldo:
                        excesso += linha.amount_payed - saldo
            if excesso>0:
                excesso_id = self.criar_valor_excesso(cr, uid, pagamento.id, valor_excesso=excesso)
                self.pool.get('dotcom.recebimento').write(cr,uid, pagamento.id,{'valor_excesso': True,'auto_doc': excesso_id})

            logger.info('\nExcesso %s: %s' % (pagamento.document_number, excesso))
    
    def criar_valor_excesso(self, cr, uid, pagamento_id, valor_excesso=0.0, context=None):
        if context is None:
            context = {}
        pagamento = {}
        document = self.pool.get('dotcom.recebimento').browse(cr,uid, pagamento_id)
        excesso = abs(valor_excesso)
        
        exc_doc_type = document.doc_type and document.doc_type.excesso_doc_id
        if exc_doc_type:
            
            pagamento = {}
            
            seq = None
            
            sequence = exc_doc_type.default_sequence and exc_doc_type.default_sequence.id or None
            if sequence:
                pagamento['seq_id'] = sequence
            else:
                raise osv.except_osv(_('Erro !'), _('Para o documento de valores em excesso a criar, não existe uma sequencia prédefinida'))
            
            pagamento['doc_type'] = exc_doc_type.id
            pagamento['partner_id'] = document.partner_id.id
            pagamento['partner_address_id'] = document.partner_address_id.id
            pagamento['partner_nuit'] = document.partner_nuit
            pagamento['partner_contact'] = document.partner_contact
            pagamento['partner_currency_id'] = document.doc_currency.id
            pagamento['document_date'] = time.strftime('%Y-%m-%d')or document.document_date
            pagamento['is_adc'] = True
            pagamento['is_last'] = False
            pagamento['period_id'] = document.period_id.id
            
            pagamento['partner_type'] = document.partner_type
            pagamento['amount_total'] = self.pool.get('dotcom.recebimento').pattern(cr,uid,abs(excesso))
            pagamento['amount_remaining'] = 0
            pagamento['amount_payed'] = self.pool.get('dotcom.recebimento').pattern(cr,uid,abs(excesso))
            pagamento['exchanged_total'] = self.pool.get('dotcom.recebimento').pattern(cr,uid,abs(excesso))
            pagamento['exchanged_vat'] = self.pool.get('dotcom.recebimento').pattern(cr,uid,abs(excesso))
            
            pagamento['company_id'] = document.company_id.id
            pagamento['payment_method'] = document.payment_method.id
            pagamento['doc_currency'] = document.doc_currency.id
            pagamento['exchange_rate'] = self.pool.get('dotcom.recebimento').pattern(cr,uid,1)
            pagamento['doc_currency_str'] = document.doc_currency_str
            
            pagamento['user_id'] = document.user_id.id
            pagamento['state'] = 'draft'    
            
            pagamento['doc_type'] = exc_doc_type.id
            others = self.pool.get('dotcom.recebimento').on_change_doc_type(cr, uid, None, exc_doc_type.id, context=context).get('value')
            pagamento = dict(pagamento.items() + others.items())
            
            payment = None
            if document.auto_doc:
                auto_document = document.auto_doc
                unlinkable_lines = []
                for line in auto_document.adiantamentos_linhas_ids:
                    unlinkable_lines.append(line.id)
                self.pool.get('dotcom.recebimento.adc.linha').unlink(cr, uid, unlinkable_lines)
                self.pool.get('dotcom.recebimento').write(cr, uid, auto_document.id, pagamento,context=context)
                payment = auto_document.id
            else:
                payment = self.pool.get('dotcom.recebimento').create(cr, uid, pagamento,context=context)
            
            adc_line = {}
            adc_line['amount_payed'] = abs(excesso)
            adc_line['desc'] = _('Valores em Excesso de %s numero %s') % (document.doc_type.name,document.document_number)
            adc_line['pagamento_id'] = payment
            
            self.pool.get('dotcom.recebimento.adc.linha').create(cr, uid, adc_line)
            if document.auto_doc:
                self.pool.get('dotcom.recebimento').re_confirm_payment(cr,uid,[payment], context=context)
            else:
                self.pool.get('dotcom.recebimento').confirm_payment(cr, uid, [payment], context=context)
        
        return payment