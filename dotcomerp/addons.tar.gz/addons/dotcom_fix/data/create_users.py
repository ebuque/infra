# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import osv, fields

import logging
logger = logging.getLogger('dotcom_data')

class dotcom_fix_create_users(osv.osv_memory):
    _name = 'dotcom.fix.create.users'
    _columns = {
                'conta_id': fields.many2one('dotcom.contabilidade.plano.contas', 'Conta Pai', required=True),
                'code': fields.char('Referência', size=20, required=True),
                'number': fields.integer('Inicio'),
                'ano_id': fields.many2one('configuration.fiscalyear', 'Ano Fiscal'),
                'link_account': fields.boolean('Conectar plano de conta'),
                'partner_type': fields.selection([('customer', 'Cliente'),('supplier','Fornecedor'),('debtor','Devedor'),('creditor','Credor')], 'Tipo de Parceiro'),
    }
    _defaults = {'number': 1, 'code': 'CL', 'partner_type': 'customer'}
    _rec_name = 'code'
    
    def create_users(self, cr, uid, ids, context={}):
        browse = self.browse(cr, uid, ids and ids[0], context=context)
        number = browse.number or 1
        code = browse.code or 'CL'
        ano_id = browse.ano_id and browse.ano_id.id or False
        conta_id = browse.conta_id and browse.conta_id.id or False
        
        logger.info('\nSearching for available accounts')
        contas = self.pool.get('dotcom.contabilidade.plano.contas').search(cr, uid, [('parent_id','=',conta_id),('ano_fiscal_id','=',ano_id)])
        
        partner_type = browse.partner_type or 'customer'
        link = browse.link_account or True
        
                
        logger.info('\nSetting default data')
        values = {}
        values['active'] = True
        values['company_id'] = self.pool.get('res.company')._company_default_get(cr, uid, 'dotcom.venda', context=context)
        values[partner_type] = True
        res = []
        logger.info('\nReading found account data')
        
        for conta in self.pool.get('dotcom.contabilidade.plano.contas').read(cr, uid, contas, ['nome','id']):
            values['ref'] = '%s%s' % (code, str(number).zfill(4))
            values['name'] = conta.get('nome', '')
            if link:
                values['ano_contab_id'] = ano_id
                values['conta_%s_id' % partner_type] = conta.get('id', False)
            logger.info('Creating parter info')
            partner_id = self.pool.get('res.partner').create(cr, uid, values)
            contacts = {}
            contacts['partner_id'] = partner_id
            contacts['name'] = conta.get('nome', '')
            contacts['type'] = 'default'
            contacts['active'] = True
            self.pool.get('res.partner.address').create(cr, uid, contacts)
            res.append(partner_id)
            number += 1
        
        return {
            'type': 'ir.actions.act_window',
            'name': 'Parceiros Criados',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'context': context,
            'domain' : [('id','in',res)],
            'res_model': 'res.partner',
            'nodestroy': True,
        }
        
dotcom_fix_create_users()