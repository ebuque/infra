# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import osv, fields
import time
import base64
import csv     # imports the csv module

import logging
logger = logging.getLogger('dotcom_data')

class dotcom_fix_data_importer_list(osv.osv):
    _name = 'dotcom.fix.data.importer.list'
    _columns = {
                'priority': fields.integer('Sequência'),
                'name': fields.char('Campo', size=120,required=True),
                'import_id': fields.many2one('dotcom.fix.data.importer', 'Importer', invisible=True),
    }
dotcom_fix_data_importer_list()

class dotcom_fix_data_importer(osv.osv):
    _name = 'dotcom.fix.data.importer'
    _description = 'Utilitário para importação de dados de ficheiros'
    _columns = {
                    'file': fields.binary('Ficheiro',readonly=True,states={'draft':[('readonly',False)]}),
                    'file_type': fields.char('Extensão do Ficheiro', size=15, required = True,readonly=True,states={'draft':[('readonly',False)]}),
                    'table_id': fields.many2one('ir.model', 'Objecto a importar',readonly=True,states={'draft':[('readonly',False)]}),
                    'datetime': fields.datetime('Data e Hora',readonly=True,states={'draft':[('readonly',False)]}),
                    'user_id': fields.many2one('res.users', 'Usuário',readonly=True,states={'draft':[('readonly',False)]}),
                    'list_ids': fields.one2many('dotcom.fix.data.importer.list','import_id','Lista de Campos',readonly=True,states={'draft':[('readonly',False)]}),
                    'state': fields.selection([('draft', 'Rascunho'),('done','Emitido')], 'Estado', readonly=True),
                    'header': fields.boolean('Inclui cabeçalhos'),
                }
    _defaults = {
                    'user_id': lambda s, cr, u, c: u,
                    'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
                    'file_type': 'csv',
                    'state': 'draft',
                    'header': True,
                 }
    
    def write_file(self, binary, path='/tmp/'):
        crypted_file = base64.b64decode(binary)
        f = open(path, 'w+')
        try:
            f.write(crypted_file)
        finally:
            f.close()
        return path
    
    def read_csv(self, path, header=True):
        data = []
        f = open(path, 'rb')         # opens the csv file
        try:
            reader = csv.reader(f)          # creates the reader object
            num = 0
            for row in reader:             # iterates the rows of the file in orders
                if header and num == 0:
                    continue
                else:
                    r2 = []
                    r1 = str(row[0]).split(';')
                    for i in r1:
                        try:
                            r2.append(eval(i))
                        except Exception:
                            r2.append(str(i))
                    data.append(r2)
                num += 1
        finally:
            f.close()                       # closing
        return data
    
    def parse(self, data, dicionario={}):
        values = []
        for row in data:
            val = {}
            for dic in dicionario:
                try:
                    val[dicionario.get(dic)] = row[int(dic)]
                except IndexError:
                    if dic == 2:
                        val[dicionario.get(dic)] = 1
            values.append(val)
        return values
            
    
    def start_action(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        browse = self.browse(cr, uid, ids and ids[0], context=context)
        if not browse.file:
            raise osv.except_osv('Erro !', 'Ficheiro não foi carregado!')
        path = '/tmp/%s.%s' % (time.strftime('%H%M%S'),browse.file_type)
        header = browse.header or False
        self.write_file(browse.file,path=path)
        data = self.read_csv(path, header=header)
        
        dicts = {}
        for lista in browse.list_ids:
            dicts[lista.priority] = lista.name
        vals = self.parse(data, dicionario=dicts)
        logger.info('\nParsed:\n\n%s' % vals)
        return {}
    
dotcom_fix_data_importer()