# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


{
    'name': 'DotComERP - Maintenance Module',
    'version': '1.3',
    'description': '''Module designed to work as a maintenance and update server for DotComERP(R) 2013''',
    'author': 'DotCom, LDA',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'complexity': 'easy',
    'category': 'DotComERP',
    'depends': ['dotcom_base','dotcom_doc_base','dotcom_doc','dotcom_stock','dotcom_doc_reports','dotcom_notification_cm','dotcom_cm_conversion'],
    'init_xml': [],
    'update_xml':['menu.xml',
                  'cm/repost.xml',
                  'june/view/pendentes_view.xml',
                  'february_2016/view/processamento_bloco.xml',
                  'february_2016/view/stock.xml',
                  'data/importer.xml',
                  # 'data/create_users.xml'
                  ],
    'demo_xml': [],
    'images' : [],
    'test': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
