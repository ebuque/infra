# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields,osv
import time
import logging
logger = logging.getLogger('jasper_print')

class dotcom_fix_2013_june_pendentes(osv.osv_memory):
    _name='dotcom.fix.2013.june.pendentes'

    _columns ={
        'confirm_action' : fields.boolean('Processar documentos Emitidos'),
        }

    def sequences(self, cr, uid, ids, context={}):
        src = self.pool.get('dotcom.sequence').search(cr, uid, [('fiscal_year_id','=',2),('documento_tipo_id','!=',False)])
        for each in self.pool.get('dotcom.sequence').read(cr, uid, src, ['id','code','documento_tipo_id','serie_id']):
            id = each.get('id')
            code = each.get('code', (False,))
            split = str(code).split('/')[0]
            src_type = self.pool.get('dotcom.sequence.type').search(cr, uid, [('name','=',split)])
            if src_type:
                self.pool.get('dotcom.sequence.type').unlink(cr, uid, src_type)
            
            doc_type = self.pool.get('documento.tipo').read(cr, uid, each.get('documento_tipo_id', (False,))[0], ['ref']).get('ref')
            serie = self.pool.get('dotcom.sequence.serie').read(cr, uid, each.get('serie_id', (False,))[0], ['ref']).get('ref')
            ano = 2016
            code_str = '%s/%s/%s' % (doc_type,serie,ano)
            name = '%s/%s' % (serie,ano)
            self.pool.get('dotcom.sequence.type').create(cr, uid, {'name': name, 'code': code_str})
            cr.commit()
            self.pool.get().write(cr, uid, id, {'code': code_str})
            logger.info('\nCreate: %s' % code_str)
        return {}
    
    def start_action(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,['confirm_action'])
        logger.info('\nReading button state %s' % data)
        _counter = []
        if data:
            logger.info('\nA ler lista de pendentes')
            for each in self.pool.get('dotcom.venda.pendente').search(cr, uid, []):
                UNLINKED = None
                REPOSTED = None
                logger.info('\nA processar pendente: %s' % each)
                this = self.pool.get('dotcom.venda.pendente').browse(cr, uid, each)
                logger.info('\nVenda origem %s' % this.venda_id)
                logger.info('\nTotal da Venda %s' % this.amount_remaining)
               
                if this.amount_remaining != 0:
                    if this.venda_id:
                        if this.venda_id.doc_type.pagar_directamente_selection == 'activo':
                            logger.info('''
                                        ################################
                                        #     A apagar Registo
                                        #     Preparar Reset
                                        #     Re emitir documento
                                        ################################''')
                            venda_id = [this.venda_id.id]
                            doc_type = this.venda_id.doc_type.ref
                            doc_number = this.venda_id.document_number or ''
                            self.pool.get('dotcom.venda.pendente').unlink(cr, uid, each)
                            self.pool.get('dotcom.venda').run_reset(cr, uid, venda_id, context=context)
                            self.pool.get('dotcom.venda').post(cr, uid, venda_id, context=context)
                            REPOSTED = '%s  %s' %(doc_type, doc_number)
                        else:
                            continue
                else:
                    logger.info('\nTOTAL A ZERO =====>>>> Writing as done')
                    
                    #self.pool.get('dotcom.venda').write(cr, uid, [this.venda_id.id], {'state':'done'})
                    if this.venda_id.doc_type.ligar_cc == True:
                        self.pool.get('dotcom.venda').write(cr, uid, [this.venda_id.id], {'state':'done'})
                    UNLINKED = '%s  %s' %(this.venda_id.doc_type.ref, this.venda_id.document_number or '')
                    self.pool.get('dotcom.venda.pendente').unlink(cr, uid, each)
                    
                _counter.append(UNLINKED)
                _counter.append(REPOSTED)
        for one in _counter:
            logger.info('\n--------------------------------')
            logger.info('\n%s' % one)
        
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
 
dotcom_fix_2013_june_pendentes()