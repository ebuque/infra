# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2016 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


from osv import osv
import logging
logger = logging.getLogger('STOCK:FIX')

class dotcom_stock_fix(osv.osv_memory):
    _name='dotcom.fix.2016.may.stock'
    _columns = {}
    
    def process(self, cr, uid, ids, context={}):
        search = self.pool.get('dotcom.stock.report').search(cr, uid, [], order='id,DATE ASC')
        number_next = 1
        res = {}
        models = {}
        # , ['ordem','id', 'model_id', 'origin_id']
        for each in self.pool.get('dotcom.stock.report').browse(cr, uid, search):
            model = each.model_id
            model_id = model and model.id
            origin_id = each.origin_id
            
            ordem = each.ordem
            id = each.id
            new_number = False
            if res.has_key((model_id, origin_id)):#res.get((model_id, origin_id), False):
                new_number = res.get((model_id, origin_id))
            else:
                new_number = number_next + 1
                number_next = number_next + 1
            self.pool.get('dotcom.stock.report').write(cr, uid, id, {'ordem': new_number})
            res[(model_id, origin_id)] = new_number
            
            model_name = ''
            if models.has_key(model_id):
                model_name = models.get(model_id)
            else:
                model_name = model and model.model
                models[model_id] = model_name
            
            logger.info('\nModel Name: %s \t\tID: %s\t\tNumber: %s' % (model_name,origin_id,new_number))
            try:
                self.pool.get(model_name).write(cr, uid, [origin_id], {'report_id': new_number})
            except AttributeError:
                pass
            # except Exception:
                # pass
        counter = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_stock', 'stock_counter')
        self.pool.get('dotcom.stock.sequence').write(cr, uid, counter.id, {'name': number_next})
        return {}