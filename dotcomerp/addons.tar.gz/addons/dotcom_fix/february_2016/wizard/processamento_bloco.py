# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2016 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields,osv
import time
import logging
logger = logging.getLogger('jasper_print')

class dotcom_fix_2016_february_processamento_bloco(osv.osv_memory):
    _name='dotcom.fix.2016.february.processamento_bloco'
    _columns = {
                'doc_type': fields.selection([('sales','Vendas'),('purchase','Compras'),('pay_rec','Recebimentos'),('payable','Pagamentos')],'Tipo de Documentos', required=True),
                'sale_ids': fields.many2many('dotcom.venda','fix_pb_sales','fix_id','sale_id','Vendas'),
                'purchase_ids': fields.many2many('dotcom.compra','fix_pb_purchase','fix_id','purchase_id','Compras'),
                'receivable_ids': fields.many2many('dotcom.recebimento','fix_pb_receivable','fix_id','receivable_id','Recebimentos'),
                'purchase_ids': fields.many2many('dotcom.pagamento','fix_pb_purchase','fix_id','purchase_id','Pagamentos'),
                'action': fields.selection([('reset','Definir para Rascunho'),('post','Emitir'),('cancel','Cancelar')], 'Acção', required=True),
                'uid': fields.many2one('res.users', 'Usuário', required=True, readonly=True),
                'datetime': fields.datetime('Data e Hora', readonly=True),
                'motivo': fields.text('Motivos de Cancelamento'),
    }
    _defaults = {
                'uid': lambda s, cr, u, c: u,
                'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    def start_action(self, cr, uid, ids, context={}):
        for each in self.read(cr, uid, ids, []):
            classe = 'dotcom.venda'
            lista = []
            classe_each = each.get('doc_type')
            if classe_each == 'sales':
                classe = 'dotcom.venda'
                lista = each.get('sale_ids')
            elif classe_each == 'purchase':
                classe = 'dotcom.compra'
                lista = each.get('purchase_ids')
            elif classe_each == 'pay_rec':
                classe = 'dotcom.recebimento'
                lista = each.get('receivable_ids')
            elif classe_each == 'payable':
                classe = 'dotcom.pagamento'
                lista = each.get('purchase_ids')
            
            logger.info('\nClasse: %s\nIDS:%s' % (classe,lista))
        
        return {}

dotcom_fix_2016_february_processamento_bloco()