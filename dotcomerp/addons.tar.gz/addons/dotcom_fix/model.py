# -*- encoding: utf-8 -*-


import time
import datetime
import calendar
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_comercial_actualiza(osv.osv):
    _name='dotcom.gestao.comercial.actualiza'
    _columns={
                'tipo_documento':fields.many2one('documento.tipo','Documento'),
                'linhas_ids':fields.one2many('dotcom.gestao.comercial.actualiza.linha','documento_id', readonly=True),
            }
    
    
    def actualiza(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            
            for linha in documento.linhas_ids:
                self.pool.get('dotcom.gestao.comercial.actualiza.linha').unlink(cr,uid,linha.id)
                
            linhas_documento_ids=self.pool.get('dotcom.venda').search(cr,uid,[
                                                                                ('state','=','done'),
                                                                                ('doc_type','=',documento.tipo_documento.id)
                                                                            ])
            logger.info('Numero de documentos %s' %str(len(linhas_documento_ids)))
            
            for venda in linhas_documento_ids:
                venda=self.pool.get('dotcom.venda').browse(cr,uid,venda)
                
                if(len( venda.pagamento_ids))<=0:
                    val={
                        'tipo_documento':documento.tipo_documento.id,
                        'data':venda.document_date,
                        'parceiro':venda.partner_id.id,
                        'numero':venda.document_number,
                        'tota_documento':venda.total_document,
                        'venda_id':venda.id,
                        'documento_id':documento.id,
                    }
                    
                    self.pool.get('dotcom.gestao.comercial.actualiza.linha').create(cr,uid,val)
                #
            
        return True
    
    
    def emitir(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            for linha in documento.linhas_ids:
                self.pool.get().pay_directly(cr,uid,linha.venda_id.id)
    
               ## recebimento_report={
                 #  'venda_id':linha.venda_id.id,
                  #  'payed_amount':linha.venda_id.total_document,
                   # 'partner_id':linha.parceiro.id,
                    #'rate':linha.venda_id.exchange_rate,
                    #'date':linha.data,
                    #'user_id':linha.venda_id.user_id.id,
               # }
                
                #self.pool.get('dotcom.recebimento.report').create(cr,uid,recebimento_report)
                
                #for linha_venda in linha.venda_idx:
                 #   
        return True
                
            
    
    
dotcom_gestao_comercial_actualiza()


class dotcom_gestao_comercial_actualiza_linha(osv.osv):
    _name='dotcom.gestao.comercial.actualiza.linha'
    _columns={
                'tipo_documento':fields.many2one('documento.tipo','Documento'),
                'data':fields.date('Data Documento'),
                'parceiro':fields.many2one('res.partner','Parceiro'),
                'numero':fields.char('Numero', size=100),
                'tota_documento':fields.float('Total Documento',),
                'venda_id':fields.many2one('dotcom.venda','Venda'),
                
                'documento_id':fields.many2one('dotcom.gestao.comercial.actualiza',required=True),
            }
    
    
    def emitir(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.venda').write(cr,uid,documento.venda_id.id,{'state':'draft'})
            data_venda=documento.venda_id.document_date
            data_vencimento_venda=documento.venda_id.due_date
            data_atual=datetime.datetime.now()
            self.pool.get('dotcom.venda').write(cr,uid,documento.venda_id.id,{'document_date':data_atual,'due_date':data_atual})
            #venda_object=
            self.pool.get('dotcom.venda').pay_directly(cr,uid,documento.venda_id.id)
        
        return True
    
    
dotcom_gestao_comercial_actualiza_linha()