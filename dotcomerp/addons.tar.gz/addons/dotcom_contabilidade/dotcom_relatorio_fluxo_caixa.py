# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
from dateutil.relativedelta import relativedelta
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_relatorio_fluxo_caixa_directo(osv.osv):
	_name='dotcom.contabilidade.relatorio.fluxo.caixa.directo'
	_columns={
		'periodo_inicio_id':fields.many2one('configuration.period','Período inicial',domain="[('fiscalyear_id','=',ano_fiscal_actual_id)]",required=True),
		'periodo_fim_id':fields.many2one('configuration.period','Período final',domain="[('fiscalyear_id','=',ano_fiscal_actual_id)]",required=True),
		'ano_fiscal_actual_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=True),
		'ano_fiscal_anterior_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Anterior',required=False, readonly=True),
		
		'variacao_caixa_inicio':fields.float('Variação de caixa e equivalente de caixa', readonly=True),
		'variacao_caixa_fim':fields.float('Variação de caixa e equivalente de caixa', readonly=True),
				
		'caixa_equivalente_inicio_actual':fields.float('Caixa equivalente inicio actual', readonly=True),
		'caixa_equivalente_inicio_anterior':fields.float('Caixa equivalente inicio anterior',readonly=True),
		
		'caixa_equivalente_fim_actual':fields.float('Caixa equivalente fim actual',readonly=True),
		'caixa_equivalente_fim_anterior':fields.float('Caixa equivalente fim anterior',readonly=True),
		#'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',),
		#'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',),
		'incluir_periodos':fields.boolean('Incluir Periodos'),
		
		'linhas_actividades_operacionais_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_actividades_operacionais_id'),
		'linhas_caixagerada_operacoes_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_caixa_gerada_operacoes_id'),
		'linhas_actividades_investimentos_pagamentos_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_actividades_ivestimento_pagamento_id'),
		'linhas_actividades_investimentos_recebimentos_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_actividades_ivestimento_recebimentos_id'),
		'linhas_actividades_financeira_recebimentos_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_actividades_financeiras_recebimentos_id'),
		'linhas_actividades_financeira_pagamentos_ids':fields.one2many('dotcom.contabilidade.relatorio.fluxo.caixa.linha','directo_actividades_financeiras_pagamentos_id'),
	}
	
	_defaults={
		'ano_fiscal_actual_id':validator._get_default_year,
		'periodo_inicio_id':validator._get_default_openning_period,
		'periodo_fim_id':validator._get_default_present_period
	}
	
	def actualizar_linhas_relatorio(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			
			ano_fical_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,documento.ano_fiscal_actual_id.id)
			anos_fiscais_anteriores=self.pool.get('configuration.fiscalyear').search(cr,uid,[
																					('date_stop','<',ano_fical_object.date_start)
																					])
			
			periodos_actuais_ids=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',documento.ano_fiscal_actual_id.id),
																					('date_start','>=',documento.periodo_inicio_id.date_start),
																					('date_stop','<=',documento.periodo_fim_id.date_stop),
																					])
			
			data_inicio_anterior=documento.periodo_inicio_id.date_start
			data_inicio_anterior = datetime(*(time.strptime(data_inicio_anterior, '%Y-%m-%d')[0:6]))
			data_inicio_anterior = data_inicio_anterior - relativedelta(years=1)
			
			data_fim_anterior=documento.periodo_fim_id.date_stop
			data_fim_anterior = datetime(*(time.strptime(data_fim_anterior, '%Y-%m-%d')[0:6]))
			data_fim_anterior = data_fim_anterior - relativedelta(years=1)
			
			periodos_anteriores_ids=[]
			if bool(documento.ano_fiscal_anterior_id.id)!=False:
				periodos_anteriores_ids=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',documento.ano_fiscal_anterior_id.id),
																					('date_start','>=',data_inicio_anterior),
																					('date_stop','<=',data_fim_anterior),
																					])
			
			#data_inicio_anterior=str((datetime.now() - timedelta(years=1)).strftime('%d/%m/%Y'))
			logger.info('DATA DE INICIO ANO ANTERIOR TESTE %s' %str(periodos_anteriores_ids))
			logger.info('METODO DIRECTO EM EXECUCAO ')
			periodo_abertura_actual=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',documento.ano_fiscal_actual_id.id),
																					('special','>=',True),
																					])
			
			
			if len(anos_fiscais_anteriores)>0:
				self.write(cr,uid,documento.id,{'ano_fiscal_anterior_id':anos_fiscais_anteriores[len(anos_fiscais_anteriores)-1]})
			
			for lancamento in documento.linhas_actividades_operacionais_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
			
			for lancamento in documento.linhas_caixagerada_operacoes_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
				
			for lancamento in documento.linhas_actividades_investimentos_pagamentos_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
				
			for lancamento in documento.linhas_actividades_investimentos_recebimentos_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
				
			for lancamento in documento.linhas_actividades_financeira_recebimentos_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
				
			for lancamento in documento.linhas_actividades_financeira_pagamentos_ids:
				self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').unlink(cr,uid,lancamento.id)
			
			
			conta_pai_abertura_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ref','in',['11','12']),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			logger.info('*****CONTAS ACHADAS NA PESQUISA DE CONTAS DE ABERTURA**** %s' %str(conta_pai_abertura_ids))
			logger.info('*****PERIODOS DE ABERTURA**** %s' %str(periodo_abertura_actual))
			#lista_contas_movimento_ids=[]
			valor_total_inicio=0
			valor_total_inicio_anterior=0
			valor_total_fim=0
			valor_total_fim_anterior=0
			variacao_caixa_inicio=0
			variacao_caixa_inicio_anterior=0
			for conta in conta_pai_abertura_ids:
				conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
				logger.info('*****REFERENCIA DA CONTA ACHADA**** %s' %str(conta.ref))
				lista_contas_local_ids=self.pool.get('dotcom.contabilidade.iva').get_filhos(cr,uid,ids,conta)
				
			
				for conta_lancamento in lista_contas_local_ids:
					conta_lancamento=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_lancamento)
					logger.info('*****REFERENCIA DA CONTA ACHADA**** %s' %str(conta_lancamento.ref))
					lancamento_inicio_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
											('conta_id','=',conta_lancamento.id),  
											('periodo_id','in',periodo_abertura_actual),
											('state','=','emitido'),
											])
					
					lancamento_inicio_fim_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
											('conta_id','=',conta_lancamento.id),  
											('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
											('state','=','emitido'),
											])
					
					for lancamento in lancamento_inicio_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if lancamento.credito>lancamento.debito:
							valor_total_inicio=valor_total_inicio+(lancamento.credito_moeda_base*(-1))
						elif lancamento.credito<lancamento.debito:
							valor_total_inicio=valor_total_inicio+lancamento.debito_moeda_base
							
					for lancamento in lancamento_inicio_fim_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if lancamento.credito>lancamento.debito:
							valor_total_fim=valor_total_fim+(lancamento.credito_moeda_base*-1)
						elif lancamento.credito<lancamento.debito:
							valor_total_fim=valor_total_fim+lancamento.debito_moeda_base
					
				#	
				logger.info('*****v=VALOR TOTAL NO INICIO DO PERIODO**** %s' %str(valor_total_inicio))	
				logger.info('*****v=VALOR TOTAL NO FIM DO PERIODO**** %s' %str(valor_total_fim))	 
								
			#===========================================================================================================================================
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','111'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			logger.info('*****FLUXO conta_pai_actual    ******%s ' %str(conta_pai_actual))
			conta_pai_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','111'),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
			logger.info('*****FLUXO conta_pai_anterior    ******%s ' %str(conta_pai_anterior))
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																		('tipo_interno','=','m'),
																		('parent_id','=',conta_pai_actual[0]),
																		('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																		])
				logger.info('*****FLUXO contas    ******%s ' %str(contas))
				logger.info('ENTROU NO PRIMEIRO PROCESSO')
				
				for fluxo in contas:
					logger.info('*****FLUXO fluxo    ******%s ' %str(fluxo))
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					logger.info('*****FLUXO lancamentos_fluxo_ids    ******%s ' %str(lancamentos_fluxo_ids))
					fluxo_filho=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					logger.info('*****FLUXO fluxo_filho    ******%s ' %str(fluxo_filho))
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_filho.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					logger.info('*****FLUXO ANTERIOR ACHADO COM SUCESSO******%s ' %str(fluxo_anterior))
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						#
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
							
						
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						logger.info('*****FLUXO lancamento    ******%s ' %str(lancamento))
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_actividades_operacionais_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					logger.info('*****Fluxo a ser criado VAL directo_actividades_operacionais_id  ******%s ' %str(val))
					create_fluxo_id_log=self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)
					logger.info('Fluxo criado com sucesso directo_actividades_operacionais_id%s' %str(create_fluxo_id_log))
			#=========================================================================================================================================================
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','112'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			logger.info('*****CONTA PAI ACHADA******%s ' %str(conta_pai_actual))
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																	('tipo_interno','=','m'),
																	('parent_id','=',conta_pai_actual[0]),
																	('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)])
				logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(conta_pai_actual))
				for fluxo in contas:
					
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_object.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
								
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_caixa_gerada_operacoes_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)	
			#========================================================================================================================================================
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','211'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			logger.info('******METODO DIRECTO AINDA EM EXECUCAO********')
			
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																				('tipo_interno','=','m'),
																				('parent_id','=',conta_pai_actual[0]),
																				('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)])
				logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(contas))
				for fluxo in contas:
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					
					logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(fluxo_object.ref))
					logger.info('*****VALOR DO FLUXO ACTUAL ACHADO******%s ' %str(lancamentos_fluxo_ids))
					
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_object.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
					
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						logger.info('CONTA COM LANCAMENTOS ENCONTRADOS')
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					logger.info('*****VALOR DO FLUXO ACTUAL ACHADO******%s ' %str(valor_total))
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_actividades_ivestimento_pagamento_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)
			
			#==================================================================================================================================================
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','212'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			#logger.info('*****CONTA PAI ACHADA******%s ' %str(conta_pai_actual))
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																				('tipo_interno','=','m'),
																				('parent_id','=',conta_pai_actual[0]),
																				('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)])
				#logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(conta_pai_actual))
				for fluxo in contas:
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_object.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
					
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if fluxo_object.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_actividades_ivestimento_recebimentos_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)
			
			
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','311'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			#logger.info('*****CONTA PAI ACHADA******%s ' %str(conta_pai_actual))
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																				('tipo_interno','=','m'),
																				('parent_id','=',conta_pai_actual[0]),
																				('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)])
				#logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(conta_pai_actual))
				for fluxo in contas:
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_object.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
					
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_actividades_financeiras_recebimentos_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)
			
			
			conta_pai_actual=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=','312'),
																						('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)
																						])
			#logger.info('*****CONTA PAI ACHADA******%s ' %str(conta_pai_actual))
			if len(conta_pai_actual)>0:
				contas=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																				('tipo_interno','=','m'),
																				('parent_id','=',conta_pai_actual[0]),
																				('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id)])
				#logger.info('*****CONTAS FILHAS ACHADAS ACHADA******%s ' %str(conta_pai_actual))
				for fluxo in contas:
					lancamentos_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																								('fluxo_caixa_id','=',fluxo),
																								('state','=','emitido'),
																								('ano_fiscal_id','=',documento.ano_fiscal_actual_id.id),
																								('periodo_id','in',periodos_actuais_ids),
																								])
					
					fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
					fluxo_anterior=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[
																						('ref','=',fluxo_object.ref),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
					
					valor_total_anterior=0
					if len(fluxo_anterior)>0:
						lancamentos_anteriores_fluxo_ids=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').search(cr,uid,[
																									('fluxo_caixa_id','=',fluxo_anterior[0]),
																									('state','=','emitido'),
																									('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
																									('periodo_id','in',periodos_anteriores_ids),
																									])
						for lancamento in lancamentos_anteriores_fluxo_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
							fluxo_local_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
							if lancamento.natureza_fluxo_caixa=='pagamento':
								valor_total_anterior=valor_total_anterior+(lancamento.valor*-1)
							else:
								valor_total_anterior=valor_total_anterior+lancamento.valor
					
					valor_total=0
					for lancamento in lancamentos_fluxo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').browse(cr,uid,lancamento)
						fluxo_object=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
						if lancamento.natureza_fluxo_caixa=='pagamento':
							valor_total=valor_total+(lancamento.valor*-1)
						else:
							valor_total=valor_total+lancamento.valor
					
					val={
						'fluxo_caixa_id':fluxo,
						'periodo_inicio':valor_total,
						'periodo_fim':valor_total_anterior,
						'directo_actividades_financeiras_pagamentos_id':documento.id,
					}
					variacao_caixa_inicio=variacao_caixa_inicio+valor_total
					if bool(documento.ano_fiscal_anterior_id.id)!=False:
						val['ano_anterior']=True
					self.pool.get('dotcom.contabilidade.relatorio.fluxo.caixa.linha').create(cr,uid,val)
			
			
			if bool(documento.ano_fiscal_anterior_id.id)!=False:
				conta_pai_abertura_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ref','in',['11','12']),
																						('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id)
																						])
				periodo_abertura_anterior=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',documento.ano_fiscal_anterior_id.id),
																					('special','>=',True),
																					])
				
				for conta in conta_pai_abertura_ids:
					conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
					#logger.info('*****REFERENCIA DA CONTA ACHADA**** %s' %str(conta.ref))
					lista_contas_local_ids=self.pool.get('dotcom.contabilidade.iva').get_filhos(cr,uid,ids,conta)
					
				
					for conta_lancamento in lista_contas_local_ids:
						conta_lancamento=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_lancamento)
						#logger.info('*****REFERENCIA DA CONTA ACHADA**** %s' %str(conta_lancamento.ref))
						lancamento_inicio_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('conta_id','=',conta_lancamento.id),  
												('periodo_id','in',periodo_abertura_anterior),
												('state','=','emitido'),
												])
						
						lancamento_inicio_fim_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('conta_id','=',conta_lancamento.id),  
												('ano_fiscal_id','=',documento.ano_fiscal_anterior_id.id),
												('state','=','emitido'),
												])
						
						for lancamento in lancamento_inicio_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if lancamento.credito>lancamento.debito:
								valor_total_inicio_anterior=valor_total_inicio_anterior+(lancamento.credito_moeda_base*(-1))
							elif lancamento.credito<lancamento.debito:
								valor_total_inicio_anterior=valor_total_inicio_anterior+lancamento.debito_moeda_base
								
						for lancamento in lancamento_inicio_fim_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if lancamento.credito>lancamento.debito:
								valor_total_fim_anterior=valor_total_fim_anterior+(lancamento.credito_moeda_base*-1)
							elif lancamento.credito<lancamento.debito:
								valor_total_fim_anterior=valor_total_fim_anterior+lancamento.debito_moeda_base
			   
			
			
			self.write(cr,uid,documento.id,{
											'variacao_caixa_inicio':variacao_caixa_inicio,
											'variacao_caixa_fim':0,
											'caixa_equivalente_inicio_actual':valor_total_inicio,
											'caixa_equivalente_inicio_anterior':valor_total_inicio_anterior,
											'caixa_equivalente_fim_actual':valor_total_fim,
											'caixa_equivalente_fim_anterior':valor_total_fim_anterior})
			
			lista_contas=[]
		return True
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		
		logger.info('PROCESSO DO ANO FISCAL A CORRER')
		return {'value':{'periodo_inicio_id':periodos_ids[0],'periodo_fim_id':periodos_ids[len(periodos_ids)-1]}}
	
	def on_change_ano_inicio(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		ano_fical_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		anos_fiscais_anteriores=self.pool.get('configuration.fiscalyear').search(cr,uid,[
																				('date_stop','<',ano_fical_object.date_start)
																				])
		periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_fiscal_id)])
		if len(anos_fiscais_anteriores)>0:
			return {'value':
				{'ano_fiscal_anterior_id':anos_fiscais_anteriores[len(anos_fiscais_anteriores)-1],'periodo_inicio_id':periodos_ids[0],'periodo_fim_id':periodos_ids[len(periodos_ids)-1]}}
		else:
			return {'value':{'ano_fiscal_anterior_id':False,'periodo_inicio_id':periodos_ids[0],'periodo_fim_id':periodos_ids[len(periodos_ids)-1]}}
		
	
dotcom_relatorio_fluxo_caixa_directo()


class dotcom_relatorio_fluxo_caixa_linhas(osv.osv):
	_name='dotcom.contabilidade.relatorio.fluxo.caixa.linha'
	_columns={
		'fluxo_caixa_id':fields.many2one('dotcom.contabilidade.fluxo.caixa','Fluxo Caixa',required=True, readonly=True),
		'notas':fields.char('Notas', size=250),
		'periodo_inicio':fields.float('Período n', readonly=True),
		'periodo_fim':fields.float('Período n-1', ),
		'ano_anterior':fields.boolean('Ano anterior'),
		
		'directo_actividades_operacionais_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		'directo_caixa_gerada_operacoes_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		'directo_actividades_ivestimento_pagamento_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		'directo_actividades_ivestimento_recebimentos_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		'directo_actividades_financeiras_recebimentos_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		'directo_actividades_financeiras_pagamentos_id':fields.many2one('dotcom.contabilidade.relatorio.fluxo.caixa.directo'),
		
		
	}
	
	_defaults={
		'ano_anterior':False
	}
	
dotcom_relatorio_fluxo_caixa_linhas()