# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')

class dotcom_diario(osv.osv):
	
	def _friendly_name(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			nome = plano.nome or ''
			friendly_name = '['+ref + '] ' + nome
			res[plano.id] = friendly_name
		return res
	
	
	def _referencia_gerada(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			ano = plano.ano_fiscal_id.code or ''
			friendly_name = ref + '/' + ano
			res[plano.id] = friendly_name
		return res
	
	
	_name='dotcom.contabilidade.diario'
	_columns={
		'ref':fields.char('Ref',required=True,size=25),
		'nome':fields.char('Nome',required=True,size=50),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'numero_por_periodo':fields.char('Numero por periodo',size=50,readonly=True),
		'sequenciador_ids':fields.one2many('dotcom.contabilidade.sequenciador','diario_id','Sequênciador',readonly=True),
		
		'friendly_name': fields.function(_friendly_name, type='char', string='Diario', method=True, store=True),
		'referencia_gerada': fields.function(_referencia_gerada, type='char', string='Referencia Gerada', method=True, store=True),
	}
	
	_rec_name='friendly_name'
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	_sql_constraints = [
		('name_uniq', 'unique (ref,ano_fiscal_id)', 'Já foi criado o Diário para este Ano Fiscal!!'),
	]
	
	def create(self,cr,uid,vals,context=None):
		if context is None:
			context={}
		values={}
		
		values['padding']=3
		values['number_increment']=1
		values['fiscal_year_id']=vals['ano_fiscal_id']
		
		logger.info('VALOR DO PERIODO A SER CRIADO %s' % str(values))
		#logger.info('SEQUENCIA %s' % str(sequencia_ids))
		
		diario_id=super(dotcom_diario, self).create(cr,uid,vals,context=context)
		#logger.info('DIARIO %s' % str(diario_id))
		values['diario_id']=diario_id
		sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').create(cr,uid,values)
		#for seq in sequencia_ids:
		#	self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,seq,{'diario_id':diario_id})
		return  diario_id
		
		
	
	def generate_sequence(self, cr, uid,sequence_id,data, document_id,movimento_id,context=None):
		documento_pool = self.pool.get('dotcom.contabilidade.diario')
		documento = documento_pool.browse(cr,uid,document_id)
		movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento_id)
		doc_number = ''
		if movimento.numero_diario is False or movimento.numero_diario=='':
			#sequence_id = documento.sequenciador_ids.id
			sequence_obj = self.pool.get('dotcom.contabilidade.sequenciador')
			if sequence_id:
				
				sequence = sequence_obj.browse(cr,uid,sequence_id)

				now = datetime.now()
				year = int(now.year)
				
				day = data
				doc_date = datetime(*(time.strptime(day, '%Y-%m-%d')[0:6]))
				date_year = doc_date.strftime('%Y')
				
				if (int(sequence.fiscal_year_id.code)!=int(date_year)):
					raise osv.except_osv(_('Invalid action !'), _('The document date - Fiscal year ERROR'))
				else:
					doc_number =sequence_obj.next_by_id(cr, uid, sequence_id) or sequence_obj.next_by_code(cr, uid, sequence.code)
		else:
			doc_number = documento.numero_por_periodo
		
		documento_pool.write(cr,uid,documento.id,{'numero_por_periodo':doc_number})
		self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'numero_diario':doc_number})
		return doc_number

dotcom_diario()
