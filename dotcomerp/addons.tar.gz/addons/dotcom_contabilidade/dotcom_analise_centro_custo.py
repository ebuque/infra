# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_analise_centro_custo(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		#logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		#logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	_name='dotcom.contabilidade.analise.centro.custo'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'periodo_inicio_id':fields.many2one('configuration.period','Início',required=True),
		'periodo_fim_id':fields.many2one('configuration.period','Fim',required=True),
		'conversao_moeda':fields.selection(_acerto,'Moeda', required=True,),
		'linhas_analise_ids':fields.one2many('dotcom.contabilidade.analise.centro.custo.linha','analice_centro_id','Linhas')
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'periodo_inicio_id':validator._get_default_openning_period,
		'periodo_fim_id':validator._get_periodo_ultimo_movimento,
		'conversao_moeda':'mp'
	}
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_fiscal_id)])
		
		return {'value':{'periodo_inicio_id':periodos_ids[0],'periodo_fim_id':periodos_ids[len(periodos_ids)-1]}}
	
	def actualizar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		linhas_ids=self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').search(cr,uid,[])
		for linha in linhas_ids:
			self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').unlink(cr,uid,linha)
		
		
		for documento in self.browse(cr,uid,ids):
			
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('id','>=',documento.periodo_inicio_id.id),
							('id','<=',documento.periodo_fim_id.id),
				])
			
			lista_centros_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[
				('ano_fiscal_id','=',documento.ano_fiscal_id.id),
				('tipo_interno','=','m')])
																							   
			total_plano=0
							
			for centro_custo in lista_centros_ids:
				centro_custo=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro_custo)
				   
				#if centro_id.ano_fiscal_id.id==documento.ano_fiscal_id.id:
				lancamentos_centro_custos_ids=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').search(cr,uid,[
										('estado_movimento','=','emitido'),
										('periodo_id','in',periodos_ids),
										('centro_id','=',centro_custo.id)
					])
				if len(lancamentos_centro_custos_ids)>0:
					valor_pai=0
					natureza_pai=None
					valor_pai_debito=0
					valor_pai_credito=0
					lista_items=[]
					
					logger.info('CENTRO DE CUSTO %s' %str(centro_custo.centro))
					logger.info('LANCAMENTOS ACHADOS DA CONTA %s' %str(lancamentos_centro_custos_ids))
					for lancamento in lancamentos_centro_custos_ids:
						lancamento=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').browse(cr,uid,lancamento)
						if lancamento.movimento_id.state=='emitido':
							val={
								'conta_id':lancamento.conta_id.id,
								#'plano_centro_id':lancamento.plano_id.id,
								#'valor_credito':0,
								#'valor_debito':0,
								'natureza':lancamento.adicao_id.natureza,
								'analice_centro_id':documento.id,
								#'parent_id':pai_id,
							}
							
							if lancamento.natureza=='debito':
								if documento.conversao_moeda=='mp':
									val['valor_debito']=lancamento.valor_moeda_base
								elif documento.conversao_moeda=='ms':
									val['valor_debito']=lancamento.valor_moeda_secundaria
								val['valor_credito']=0
								val['saldo']=val['valor_debito']
							elif lancamento.natureza=='credito':
								if documento.conversao_moeda=='mp':
									val['valor_credito']=lancamento.valor_moeda_base
								elif documento.conversao_moeda=='ms':
									val['valor_credito']=lancamento.valor_moeda_secundaria
								val['valor_debito']=0
								val['saldo']= val['valor_credito']
							
							valor_pai_debito=valor_pai_debito+val['valor_debito']
							valor_pai_credito=valor_pai_credito+val['valor_credito']
									
							lista_items.append(val)
								 
		
					
					saldo_pai=0		
					if valor_pai_debito>valor_pai_credito:
						valor_pai=valor_pai_debito-valor_pai_credito
						natureza_pai='debito'
					elif valor_pai_debito<valor_pai_credito:
						valor_pai=valor_pai_credito-valor_pai_debito
						natureza_pai='credito'
						
					total_plano=total_plano+valor_pai
						
					val={
							#'conta_id':lancamento.conta_id.id,
							#'plano_centro_id':centro_custo.centro_id.id,
							'natureza':natureza_pai,
							'centro_id':centro_custo.id,
							'valor_credito':valor_pai_credito,
							'valor_debito':valor_pai_debito,
							'saldo':valor_pai,
							'analice_centro_id':documento.id,
						}
					
					if bool(centro_custo.parent_id.id):
						#logger.info('CENTRO DE CUSTOS COM PARENTES')
						linhas_achadas=self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').search(cr,uid,[('centro_id','=',centro_custo.parent_id.id)])
						if len(linhas_achadas)>0:
							copia_id=linhas_achadas[0]
							parente=self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').browse(cr,uid,linhas_achadas[0])
							valor_parente_credito=parente.valor_credito+val['valor_credito']
							valor_parente_debito=parente.valor_debito+val['valor_debito']
							saldo_disponivel_pai=0
							natureza=''
							if valor_parente_credito>valor_parente_debito:
								saldo_disponivel_pai=valor_parente_credito-valor_parente_debito
								natureza='credito'
							else:
								saldo_disponivel_pai=valor_parente_debito-valor_parente_credito
								natureza='debito'
								
							self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').write(cr,uid,parente.id,{
																		'valor_debito':valor_parente_debito,
																		'valor_credito':valor_parente_credito,
																		'saldo':saldo_disponivel_pai,
																		'natureza':natureza})
							
						else:
							#logger.info('PRIMEIRO VALOR A SER CRIADO %s' %str(val))
							val_copia=val.copy()
							val_copia['centro_id']=centro_custo.parent_id.id
							copia_id=self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').create(cr,uid,val_copia)
						val['parent_id']=copia_id
					
					pai_id=self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').create(cr,uid,val)
					
					lista_items = sorted(lista_items, key=lambda d: (d['conta_id']))  
					for val in lista_items:
						val['parent_id']=pai_id
						self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').create(cr,uid,val)
														   
								
							#logger.info('VALOR DO PAI ACHADO %s' %str(pai_id))
						#self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').write(cr,uid,pai_id,{'valor':valor_pai})
				#self.pool.get('dotcom.contabilidade.analise.centro.custo.linha').write(cr,uid,plano_pai_id,{'valor':total_plano})  
		
		
		return {
			'type': 'ir.actions.act_window',
			'name': 'Balancete',
			'view_mode': 'tree',
			'view_type': 'tree',
			'res_model': 'dotcom.contabilidade.analise.centro.custo.linha',
			'res_id':None,
			'domain': [('parent_id','=',False)],
			'context': context,
			'nodestroy': True,
		}

dotcom_analise_centro_custo()


class dotcom_analise_centro_custo_linha(osv.osv):
	_name='dotcom.contabilidade.analise.centro.custo.linha'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Origem',required=False,),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano C. Custo',required=False),
		'centro_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','C. Custo', domain="[('centro_id','=',plano_id),('tipo_interno','=','m')]",required=False),
		'valor_credito':fields.float('Credito'),
		'valor_debito':fields.float('Debito'),
		'saldo':fields.float('Saldo'),
		'natureza':fields.selection([('debito','Débito'),('credito','Crédito')],'Natureza',readonly=True),
		'analice_centro_id':fields.many2one('dotcom.contabilidade.analise.centro.custo','Analise Centro'),
		
		'parent_id': fields.many2one('dotcom.contabilidade.analise.centro.custo.linha', 'Ascendente', required=False, ondelete="cascade"),
		'child_id':fields.one2many('dotcom.contabilidade.analise.centro.custo.linha', 'parent_id', string='Sub-contas'),
	}

dotcom_analise_centro_custo_linha()