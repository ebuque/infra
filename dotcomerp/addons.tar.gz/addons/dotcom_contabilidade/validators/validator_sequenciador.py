import time
import datetime


def data_actual(self, cr,uid,context=None):
	
	
	def ultimo_elemento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		pool= pooler.get_pool(cr.dbname)
		obj = pool.get('dotcom.contabilidade.plano.contas')
		


