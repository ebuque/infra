# -*- coding: utf-8 -*-

import time
import datetime
import calendar
#from lxml import etree
#import netsvc
from osv import osv, fields, orm
from tools.translate import _
import pooler

import logging
logger = logging.getLogger('DOTCOM_LOGGER')


#Pega o ano de trabalho definido nas configuracoes da empresa, caso esteja, ou o ano da data actual do SO caso nada esteja definido
def _get_default_year(self,cr, uid, context=None):
	pool= pooler.get_pool(cr.dbname)
	
	ano_default_pool=pool.get('res.company')	
	ano_ids=ano_default_pool.search(cr,uid,[])
	retorno=0
	object=ano_ids[0]
	object=ano_default_pool.browse(cr,uid,object)
	
	#lancamentos_diarios=
	if object.ano_fiscal_id.id:
		retorno=object.ano_fiscal_id.id
	else:
		fiscal_pool = pool.get('configuration.fiscalyear')
		today= datetime.datetime.now().strftime('%Y-%m-%d')
		results = fiscal_pool.search(cr,uid,[('date_start','<=',today),('date_stop','>=',today)])
		res = None
		if results and len(results)>0:
			retorno = results[0]
		logger.info('ENTROU2 %s' %str(retorno))
	logger.info('RET %s' %str(retorno))
	return retorno
#Pega a configuracao de balancemanto definido nas configuracoes da empresa

def _get_default_balanceamento(self,cr, uid, context=None):
	pool= pooler.get_pool(cr.dbname)
	
	company_pool=pool.get('res.company')	
	ano_ids=company_pool.search(cr,uid,[])
	retorno=False
	object=ano_ids[0]
	object=company_pool.browse(cr,uid,object)
	
	#lancamentos_diarios=
	if object.check_balanceamento_MS:
		retorno=object.check_balanceamento_MS
	return retorno





#Pega o periodo de abertura do ano fiscal definido na empresa
def _get_default_openning_period(self,cr,uid,context=None):
	if context is None:
		context={}
	
	ano_default=_get_default_year(self,cr,uid,context=context)
	periodo_abertura_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_default),
							('special','=',True)
				])
	return periodo_abertura_ids[0]
	
	
def _get_default_present_period(self,cr,uid,context=None):
	if context is None:
		context={}
	
	ano_default=_get_default_year(self,cr,uid)
	data= datetime.datetime.now().strftime('%Y-%m-%d')
	periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_default),
							('date_start','<=',data),
							('date_stop','>=',data)
				])
	if len(periodo_ids)>0:
		return periodo_ids[0]
	else:
		return None


def _get_actual(self,cr,uid,context=None):
	if context is None:
		context={}
	data= datetime.datetime.now().strftime('%Y-%m-%d')
	return data


def _get_data_inicio_ano(self,cr,uid,context=None):
	if context is None:
		context={}
		
	ano_default=_get_default_year(self,cr,uid,context=context)
	periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_default),
							('special','=',True),
				])
	periodo=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
	data_inicio=periodo.date_start
	logger.info('DATA DE INICIO %s' %str(data_inicio))
	return data_inicio


#Verificar a existencia de movimentos em Rascunho(Nao Emitidos)
def chech_movimentos_rascunho(self,cr,uid,context=None):
	if context is None:
		context={}
		
	pool= pooler.get_pool(cr.dbname)
	movimentos_pool=pool.get('dotcom.contabilidade.movimentos')
	movimentos_ids=movimentos_pool.search(cr,uid,[('state','in',['rascunho','outro_rascunho'])])
	if len(movimentos_ids)>0:
		raise osv.except_osv(_('Acção Inválida !'), _('Foi detectada a existência de Movimentos no estado Rascunho! Não é possível prosseguir!!'))
	return {}
		
	

def get_data_movimento(self,cr,uid,context=None):
	if context is None:
		context={}
	pool= pooler.get_pool(cr.dbname)
	company_pool = pool.get('res.company')
	data=False
	company_ids=company_pool.search(cr,uid,[])
	company=company_pool.browse(cr,uid,company_ids[0])
	ano_fiscal_id=_get_default_year(self,cr,uid)
	#logger.info*()
	
	movimentos_pool=pool.get('dotcom.contabilidade.movimentos')
	movimentos_ids=movimentos_pool.search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
	logger.info('MOVIMETOS %s' %str(movimentos_ids))
	
	if len(movimentos_ids)>0:
		movimento=movimentos_pool.browse(cr,uid,movimentos_ids[0])
		data=movimento.data
		logger.info('MOVIMENTOS ACHADOS MO VALIDATOR E SUA DATA %s' %str(data))
	else:
		ano_fiscal=pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		logger.info('MOVIMENTOS ACHADOS NAO TEM COMO ENTRAR NO ELSE' )
		if (ano_fiscal.id)== False:
			raise osv.except_osv(_('Acção Invalida !'), _('Ano de Trabalho nao definido para a empresa!'))
		else:
			
			logger.info('ANO FISCAL ACHADO %s'%str(ano_fiscal))
			ano=ano_fiscal.code
			
			data_actual=datetime.datetime.now()
			mes=data_actual.month
			logger.info('MES%s'%str(mes))
			dia=1
			logger.info('ANO%s'%str(ano))
			
			
			data=datetime.datetime(int(ano),int(mes),dia,0,0,0)
			dias_mes=calendar.mdays[data.month]
			#logger.info('DIAS%s'%str(dias_mes))
			data=datetime.datetime(int(ano),int(mes),dias_mes,0,0,0)
			data=data.strftime('%Y-%m-%d')	
	return data


def _get_periodo_ultimo_movimento(self,cr,uid,context=None):
	if context is None:
		context={}
		
	data_ultimo_movimento=get_data_movimento(self,cr,uid)
	ano_fiscal_id=_get_default_year(self,cr,uid)
	periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id),
							('date_start','<=',data_ultimo_movimento),
							('date_stop','>=',data_ultimo_movimento)
						])
	if len(periodo_ids)>0:
		return periodo_ids[0]
	else:
		return False


def diario_movimento(self,cr,uid,context=None):
	if context is None:
		context={}
	pool= pooler.get_pool(cr.dbname)
	ano_fiscal_id=_get_default_year(self,cr,uid)
	movimentos_pool=pool.get('dotcom.contabilidade.movimentos')
	movimentos_ids=movimentos_pool.search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
	
	diario=None
	if len(movimentos_ids)>0:
		movimento=movimentos_pool.browse(cr,uid,movimentos_ids[len(movimentos_ids)-1])
		diario=movimento.diario_id.id
		
	return diario


def documento_movimento(self,cr,uid,context=None):
	if context is None:
		context={}
	pool= pooler.get_pool(cr.dbname)
	ano_fiscal_id=_get_default_year(self,cr,uid)
	movimentos_pool=pool.get('dotcom.contabilidade.movimentos')
	movimentos_ids=movimentos_pool.search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
	
	documento=None
	if len(movimentos_ids)>0:
		movimento=movimentos_pool.browse(cr,uid,movimentos_ids[len(movimentos_ids)-1])
		documento=movimento.documento_id.id
		
	return documento
		
	
def validar_numero_caracteres(cr,uid,conta,context=None):
	if context is None:
		context={}
	tamanho=len(conta)
	if tamanho<=1:
		raise osv.except_osv(_('Acção Invalida !'), _('A conta deve conter no mínimo 2 caracteres!'))
	elif tamanho>=2:
		if conta.isdigit() is False:
			raise osv.except_osv(_('Acção Invalida !'), _('A conta deve conter no mínimo 2 caracteres. Espaços, acentuação, caracteres epecias como !/(#,etc são inválidos!'))
	return {}
	
	
def get_conta_ascendente(cr,uid,conta,ano_fiscal_id,context=None):
	if context is None:
		context={}
	i = None
	pool= pooler.get_pool(cr.dbname)
	obj = pool.get('dotcom.contabilidade.plano.contas')
	ver = obj.search(cr, uid, [
				('ref','=',conta),
				('ano_fiscal_id','=',ano_fiscal_id)				
				])
	#if ver and len(ver)>0:
	#	raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
	for x in range(1, len(conta)):
		now = conta[:-x]
		res = obj.search(cr, uid, [
						('ref','=',now),
						('ano_fiscal_id','=',ano_fiscal_id)
						])
		if res and len(res)>0:
			i = int(res[0])
			break
		else:
			continue
	return i


def get_centro_ascendente(cr,uid,conta,ano_fiscal_id,context=None):
	if context is None:
		context={}
	i = None
	pool= pooler.get_pool(cr.dbname)
	obj = pool.get('dotcom.contabilidade.conta.centro.custos')
	#logger.info('IDENTIFICADOR %s'% str(identificador))
	
	ver = obj.search(cr, uid, [('centro','=',conta),('ano_fiscal_id','=',ano_fiscal_id)])
	#if ver and len(ver)>0:
	#	raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
	for x in range(1, len(conta)):
		now = conta[:-x]
		logger.info('NOW %s'% str(now))
		res = obj.search(cr, uid, [('centro','=',now),('ano_fiscal_id','=',ano_fiscal_id)])
		logger.info('CENTROS %s'% str(res))
		if res and len(res)>0:
			i = int(res[0])
			break
		else:
			continue
	return i


def get_fluxo_caixa_ascendente(cr,uid,conta,ano_fiscal_id,context=None):
	if context is None:
		context={}
	i = None
	pool= pooler.get_pool(cr.dbname)
	obj = pool.get('dotcom.contabilidade.fluxo.caixa')
	#logger.info('IDENTIFICADOR %s'% str(identificador))
	
	ver = obj.search(cr, uid, [('ref','=',conta),('ano_fiscal_id','=',ano_fiscal_id)])
	logger.info('IDENTIFICADOR =====================  ver %s'% str(ver))
	
	#if ver and len(ver)>0:
	#	raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
	for x in range(1, len(conta)):
		now = conta[:-x]
		logger.info('NOW %s'% str(now))
		res = obj.search(cr, uid, [('ref','=',now),('ano_fiscal_id','=',ano_fiscal_id)])
		logger.info('CENTROS %s'% str(res))
		if res and len(res)>0:
			i = int(res[0])
			break
		else:
			continue
	return i


def validar_referencias(cr,uid,referencia):
	#if context is None:
	#	context={}
	
	lista=referencia.split(' ')
	logger.info('NURMEDO DE PARCELAS %s' %str(lista))
	referencia=''
	if len(lista)>1:
		for parcela in lista:
			referencia=str(referencia)+str(parcela)
		
		#raise osv.except_osv(_('Acção Inválida !'), _('Nao são permitidos espaços em branco!!'))
	else:
		referencia=lista[0]
	return referencia


def validar_antecessor(cr,uid,ref,contas,context=None):
	if context is None:
		context={}
		
	validar_numero_caracteres(cr,uid,ids,ref,context)	
	lista=[]
	if contas>0:
		for conta in contas:	
			for i in range(0,(len(ref))):
				caracteres=''			
				if conta[i].ref==ref[i]:
					caracteres=caracteres+conta[i]
				else: break
			lista.append(caracteres)
	
		tamanho=0
		parente=''
		for conta in lista:
			if tamanho<len(conta):
				tamanho=len(conta)
				parente=conta
	else:
		parete=''
	
	return parente		
			
	
def validar_tipo_interno(cr,uid,ids,ref,contas,context=None):
	if context is None:
		context={}
	
	parente= validar_antecessor(cr,uid,ids,ref,contas,context)  
	tipo=''
	if len(ref)==2:
		tipo='r'
	elif (parente==None is False) & len(ref)>2:
		tipo='m'
	return tipo


def get_parcelas_operacao(cr,uid,operacao,context=None):
	if context is None:
		context={}
	lista=operacao.split()
	lista_retorno=[]
	lista_retorno2=[]
	outra_lista_local=[]
	
	#logger.info('LISTA ACHADA NO PARCELAMENTO %s' %str(lista))
	for parcela in lista:
		if len(get_valores_parcela(cr,uid,parcela,context=context))>0:
			outra_lista_local=get_valores_parcela(cr,uid,parcela,context=context)
			outra_lista_local2=[]
			
			operador=''
			
			if len(outra_lista_local)>1:
				if outra_lista_local[0]=='+' or outra_lista_local[0]=='-':
					operador=outra_lista_local[0]
					
					
				contador_items=0
				for parcela_local in outra_lista_local:
					#logger.info('ENTROU NO PROCESSAMENTO %s' %str(contador_items))
					if contador_items>0:
						if operador=='+' or operador=='-':
							outra_lista_local2.append([operador])
						else:
							outra_lista_local2.append(['+'])
					outra_lista_local2.append([parcela_local])
					contador_items=contador_items+1		   
			elif len(outra_lista_local)==1:
				outra_lista_local2.append(outra_lista_local)
			
			#logger.info('VALORES ACHADOS DE CADA PARCELA %s' %str(outra_lista_local))
			for parcela_final in outra_lista_local2:
				lista_retorno2.append(parcela_final)
			lista_retorno.append(get_valores_parcela(cr,uid,parcela,context=context))
			
			#logger.info('VALOR DA OUTRA LISTA LOCAL 2 %s' %str(lista_retorno2))
			#logger.info('VALOR DE RETORNO DA LISTA FINAL %s' %str(lista_retorno))
	
	return lista_retorno2


def get_valores_parcela(cr,uid,parcela,context=None):
	if context is None:
		context={}
	lista=[]
	lista_retorno=[]
	if len(parcela)>1:
		lista=parcela.split('(')
		if len(lista)>1:
			tipo_saldo=lista[0]
			if tipo_saldo=='saldo':
				tipo_saldo='N'
				#logger.info('VALORES ACHADOS DE CADA PARCELA %s' %str(tipo_saldo))
			elif tipo_saldo=='saldoCr':
				tipo_saldo='-'
			elif tipo_saldo=='saldoDb':
				logger.info('SALDO A DEBITO ACHADO')
				tipo_saldo='+'
			logger.info('VALORES ACHADOS DE CADA PARCELA %s' %str(tipo_saldo)) 
			lista1=lista[1].split(')')
			conta=lista1[0]
			if len(conta)>1:
				lista_sem_barras=get_valores_com_barra(cr,uid,conta)
				if len(lista_sem_barras)>1:
					#logger.info('VALORES ACHADOS DE CADA PARCELA %s' %str(lista_sem_barras))
					#lista_sem_barras=lista_sem_barras[0]
					#logger.info('VALORES ACHADOS DE CADA PARCELA LOCAL %s' %str(lista_sem_barras))
					
					contador=0
					for sem_barra in lista_sem_barras:
						#logger.info('VALORES ACHADOS DE CADA PARCELA LOCAL %s' %str(sem_barra))
						conta=tipo_saldo+sem_barra[0]
						outra_lista=[]
						#if contador>0:
						#	lista_retorno.append(['+'])
							
						#outra_lista.append(conta)
						lista_retorno.append(conta)
						contador=contador+1
					#logger.info('VALORES ACHADOS SEM BARRA PARCELA %s' %str(lista_retorno))
				else:		
					conta=tipo_saldo+conta
					lista_retorno.append(conta)
					
	elif len(parcela)==1:
		if parcela=='-' or parcela=='+':
			lista_retorno.append(parcela)
	logger.info('VALORES ACHADOS SEM BARRA PARCELA %s' %str(lista_retorno))
	return lista_retorno


def get_valores_com_barra(cr,uid,parcela,context=None):
	if context is None:
		context=[]
	lista_retorno=[]
	outra_lista=[]
	if len(parcela)>1:
		lista_parcela=parcela.split('/')
		if len(lista_parcela)>1:

			valor_inicial=lista_parcela[0]
			valor_final=lista_parcela[1]
			contador=valor_inicial[len(valor_inicial)-1]
			contador=int(contador)
			termino=int(valor_final)
			outra_lista.append(lista_parcela[0])
			outra_lista.append(['+'])
			outra_lista.append(lista_parcela[1])
			while contador<=termino:
				valor_oficial=valor_inicial[:len(valor_inicial)-1]+str(contador)
				#logger.info('VALORES A SEREM PROCESSADOS %s' %str(valor_oficial))
				lista_local=[]
				lista_local.append(valor_oficial)
				contador=contador+1
				lista_retorno.append(lista_local)
		else:
			lista_retorno=lista_parcela
	return lista_retorno
					#print valor_oficial

def _pegar_ultimo_movimento(self,cr,uid,context=None):
    if context is None:
        context={}
    pool= pooler.get_pool(cr.dbname)
    movimento_pool = pool.get('dotcom.contabilidade.movimentos')
    movimento_ids=movimento_pool.search(cr,uid,[])

    logger.info('Movimentos ACHADOS NA PESQUISA %s' %str(movimento_ids))
    return movimento_ids[len(movimento_ids)-1]


def get_filhos(cr,uid,conta,context=None):
		if context is None:
			context={}
		lista=[]

		if conta.tipo_interno=='m':
			lista.append(conta)
		elif conta.tipo_interno!='m' and len(conta.child_id)>0:
			for conta_interna in conta.child_id:
				if conta_interna.tipo_interno=='m':
					lista.append(conta_interna)
				else:
					lista2=get_filhos(cr,uid,conta_interna)
					for outro in lista2:
						lista.append(outro)
		return lista

	
def get_filhos_id(cr,uid,conta,context=None):
		if context is None:
			context={}
		lista=[]

		if conta.tipo_interno=='m':
			lista.append(conta.id)
		elif conta.tipo_interno!='m' and len(conta.child_id)>0:
			for conta_interna in conta.child_id:
				if conta_interna.tipo_interno=='m':
					lista.append(conta_interna.id)
				else:
					lista2=get_filhos(cr,uid,conta_interna)
					for outro in lista2:
						lista.append(outro.id)
		return lista
  
	
def get_filhos_ids(cr,uid,conta,context=None):
		if context is None:
			context={}
		lista=[]
		
		char=conta.ref[:1]
		if char=='1':
			logger.info('CONTA DE ENTRADA %s' %str(conta.ref))
		
		if conta.tipo_interno=='m':
			lista.append(conta.id)
		elif conta.tipo_interno!='m' and len(conta.child_id)>0:
			for conta_interna in conta.child_id:
				if conta_interna.tipo_interno=='m':
					lista.append(conta_interna.id)
				else:
					lista2=get_filhos(cr,uid,conta_interna)
					for outro in lista2:
						lista.append(outro.id)
		return lista


def get_getAntecessor_topo(cr,uid,conta,context=None):
	if context is None:
		context={}
		
	parente_topo=False
	
	if (conta.tipo_interno!='r'):
		if bool(conta.parent_id.id)!=False:
			parente=conta.parent_id
			#logger.info('PARENTE DIRECTO ACHADO PARA A CONTA 1% s' %str(parente.tipo_interno))
			if (parente.tipo_interno=='r'):
				parente_topo=parente
				#logger.info('PARENTE DIRECTO ACHADO E PARENTE DE TOPO 2 %s' %str(parente_topo))
			else:
				if bool(parente.parent_id.id)!=False:
					parente_topo=get_getAntecessor_topo(cr,uid,parente)
					#logger.info('PARENTE DIRECTO ACHADO E PARENTE DE TOPO 31 %s' %str(parente.parent_id.ref))
				else:
					parente_topo=parente
					#logger.info('PARENTE DIRECTO ACHADO E PARENTE DE TOPO 32 %s' %str(parente.parent_id.ref))

	else:
		parente_topo=conta
	#logger.info('PARENTE DE TOPO ACHADO PARA A CONTA 4 %s' %str(parente_topo))
	return parente_topo


def get_antecessores(cr,uid,conta,context=None):
	if context is None:
		context={}
	
	lista=[]
	#lista.append(conta)
	if (conta.tipo_interno!='r' ):
		#logger.info('CONTA AXADA %s' %str(conta.ref))
		if (conta.parent_id.id)==True:
			conta=conta.parent_id
			#logger.info('PARENTE ACHADO %s' %str(conta.ref))
			lista.append(conta)
			if (conta.tipo_interno!='r' ):
				lista2=get_antecessores(cr,uid,conta)
				for outra in lista2:
					lista.append(outra)
	return lista


def get_ascendente_totalizador(cr,uid,conta,context=None):
	if context is None:
		context,{}
	lista=[]
	valores={}
	if bool(conta.parent_id)==True and (conta.parent_id.tipo_interno=='t'):
		conta_ascendente=conta.parent_id

		lista.append(conta.parent_id)
		outra_lista=get_ascendente_totalizador(cr,uid,conta_ascendente)
		for outro in outra_lista:
			lista.append(outro)
		lista=sorted(lista, key=lambda d: (d['ref']))
		
	return lista

#Operacoes para o apuramento de IVA e Resultado

def get_periodo_apuramento_iva(self,cr,uid,context=None):
	if context is None:
		context={}
	
	periodo_retorno=None
	pool= pooler.get_pool(cr.dbname)
	iva_pool = pool.get('dotcom.contabilidade.iva')
	lancamentos_iva=iva_pool.search(cr,uid,[])
	
	#logger.info('ULTIMO LANCAMENTO IVA ACHADO %s' %str(lancamentos_iva))
	if len(lancamentos_iva)>0:
		ultimo_apuramento_id=lancamentos_iva[len(lancamentos_iva)-1]
		ultimo_lancamento_object=iva_pool.browse(cr,uid,ultimo_apuramento_id)
		
		#logger.info('ULTIMO LANCAMENTO IVA ACHADO %s' %str(ultimo_lancamento_object))
		outros_periodos_ids=pool.get('configuration.period').search(cr,uid,[
															('id','>',ultimo_lancamento_object.periodo_id.id),
															('fiscalyear_id','=',ultimo_lancamento_object.ano_fiscal_id.id),
															('special','=',False),
															('closing','=',False),
															])
		
		if len(outros_periodos_ids)>0:
			periodo_retorno=outros_periodos_ids[0]
	return periodo_retorno
	
	
def validar_apuramentos_iva(cr,uid,periodo_id,conversao_moeda,context=None):
	if context is None:
		context={}
	
	pool= pooler.get_pool(cr.dbname)
	logger.info('VALOR DA CONVERSAO MOEDA %s ' %str(conversao_moeda))
	moeda_secundaria_id=pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
	moeda_secundaria_id=moeda_secundaria_id[0]
	moeda_primaria_id=pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.tesouraria.lancamento.movimentos')
	moeda_lancamento_id=None
	if conversao_moeda=='mp':
		moeda_lancamento_id=moeda_primaria_id
	elif conversao_moeda=='ms':
		moeda_lancamento_id=moeda_secundaria_id
	
	
	movimentos_ids=pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
															('periodo','=',periodo_id),
															('state','=','emitido'),
															('moeda_lancamento_id','=',moeda_lancamento_id)
															])
	
	if len(movimentos_ids)>0:
		for movimento in movimentos_ids:
			movimento =pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
			if bool(movimento.iva_id.id)==True:
				raise osv.except_osv(_('Acção Inválida !'), _('Periodo com IVA já apurado!!'))
	return {}



def validar_referencia_movimento_fluxo_caixa(cr,uid,ano_fiscal_object,context=None):
	pool= pooler.get_pool(cr.dbname)
	contratos_pool = pool.get('dotcom.contabilidade.movimento.fluxo.caixa')
	results = contratos_pool.search(cr,uid,[
											('ano_fiscal_id','=',ano_fiscal_object.id),
											('ref','!=',False)])
	
	results=sorted(results,reverse=True)
	new_id=0
	if results !=[]:
		movimentos=contratos_pool.browse(cr,uid,results[0])
		new_id=len(results)+1
	else:
		new_id=new_id+1	
	
	#data=datetime.now()
	#ano=data.year
	
	ref=''
	if len(str(new_id))<=01:
		ref='FC.000'+str(new_id)+'-'+str(ano_fiscal_object.code)
	elif len(str(new_id))==2:
		ref='FC.00'+str(new_id)+'-'+str(ano_fiscal_object.code)
	elif len(str(new_id))==3:
		ref='FC.0'+str(new_id)+'-'+str(ano_fiscal_object.code)
	elif len(str(new_id))==4:
		ref='FC.'+str(new_id)+'-'+str(ano_fiscal_object.code)
	return ref
		
