# -*- coding: utf-8 -*-

import time
import datetime
#from lxml import etree
#import netsvc
from osv import osv, fields, orm
from tools.translate import _
import pooler

import logging
logger = logging.getLogger('DOTCOM_LOGGER')


def referencia_documento(cr,uid,documento,context=None):
	pool= pooler.get_pool(cr.dbname)
	obj = pool.get('dotcom.contabilidade.documento')
	documento_ids=obj.search(cr,uid,[])
	data_hoje=data=datetime.now()

	return {}