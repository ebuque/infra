# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


#class dotcom_plano_contas_confirmation(osv.osv):
#	_name='dotcom.contabilidade.plano.contas.confirmacao'
#	_columns={
#		'conta_anterior_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Anterior'),
#		'conta_actual_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Actual'),
#		
#	}
#
#dotcom_plano_contas_confirmation()

class dotcom_plano_contas(osv.osv):
	
	def _friendly_name(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			nome = plano.nome or ''
			friendly_name = '['+ref + '] ' + nome
			res[plano.id] = friendly_name
			
			
		return res
	
	def _referencia_gerada(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			ano = plano.ano_fiscal_id.code or ''
			friendly_name = ref + '/' + ano
			res[plano.id] = friendly_name
		return res
	
	#def name_get(self, cr, uid, ids, context=None):
	#	if not len(ids):
	#		return []
	#	reads = self.read(cr, uid, ids, ['ref','nome'], context=context)
	#	res = []
	#	for record in reads:
	#		name = record['nome']
	#		if record['ref']:
	#			name = record['ref']+' - '+name
	#		res.append((record['id'], name))
	#	return res
	def _ano_fiscal_company(self, cr, uid, ids, field, args, context=None):
		if context is None:
			context={}
			
		res = {}
		company_ids=self.pool.get('res.company').search(cr,uid,[])
		company_object=self.pool.get('res.company').browse(cr,uid,company_ids[0])
		for each in self.browse(cr, uid, ids):
			if company_object.ano_fiscal_id.id:
						logger.info('ANO FISCAL ACHADO NA COPANHIA %s' %str(company_object.ano_fiscal_id.code))		   
						res[each.id] = company_object.ano_fiscal_id.id
		logger.info('ANO FISCAL ACHADO NA COPANHIA %s' %str(res))	
		return res




	
	
	def _name_get_fnc(self, cr, uid, ids, prop, unknow_none, context=None):
		res = self.name_get(cr, uid, ids, context=context)
		return dict(res)
	
	def name_search(self,cr,uid,name='', args=[],operator='ilike',context={},limit=80):
		ids = []
		if name:
			ids = self.search(cr, uid, [('ref', '=ilike', '%s%%' % name)] + args,limit=limit, context=context)
			if not ids:
				ids = self.search(cr, uid, [('nome', operator, name)] + args,limit=limit, context=context)
		return self.name_get(cr,uid,ids)
	
	_name='dotcom.contabilidade.plano.contas'
	_columns={
			'ref':fields.char('Conta',size=25, required=True),
			'nome':fields.char('Nome',required=True,size=50),
			'complete_name': fields.function(_name_get_fnc, type="char", string='Name'),
			'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
			'tipo_conta_id':fields.many2one('dotcom.contabilidade.tipo.contas','Tipo de contas',),
			'conta_iva':fields.many2one('dotcom.contabilidade.plano.contas','Conta IVA'),
			'taxa':fields.float('Taxa'),
			'reflexao_custos_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano C. Custo', ),
			'reflexao_centro_custo_conta_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','C. Custo'),
			'tipo_reflexao_custo':fields.selection([('total','100 %'),('repartida','Repartida')],'Tipo Reflexao'),
			'tem_ref_custos':fields.boolean('Tem Reflexão'),
			'refectir_multipla':fields.boolean('Reflectir M. Dimensão'),
			'reflexao_analitica':fields.many2one('dotcom.contabilidade.plano.contas','Analitica'),
			'tipo_reflexao_analitica':fields.selection([('total','100 %'),('repartida','Repartida')],'Tipo Reflexão'),
			'tem_ref_analitica':fields.boolean('Tem Reflexão'),
			'tipo_interno':fields.selection([('r','Razão'),('t','Totalizadora'),('m','Movimento')],'Tipo Interno'),
			'moeda_lancamento_id':fields.many2one('res.currency','Moeda',),
			'periodo':fields.selection([('iva','IVA'),('resultados','Resultados')],'Periodo'),
			
			'apuramento_id':fields.many2one('dotcom.contabilidade.apuramentos','Apuramento'),
			'movimentos_ids':fields.one2many('dotcom.contabilidade.lancamentos.diarios','conta_id','Movimentos',readonly=True),
			
			'lancamentos_ascendente':fields.boolean('Lanç. na Ascendente'),
			'mandar_filho':fields.boolean('Enviar C. Filho'),
			
			'parent_id': fields.many2one('dotcom.contabilidade.plano.contas', 'Ascendente', required=False, ondelete="cascade"),
			'child_id': fields.one2many('dotcom.contabilidade.plano.contas', 'parent_id', string='Sub-contas'),
			'parent_left': fields.integer('Left Parent', select=1),
			'parent_right': fields.integer('Right Parent', select=1),
			'state': fields.selection([
						('draft','Draft'),
						('post','Posted'),
						('reset','Draft'),
						],'State', select=True, readonly=True),
			
			'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, ),
			
			'visivel':fields.boolean('Visivel'),
			
			'referencia_gerada': fields.function(_referencia_gerada, type='char', string='Referencia Gerada', method=True, store=True),
			
			'balancete_id':fields.many2one('dotcom.contabilidade.balancete','Balancete'),
			
			#declaracoes periodicas
			'declaracao_modelo_a':fields.boolean('Declaração'),
			'modelo_A_campos':fields.selection([
				('campo_1','1-Base Tributável'),
				('campo_2','2-Imposto a Favor do Estado'),
				('campo_3','3-Base Tributável'),
				('campo_4','4-Base Tributável'),
				('campo_5','5-Impostos a Favor do Sujeito Passívo'),
				('campo_6','6-Impostos a Favor do Sujeito Passívo'),
				('campo_7','7-Impostos a Favor do Sujeito Passívo'),
				('campo_8','8-Impostos a Favor do Sujeito Passívo'),
				('campo_9','9-Impostos a Favor do Sujeito Passívo'),
				('campo_10','10-Imposto a Favor do Estado'),
				('campo_16','16-Excesso a Reportar do Período Anterior'),
				('','17-Créditos Comunicados Pelos Serviços')],'Campos da Declaração'),
			
			'ano_fiscal_company': fields.function(_ano_fiscal_company, type='many2one', relation='configuration.fiscalyear', string='Ano Company', method=True, store=True),
			
			'fluxo_caixa':fields.boolean('Fluxo de Caixa'),
			}
		   
	_rec_name = 'friendly_name'
	
	#_order='create_date desc'
	
	_defaults = {
				'state': 'draft',
				'ano_fiscal_id':validator._get_default_year,
				'moeda_lancamento_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=c),
				}
	_parent_name = "parent_id"
	_parent_store = True
	_parent_order = 'ref, nome'
	_order = 'ref asc'
	
	
	
	def unlink(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		plano_contas=self.browse(cr,uid,ids,context)
		#logger.info('CONTAS SELECCIONADAS %s'  %str(plano_contas))
		lista_apagavel=[]
		for conta in plano_contas:
			if len(conta.movimentos_ids)>0:
				raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover esta Conta pois já tem movimentos emitidos.!'))
			if conta.tipo_interno!='m' and len(conta.child_id)>0:
				raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover esta Conta pois tem sub contas.!'))
			else:
				lista_apagavel.append(conta.id)
			
			if conta.tipo_interno=='m' and len(conta.movimentos_ids)<=0:
				lista_apagavel.append(conta.id)
				
				linhas_balancate_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[])
				for linha in linhas_balancate_ids:
					self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha)
				
				linhas_balancate_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[])
				for linha in linhas_balancate_ids:
					self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha)
					
				linhas_balancate_ids=self.pool.get('dotcom.contabilidade.alteracoes.lancamentos').search(cr,uid,[])
				for linha in linhas_balancate_ids:
					self.pool.get('dotcom.contabilidade.alteracoes.lancamentos').unlink(cr,uid,linha)
				
				linhas_balancate_ids=self.pool.get('dotcom.contabilidade.analise.movimento.linha').search(cr,uid,[])
				for linha in linhas_balancate_ids:
					self.pool.get('dotcom.contabilidade.analise.movimento.linha').unlink(cr,uid,linha)	
				
				if len(conta.parent_id.ref)>2 and (conta.parent_id.tipo_interno=='t' and len(conta.parent_id.child_id))==1:
					self.write(cr,uid,conta.parent_id.id,{'tipo_interno':'m'})
					logger.info('CONTA ASCENDENTE PASSA A SER Movimento')
				
		osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)
					#if 
					
					#logger.info('CONTA ASCENDENTE %s' %str(conta.parent_id.ref))
					#logger.info('TIPO INTERNO DA CONTA ASCENDENTE %s' %str(conta.parent_id.tipo_interno))
			#if (intervencao.state=='rascunho') and (intervencao.nome== False) :
		#		lista_apagavel.append(intervencao.id)
		#		if bool(intervencao.pedido_id) is not False:
		#			#pedido=self.pool.get('dotcom.internos.pedido.intervencao').search(cr,uid,[('intervencao_id','=',intervencao['id'])])
		#			#logger.info('PED %s' % str(pedido))
		#			self.pool.get('dotcom.internos.pedido.intervencao').write(cr,uid,intervencao.pedido_id.id,{'state':'registado'})
		#	else:
		#		raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover esta Intervenção pois já foi registada.!'))
		#	osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)
		return True
	
	
	def get_ano_fiscal(self, cr, uid, context={}):
		return validator._get_default_year
	
	_sql_constraints = [
		('name_uniq', 'unique (referencia_gerada,ano_fiscal_id)', 'A conta já está registrada no sistema. Conta deve ser única !'),
	]
	
	def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
		if context is None:
			context = {}
		this = super(dotcom_plano_contas, self).fields_view_get(cr, uid, view_id=view_id, view_type=view_type, context=context, toolbar=toolbar,submenu=submenu)
		fields = this.get('fi')
		#logger.info('FIELDS VIEW GET:\n%s' % this)
		return this
	
	def on_change_conta_iva(self,cr,uid,ids,conta_id,context=None):
		if context is None:
			context={}
		logger.info('CONTA-Id %s' %str(conta_id))
		lancamento=self.browse(cr,uid,ids)
		val={}
		if bool(conta_id)==True:
			conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_id)
			logger.info('CONTA %s' %str(conta))
			if (conta.tipo_interno=='r'):
				raise osv.except_osv(_('Acção Invalida !'), _('Tipo de Conta Nao Permitido!!'))
			elif (conta.tipo_interno=='t'):
				raise osv.except_osv(_('Acção Invalida !'), _('Tipo de Conta Nao Permitido!!'))	
		
			if bool(conta.conta_iva)==True:
				val={'reflexao_iva':True}
			if bool(conta.reflexao_custos_id)==True or(conta.tem_ref_custos==True):
				val['reflexao_centro']=True
				val['taxa']=17
		else:
			raise osv.except_osv(_('Acção Invalida !'), _('Seleccione a Conta!!'))
		return {'value':val}
	
	def _check_recursion(self, cr, uid, ids, context=None):
		level = 100
		while len(ids):
			cr.execute('select distinct parent_id from dotcom_contabilidade_plano_contas where id IN %s',(tuple(ids),))
			ids = filter(None, map(lambda x:x[0], cr.fetchall()))
			if not level:
				return False
			level -= 1
		return True

	_constraints = [
		(_check_recursion, 'Error ! You cannot create recursive categories.', ['parent_id'])
	]
	def child_get(self, cr, uid, ids):
		return [ids]

	
	def on_change_declaracao(self, cr,uid,ids,declacao,context=None):
		if context is None:
			context={}
		if bool(declacao)==True:
			return{'value':{'declaracao_modelo_a':True}}
		else:
			return{'value':{'declaracao_modelo_a':False}}
	
	
	def on_change_ref(self,cr,uid,ids,conta,ano_fiscal_id,context=None):
		if context is None:
			context={}
		val = {}
		validator.validar_numero_caracteres(cr,uid,conta,context)
		conta_asc = validator.get_conta_ascendente(cr, uid, conta,ano_fiscal_id, context=context)
		ascendent_object=self.browse(cr,uid,conta_asc)
		
		lista_lancamentos=self.verificar_existencia_lancamentos(cr,uid,conta_asc,ano_fiscal_id)
		retorno={}
		val = {'parent_id':conta_asc}
		
		if len(lista_lancamentos)>0:
			msgalert = {'title':'Warning','message':'A conta '+ ascendent_object.ref+' deixará de ser de movimento, os seus movimentos serão transferidos para a nova conta de movimento '+conta}
			retorno= {'value':val,'warning':msgalert}
		else:
			retorno= {'value':val}
		
		logger.info('ASC: %s' % conta_asc)
		
		
		return retorno


	def write_recursive(self, cr, uid, conta_id, context=None):
		if context is None:
			context = {}
		conta = self.browse(cr, uid, conta_id)
		if conta.parent_id:
			self.write_recursive(cr, uid, conta.parent_id.id, context=context)
			if conta.child_id:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
			else:
				logger.info('A definir conta parent como Mov')
				self.write(cr, uid, conta.id, {'tipo_interno':'m'})
		else:
			if len(conta.ref)>2:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
			else:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
		return True
	
  
	def write_recursive_children(self, cr, uid, conta_id ,context=None):
		if context is None:
			context = {}
		conta = self.browse(cr, uid, conta_id, context=context)
		if conta.child_id:
			for child in conta.child_id:
				if child.child_id:
					self.write_recursive_children(cr, uid, child.id, context=context)
			if len(conta.ref)==2:
				logger.info('A definir conta como Razao')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
			else:
				logger.info('A definir conta parent como Totalizadora')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
		else:
			if len(conta.ref)==2:
				logger.info('A definir conta como Razao')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
			else:
				logger.info('A definir conta parent como Movimento')
				self.write(cr, uid, conta.id, {'tipo_interno':'m'})
				
		return True
	
	
	def write(self,cr,uid,ids,values,context=None):
		if context is None:
			context={}
		
		reads = self.read(cr, uid, ids, ['ref','id','nome'])
		read_ids=None
		nome=None
		if reads:
			logger.info('READS %s' %str(reads))
			if type(reads) == list:
				read_ids=reads[0]
			elif type(reads) == dict:
				read_ids=reads
			read_ref=read_ids['ref']
			id=read_ids['id']
			nome_lido=read_ids['nome']
			
			chaves=values.keys()
						
			documento=self.browse(cr,uid,id)
			
			if chaves.__contains__('nome'):
				nome=values.get('nome', '')
			else:
				nome=nome_lido
			
			if chaves.__contains__('ref'):
				for chave in chaves:
					if chave=='ref':
						if values['ref']==read_ref:
							super(dotcom_plano_contas, self).write(cr, uid,id, values,context=context)
							
						else:
							val={
								'ref':values['ref'],
								'nome':nome,
								'ano_fiscal_id':documento.ano_fiscal_id.id,
								'tipo_interno':'m'
							}
							documento_criado_id=self.create(cr,uid,val)
							ref=values['ref']
							ref=ref.strip()
				
			else:
				super(dotcom_plano_contas, self).write(cr, uid,id, values,context=context)
		else:
			super(dotcom_plano_contas, self).write(cr, uid,id, values,context=context)
		return True

	
	def local_create(self,cr,uid,values,context=None):
		if context is None:
			context={}
		
		identificador=super(dotcom_plano_contas, self).create(cr, uid, values, context=context)
		return identificador
	

	def create(self, cr, uid, values, context=None):
		if context is None:
			context = {}
		conta = values.get('ref')
		ano_fiscal_id=values['ano_fiscal_id']
		nada = validator.validar_numero_caracteres(cr, uid, conta, context=context)
		pai_id = validator.get_conta_ascendente(cr, uid, conta,ano_fiscal_id, context=context)
		logger.info('A iniciar processo de criação de Conta ref: %s' %str (conta))
		#logger.info('Resultado de procura de conta ascendente, ID: %s' % pai_id)
		if pai_id is None:
			logger.info('Conta ascendente não existe, a iniciar verificações')
			if len(conta)>2:
				#logger.info('Conta possui mais de dois digitos, a iniciar processo de criação de conta ascendente')
				father_values = values.copy()
				##logger.info('Conta copiada, a definir valores')
				father_values['ref'] = conta[:2]
				father_values['tipo_interno'] = 'r'
				father_values['nome']='CONTA '+str(conta[:2])
				#logger.info('Valores definidos, ref: %s, tipo interno: Razão' % father_values.get('ref'))
				father = super(dotcom_plano_contas, self).create(cr, uid, father_values, context=context)
				#logger.info('Conta ascendente criada, a definir na conta a criar %s' %father)
				values['parent_id'] = father
			else:
				#logger.info('Conta possui 2 digitos, será definida como conta de Razão')
				values['parent_id'] = None
				values['tipo_interno'] = 'r'
		else:
			values['parent_id'] = pai_id
		#logger.info('A criar conta...')
		base = super(dotcom_plano_contas, self).create(cr, uid, values, context=context)
		
		#logger.info('Conta criada com ID: %s' % base)
		#logger.info('Inicio do processo de actualização de contas semelhantes')
		sons = self.search(cr, uid, [
							('ref','like',conta),
							('ano_fiscal_id','=',ano_fiscal_id)
						])
		#logger.info('Resultado da procura de Semelhantes: %s' %sons)
		#logger.info('..............................................................')
		if sons and len(sons)>0:
			#logger.info('A ordenar lista: %s' %sons)
			sons = sorted(sons)
			#logger.info('Lista ordenada: %s' %sons)
			reads = self.read(cr, uid, sons, ['ref','id','child_id'])
			reads = sorted(reads, key=lambda d: (d['id'], d['ref']), reverse=True)
			#logger.info('A ler valores e actualizar cada conta')
			for read in reads:
				#logger.info('A processar: %s' % read)
				me = read['id']
				my_ref = read['ref']
				my_father = validator.get_conta_ascendente(cr, uid, my_ref,ano_fiscal_id, context=context)
				self.write(cr, uid, me, {'parent_id':my_father})
		test = self.write_recursive(cr, uid, base, context=context)
		again = self.write_recursive_children(cr, uid, base, context=context)
		
		base_object=self.browse(cr,uid,base)
		ano_fiscal_id=base_object.ano_fiscal_id.id
		#logger.info('ANO FISCAL ID %s' %str(ano_fiscal_id))
		parent_id=base_object.parent_id.id
		#logger.info('PARENTE ID %s' %str(parent_id))
		
		lista_lancamentos=self.verificar_existencia_lancamentos(cr,uid,parent_id,ano_fiscal_id)
		
		saldos_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[('conta_id','=',parent_id)])
		for saldo in saldos_ids:
			self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,saldo,{'conta_id':base})
		
		if len(lista_lancamentos)>0:
			
			for lancamento in lista_lancamentos:
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento,{'conta_id':base})
				
		return base
	
	
	def verificar_existencia_lancamentos(self,cr,uid,conta_id,ano_fiscal_id,context=None):
		if context is None:
			context={}
		lista=[]
		lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[	
								('conta_id','=',conta_id),
								('ano_fiscal_id','=',ano_fiscal_id),
								('state','=','emitido')
			])
		if len(lancamentos_ids)>0:
			lista=lancamentos_ids
		return lista   
	
dotcom_plano_contas()


class dotcom_tipo_conta(osv.osv):
	_name='dotcom.contabilidade.tipo.contas'
	_columns={
		'codigo':fields.char('Código',size=25,required=True),
		'tipo':fields.char('Tipo',size=25,required=True),
		
	}
	_rec_name = 'codigo'

dotcom_tipo_conta()



class dotcom_saldo_contas(osv.osv):
	_name='dotcom.contabilidade.saldo.contas'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta'),
		'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		'linhas_saldos_ids':fields.one2many('dotcom.contabilidade.saldo.contas.periodo','saldos_ids','Saldos Periodicos', readonly=True)
	}
	
	
	#def actualizar_saldos(self,cr,uid,ids,context):
	#	if context is None:
	#		context={}
	#
	#	for documento in self.browse(cr,uid,ids):
	#		
	#		for lancamento in documento.linhas_saldos_ids:
	#			self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,lancamento.id,{'saldos_ids':False})	
	#		
	#		if bool(documento.conta_id.id)!=False:
	#			
	#			
	#			saldos_periodicos_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[('conta_id','=',documento.conta_id.id)])
	#			for lancamento in saldos_periodicos_ids:
	#				self.pool.get('dotcom.contabilidade.saldo.contas.periodo').unlink(cr,uid,lancamento)
	#			
	#			 
	#			for periodo in documento.ano_fiscal_id.period_ids:
	#				lancamentos_period_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
	#																								('conta_id','=',documento.conta_id.id),
	#																								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
	#																								('periodo_id','=',periodo.id),
	#																								('state','=','emitido'),
	#																								])
	#				#logger.info('LANCAMENTOS ACHADOS %s' %str(lancamentos_period_ids))
	#				 
	#				
	#				#logger.info('PERIODO %s' %str(periodo.name))
	#				#logger.info('PERIODO %s' %str(documento.conta_id.ref))
	#				
	#				credito_base=0
	#				debito_base=0
	#				credito_secundario=0
	#				debito_secundario=0
	#				
	#				logger.info('LANCAMENTOS ACHADOS %s' %str(lancamentos_period_ids))
	#				for lancamento in lancamentos_period_ids:
	#					
	#					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
	#					#logger.info('ENTROU NO PROCESSO %s' %str(lancamento.credito_moeda_base))
	#					#logger.info('ENTROU NO PROCESSO %s' %str(lancamento.debito_moeda_base))
	#					#logger.info('ENTROU NO PROCESSO %s' %str(credito_secundario))
	#					#logger.info('ENTROU NO PROCESSO %s' %str(debito_secundario)) 
	#					#
	#					credito_base=credito_base+lancamento.credito_moeda_base
	#					debito_base=debito_base+lancamento.debito_moeda_base
	#					credito_secundario=credito_secundario+lancamento.credito_moeda_secundaria
	#					debito_secundario=debito_secundario+lancamento.debito_moeda_secundaria
	#			   
	#				
	#				val={
	#					'total_debito_primaria':debito_base,
	#					'total_credito_primaria':credito_base,
	#					'total_debito_secundaria':debito_secundario,
	#					'total_credito_secundaria':credito_secundario,
	#					'periodo_id':periodo.id,
	#					'conta_id':documento.conta_id.id,
	#					'saldos_ids':documento.id,
	#				}
	#				
	#				self.pool.get('dotcom.contabilidade.saldo.contas.periodo').create(cr,uid,val)
	#		
	#		else:
	#			contas_movimento_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
	#																									('tipo_interno','=','m'),
	#																									('ano_fiscal_id','=',documento.ano_fiscal_id.id)
	#																									])
	#			
	#			linhas_diarios=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,[('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
	#			self.pool.get('dotcom.contabilidade.extratos.diario.linhas').unlink(cr,uid,linhas_diarios)
	#			for conta in contas_movimento_ids:
	#				
	#				
	#				
	#				
	#				saldos_periodicos_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[('conta_id','=',conta)])
	#				for lancamento in saldos_periodicos_ids:
	#					self.pool.get('dotcom.contabilidade.saldo.contas.periodo').unlink(cr,uid,lancamento)
	#								
	#				for periodo in documento.ano_fiscal_id.period_ids:
	#					#logger.info('PROCESSO INICIADO')
	#					lancamentos_period_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
	#																								('conta_id','=',conta),
	#																								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
	#																								('periodo_id','=',periodo.id),
	#																								('state','=','emitido'),
	#																								])
	#				
	#					credito_base=0
	#					debito_base=0
	#					credito_secundario=0
	#					debito_secundario=0
	#					
	#					for lancamento in lancamentos_period_ids:
	#						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
	#						credito_base_local=lancamento.credito_primario_arredondado
	#						debito_base_local=lancamento.debito_primario_arredondado
	#						credito_secundario_local=lancamento.credito_secundario_arredondado
	#						debito_secundario_local=lancamento.debito_secundario_arredondado
	#						
	#						
	#						if bool(lancamento.movimento_id.diario_id.id)==False:
	#							raise osv.except_osv(_('Acção Invalida !'), _('LANCAMENTO SEM DIARIO!!'))
	#						val={
	#							'data':lancamento.data_lancamento,
	#							'diario_id':lancamento.movimento_id.diario_id.id,
	#							'numero_diario':lancamento.numero_diario,
	#							'documento_id':lancamento.documento_id.id,
	#							'numero_documento':lancamento.numero_documento,
	#							'movimento_id':lancamento.movimento_id.id,
	#							'conta_id':lancamento.conta_id.id,
	#							'descricao':lancamento.descricao,
	#							'periodo_id':lancamento.periodo_id.id,
	#							#'extrato_diario_lancamento_id':documento.id,
	#							'lancamento_diario_id':lancamento.id,
	#							'debito':lancamento.debito,
	#							'credito':lancamento.credito,
	#							'debito_moeda_primaria':debito_base_local,
	#							'credito_moeda_primaria':credito_base_local,
	#							'debito_ms':debito_secundario_local,
	#							'credito_ms':credito_secundario_local,
	#						}
	#						#logger.info('VALOR A SER CRIADO %s' %str(val))
	#						identificador=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').create(cr,uid,val)
	#						logger.info('ENTROU NO PROCESSO %s' %str(identificador))
	#						#logger.info('ENTROU NO PROCESSO %s' %str(lancamento.movimento_id.diario_id.id))
	#						
	#						credito_base=credito_base+lancamento.credito_moeda_base
	#						debito_base=debito_base+lancamento.debito_moeda_base
	#						credito_secundario=credito_secundario+lancamento.credito_moeda_secundaria
	#						debito_secundario=debito_secundario+lancamento.debito_moeda_secundaria
	#					
	#					val={
	#						'total_debito_primaria':debito_base,
	#						'total_credito_primaria':credito_base,
	#						'total_debito_secundaria':debito_secundario,
	#						'total_credito_secundaria':credito_secundario,
	#						'periodo_id':periodo.id,
	#						'conta_id':conta,
	#						#'saldos_ids':documento.id,
	#					}
	#					
	#					self.pool.get('dotcom.contabilidade.saldo.contas.periodo').create(cr,uid,val)
	#				
	#	return True
	#		
	#		
	#
	#def carregar_linhas_saldo(self,cr,uid,ids,context):
	#	if context is None:
	#		context={}
	#		
	#	for documento in self.browse(cr,uid,ids):
	#		
	#		for lancamento in documento.linhas_saldos_ids:
	#			self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,lancamento.id,{'saldos_ids':False})
	#			
	#		if bool(documento.conta_id.id)==True:
	#			
	#			saldos_periodicos_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[
	#																									('conta_id','=',documento.conta_id.id)])
	#			logger.info('A CARREGAR LINHAS %s' %str(saldos_periodicos_ids))
	#			for saldo in saldos_periodicos_ids:
	#				self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,saldo,{'saldos_ids':documento.id})
	#			
	#	return True
		
dotcom_saldo_contas()


class dotcom_saldo_periodo(osv.osv):
	
	def _saldo_moeda_primaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		for documento in self.browse(cr,uid,ids):
			debito=documento.total_debito_primaria
			credito=documento.total_credito_primaria
			saldo=credito-debito
			res[documento.id]=0
								   
		return res
	
	
	def _saldo_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		for documento in self.browse(cr,uid,ids):
			debito=documento.total_debito_secundaria
			credito=documento.total_credito_secundaria
			saldo=credito-debito
			res[documento.id]=0
								   
		return res
	
	
	_name='dotcom.contabilidade.saldo.contas.periodo'
	_columns={
		'saldo_moeda_primaria': fields.function(_saldo_moeda_primaria, type='float', string='Saldo Primaria', method=True, store=True),
		'saldo_moeda_secundaria': fields.function(_saldo_moeda_secundaria, type='float', string='Saldo Secundaria', method=True, store=True),
		'total_debito_primaria':fields.float('Total Debito Primaria'),
		'total_debito_secundaria':fields.float('Total Debito Secundaria'),
		'total_credito_primaria':fields.float('Total Credito Primaria'),
		'total_credito_secundaria':fields.float('Total Credito Secundaria'),
		'natureza':fields.selection([('credito','C'),('debito','D'),('null','N')],'Natureza'),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta'),
		'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		
		'saldos_ids':fields.many2one('dotcom.contabilidade.saldo.contas','Saldo do Periodicos'),
	}
	
	
	#def write(self,cr,uid,ids,value,context=None):
	#	if context is None:
	#		context={}
	#		
	#	raise osv.except_osv(_('Acção Invalida !'), _('##################A ACTUALIZAR OS VALORES!!#############'))
	#	return true
		

dotcom_saldo_periodo()
