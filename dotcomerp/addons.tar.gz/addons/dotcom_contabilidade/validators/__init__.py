
import validator
#validator_sequenciador.py