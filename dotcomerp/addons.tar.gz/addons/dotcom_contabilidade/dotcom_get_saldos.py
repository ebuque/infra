# -*- coding: utf-8 -*-
import time
from datetime import datetime,timedelta
from dateutil.relativedelta import relativedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')
	
class dotcom_get_saldos(osv.osv):
		
	_name='dotcom.contabilidade.get.saldos'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=True, ),
		'ano_fiscal_anterio_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Anterior',required=False, readonly=True),
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'linhas_config_ids':fields.one2many('dotcom.contabilidade.linhas.resultado','venda_id','Linhas Vendas')
	}
		
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'periodo_inicial_id':validator._get_default_openning_period,
		'periodo_final_id':validator._get_default_present_period
	}
		
	def on_change_ano_id(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
				
		val={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		#logger.info('ANO ACTUAL %s' %str(ano_fiscal.date_start))
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		#logger.info('ANO ACTUAL %s' %str(ano_actual))
		ano_anterior=ano_actual-1
		#logger.info('ANO ANTERIOR %s' %str(ano_anterior))
		
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
		
		
		#logger.info('DATA INICIO ANO ANTERIOR %s' %str(data_inicio_novo_ano))
		
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			#ano_anterior=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_anterior_ids[0])
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
			periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
			data_fecho=periodo_abertura.date_stop
			val={'ano_fiscal_anterio_id':ano_anterior_ids[0]}
			self.write(cr,uid,ids,val)
		#else:
		#	raise osv.except_osv(_('Acao Invalida !'), _('Ano fiscal anterior a '+str(ano_actual)+' inesistente')) 
		ano_actual=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		val['periodo_inicial_id'] =  ano_actual.period_ids[0].id
		val['periodo_final_id']=False
		
		return {'value':val}
	#=============================================================================================================
	def carregar_saldos(self,cr,uid,ids,context):
		if context is None:
			context={}
		logger.info('===================Code running ======================= %s')
		for form_data in self.browse(cr,uid,ids):
			ano_actual = form_data.ano_fiscal_id.code
			ano_anterior=str(int(ano_actual)-1)
			ano_anterior_id = self.pool.get('configuration.fiscalyear').search(cr,uid,[('code','=',ano_anterior)])
			logger.info('ANO ANTERIOR======================= %s' %str(ano_anterior_id))
			
			if len(ano_anterior_id)>0:
				val={'ano_fiscal_anterio_id':ano_anterior_id[0]}
				self.write(cr,uid,ids,val)
			
	   
		lancamento_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
		
		for documento in self.browse(cr,uid,ids):
			
			#========================================================================
			ano_fiscal=str(documento.ano_fiscal_id.code)
			logger.info('ano_fiscal string %s' %str(ano_fiscal))
			
			ano_fiscal_anterior=str(int(documento.ano_fiscal_id.code)-1)
			logger.info('ano_fiscal (anterior)string %s' %str(ano_fiscal_anterior))
			
			periodo_inicial=documento.periodo_inicial_id
			periodo_final=documento.periodo_final_id
			
			periodo_inicial_id=periodo_inicial.id
			
			periodo_final_id=periodo_final.id
			
			
			
			periodo_inicial_code=periodo_inicial.code
			periodo_inicial_lancamento=periodo_inicial_code[0]+periodo_inicial_code[1]
			periodo_inicial_lancamento=int(periodo_inicial_lancamento)
			logger.info('periodo_inicial_lancamento ###########################%s' %str(periodo_inicial_lancamento))
			
			
			periodo_final_code=periodo_final.code
			periodo_final_lancamento=periodo_final_code[0]+periodo_final_code[1]
			periodo_final_lancamento=int(periodo_final_lancamento)
			logger.info('periodo_inicial_lancamento ###########################%s' %str(periodo_final_lancamento))
			
			
			
			
		  
			periodo_actual_start_date=periodo_inicial.date_start
			logger.info('Ano Actual periodo_actual_start_date %s' %str(periodo_actual_start_date))
			
			periodo_actual_end_date=periodo_final.date_stop
			logger.info('Ano Actual periodo_actual_end_date %s' %str(periodo_actual_end_date))
			
			#current_date =datetime.strptime(data_doc, "%Y-%m-%d").date()
			#end_date = current_date + timedelta(days=int(obj.dias))
			
			periodo_anterior_start_date=datetime.strptime(periodo_actual_start_date, "%Y-%m-%d").date()
			periodo_anterior_start_date=str(periodo_anterior_start_date - relativedelta(years=1))
			
			
			periodo_anterior_end_date=datetime.strptime(periodo_actual_end_date, "%Y-%m-%d").date()
			periodo_anterior_end_date=str(periodo_anterior_end_date - relativedelta(years=1))
			
			model_resultado=self.pool.get('dotcom.contabilidade.linhas.resultado')
			
			model_ano_fiscal=self.pool.get('configuration.fiscalyear')
			ano_fiscal_actual_id=model_ano_fiscal.search(cr,uid,[('code','=',ano_fiscal)])
			
			ano_fiscal_anterior_id=model_ano_fiscal.search(cr,uid,[('code','=',ano_fiscal_anterior)])
			
			modelo_periodo=self.pool.get('configuration.period')
			
			
			ids_to_remove=model_resultado.search(cr,uid,[])
			model_resultado.unlink(cr,uid,ids_to_remove)
			
			model_configuracoes=self.pool.get('dotcom.contabilidade.configuracao')
			configuracoes_ids=model_configuracoes.search(cr,uid,[])
			rubrica_objs=model_configuracoes.browse(cr,uid,configuracoes_ids)
			logger.info(' ===================================== PRINT rubrica_objs string %s' % rubrica_objs)
			#config_ids=[]
			linhas_criadas_ids=[]
			for rubrica_obj in rubrica_objs:
				saldo_actual=0
				saldo_anterior=0
				
	
					
					
				vals={
					'venda_id':ids[0],
					'periodo_inicial_id':periodo_inicial_id,
					'periodo_final_id':periodo_final_id,
					'ano_fiscal_id': ano_fiscal_actual_id[0],
					'config_id':rubrica_obj.id,
					'saldo_actual':saldo_actual,
					'saldo_anterior':saldo_anterior,
				}
				
				linha_criada=model_resultado.create(cr,uid,vals)
				linhas_criadas_ids.append(linha_criada)
			#===========================================================================================
			model_linha_conf=self.pool.get('dotcom.contabilidade.conf.linha')
				
			contas_a_remover=self.pool.get('dotcom.contabilidade.conf.linha').search(cr,uid,[])
			self.pool.get('dotcom.contabilidade.conf.linha').unlink(cr,uid,contas_a_remover)
				
				
			rubricas = model_configuracoes.browse(cr,uid,configuracoes_ids)
			logger.info('rubricas list %s' %str(rubricas))
			config_pos=0
			sequence=0
			total_credito_63=0
			total_debito_63=0
			for rubrica in rubricas:
				sequence=sequence+1
				
				total_saldo_actual=0
				total_saldo_anterior=0
				
				total_credito_actual=0
				total_debito_actual=0
				
				total_credito_anterior=0
				total_debito_anterior=0
				
				
				contas_relacionadas=rubrica.contas_relacionadas
				contas_relacionadas=contas_relacionadas.split(',')
				
				conta_model=self.pool.get('dotcom.contabilidade.plano.contas')
				conta_ids=conta_model.search(cr,uid,[('ref','in',contas_relacionadas)])
				
				
				
				
				linha_conf_ids=[]
				#========================================================== Saldos Actuais===============================================
				for conta_ref in contas_relacionadas:
				
					saldo_actual_conta=0
					credito_actual_conta=0
					debito_actual_conta=0
					
					logger.info('conta_ref %s' %str(conta_ref))
					conta_ref
					conta_id=conta_model.search(cr,uid,[('ref','=',conta_ref),('ano_fiscal_id','=',ano_fiscal_actual_id[0])])
					
					logger.info('conta_id %s' %str(conta_id))
					child=conta_model.browse(cr,uid,conta_id)[0]
				
					
					logger.info('child %s' %str(child))
					if child.tipo_interno =='m':
					
						for movimento in child.movimentos_ids:
							periodo_movimento=str(movimento.periodo_id.code)[0]+ str(movimento.periodo_id.code)[1]
							periodo_movimento=int(periodo_movimento)
							#logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
							if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento : #and movimento.periodo_id.code = :
								if movimento.state == 'emitido':
									logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
									total_credito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).credito
									total_debito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).debito
									
									total_credito_actual=total_credito_actual+total_credito_actual_readed
									total_debito_actual=total_debito_actual+total_debito_actual_readed
									
									credito_actual_conta=credito_actual_conta+total_credito_actual_readed
									debito_actual_conta=debito_actual_conta+total_debito_actual_readed
								
									
						total_saldo_actual=total_credito_actual-total_debito_actual
						saldo_actual_conta=credito_actual_conta-debito_actual_conta
						if total_saldo_actual<0:
							total_saldo_actual=total_saldo_actual*(-1)
							
					elif child.tipo_interno =='r':
						for child in child.child_id:
							if child.tipo_interno =='m':
					
								for movimento in child.movimentos_ids:
									periodo_movimento=str(movimento.periodo_id.code)[0]+str(movimento.periodo_id.code)[1]
									periodo_movimento=int(periodo_movimento)
									#logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
									if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento:
										if movimento.state == 'emitido':
											total_credito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).credito
											total_debito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).debito
											
											total_credito_actual=total_credito_actual+total_credito_actual_readed
											total_debito_actual=total_debito_actual+total_debito_actual_readed
											
											credito_actual_conta=credito_actual_conta+total_credito_actual_readed
											debito_actual_conta=debito_actual_conta+total_debito_actual_readed
											
								total_saldo_actual=total_credito_actual-total_debito_actual
								saldo_actual_conta=credito_actual_conta-debito_actual_conta
								if total_saldo_actual<0:
									total_saldo_actual=total_saldo_actual*(-1)

							elif child.tipo_interno =='t':
								total_credito_actual_readed =self.get_credito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
								total_debito_actual_readed =self.get_debito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
								
								total_credito_actual=total_credito_actual+total_credito_actual_readed
								total_debito_actual=total_debito_actual+total_debito_actual_readed
								
								
								credito_actual_conta=credito_actual_conta+total_credito_actual_readed
								debito_actual_conta=debito_actual_conta+total_debito_actual_readed
								
								total_saldo_actual=total_credito_actual-total_debito_actual
								saldo_actual_conta=credito_actual_conta-debito_actual_conta
									
					elif child.tipo_interno =='t':
						total_credito_actual_readed =self.get_credito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
						total_debito_actual_readed =self.get_debito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
								
						total_credito_actual=total_credito_actual+total_credito_actual_readed
						total_debito_actual=total_debito_actual+total_debito_actual_readed
								
						credito_actual_conta=credito_actual_conta+total_credito_actual_readed
						debito_actual_conta=debito_actual_conta+total_debito_actual_readed
								
						total_saldo_actual=total_credito_actual-total_debito_actual
						saldo_actual_conta=credito_actual_conta-debito_actual_conta
				
					#Aqui
					linha_conf={
						'conta_id':conta_id[0],
						'conf_id':rubrica.id,
						'saldo_actual':saldo_actual_conta,
						'saldo_anterior':0,	
					}
					
					linha_conf_id=model_linha_conf.create(cr,uid,linha_conf)
					linha_conf_ids.append(linha_conf_id)
				
				#===============================================================Fim Actuais=================================================
				#========================================================== Saldos Anteriores===============================================
				total_saldo_anterior=0
				pos_id=0
				if len(ano_fiscal_anterior_id)>0:
					for conta_ref in contas_relacionadas:
						saldo_anterior_conta=0
						credito_anterior_conta=0
						debito_anterior_conta=0
						
					
						logger.info('conta_ref %s' %str(conta_ref))
						conta_ref
						conta_id=conta_model.search(cr,uid,[('ref','=',conta_ref),('ano_fiscal_id','=',ano_fiscal_anterior_id[0])])
					
						logger.info('conta_id %s' %str(conta_id))
						child=conta_model.browse(cr,uid,conta_id)[0]
				
					
						logger.info('child %s' %str(child))
						if child.tipo_interno =='m':
					
							for movimento in child.movimentos_ids:
								periodo_movimento=str(movimento.periodo_id.code)[0]+ str(movimento.periodo_id.code)[1]
								periodo_movimento=int(periodo_movimento)
								#logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
								if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento : #and movimento.periodo_id.code = :
									if movimento.state == 'emitido':
										logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
										total_credito_anterior_readed=lancamento_model.browse(cr, uid,movimento.id).credito
										total_debito_anterior_readed=lancamento_model.browse(cr, uid,movimento.id).debito
									
										total_credito_anterior=total_credito_anterior+total_credito_anterior_readed
										total_debito_anterior=total_debito_anterior+total_debito_anterior_readed
										
										credito_anterior_conta=credito_anterior_conta+total_credito_anterior_readed
										debito_anterior_conta=debito_anterior_conta+debito_anterior_conta
								
									
							total_saldo_anterior=total_credito_anterior-total_debito_anterior
							saldo_anterior_conta=credito_anterior_conta-debito_actual_conta
							if total_saldo_anterior<0:
								total_saldo_anterior=total_saldo_anterior*(-1)
							
						elif child.tipo_interno =='r':
							for child in child.child_id:
								if child.tipo_interno =='m':
					
									for movimento in child.movimentos_ids:
										periodo_movimento=str(movimento.periodo_id.code)[0]+str(movimento.periodo_id.code)[1]
										periodo_movimento=int(periodo_movimento)
										#logger.info('periodo_movimento ###########################%s' %str(periodo_movimento))
										if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento:
											if movimento.state == 'emitido':
												total_credito_anterior_readed=lancamento_model.browse(cr, uid,movimento.id).credito
												total_debito_anterior_readed=lancamento_model.browse(cr, uid,movimento.id).debito
											
												total_credito_anterior=total_credito_anterior+total_credito_anterior_readed
												total_debito_anterior=total_debito_anterior+total_debito_anterior_readed
												
												credito_anterior_conta=credito_anterior_conta+total_credito_anterior_readed
												debito_anterior_conta=debito_anterior_conta+debito_anterior_conta
											
									total_saldo_anterior=total_credito_anterior-total_debito_anterior
									saldo_anterior_conta=credito_anterior_conta-debito_actual_conta
									if total_saldo_anterior<0:
										total_saldo_anterior=total_saldo_anterior*(-1)

								elif child.tipo_interno =='t':
									total_credito_anterior_readed =self.get_credito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
									total_debito_anterior_readed =self.get_debito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
								
									total_credito_anterior=total_credito_anterior+total_credito_anterior_readed
									total_debito_anterior=total_debito_anterior+total_debito_anterior_readed
								
									credito_anterior_conta=credito_anterior_conta+total_credito_anterior_readed
									debito_anterior_conta=debito_anterior_conta+debito_anterior_conta
											
									total_saldo_anterior=total_credito_anterior-total_debito_anterior
									saldo_anterior_conta=credito_anterior_conta-debito_actual_conta
									
						elif child.tipo_interno =='t':
							total_credito_anterior_readed =self.get_credito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
							total_debito_anterior_readed =self.get_debito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
								
							total_credito_anterior=total_credito_anterior+total_credito_anterior_readed
							total_debito_anterior=total_debito_anterior+total_debito_anterior_readed
								
							credito_anterior_conta=credito_anterior_conta+total_credito_anterior_readed
							debito_anterior_conta=debito_anterior_conta+debito_anterior_conta
											
							total_saldo_anterior=total_credito_anterior-total_debito_anterior
							saldo_anterior_conta=credito_anterior_conta-debito_actual_conta
						
				
						#Aqui
						linha_conf={
							'saldo_anterior':saldo_anterior_conta,	
						}
						model_linha_conf.write(cr,uid,linha_conf_ids[pos_id],linha_conf)
						pos_id+=1
				#===============================================================Fim Anterior=================================================
				
				
				logger.info('ids string %s' %str(ids))
				vals={
					'saldo_actual':total_saldo_actual,
					'saldo_anterior':total_saldo_anterior,
					'sequence':sequence,
				}
				model_resultado.write(cr,uid,linhas_criadas_ids[config_pos],vals)
				config_pos+=1
			
			
			
				valores={
					'periodo_inicial_id':periodo_inicial_id,
					'periodo_final_id':periodo_final_id,
					'ano_fiscal_id': ano_fiscal_actual_id[0],
					'valor_demonstracao_actual':total_saldo_actual,
					'valor_demonstracao_anterior':total_saldo_anterior,	
				}
				logger.info('vals string %s' %str(vals))
			
				model_configuracoes.write(cr,uid,rubrica.id,valores)
	
		return total_saldo_actual
	#=============================================================================================================
		
		
		
		
		
	def get_credito(self,cr,uid,conta,periodo_inicial_lancamento,periodo_final_lancamento ):
		total_credito=0
		lancamento_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
		for child in conta.child_id:
			if child.tipo_interno =='m':
				for movimento in child.movimentos_ids:
					periodo_movimento=str(movimento.periodo_id.code)[0]+str(movimento.periodo_id.code)[1]
					periodo_movimento=int(periodo_movimento)
					if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento :
						if movimento.state == 'emitido':
							total_credito_readed=lancamento_model.browse(cr, uid,movimento.id).credito
							total_credito=total_credito+total_credito_readed
			elif child.tipo_interno =='t':
				total_credito=total_credito+self.get_credito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
		return total_credito
		
		
		
	def get_debito(self,cr,uid,conta,periodo_inicial_lancamento,periodo_final_lancamento ):
		total_debito=0
		lancamento_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
		for child in conta.child_id:
			if child.tipo_interno =='m':
				for movimento in child.movimentos_ids:
					periodo_movimento=str(movimento.periodo_id.code)[0]+str(movimento.periodo_id.code)[1]
					periodo_movimento=int(periodo_movimento)
					if periodo_inicial_lancamento <= periodo_movimento <= periodo_final_lancamento :
						if movimento.state == 'emitido':
							total_debito_readed=lancamento_model.browse(cr, uid,movimento.id).debito
							total_debito=total_debito+total_debito_readed
			elif child.tipo_interno =='t':
				total_debito=total_debito+self.get_debito(cr,uid,child,periodo_inicial_lancamento,periodo_final_lancamento)
		return total_debito
	#===================================================================================================================
	#calcular saldo
	#=============================================================================================================
		
dotcom_get_saldos()
	
	
	
	
	
class dotcom_linhas_resultado(osv.osv):
	_name='dotcom.contabilidade.linhas.resultado'
	_columns={
			
		'venda_id': fields.many2one('dotcom.contabilidade.get.saldos','contas',required=True),
		'config_id':fields.many2one('dotcom.contabilidade.configuracao','Rubricas'),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=True ),
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'saldo_actual':fields.float('Saldo Actual',readonly=True),
		'saldo_anterior':fields.float('Saldo Anterior',readonly=True),
		'sequence':fields.integer('Sequencia',readonly=True),
	}
	_rec_name='conta_id'
dotcom_linhas_resultado()
	
	
	
class dotcom_configuracao(osv.osv):
	_name='dotcom.contabilidade.configuracao'
	_columns={
			
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual'),
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=False ),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=False),
		'ref':fields.char('Ref', size=25,required=True),
		'contas_relacionadas':fields.char('Contas Relacionadas', size=150,required=True),
		'child_id':fields.one2many('dotcom.contabilidade.conf.linha','conf_id','Activos', readonly=True),
		'descricao':fields.char('Descricao',size=100,required=True),
		'valor_demonstracao_actual':fields.float('Valor Dem. Result.(Actual)', readonly=True),
		'valor_demonstracao_anterior':fields.float('Valor Dem. Result.(Anterior)', readonly=True),
	}
		
	_rec_name="descricao"
		
		
		
	def on_change_ano_id(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
				
		val={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		#logger.info('ANO ACTUAL %s' %str(ano_fiscal.date_start))
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		#logger.info('ANO ACTUAL %s' %str(ano_actual))
		ano_anterior=ano_actual-1
		#logger.info('ANO ANTERIOR %s' %str(ano_anterior))
		
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
			
			
		#logger.info('DATA INICIO ANO ANTERIOR %s' %str(data_inicio_novo_ano))
			
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			#ano_anterior=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_anterior_ids[0])
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
			periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
			data_fecho=periodo_abertura.date_stop
			val={'ano_fiscal_anterio_id':ano_anterior_ids[0]}
			self.write(cr,uid,ids,val)
		#else:
		#	raise osv.except_osv(_('Acao Invalida !'), _('Ano fiscal anterior a '+str(ano_actual)+' inesistente')) 
		ano_actual=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		val['periodo_inicial_id'] =  ano_actual.period_ids[0].id
		val['periodo_final_id']=False
			
		return {'value':val}
		
		
		
		
		#==============================================ACTualiza Contas Configuracao========================================================
	def actualiza_contas_relacionadas(self,cr,uid,ids,context):
					
		for form_data in self.browse(cr,uid,ids):
			contas_relacionadas=form_data.contas_relacionadas
			logger.info('contas_relacionadas string %s' %str(contas_relacionadas))
			contas_relacionadas=contas_relacionadas.split(',')
					
				
			conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[])
				
			logger.info('contas_relacionadas list %s' %str(contas_relacionadas))
			contas_a_remover=self.pool.get('dotcom.contabilidade.conf.linha').search(cr,uid,[('conta_id','in',conta_ids)])
			self.pool.get('dotcom.contabilidade.conf.linha').unlink(cr,uid,contas_a_remover)
				
			ano_fiscal=str(form_data.ano_fiscal_id.code)
			logger.info('ano_fiscal string %s' %str(ano_fiscal))
				
				
			ano_fiscal_anterior=str(int(form_data.ano_fiscal_id.code)-1)
				
			periodo_actual_start_date=form_data.periodo_inicial_id.date_start
			logger.info('Ano Actual periodo_actual_start_date %s' %str(periodo_actual_start_date))
				
			periodo_actual_end_date=form_data.periodo_final_id.date_stop
			logger.info('Ano Actual periodo_actual_end_date %s' %str(periodo_actual_end_date))
				
			periodo_anterior_start_date=datetime.strptime(periodo_actual_start_date, "%Y-%m-%d").date()
			periodo_anterior_start_date=periodo_anterior_start_date-relativedelta(years=1)
			periodo_anterior_start_date=str(periodo_anterior_start_date)
			logger.info('Ano Anterior periodo_anterior_start_date %s' %str(periodo_anterior_start_date))
				
				
				
				
			periodo_anterior_end_date=datetime.strptime(periodo_actual_end_date, "%Y-%m-%d").date()
			periodo_anterior_end_date=periodo_anterior_end_date-relativedelta(years=1)
			periodo_anterior_end_date=str(periodo_anterior_end_date)
			logger.info('Ano Anterior periodo_anterior_end_date %s' %str(periodo_anterior_end_date))
				
			linhas_ids=[]#IDS linhas criadas
			#=======================================Contas Actuais================================================================
			contas_relacionadas_actuais_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal),('ref','in',contas_relacionadas)])
			logger.info('contas_relacionadas_actuais_ids string %s' % contas_relacionadas_actuais_ids)
			
			saldo_global_actual=0.0
			for conta_id in contas_relacionadas_actuais_ids:
				saldo_actual=self.carregar_saldo(cr,uid,ids,conta_id,ano_fiscal,periodo_actual_start_date,periodo_actual_end_date,context)
				saldo_anterior=self.carregar_saldo(cr,uid,ids,conta_id,ano_fiscal,periodo_anterior_start_date,periodo_anterior_end_date,context)
				val={
						'conta_id':conta_id,
						'conf_id': form_data.id,
						'saldo_actual':saldo_actual,
						'saldo_anterior':saldo_anterior,
				}
				linhas_id=self.pool.get('dotcom.contabilidade.conf.linha').create(cr,uid,val)
				linhas_ids.append(linhas_id)
				saldo_global_actual+=saldo_actual
				valor={
					'valor_demonstracao_actual':saldo_global_actual
				}
				self.write(cr,uid,ids,valor)
					
			#=======================================Contas Anteriores================================================================
			contas_relacionadas_anteriores_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_anterior),('ref','in',contas_relacionadas)])
			logger.info('contas_relacionadas_anteriores_ids string %s' % contas_relacionadas_actuais_ids)
				
			id_linha_pos=0
			saldo_global_anterior=0.0
			logger.info('===============================linhas_ids string %s' % linhas_ids)
			for conta_id in contas_relacionadas_anteriores_ids:
				saldo_actual=self.carregar_saldo(cr,uid,ids,conta_id,ano_fiscal,periodo_actual_start_date,periodo_actual_end_date,context)
				saldo_anterior=self.carregar_saldo(cr,uid,ids,conta_id,ano_fiscal_anterior,periodo_anterior_start_date,periodo_anterior_end_date,context)
				val={
					'saldo_anterior':saldo_anterior,
				}
				logger.info('id_linha_pos string %s' % id_linha_pos)
				logger.info('linhas_ids[int(id_linha_pos)] string %s' % linhas_ids[id_linha_pos])
				self.pool.get('dotcom.contabilidade.conf.linha').write(cr,uid,linhas_ids[id_linha_pos],val)	 
				id_linha_pos+=1
				saldo_global_anterior+=saldo_anterior
				
				valor={
					'valor_demonstracao_anterior':saldo_global_anterior
				}
				self.write(cr,uid,ids,valor)
			
		return contas_relacionadas_actuais_ids	
		
	#====================================================================================================================================	
	
	
	def carregar_saldo(self,cr,uid,ids,conta_id,ano_fiscal_id,periodo_start_date,periodo_end_date,context):
		if context is None:
			context={}
		
		for form_data in self.browse(cr,uid,ids):
			ano_actual = form_data.ano_fiscal_id.code
			ano_anterior=str(int(ano_actual)-1)
			ano_anterior_id = self.pool.get('configuration.fiscalyear').search(cr,uid,[('code','=',ano_anterior)])
			if len(ano_anterior_id)>0:
				val={'ano_fiscal_anterio_id':ano_anterior_id[0]}
				self.write(cr,uid,ids,val)
			
		conta_model=self.pool.get('dotcom.contabilidade.plano.contas')
		lancamento_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
		
		for documento in self.browse(cr,uid,ids):
			 
			lista_ids_linhas=[]
			
			conta=conta_model.browse(cr,uid,conta_id)
			total_saldo_actual=0
			for child in conta.child_id:
				if child.tipo_interno =='m':
					
					for movimento in child.movimentos_ids:
						if periodo_start_date <= movimento.data_lancamento <= periodo_end_date:
							if movimento.state == 'emitido':
								total_credito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).credito
								total_debito_actual_readed=lancamento_model.browse(cr, uid,movimento.id).debito
							
								saldo_linha=total_credito_actual_readed - total_debito_actual_readed
	
								total_saldo_actual+=saldo_linha
					
					if total_saldo_actual<0:
						total_saldo_actual=total_saldo_actual*(-1)
							
				elif child.tipo_interno =='t':
					total_saldo_actual_readed= self.calcula_saldo(cr,uid,child,periodo_start_date,periodo_end_date)
					total_saldo_actual += total_saldo_actual_readed
		return total_saldo_actual
	
	def calcula_saldo(self,cr,uid,conta,periodo_start_date,periodo_end_date):
		total_saldo=0
		lancamento_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
		for child in conta.child_id:
			if child.tipo_interno =='m':
				for movimento in child.movimentos_ids:
					if periodo_start_date <= movimento.data_lancamento <= periodo_end_date:
						if movimento.state == 'emitido':
							total_credito_readed=lancamento_model.browse(cr, uid,movimento.id).credito
							total_debito_readed=lancamento_model.browse(cr, uid,movimento.id).debito
							saldo_linha=total_credito_readed - total_debito_readed
					   
							total_saldo+=saldo_linha
				
				if total_saldo<0:
					total_saldo=total_saldo*(-1)	   
			elif child.tipo_interno =='t':
				total_saldo_readed = self.calcula_saldo(cr,uid,child,periodo_start_date,periodo_end_date)
				total_saldo += total_saldo_readed
		return total_saldo
	
dotcom_configuracao()
	
class dotcom_configuracao_linha(osv.osv):
	_name='dotcom.contabilidade.conf.linha'
	_columns={
	   'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Activos',required=True),
	   'conf_id':fields.many2one('dotcom.contabilidade.configuracao'),
	   'saldo_actual':fields.float('Saldo Actual',readonly=True),
	   'saldo_anterior':fields.float('Saldo Anterior',readonly=True),
	
	}
dotcom_configuracao_linha()