# -*- encoding: utf-8 -*-

from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('definicoe_defaults_wizards')
import csv

class ano_fiscal(osv.osv):
	
	
	def _ano_fiscal(self,cr,uid,context=None):
		#ano_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','!=',False or None)])
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
		i=1
		
		#for documento in self.browse(cr, uid, ids):
		#	logger.info('IDENTIFICADOR DO DOCUMENTO %s' %str(documento.id))
		
		for centro in ano_ids:
			#if centro!=ids:
				
			centro=self.browse(cr,uid,centro)
			nome = 'Copiar '+ str(centro.code)
			result= (str(centro.id),str(nome))
			this.append(result)
			
		nome='NOVO'
		result=('novo',str(nome))
		this.append(result)
			
			
		
		return this
  
	def _centro_custo(self,cr,uid,context=None):
		centro_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[])
		result= ()
		this = []
		lista_anos_fiscais=[]
		logger.info('CENTRO%s'%str(len(centro_ids)))
		for centro in centro_ids:
			centro=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro)
			if bool(lista_anos_fiscais.__contains__(centro.ano_fiscal_id))==False:
				lista_anos_fiscais.append(centro.ano_fiscal_id)
			logger.info('CENTRO')
		
		for ano in lista_anos_fiscais:	  
			nome='Copiar ' +str(ano.code)
			result=(str(ano.id),nome)
			this.append(result) 
			#if i==len(centro_ids):
		#nome='NOVO'
		#result=('novo',str(nome))
		#this.append(result)
			#i=i+1
		#result = tuple(this)
		logger.info('CENTRO %s' %str(this))
		return this
	
	def _fluxo_caicurrency_idxa(self,cr,uid,context=None):
		fluxo_ids=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[])
		result=()
		this=[]
		for fluxo in fluxo_ids:
			#i=1
			#if i==len(fluxo_ids):
			logger.info('FLUXO')
			fluxo=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,fluxo)
			nome=fluxo.ref+'/'+fluxo.ano_fiscal_id.code
			result=(str(fluxo.id),nome)
			this.append(result)

		logger.info('FLUXO %s' %str(result))
		return this
		
	def _diario(self,cr,uid,context=None):
		diario_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[])
		result=()
		this=[]
		i=1
		lista_anos_fiscais=[]
		for diario in diario_ids:
			diario=self.pool.get('dotcom.contabilidade.diario').browse(cr,uid,diario)
			if bool(lista_anos_fiscais.__contains__(diario.ano_fiscal_id))==False:
				lista_anos_fiscais.append(diario.ano_fiscal_id)
		
		for ano in lista_anos_fiscais:		
			nome='Copiar ' +str(ano.code)
			result=(str(ano.id),nome)
			this.append(result)
			#if i==len(diario_ids):
		nome='NOVO'
		result=('novo',str(nome))
		this.append(result)
			#i=i+1
		#logger.info('DIARIO %s' %str(result))
		return this
		
	def _documento(self,cr,uid,context=None):
		diario_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[])
		result=()
		this=[]
		lista_anos_fiscais=[]
		for diario in diario_ids:
			diario=self.pool.get('dotcom.contabilidade.documento').browse(cr,uid,diario)
			if bool(lista_anos_fiscais.__contains__(diario.ano_fiscal_id))==False:
				lista_anos_fiscais.append(diario.ano_fiscal_id)
		
		for ano in lista_anos_fiscais:  
			nome='Copiar ' +str(ano.code)
			result=(str(ano.id),nome)
			this.append(result) 
		nome='NOVO'
		result=('novo',str(nome))
		this.append(result)
			#i=i+1
			#i=i+1
		logger.info('RESULT %s' %str(result))
		return this
	
	def _apuramento(self,cr,uid,context=None):
		diario_ids=self.pool.get('dotcom.contabilidade.apuramentos').search(cr,uid,[])
		result=()
		this=[]
		lista_anos_fiscais=[]
		for diario in diario_ids:
			diario=self.pool.get('dotcom.contabilidade.apuramentos').browse(cr,uid,diario)
			if bool(lista_anos_fiscais.__contains__(diario.ano_fiscal_id))==False:
				lista_anos_fiscais.append(diario.ano_fiscal_id)
		
		for ano in lista_anos_fiscais:	 
			nome='Copiar ' +str(ano.code)
			result=(str(ano.id),nome)
			this.append(result)
			
		nome='NOVO'
		result=('novo',str(nome))
		this.append(result)
		logger.info('RESULT %s' %str(result))
		return this
	
	
	def _fluxo_caixa(self,cr,uid,context=None):
		diario_ids=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[])
		result=()
		this=[]
		lista_anos_fiscais=[]
		for diario in diario_ids:
			diario=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,diario)
			if bool(lista_anos_fiscais.__contains__(diario.ano_fiscal_id))==False:
				lista_anos_fiscais.append(diario.ano_fiscal_id)
		
		for ano in lista_anos_fiscais:	 
			nome='Copiar ' +str(ano.code)
			result=(str(ano.id),nome)
			this.append(result)
			
		nome='NOVO'
		result=('novo',str(nome))
		this.append(result)
		logger.info('RESULT %s' %str(result))
		return this
		
		
	_name = "configuration.fiscalyear"
	_inherit = 'configuration.fiscalyear'
	_columns = {
		'ano_copia':fields.selection(_ano_fiscal,'Plano de Contas'),
		'check_ano_copia':fields.boolean('Criar'),
		
		'centro_custo_id':fields.selection(_centro_custo,'Centro de Custos'),
		'check_centro':fields.boolean('Criar'),
		
		'fluxo_caixa_id':fields.selection(_fluxo_caixa,'Fluxo Caixa',),
		'check_caixa':fields.boolean('Criar'),
		
		'diario_id':fields.selection(_diario,'Diário',),
		'check_diario':fields.boolean('Criar'),
		
		'documento_id':fields.selection(_documento,'Documento',),
		'check_documento':fields.boolean('Criar'),
		
		'apuramento_id':fields.selection(_apuramento,'Apuramento'),
		'check_apuramento':fields.boolean('Criar'),
		
		'plano_contas_ids': fields.one2many('dotcom.contabilidade.plano.contas','ano_fiscal_id','Planos de Conta'),
		
		'percentagem_processamento':fields.float('Percentagem'),
	}
	
	
	_defaults={
		'ano_copia':'novo',
		#'centro_custo_id':'novo',
		#'fluxo_caixa_id':'novo',
		'diario_id':'novo',
		'documento_id':'novo',
		'apuramento_id':'novo',
		
	}
		
	
	def create_plano_default(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		planos_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
				('ano_fiscal_id','=',False or None)
			])
		logger.info('PLANOS %s' %str(planos_ids))
		ano_fiscal=None
		for documento in self.browse(cr,uid,ids):
			for plano in planos_ids:
				self.pool.get('dotcom.contabilidade.plano.contas').write(cr,uid,plano,{'ano_fiscal_id': documento.id})
		
		return {}

	def read_plano_from_csv(self, cr, uid,ids,address='', ano_fiscal=None,classe='', context=None):
		if context is None:
			context = {}
		res = {}
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			contador=0
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal)
					linha = {}
					linha['ref'] = row and row[0]
					linha['nome'] = row and row[1]
					linha['tipo_interno'] = row and row[2]
					linha['ano_fiscal_id'] = ano_fiscal or False
					campo_modelo_A=row and row[3]
					#logger.info('VALOR DA CONTA DO MODELO A %s' %str(campo_modelo_A))
					if campo_modelo_A!="":
						linha['modelo_A_campos']=campo_modelo_A
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
					contador=contador+1
					#self.write(cr,uid,ids,{'percentagem_processamento':percentagem})
		return res
	
	def read_balanco_conf_from_csv(self, cr, uid,address='', ano_fiscal=None,classe='', context=None):
		if context is None:
			context = {}
		res = {}
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					logger.info('ROWS ENCONTRADOS %s' %str(row))
					linha = {}
					linha['ref'] = row and row[0]
					linha['descricao'] = row and row[1]
					linha['operacao']=row and row[2]
					linha['ano_fiscal_id'] = ano_fiscal or False
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
		return res
	
	def read_plano_conf_linha_from_csv(self, cr, uid,address='', ano_fiscal=None,classe='',plano_contas={},  conf={},context=None):
		if context is None:
			context = {}
		res = {}
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					linha = {}
					linha['ref']=row[0]
					
					logger.info('CONF REFERENCE %s' %str(row[0]))
					
					linha['conf_id'] = self.get_real_value(conf, row and row[2])
					linha['ano_fiscal_id'] = ano_fiscal or False
					
					logger.info('REFERENCIA DA CONTA ACHADA %s' %str(row[1]))
					conta_id=self.get_real_value(plano_contas, row and row[1])
					logger.info('CONTA ID %s' %str(conta_id))
					linha['conta_id'] = conta_id
					
					id = self.pool.get(classe).create(cr, uid, linha)
					#logger.info('IDENTIFICADOR CRIADO %s' %str(id))
					res[linha['ref']] = id
		return res
	
	def read_diario_from_csv(self, cr, uid,address='', ano_fiscal=None,classe='', context=None):
		if context is None:
			context = {}
		res = {}
		logger.info('ANO FISCAL DO DOCUMENTO A SER CRIADO%s' %str(ano_fiscal))
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal)
					
					linha = {}
					linha['ref'] = row and row[0]
					#logger.info('ANO FISCAL DO DOCUMENTO A SER CRIADO%s' %str(ano_fiscal_object.code))
					linha['nome'] = row and row[1]
					linha['ano_fiscal_id'] = ano_fiscal or False
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
		return res
	   
	def read_documento_from_csv(self, cr, uid,address='', ano_fiscal=None,classe='',diarios={}, context=None):
		if context is None:
			context = {}
		res = {}
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal)
					
					linha = {}
					linha['ref'] = row and row[0]
					linha['nome'] = row and row[1]
					linha['ano_fiscal_id'] = ano_fiscal or False
					linha['diario_id']=self.get_real_value(diarios, row and row[2])
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
		return res
	
	def read_contas_from_csv(self, cr, uid,ano_fiscal_id,address='',classe='', apuramento={}, plano={}, context=None):
		if context is None:
			context = {}
		res = []
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																				('ano_fiscal_id','=',ano_fiscal_id),
																						])				  
					
					linha = {}
					
					if plano_contas_ids>0:
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																											('ano_fiscal_id','=',ano_fiscal_id),
																											('ref','=',row[0])
																											])
						if len(plano_contas_ids)>0:		 
							linha['conta_id']= plano_contas_ids[0]
					else:
						linha['conta_id'] = self.get_real_value(plano, row and row[0])
					
					#logger.info('APURAMENENTO ACHADO PARA CRIACAO %s' %str(self.get_real_value(apuramento, row and row[1])))
					linha['apuramento_id'] = self.get_real_value(apuramento, row and row[1])
					#raise osv.except_osv(_('Acção Inválida !'), _('TESTE EM EXECUCAO'))
					linha['periodo'] = row and row[2]
					
					id = self.pool.get(classe).create(cr, uid, linha)
					res.append(id)
		return res
	
	def get_real_value(self, lista = {}, campo=''):
		res = None
		#logger.info('VALOR ENTREGUE AO APURAMENTO %s' %str(lista))
		if lista and campo:
			if lista.has_key(campo):
				res = lista.get(campo)
		#logger.info('APURAMENTO ACHADO %s' %str(res))
		return res
	
	def read_apuramento_from_csv(self, cr, uid,ids,address='', ano_fiscal=None,classe='', plano_contas={}, diario={}, documento={},context=None):
		if context is None:
			context = {}
		res = {}
	
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal)
				
					linha = {}
					linha['ref'] = row and row[0] or False
					linha['nome'] = row and row[1] or False
					linha['tipo_apuramento'] = row and row[2] or False
					
					
					linha['ano_fiscal_id'] = ano_fiscal or False
					
					
					diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal)])
					if len(diarios_ids)>0:
						diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal),
																								('ref','=',row[3])])
						if len(diarios_ids)>0:
							linha['diario_id'] = diarios_ids[0]
					else:
						linha['diario_id'] = self.get_real_value(diario, row and row[3])
						
					
					documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal)])
					if len(documentos_ids)>0:
						documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal),
																										('ref','=',row[4])])
						if len(documentos_ids)>0:
							linha['documento_id'] = documentos_ids[0]
					else:
						linha['documento_id'] = self.get_real_value(documento, row and row[4]) 
					
					plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal)])
					if len(plano_contas_ids)>0:
						logger.info('ENTROU NO PROCESSAMENTO')
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ano_fiscal_id','=',ano_fiscal),
																						('ref','=',row[5])])
						logger.info('val NOVO ACHADoS apuramentos  ano_fiscal================================== %s' %str(ano_fiscal))
						logger.info('val NOVO ACHADoS apuramentos  ref================================== %s' %str(row[5]))
						logger.info('val NOVO ACHADoS apuramentos  plano_contas_ids================================== %s' %str(plano_contas_ids))
						if len(plano_contas_ids)>0:
							linha['contra_partida_id'] = plano_contas_ids[0]
							
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ano_fiscal_id','=',ano_fiscal),
																						('ref','=',row[6])])
						if len(plano_contas_ids)>0:
							linha['conta_iva_a_pagar_id'] = plano_contas_ids[0]
							
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ano_fiscal_id','=',ano_fiscal),
																						('ref','=',row[7])])
						if len(plano_contas_ids)>0:
							linha['conta_de_reporte_id'] = plano_contas_ids[0]
							
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																						('ano_fiscal_id','=',ano_fiscal),
																						('ref','=',row[8])])
						if len(plano_contas_ids)>0:
							linha['conta_de_reembolso_id'] = plano_contas_ids[0]
					else:
						linha['contra_partida_id'] = self.get_real_value(plano_contas, row and row[5])
						linha['conta_iva_a_pagar_id'] = self.get_real_value(plano_contas, row and row[6])
						linha['conta_de_reporte_id'] = self.get_real_value(plano_contas, row and row[7])
						linha['conta_de_reembolso_id'] = self.get_real_value(plano_contas, row and row[8])
					
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
		return res

	
	def read_fluxo_caixa_from_csv(self, cr, uid,address='', ano_fiscal=None,classe='', context=None):
		if context is None:
			context = {}
		res = {}
		with open(address, 'rb') as csvfile:
			reader = csv.reader(csvfile, delimiter=',')
			exclude_line = True
			for row in reader:
				if exclude_line:
					exclude_line = False
					continue
				else:
					ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal)
					natureza_fluxo_caixa=row and row[2]
					if natureza_fluxo_caixa=='False':
						natureza_fluxo_caixa=False
					
					linha = {}
					linha['ref'] = row and row[0]
					linha['nome'] = row and row[1]
					linha['natureza_fluxo_caixa']=natureza_fluxo_caixa
					linha['ano_fiscal_id'] = ano_fiscal or False
					
					id = self.pool.get(classe).create(cr, uid, linha)
					res[linha['ref']] = id
		return res
	def get_fluxo_ascendente(self,cr,uid,conta,ano_fiscal_id,context=None):
		if context is None:
			context={}
		i = None
		
		obj = self.pool.get('dotcom.contabilidade.fluxo.caixa')
		ver = obj.search(cr, uid, [
					('ref','=',conta),
					('ano_fiscal_id','=',ano_fiscal_id)				
					])
		logger.info('Pega ano conta ascendente ideal================== %s' %str(ano_fiscal_id))
		#if ver and len(ver)>0:
		#	raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
		for x in range(1, len(conta)):
			now = conta[:-x]
			logger.info('ENTROU NO PROCESSO DE RECTIFICACAO DE CONTAS')
			res = obj.search(cr, uid, [
							('ref','=',now),
							('ano_fiscal_id','=',ano_fiscal_id)
							])
			if res and len(res)>0:
				i = int(res[0])
				break
			else:
				continue
		logger.info('Pega ano conta ascendente ideal id ================== %s' %str(i))
		return i

	def get_centro_ascendente(self,cr,uid,conta,ano_fiscal_id,context=None):
		if context is None:
			context={}
		i = None
		obj = self.pool.get('dotcom.contabilidade.conta.centro.custos')
		#logger.info('IDENTIFICADOR %s'% str(identificador))
	
		ver = obj.search(cr, uid, [('centro','=',conta),('ano_fiscal_id','=',ano_fiscal_id)])
		#if ver and len(ver)>0:
		#	raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
		for x in range(1, len(conta)):
			now = conta[:-x]
			logger.info('NOW %s'% str(now))
			res = obj.search(cr, uid, [('centro','=',now),('ano_fiscal_id','=',ano_fiscal_id)])
			logger.info('CENTROS %s'% str(res))
			if res and len(res)>0:
				i = int(res[0])
				break
			else:
				continue
		return i

	def criar_todos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids,context):
			
			plano_contas = {}
			diarios = {}
			documentos = {}
			apuramentos = {}
			apuramentos_contas = []
			
			ano_fiscal = documento and documento.id or False
			
			
			#logger.info('ANO FISCAL DO DOCUMENTO A SER CRIADO %s' %str(documento.name))
			home = '/opt/dotcomerp/server/openerp/addons/dotcom_contabilidade/data/%s'
			if documento.check_ano_copia==True:
				contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
								('ano_fiscal_id','=',documento.id)					
					])
				
				if len(contas_ids)>0:
					raise osv.except_osv(_('Acção Invalida !'), _('Plano de Contas para o ano '+documento.code+' já criado no Sistema !'))
				
				if documento.ano_copia=='novo':
					ficheiro = home % 'dotcom.contabilidade.plano.contas.csv'
					classe = 'dotcom.contabilidade.plano.contas'
					plano_contas = self.read_plano_from_csv(cr, uid,documento.id, address=ficheiro, ano_fiscal=ano_fiscal, classe=classe, context=context)
					self.write(cr,uid,documento.id,{'percentagem_processamento':60})
					
					balanco_conf_class='dotcom.comtabilidade.relatorios.legais.balanco.conf'
					balanco_conf_ficheiro=home % 'dotcom.comtabilidade.relatorios.legais.balanco.conf.csv'
					balanco_conf=self.read_balanco_conf_from_csv(cr, uid, address=balanco_conf_ficheiro, ano_fiscal=ano_fiscal, classe=balanco_conf_class, context=context)
					
					self.write(cr,uid,documento.id,{'percentagem_processamento':65})
					#ftp://Dev/opt/dotcomerp/server/openerp/addons/dotcom_contabilidade/data/dotcom.comtabilidade.relatorios.legais.balanco.conf.linha.csv
					conf_linha_class="dotcom.comtabilidade.rl.linha"
					conf_linha_ficheiro=home % 'dotcom.comtabilidade.relatorios.legais.balanco.conf.linha.csv'
					conf_linha=self.read_plano_conf_linha_from_csv(cr, uid, address=conf_linha_ficheiro, ano_fiscal=ano_fiscal, classe=conf_linha_class,plano_contas=plano_contas,conf=balanco_conf, context=context)
				
					self.write(cr,uid,documento.id,{'percentagem_processamento':70})
				else:
					ano_fiscal=int(documento.ano_copia)
					contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal)])
					
					lista_contas=[]
					for conta in contas_ids:
						conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
						
						conta_ascentdentes_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			 ('ano_fiscal_id','=',documento.id),
																			 ('ref','=',conta.parent_id.ref)])
						
						nome_conta=conta.nome
						conta_val={
							'ref':conta.ref,
							'nome':conta.nome,
							'ano_fiscal_id':documento.id,
							'parent_id':None,
							'tipo_interno':conta.tipo_interno
						}
						logger.info('ID ASC  %s ' %str(conta_ascentdentes_ids))
						if len(conta_ascentdentes_ids)>0:
							conta_val['parent_id']=conta_ascentdentes_ids[0]
							
						logger.info('CONTA A SER CRIADA  %s ' %str(conta_val))
						valor=self.pool.get('dotcom.contabilidade.plano.contas').local_create(cr,uid,conta_val)
						plano_contas[valor]=conta_val
						lista_contas.append(conta_val)
						# lista_contas = sorted(lista_contas, key=lambda d: (d['ref']))
					#=============================================================================================	
					# for conta_val in lista_contas:
					#	 conta_ascentdentes_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
					#														 ('ano_fiscal_id','=',documento.id),
					#														 ('ref','=',conta.parent_id.ref)])
					#	 logger.info('ID ASC  %s ' %str(conta_ascentdentes_ids))
					#	 if len(conta_ascentdentes_ids)>0:
					#		 conta_val['parent_id']=conta_ascentdentes_ids[0]
					#		 
					#	 
					#	 valor=self.pool.get('dotcom.contabilidade.plano.contas').local_create(cr,uid,conta_val)
					#	 plano_contas[valor]=conta_val
						
					lista_balanco_conf=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
																											('ano_fiscal_id','=',ano_fiscal)])
					for configuracao in lista_balanco_conf:
						conf_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,configuracao)
						conf_value={
							'ano_fiscal_id':documento.id,
							'ref':conf_object.ref,
							'descricao':conf_object.descricao,
							'operacao':conf_object.operacao,
						}
						
						conf_rl_id=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').create(cr,uid,conf_value)
						for linha_configuracao in conf_object.linha_ids:
							linha_value={
								'ref':linha_configuracao.ref,
								'conta_id':linha_configuracao.conta_id.id,
								'ano_fiscal_id':documento.id,
								'operador':linha_configuracao.operador,
								'conf_id':conf_rl_id,
							}
							self.pool.get('dotcom.comtabilidade.rl.linha').create(cr,uid,linha_value)
					
			if documento.check_diario==True:
				if documento.diario_id=='novo':
					ano_fiscal=documento.id
					ficheiro = home % 'dotcom.contabilidade.diario.csv'
					classe = 'dotcom.contabilidade.diario'
					logger.info('CRIACAO DE UM NOVO DIARIO')
					logger.info('ANO FISCAL DO DOCUMENTO A SER CRIADO%s' %str(ano_fiscal))
					diarios = self.read_diario_from_csv(cr, uid, address=ficheiro, ano_fiscal=ano_fiscal,
														classe=classe, context=context)
					
				
				else:
					logger.info('COPIA DE UM DIARIO PARA NOVO ANO')
					ano_fiscal_id=int(documento.diario_id)
					diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
					#logger.info('DIARIOS ACHADOS PARA A COPIA %s' %str(diarios_ids))
					for diario in diarios_ids:
						diario=self.pool.get('dotcom.contabilidade.diario').browse(cr,uid,diario)
						val={
							'ref':diario.ref,
							'nome':diario.nome,
							'ano_fiscal_id':documento.id
						}
						self.pool.get('dotcom.contabilidade.diario').create(cr,uid,val)
			
			if documento.check_documento==True:
				if documento.documento_id=='novo':
					ano_fiscal=documento.id
					ficheiro = home % 'dotcom.contabilidade.documento.csv'
					classe = 'dotcom.contabilidade.documento'
					documentos = self.read_documento_from_csv(cr, uid, address=ficheiro, ano_fiscal=ano_fiscal, classe=classe,
															  diarios=diarios, context=context)
					
				else:
					ano_fiscal_id=int(documento.documento_id)
					documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
					for doc in documentos_ids:
						doc=self.pool.get('dotcom.contabilidade.documento').browse(cr,uid,doc)
						diario_id=doc.diario_id
						
						
						
						diarios_actuais=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[
							('ano_fiscal_id','=',documento.id),
							('ref','=', diario_id.ref),
							#('nome','=',doc.nome)
						])
						#logger.info('DIARIO ACHADO PARA A COPIA %s' %str(diarios_actuais))
						if len(diarios_actuais)>0:
							diario_id=diarios_actuais[0]
						else:
							diario_id=None
						val={
							'ref':doc.ref,
							'nome':doc.nome,
							'diario_id':diario_id,
							'ano_fiscal_id':documento.id,
							'conta_defeito_debito':doc.conta_defeito_debito.id,
							'conta_defeito_credito':doc.conta_defeito_credito.id,
							'balanceamento_financeira':doc.balanceamento_financeira,
							'balanceamento_analitica':doc.balanceamento_analitica,
							'fluxo_de_caixa_id':doc.fluxo_de_caixa_id.id,
						}
						self.pool.get('dotcom.contabilidade.documento').create(cr,uid,val)
					
			
			if documento.check_apuramento == True:
				logger.info('========================= Check apuramento =========================================')
				if documento.apuramento_id=='novo':
					ano_fiscal=documento.id
					if (plano_contas=={}) or (diarios=={}) or (documentos=={}):
						plano_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal)])
						#logger.info('DIARIS ACHADOS NA CRIACAO %s' %str(plano_contas_ids))
						if len(plano_contas_ids)<=0:
							raise osv.except_osv(_('Acção Invalida !'), _('A criação dos Apuramentos deve ser acompanhada com a do Plano de Contas, Diarios e Documentos!'))
					
					ficheiro = home % 'dotcom.contabilidade.apuramentos.csv'
					ap_contas = home % 'dotcom.contabilidade.contas.apuramentos.csv'
					classe = 'dotcom.contabilidade.apuramentos'
					ap_classe = 'dotcom.contabilidade.contas.apuramentos'
					apuramentos = self.read_apuramento_from_csv(cr, uid,documento.id, address=ficheiro, ano_fiscal=ano_fiscal, classe=classe,
																plano_contas=plano_contas, diario=diarios, documento=documentos, context=context)
					#logger.info('PASSOU PELO PROCESSO DA CRIACAO DOS DIARIOS')
					apuramentos_contas = self.read_contas_from_csv(cr, uid,documento.id,address=ap_contas, classe=ap_classe, apuramento=apuramentos,
																   plano=plano_contas, context=context)
					
					
					
				else:
					ano_fiscal_id=int(documento.apuramento_id)
					logger.info('COPIA DE UM APURAMENTP PARA NOVO ANO %s' %str(ano_fiscal_id))
					apuramentos_ids=self.pool.get('dotcom.contabilidade.apuramentos').search(cr,uid,[('ano_fiscal_id','=',ano_fiscal_id)])
					logger.info('DIARIOS ACHADOS PARA A COPIA %s' %str(apuramentos_ids))
					for apuramento in apuramentos_ids:
						apuramento=self.pool.get('dotcom.contabilidade.apuramentos').browse(cr,uid,apuramento)
						
						#lista_contas=[]
						
							#lista_contas.append(conta.id)
						
						diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.diario_id.ref)])
						
						documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.documento_id.ref)])
						
						conta_contrapartida_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.contra_partida_id.ref)])
						
						conta_iva_a_pagar_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.conta_iva_a_pagar_id.ref)])
						
						conta_de_reporte_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.conta_de_reporte_id.ref)])
						
						conta_de_reembolso_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.conta_de_reembolso_id.ref)])
						
						contra_partida_ids =self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',apuramento.contra_partida_id.ref)])


						logger.info('val ACHADoS apuramentos  ano_fiscal_id================================== %s' %str(documento.id))
						logger.info('val ACHADoS apuramentos  ref================================== %s' %str(apuramento.contra_partida_id.ref))
						logger.info('val ACHADoS apuramentos  contra_partida_ids================================== %s' %str(contra_partida_ids))
						val={
							'ref':apuramento.ref,
							'nome':apuramento.nome,
							'tipo_apuramento':apuramento.tipo_apuramento,
							'contra_partida_id':contra_partida_ids[0],
							'ano_fiscal_id':documento.id
						}
						if len(diarios_ids)>0:
							val['diario_id']=diarios_ids[0]   
						if len(documentos_ids)>0:
							val['documento_id']=documentos_ids[0]
						if len(conta_contrapartida_ids)>0:
							val['contra_partida_id']=conta_contrapartida_ids[0]
						if len(conta_iva_a_pagar_ids)>0:
							val['conta_iva_a_pagar_id']=conta_iva_a_pagar_ids[0]
						if len(conta_de_reporte_ids)>0:
							val['conta_de_reporte_id']=conta_de_reporte_ids[0]
						if len(conta_de_reembolso_ids)>0:
							val['conta_de_reembolso_id']=conta_de_reembolso_ids[0]
						logger.info('val ACHADoS apuramentos ================================================================ %s' %str(val))
						apuramento_id=self.pool.get('dotcom.contabilidade.apuramentos').create(cr,uid,val)
						
						for conta in apuramento.contas_ids:
							logger.info('CONTAS ACHADAS %s' %str(conta.conta_id))
							conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.id),
																			('ref','=',conta.conta_id.ref)])
							if len(conta_ids)>0:
								val={
									'conta_id':conta_ids[0],
									'apuramento_id':apuramento_id,
									'periodo':conta.periodo
								}
								self.pool.get('dotcom.contabilidade.contas.apuramentos').create(cr,uid,val)
								
			
			if documento.check_centro==True:
				logger.info('=========================CENTRO CUSTO ANTERIOR INICIO =========================================')
				centro_id=int(documento.centro_custo_id)
				logger.info('PROCESSO EM EXECUCAO %s ' %str(centro_id))
				centro_custo_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[('ano_fiscal_id','=',centro_id)])
				logger.info('PROCESSO EM EXECUCAO %s ' %str(centro_custo_ids))
					
				#break
				for centro in centro_custo_ids:
					ano_fiscal=documento.id
						
					logger.info('CENTRO ANTERIOR ANO: %s ' %str(ano_fiscal))
					centro=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,int(centro))
					logger.info('CENTRO ANTERIOR ANO: %s ' %str(centro))
					val={
						'centro':centro.centro,
						'nome':centro.nome,
						'ano_fiscal_id':ano_fiscal,
                        'parent_id':self.get_centro_ascendente(cr,uid,centro.centro,ano_fiscal),
                        #'centro_id':centro.centro_id,
					}
					logger.info('VALS %s'%str(val))
					self.pool.get('dotcom.contabilidade.conta.centro.custos').create(cr,uid,val)
				logger.info('==========================CENTRO CUSTO ANTERIOR FIM ========================================')

				#logger.info('==========================centro de custos========================================')
				#centro_id=documento.centro_custo_id
				#centro_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[
				#									('ano_fiscal_id','=',centro_id),
				#									('tipo_interno','=','r')])
				
				#for centro in centro_ids:
				#	conta_centro_object=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro)
				#	#for conta in plano_centro.contas_centro_ids:
				#	conta={
				#		'centro':conta_centro_object.centro,
				#		'nome':conta_centro_object.nome,
				#		'ano_fiscal_id':documento.id,
				#	}
				#	logger.info('valor %s'%str(conta))
				#	self.pool.get('dotcom.contabilidade.conta.centro.custos').create(cr,uid,conta)
					
					
				
				#centro_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[
				#									('ano_fiscal_id','=',centro_id),
				#									('tipo_interno','!=','r')])
				
				#for centro in centro_ids:
				#	conta_centro_object=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro)
				#	#for conta in plano_centro.contas_centro_ids:
				#	conta={
				#		'centro':conta_centro_object.centro,
				#		'nome':conta_centro_object.nome,
				#		'ano_fiscal_id':documento.id,
				#	}
				#	logger.info('valor %s'%str(conta))
				#	self.pool.get('dotcom.contabilidade.conta.centro.custos').create(cr,uid,conta)
				#logger.info('==========================centro de custos========================================')
			
			if documento.check_caixa==True:
				#logger.info('CAIXA%s'%str(documento.fluxo_caixa_id))
				ano_fiscal=documento.id
				if documento.fluxo_caixa_id=='novo':
					
					ficheiro = home % 'dotcom.contabilidade.fluxo.caixa.csv'
					classe = 'dotcom.contabilidade.fluxo.caixa'
					fluxo_caixa_model=self.pool.get(classe)
					fluxo_caixas = self.read_fluxo_caixa_from_csv(cr, uid, address=ficheiro, ano_fiscal=ano_fiscal,
														classe=classe, context=context)
					for fluxo in fluxo_caixas:
						logger.info('\n ==============fluxo_no_parent %s'%str(fluxo))
						fluxo_no_parent_id=fluxo_caixa_model.search(cr,uid,[('ano_fiscal_id','=',ano_fiscal),('ref','=',fluxo)])
						logger.info('\n ==============fluxo_no_parent_id %s'%str(fluxo_no_parent_id))
						# fluxo_no_parent_obj = fluxo_caixa_model.browse(cr,uid,fluxo_no_parent_id)
						# logger.info('\n ==============fluxo_no_parent_obj %s'%str(fluxo_no_parent_obj))
						asc_fluxo=self.get_fluxo_ascendente(cr,uid,fluxo,ano_fiscal)
						logger.info('\n ==============asc_fluxo %s'%str(asc_fluxo))
						fluxo_parent_obj = fluxo_caixa_model.browse(cr,uid,asc_fluxo)
						logger.info('\n ==============fluxo_parent_obj %s'%str(fluxo_parent_obj))
						logger.info('\n ==============fluxo_parent_obj.ref %s'%str(fluxo_parent_obj.ref))
						fluxo_caixa_model.write(cr,uid,fluxo_no_parent_id,{'parent_id':asc_fluxo})

				else:
					logger.info('=========================FLUXO ANTERIOR INICIO =========================================')
					fluxo_id=int(documento.fluxo_caixa_id)
					logger.info('PROCESSO EM EXECUCAO %s ' %str(fluxo_id))
					fluxos_caixa_ids=self.pool.get('dotcom.contabilidade.fluxo.caixa').search(cr,uid,[('ano_fiscal_id','=',fluxo_id)])
					logger.info('PROCESSO EM EXECUCAO %s ' %str(fluxos_caixa_ids))
					
					#break
					for fluxo in fluxos_caixa_ids:
						ano_fiscal=documento.id
						
						logger.info('FLUXO ANTERIOR ANO: %s ' %str(ano_fiscal))
						fluxo=self.pool.get('dotcom.contabilidade.fluxo.caixa').browse(cr,uid,int(fluxo))
						logger.info('FLUXO ANTERIOR ANO: %s ' %str(fluxo))
						val={
							'ano_fiscal_id':documento.id,
							'ref':fluxo.ref,
							'nome':fluxo.nome,
							'natureza_fluxo_caixa':fluxo.natureza_fluxo_caixa,
							'parent_id':self.get_fluxo_ascendente(cr,uid,fluxo.ref,ano_fiscal),
							}
						logger.info('VALOR %s'%str(fluxo.ano_fiscal_id.id))
						logger.info('VALS %s'%str(val))
						self.pool.get('dotcom.contabilidade.fluxo.caixa').create(cr,uid,val)
					logger.info('==========================FLUXO ANTERIOR FIM ========================================')
			
			
			self.write(cr,uid,documento.id,{'percentagem_processamento':100})

		return {'warning':{'Aviso':'Processado com sucesso!'}}
		
	def criar_plano_ano_fiscal(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			planos_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
				('ano_fiscal_id','=',documento.ano_copia.id)
				])
			
			for plano in planos_ids:
				plano=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,plano)
				# ascendente_anterior=plano.parent_id
				# logger.info('CONTA ######## %s ' %str(plano.ref))
				# parent_id=self.set_ascendente(cr,uid,ascendente_anterior,context)
				plano_novo={
					'ref':plano.ref,
					'nome':plano.nome,
					'complete_name':plano.complete_name,
					'ano_fiscal_id':documento.id,
					'tipo_conta_id':plano.tipo_conta_id.id,
					#'conta_iva':plano.conta_iva,
					'taxa':plano.taxa,
					'tem_ref_custos':plano.tem_ref_custos,
					'refectir_multipla':plano.refectir_multipla,
					#'reflexao_analitica':plano.reflexao_analitica,
					'tipo_reflexao_analitica':plano.tipo_reflexao_analitica,
					'tem_ref_analitica':plano.tem_ref_analitica,
					'tipo_interno':plano.tipo_interno,
					'moeda_lancamento_id':plano.moeda_lancamento_id.id,
					'periodo':plano.periodo,
					#added ascendente field
					#'parent_id':parent_id,
					'apuramento_id':plano.apuramento_id.id,
					'friendly_name':plano.friendly_name,
					'state':plano.state,
				}
				logger.info('PLANO %s' %str(plano_novo))
				self.pool.get('dotcom.contabilidade.plano.contas').create(cr,uid,plano_novo)
		return {}
	# def set_ascendente(self,cr,uid,ascendente_anterior,context):
	#	 ref_ascendente=ascendente_anterior.ref
	#	 logger.info('ascendente######## %s ' %str(ref_ascendente))
	#	 ano_fiscal=documento.id
	#	 query=[]
	#	 query.append(('ref','=',ref_ascendente))
	#	 query.append(('ano_fiscal_id','=',ano_fiscal))
	#	 
	#	 ascendente_id=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,query)
	#	 logger.info('ascendente ID ######## %s ' %str(ascendente_id))
	#	 
	#	 return ascendente_id
		
ano_fiscal()


class configuration_period(osv.osv):
	_name = "configuration.period"
	_inherit = 'configuration.period'
	_columns = {
					'trancar_periodo':fields.boolean('Trancar Período'),
				}
	
	
	_defaults={
		'trancar_periodo':False,
	}

configuration_period()


class dotcom_ano_fiscal_default(osv.osv):
	_name = 'res.company'
	_inherit = 'res.company'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano de Trabalho',required=False),
		'codigo':fields.char('Codigo',size=20,required=False),
		'conta_proveito_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Proveitos',required=False),
		'conta_custos_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Custos',required=False),
		'check_balanceamento_MS':fields.boolean(' Obrigar Balanceamento na Moeda Sec.',help="Quando activo, a aplicacao faz o controle de balanceamento na moeda secundaria"),
		
	}
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		val={
			'codigo':ano_fiscal.code
			}
		return {'value':val}
	
	
	def get_moeda_secundaria_cambio(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		user = self.pool.get('res.users').browse(cr,uid,uid)
		empresa = user.company_id
		alt = empresa.secundary_currency
		alt= alt and alt.id
		return alt


	def escrever_plano_contas(self, cr,uid,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		plano_contas_configurado_ids=[]
		outros_planos_contas_ids=[]
		
		if bool(ano_fiscal_id)==False:
			plano_contas_configurado_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[])
		else:
			plano_contas_configurado_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																										('ano_fiscal_id','=',ano_fiscal_id)])
			
			outros_planos_contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																										('ano_fiscal_id','!=',ano_fiscal_id)
																										])
			
		for plano in plano_contas_configurado_ids:
			self.pool.get('dotcom.contabilidade.plano.contas').write(cr,uid,plano,{'visivel':True})
			
		for plano in outros_planos_contas_ids:
			self.pool.get('dotcom.contabilidade.plano.contas').write(cr,uid,plano,{'visivel':False})
		
	
	def write(self,cr,uid,ids,values,context=None):
		if context is None:
			context={}
			
		reads = self.read(cr, uid, ids, ['ano_fiscal_id','id'])
		read_ids=None
		identificador=False
		ano_fiscal_id=None
		if reads:
			logger.info('READS %s' %str(reads))
			if type(reads) == list:
				read_ids=reads[0]
			elif type(reads) == dict:
				read_ids=reads
			identificador=read_ids['id']
			ano_fiscal_id=read_ids['ano_fiscal_id']
			
			chaves=values.keys()
			if chaves.__contains__('ano_fiscal_id'):
				ano_fiscal_write=values.get('ano_fiscal_id', '')
				self.escrever_plano_contas(cr,uid,ano_fiscal_write,context)
		
		super(dotcom_ano_fiscal_default, self).write(cr, uid,ids, values,context=context)
	
dotcom_ano_fiscal_default()