# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator


class dotcom_ccustos_account_selection(osv.osv):
	_name = 'dotcom.contabilidade.centros.custos.account.selection'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'lancamento_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Lancamento'),
		'valor':fields.float('Valor'),
		'natureza':fields.char('Natureza',size=60),
		'friendly_name':fields.related('conta_id','friendly_name',type='function',string='Conta'),
		}
	_rec_name='friendly_name'
dotcom_ccustos_account_selection()
