# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_analise_movimento(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	_name='dotcom.contabilidade.analise.movimento'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'periodo_inicio_id':fields.many2one('configuration.period','Início',required=True),
		'periodo_fim_id':fields.many2one('configuration.period','Fim',required=True),
		'conversao_moeda':fields.selection(_acerto,'Moeda', required=True,),
		'linhas_balancete_ids':fields.one2many('dotcom.contabilidade.analise.movimento.linha','analise_id','Linhas do Balancete',readonly=True),
		
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'periodo_inicio_id':validator._get_default_openning_period,
		'periodo_fim_id':validator._get_periodo_ultimo_movimento,
		'conversao_moeda':'mp'
	}
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_fiscal_id)])
		
		return {'value':{'periodo_inicio_id':periodos_ids[0],'periodo_fim_id':periodos_ids[len(periodos_ids)-1]}}
	
	
	
	def carregar_analise(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		linhas_balancete_ids=self.pool.get('dotcom.contabilidade.analise.movimento.linha').search(cr,uid,[])
			
		for linha in linhas_balancete_ids:
			self.pool.get('dotcom.contabilidade.analise.movimento.linha').unlink(cr,uid,linha)
			
		for documento in self.browse(cr,uid,ids):
			contas_movimento_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
								('tipo_interno','=','m')
								])
			
			contas_com_lancamentos_ids=[]
			for conta in contas_movimento_ids:
				conta_object=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
				if len(conta_object.movimentos_ids)>0:
					contas_com_lancamentos_ids.append(conta_object.id)
			
			
			for conta_movimento in contas_com_lancamentos_ids:
				conta_movimento=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_movimento)
				
				lista_lancamentos_periodo_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','=',conta_movimento.id),
																			('data_lancamento','>=',documento.periodo_inicio_id.date_start),
																			('data_lancamento','<=',documento.periodo_fim_id.date_stop),
																			('state','=','emitido'),
						])
				
				lista_lancamentos_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','=',conta_movimento.id),
																			('data_lancamento','<',documento.periodo_inicio_id.date_start),
																			#('data_lancamento','<=',documento.periodo_fim_id.date_stop),
																			('state','=','emitido'),
						])
				
				
				total_credito=0
				total_debito=0
				total_saldo=0
				
				for lancamento in lista_lancamentos_periodo_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					
					if documento.conversao_moeda=='mp':
						total_debito=total_debito+lancamento.debito_primario_arredondado
						total_credito=total_credito+lancamento.credito_primario_arredondado
					elif documento.conversao_moeda=='ms':
						total_debito=total_debito+lancamento.debito_secundario_arredondado
						total_credito=total_credito+lancamento.credito_secundario_arredondado
					
				
				if total_credito>total_debito:
					total_saldo=total_credito-total_debito
				else:
				   total_saldo= total_debito-total_credito
				
				total_credito_anterior=0
				total_debito_anterior=0
				total_saldo_acumulado=0
				
				for lancamento in lista_lancamentos_anteriores_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					
					if documento.conversao_moeda=='mp':
						total_debito_anterior=total_debito_anterior+lancamento.debito_primario_arredondado
						total_credito_anterior=total_credito_anterior+lancamento.credito_primario_arredondado
					elif documento.conversao_moeda=='ms':
						total_debito_anterior=total_debito_anterior+lancamento.debito_secundario_arredondado
						total_credito_anterior=total_credito_anterior+lancamento.credito_secundario_arredondado		
				
				if (total_credito_anterior+total_credito)>(total_debito_anterior+total_debito):
					total_saldo_acumulado=(total_credito_anterior+total_credito)-(total_debito_anterior+total_debito)
				else:
				   total_saldo_acumulado= (total_debito_anterior+total_debito)-(total_credito_anterior+total_credito)  
				
						
				val={
						'conta_id':conta_movimento.id,
						'debito_periodo':total_debito,
						'credito_periodo':total_credito,
						'saldo_periodo':total_saldo,
						'debito_acumulado':total_credito_anterior+total_debito,
						'credito_acumulado':total_debito_anterior+total_credito,
						'saldo_acumulado':total_saldo_acumulado,
					}
				
				lista_retornada=self.pool.get('dotcom.contabilidade.balancete').get_ascendente_totalizador(cr,uid,conta_movimento)
				ascendente_razao_id=validator.get_getAntecessor_topo(cr,uid,conta_movimento)
				
				logger.info('CONTA RAZAO ACHADA %s' %str(ascendente_razao_id.ref))
				
				parente_razao_id=None
				linha_razao_ids=self.pool.get('dotcom.contabilidade.analise.movimento.linha').search(cr,uid,[('conta_id','=',ascendente_razao_id.id)])
				logger.info('LINHAS RAZAO ACHADAS %s' %str(linha_razao_ids))
				if len(linha_razao_ids)<=0:
					val_copia=val.copy()
					val_copia['conta_id']=ascendente_razao_id.id
					
					if val_copia['debito_periodo']>0 or val_copia['credito_periodo']>0 or val_copia['debito_acumulado']>0 or val_copia['credito_acumulado']>0:
						parente_razao_id=self.pool.get('dotcom.contabilidade.analise.movimento.linha').create(cr,uid,val_copia)
				else:
					parente_razao_id=linha_razao_ids[0]
					linha_razao_object=self.pool.get('dotcom.contabilidade.analise.movimento.linha').browse(cr,uid,linha_razao_ids[0])
					total_debito_acumulado_linha=linha_razao_object.debito_acumulado+val['debito_acumulado']
					total_credito_acumulado_linha=linha_razao_object.credito_acumulado+val['credito_acumulado']
					saldo_acumulado_linha=0
					
					total_credito_linha=linha_razao_object.credito_periodo+val['credito_periodo']
					total_debito_linha=linha_razao_object.debito_periodo+val['debito_periodo']
					saldo_linha=0
					
					if total_credito_acumulado_linha>total_debito_acumulado_linha:
						saldo_acumulado_linha=total_credito_acumulado_linha-total_debito_acumulado_linha
					else:
					   saldo_acumulado_linha= total_debito_acumulado_linha-total_credito_acumulado_linha
					   
					if total_credito_linha>total_debito_linha:
						saldo_linha=total_credito_linha-total_debito_linha
					else:
					   saldo_linha= total_debito_linha-total_credito_linha
					
					self.pool.get('dotcom.contabilidade.analise.movimento.linha').write(cr,uid,linha_razao_object.id,{
																				'credito_periodo':total_credito_linha,
																				'debito_periodo':total_debito_linha,
																				'saldo_periodo':saldo_linha,
																				'credito_acumulado':total_credito_acumulado_linha,
																				'debito_acumulado':total_debito_acumulado_linha,
																				'saldo_acumulado':saldo_acumulado_linha,
						})
				
				val['parent_id']=parente_razao_id
				
				if val['debito_periodo']>0 or val['credito_periodo']>0 or val['debito_acumulado']>0 or val['credito_acumulado']>0:
					self.pool.get('dotcom.contabilidade.analise.movimento.linha').create(cr,uid,val)
				
			
		return {
			'type': 'ir.actions.act_window',
			'name': 'Balancete',
			'view_mode': 'tree',
			'view_type': 'tree',
			'res_model': 'dotcom.contabilidade.analise.movimento.linha',
			'res_id':None,
			'domain': [('parent_id','=',False)],
			'context': context,
			'nodestroy': True,
		}		
	
	
	
	def pesquisar_linhas_balancete(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			
			linhas_balancete_ids=self.pool.get('dotcom.contabilidade.analise.movimento.linha').search(cr,uid,[])
			#logger.info('LINHAS ACHADAS DO BALANCETE %s' %str(linhas_balancete_ids))
			
			for linha in linhas_balancete_ids:
				self.pool.get('dotcom.contabilidade.analise.movimento.linha').unlink(cr,uid,linha)
			
			lancamento_ids=None
			
			conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
								('tipo_interno','=','r')
				])
			for conta in conta_ids:
				conta_pai=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
				
				total_debito_periodo=0
				total_debito_periodo_acumulado=0
				total_credito_periodo=0
				total_credito_periodo_acumulado=0
				total_saldo_periodo=0
				total_saldo_periodo_acumulado=0
				
				contas_filhos=validator.get_filhos(cr,uid,conta_pai)
				
				lista_normal=[]
				lista_acumulados=[]
				for conta in contas_filhos:
					
					#logger.info('CONTAS FILHAS %s' %str(documento.periodo_inicio_id.id))
					lancamentos_acumulado_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta.id),
													('state','=','emitido'),
													('periodo_id','<',documento.periodo_inicio_id.id)
										])
					#logger.info('LANCAMENTOS ACUMULADOS ACHADOS %s' %str(lancamentos_acumulado_ids))
					
					if bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==True:
						periodos=[]
						periodos.append(documento.periodo_inicio_id.id)
						periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
										('id','>=',documento.periodo_inicio_id.id),
										('id','<=',documento.periodo_fim_id.id),
									])
						for periodo in periodos_intermediarios_ids:
							periodos.append(periodo)

						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta.id),
													('state','=','emitido'),
													('periodo_id','in',periodos),					 
											])
						
					elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==True:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta.id),
													('state','=','emitido'),
													('periodo_id','<=',documento.periodo_fim_id.id)
											])
						#logger.info('LANCAMENTOS AXADOS %s' %str(lancamento_ids))
					elif bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==False:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta.id),
													('state','=','emitido'),
													('periodo_id','>=',documento.periodo_inicio_id.id)
											])
						#logger.info('LANCAMENTOS AXADOS %s' %str(lancamento_ids))
					else:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta.id),
													('state','=','emitido'),
										])
					#logger.info('LANCAMENTOS AXADOS %s' %str(lancamento_ids))
					#if len(lancamento_ids)>0:
						
					
					total_debito=0
					total_credito=0
					total_debito_acumulado=0
					total_credito_acumulado=0
					saldo=0
					saldo_acumulado=0
					
					#logger.info('LANCAMENTOS ACHADOS %s' %str(lancamento_ids))
					if len(lancamento_ids)>0 or len (lancamentos_acumulado_ids)>0:
						for lancamento in lancamento_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if documento.conversao_moeda=='mp':
								total_debito=total_debito+lancamento.debito_primario_arredondado
								total_credito=total_credito+lancamento.credito_primario_arredondado
							elif documento.conversao_moeda=='ms':
								total_debito=total_debito+lancamento.debito_secundario_arredondado
								total_credito=total_credito+lancamento.credito_secundario_arredondado
						logger.info('LANCAMENTOS AXADOS %s' %str(total_debito))
						logger.info('LANCAMENTOS AXADOS %s' %str(total_debito))
						if total_credito>total_debito:
							saldo=(total_credito-total_debito)*-1
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							
							saldo_local_acumulado=0
							if valores['debito_acumulado']+total_debito>valores['credito_acumulado']+total_credito:
								saldo_local_acumulado=valores['debito_acumulado']+total_debito-valores['credito_acumulado']+total_credito
							else:
								saldo_local_acumulado=(valores['credito_acumulado']+total_credito-valores['debito_acumulado']+total_debito)*-1
								
							val={
								'conta_id':conta.id,
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'debito_acumulado':valores['debito_acumulado']+total_debito,
								'credito_acumulado':valores['credito_acumulado']+total_credito,
								'saldo_acumulado':saldo_local_acumulado,
									
								#'balancete_id':documento.id,
								#'credito_contavel':0,
								#'debito_contavel':0,
								#'saldo_contavel':0,
							}
							lista_normal.append(val)
							#self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							
							#logger.info('VALORES ACUMULADOS %s' %str(valores))
							total_debito_acumulado=total_debito_acumulado+valores['debito_acumulado']+total_debito
							total_credito_acumulado=total_credito_acumulado+valores['credito_acumulado']+total_credito
							saldo_acumulado=0
							if total_debito_acumulado>total_credito_acumulado:
								saldo_acumulado=total_debito_acumulado-total_credito_acumulado
							else:
								saldo_acumulado=(total_credito_acumulado-total_debito_acumulado)*-1
							#saldo_acumulado=saldo_acumulado+valores['saldo_acumulado']+saldo
							#logger.info('TOTAL DEBITO ACUMULADO %s' %str(total_debito_acumulado))
							#logger.info('TOTAL CREDITO ACUMULADO %s' %str(total_credito_acumulado))
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':saldo_acumulado,
									#'balancete_acumulado_id':documento.id,---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
									#'credito_contavel':0,
									#'debito_contavel':0,
									#'saldo_contavel':0,
								}
							lista_acumulados.append(val)
							#self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
						elif total_debito>total_credito:
							saldo=total_debito-total_credito
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							total_debito_acumulado=total_debito_acumulado+valores['debito_acumulado']+total_debito
							total_credito_acumulado=total_credito_acumulado+valores['credito_acumulado']+total_credito
							saldo_acumulado=saldo_acumulado+valores['saldo_acumulado']+saldo
							
							
							saldo_local_acumulado=0
							if valores['debito_acumulado']+total_debito>valores['credito_acumulado']+total_credito:
								saldo_local_acumulado=valores['debito_acumulado']+total_debito-valores['credito_acumulado']+total_credito
							else:
								saldo_local_acumulado=valores['credito_acumulado']+total_credito-valores['debito_acumulado']+total_debito
							
							val={
								'conta_id':conta.id,
								
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'analise_id':documento.id,
								
								'debito_acumulado':valores['debito_acumulado']+total_debito,
								'credito_acumulado':valores['credito_acumulado']+total_credito,
								'saldo_acumulado':saldo_local_acumulado,
									
								#'credito_contavel':0,
								#'debito_contavel':0,
								#'saldo_contavel':0,
							}
							lista_normal.append(val)
			  
							#self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							total_debito_acumulado=total_debito_acumulado+valores['debito_acumulado']+total_debito
							total_credito_acumulado=total_credito_acumulado+valores['credito_acumulado']+total_credito
							saldo_acumulado=0
							if total_debito_acumulado>total_credito_acumulado:
								saldo_acumulado=total_debito_acumulado-total_credito_acumulado
							else:
								saldo_acumulado=total_credito_acumulado-total_debito_acumulado
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':saldo_acumulado,
									'balancete_acumulado_id':documento.id,
									
									#'credito_contavel':0,
									#'debito_contavel':0,
									#'saldo_contavel':0,
								}
							lista_acumulados.append(val)
							
						else :
							saldo=total_debito-total_credito
							
							saldo=total_debito-total_credito
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							
							saldo_local_acumulado=0
							if valores['debito_acumulado']+total_debito>valores['credito_acumulado']+total_credito:
								saldo_local_acumulado=valores['debito_acumulado']+total_debito-valores['credito_acumulado']+total_credito
							elif valores['debito_acumulado']+total_debito<valores['credito_acumulado']+total_credito:
								saldo_local_acumulado=(valores['credito_acumulado']+total_credito-valores['debito_acumulado']+total_debito)*-1
							   
							val={
								'conta_id':conta.id,
								
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'analise_id':documento.id,
								
								'debito_acumulado':valores['debito_acumulado']+total_debito,
								'credito_acumulado':valores['credito_acumulado']+total_credito,
								'saldo_acumulado':saldo_local_acumulado,
									
								#'credito_contavel':0,
								#'debito_contavel':0,
								#'saldo_contavel':0,
							}
							lista_normal.append(val)
			  
							#self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.periodo_inicio_id.fiscalyear_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
								valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],periodo_object.fiscalyear_id.id)
							total_debito_acumulado=total_debito_acumulado+valores['debito_acumulado']+total_debito
							total_credito_acumulado=total_credito_acumulado+valores['credito_acumulado']+total_credito
							saldo_acumulado=0
							if total_debito_acumulado>total_credito_acumulado:
								saldo_acumulado=total_debito_acumulado-total_credito_acumulado
							else:
								saldo_acumulado=(total_credito_acumulado-total_debito_acumulado)*-1
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':saldo_acumulado,
									'balancete_acumulado_id':documento.id,
									
									#'credito_contavel':0,
									#'debito_contavel':0,
									#'saldo_contavel':0,
								}
							lista_acumulados.append(val)
							#self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
					#logger.info('TOTAL DEBITO ACUMULADO %s' %str(total_debito_acumulado))
					#logger.info('TOTAL CREDITO ACUMULADO %s' %str(total_credito_acumulado))
					
					
					total_debito_periodo=total_debito_periodo+total_debito
					total_debito_periodo_acumulado=total_debito_periodo_acumulado+total_debito_acumulado
					total_credito_periodo=total_credito_periodo+total_credito
					total_credito_periodo_acumulado=total_credito_periodo_acumulado+total_credito_acumulado
					total_saldo_periodo=total_saldo_periodo+saldo
					total_saldo_periodo_acumulado=total_saldo_periodo_acumulado+saldo_acumulado
					
				
					
					#logger.info('TOTAL SALDO ACUMULADO %s' %str(saldo_acumulado))
				
				pai_id=None
				
				credito_acumulado=0
				debito_acumulao=0
				saldo_acumulado=0
				
				
				for normal in lista_normal:
					credito_acumulado=credito_acumulado+normal['credito_periodo']
					debito_acumulao=debito_acumulao+normal['debito_acumulado']
				
				if debito_acumulao>credito_acumulado:
					total_saldo_periodo_acumulado=debito_acumulao-credito_acumulado
				else:
					total_saldo_periodo_acumulado=(credito_acumulado-debito_acumulao)*-1
				
				if total_debito_periodo>0 or total_credito_periodo>0:
					if total_debito_periodo>total_credito_periodo:
						total_saldo_periodo=total_debito_periodo-total_credito_periodo
					else:
						total_saldo_periodo=(total_credito_periodo-total_debito_periodo)*-1
					
					
					val={
						'conta_id':conta_pai.id,
						'debito_periodo':total_debito_periodo,
						'credito_periodo':total_credito_periodo,
						'saldo_periodo':total_saldo_periodo,
						'analise_id':documento.id,
						
						'debito_acumulado':debito_acumulao,
						'credito_acumulado':credito_acumulado,
						'saldo_acumulado':total_saldo_periodo_acumulado,
						
						'credito_contavel':total_credito_periodo,
						'debito_contavel':total_debito_periodo,
						'saldo_contavel':total_saldo_periodo,
					}
					pai_id=self.pool.get('dotcom.contabilidade.analise.movimento.linha').create(cr,uid,val)
					
					#val={
					#	'conta_id':conta_pai.id,
					#	'debito_acumulado':total_debito_periodo_acumulado,
					#	'credito_acumulado':total_credito_periodo_acumulado,
					#	'saldo_acumulado':total_saldo_periodo_acumulado,
					#	'balancete_acumulado_id':documento.id,
					#	
					#	'credito_contavel':total_credito_periodo_acumulado,
					#	'debito_contavel':total_debito_periodo_acumulado,
					#	'saldo_contavel':total_saldo_periodo_acumulado,
					#}
					#
					#self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
					parente_id=pai_id
					for normal in lista_normal:
						
						
						conta_object_id=normal['conta_id']
						conta_obj=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_object_id)
						logger.info('IDENTIFICADOR DO PAI %s' %str(conta_obj.ref))
						lista_retornada=self.pool.get('dotcom.contabilidade.balancete').get_ascendente_totalizador(cr,uid,conta_obj)

						#logger.info('LISTA DE ASCENDENTES TOTALIZADORES %s' %str(lista_retornada))
						
						for linha in lista_retornada:
							outro_normal=normal.copy()
							logger.info('ASCENDENTE TOTALIZADOR ACHADO %s' %str(linha.ref))
							#if len(lista_retornada)
							outro_normal['conta_id']=linha.id
							outro_normal['parent_id']=parente_id
							lancamentos_parente=self.pool.get('dotcom.contabilidade.analise.movimento.linha').search(cr,uid,[('conta_id','=',linha.id)])
							logger.info('LANCAMENTOS ACHADOS PARA A TOTALIZADORA %s' %str(lancamentos_parente))
							if len(lancamentos_parente)==1:
								parente_id=lancamentos_parente[0]
							if len(lancamentos_parente)>0:
								for lancamento in lancamentos_parente:
									#code
									lancamento=self.pool.get('dotcom.contabilidade.analise.movimento.linha').browse(cr,uid,lancamentos_parente[0])
									self.pool.get('dotcom.contabilidade.analise.movimento.linha').write(cr,uid,lancamentos_parente[0],{
											'debito_periodo':lancamento.debito_periodo+outro_normal['debito_periodo'],
											'credito_periodo':lancamento.credito_periodo+outro_normal['credito_periodo'],
											'saldo_periodo':lancamento.saldo_periodo+outro_normal['saldo_periodo'],
							
											'debito_acumulado':lancamento.debito_acumulado+outro_normal['debito_acumulado'],
											'credito_acumulado':lancamento.credito_acumulado+outro_normal['credito_acumulado'],
											'saldo_acumulado':lancamento.saldo_acumulado+outro_normal['saldo_acumulado'],					
										})
									
							else:
								parente_id=self.pool.get('dotcom.contabilidade.analise.movimento.linha').create(cr,uid,outro_normal)
						
						
						
						normal['parent_id']=parente_id
						logger.info('PEGAR O PARENTE NO LOCAL %s' %str(parente_id))
					   
						self.pool.get('dotcom.contabilidade.analise.movimento.linha').create(cr,uid,normal)
					#for acumulado in lista_acumulados:
					#	logger.info('VALORES aCUMULADOS %s' %str(acumulado))
						#self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,acumulado)
		#context.update({'search_default_parente':True})
		return {
			'type': 'ir.actions.act_window',
			'name': 'Balancete',
			'view_mode': 'tree',
			'view_type': 'tree',
			'res_model': 'dotcom.contabilidade.analise.movimento.linha',
			'res_id':None,
			'domain': [('parent_id','=',False)],
			'context': context,
			'nodestroy': True,
		}

dotcom_analise_movimento()

class dotcom_linha_analise(osv.osv):
	_name='dotcom.contabilidade.analise.movimento.linha'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True),
		'descricao':fields.char('Descricao',size=50),
		
		'debito_periodo':fields.float('Debito (Periodo)'),
		'credito_periodo':fields.float('Credito (Periodo)'),
		'saldo_periodo':fields.float('Saldo (Periodo)'),
		'debito_acumulado':fields.float('Debito (Acum)'),
		'credito_acumulado':fields.float('Credito (Acum)'),
		'saldo_acumulado':fields.float('Saldo (Acum)'),
		
		'analise_id':fields.many2one('dotcom.contabilidade.analise.movimento','Balancete'),
		
		'parent_id': fields.many2one('dotcom.contabilidade.analise.movimento.linha', 'Ascendente', required=False, ondelete="cascade"),
		'child_id':fields.one2many('dotcom.contabilidade.analise.movimento.linha', 'parent_id', string='Sub-contas'),
	}
	
	_rec_name='conta_id'
	
dotcom_linha_analise()

class dotcom_balancete(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	
	_name='dotcom.contabilidade.balancete'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		
		'contas_ids':fields.many2many('dotcom.contabilidade.plano.contas','balanco_conta_rel','balancete_id','conta_id','Conta',required=False),
		
		'conta_razao_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Razao',required=False),
		
		'periodo_inicio_id':fields.many2one('configuration.period','Início',required=True),
		'periodo_fim_id':fields.many2one('configuration.period','Fim',required=True),
		
		
		'periodo':fields.selection([
			('periodo','Período'),
			('acumulado','Acumulado'),
			('periodo_acumulado','Período e Acumulado')
			],'Período',required=True),
		'total_debito':fields.float('Total Debito',readonly=True),
		'total_credito':fields.float('Total Credito', readonly=True),
		'total_acumulado_debito':fields.float('Total Debito Acumulado',readonly=True),
		'total_acumulado_credito':fields.float('Total Credito Acumulado', readonly=True),
		
		'conversao_moeda':fields.selection(_acerto,'Moeda', required=True,),
		'linhas_balancete_ids':fields.one2many('dotcom.contabilidade.balancete.linha','balancete_id','Linhas do Balancete',readonly=True),
		'linhas_balancete_razao_ids':fields.one2many('dotcom.contabilidade.balancete.linha','balancete_razao_id','Linhas do Balancete',readonly=True),
		'linhas_acumulados_balancete_ids':fields.one2many('dotcom.contabilidade.balancete.linha.acumulado','balancete_acumulado_id','Linhas do Balancete',readonly=True),
		'linhas_acumulados_balancete_razao_ids':fields.one2many('dotcom.contabilidade.balancete.linha.acumulado','balancete_acumulado_razao_id','Linhas do Balancete',readonly=True),
		
	}
	
	_defaults={
		'periodo':'periodo',
		'ano_fiscal_id':validator._get_default_year,
		#'periodo_inicio_id':validator._get_default_openning_period,
		#'periodo_fim_id':validator._get_periodo_ultimo_movimento,
		'conversao_moeda':'mp'
	}
	
	
	
	def carregar_balancete(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[])
			
		for linha in linhas_balancete_ids:
			self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha)
			
		linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[])
		for linha in linhas_balancete_ids:
			self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha)
			
		for documento in self.browse(cr,uid,ids):
			contas_movimento_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
								('tipo_interno','=','m')
								])
			
			
			for conta_movimento in contas_movimento_ids:
				conta_movimento=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_movimento)
				
				lista_lancamentos_periodo_ids=[]
				lista_lancamentos_anteriores_ids=[]
				#logger.info('PROCESSO EM EXECUCAO %s' %str(conta_movimento.ref))
				
				#if conta_movimento.movimentos_ids
				lista_lancamentos_periodo_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','=',conta_movimento.id),
																			('data_lancamento','>=',documento.periodo_inicio_id.date_start),
																			('data_lancamento','<=',documento.periodo_fim_id.date_stop),
																			('state','=','emitido'),
						])
				
				lista_lancamentos_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','=',conta_movimento.id),
																			('data_lancamento','<',documento.periodo_inicio_id.date_start),
																			#('data_lancamento','<=',documento.periodo_fim_id.date_stop),
																			('state','=','emitido'),
						])
				
				total_credito=0
				total_debito=0
				total_saldo=0
				for lancamento in lista_lancamentos_periodo_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					
					if documento.conversao_moeda=='mp':
						total_debito=total_debito+lancamento.debito_primario_arredondado
						total_credito=total_credito+lancamento.credito_primario_arredondado
					elif documento.conversao_moeda=='ms':
						total_debito=total_debito+lancamento.debito_secundario_arredondado
						total_credito=total_credito+lancamento.credito_secundario_arredondado
					
				if total_debito>total_credito:
					total_saldo=total_debito-total_credito
					
				elif total_credito>total_debito:
					total_saldo=total_credito-total_debito
				
				
				total_debito_anterior=0
				total_credito_anterior=0
				total_saldo_anterior=0
				
				val={
						'conta_id':conta_movimento.id,
						'debito_periodo':total_debito,
						'credito_periodo':total_credito,
						'saldo_periodo':total_saldo,
						'balancete_id':documento.id,
						
						'credito_contavel':total_credito,
						'debito_contavel':total_debito,
						'saldo_contavel':total_saldo,
						'somar':'true',
					}
				
				
				lista_ascendente=validator.get_ascendente_totalizador(cr,uid,conta_movimento)
				
				conta_razao=validator.get_getAntecessor_topo(cr,uid,conta_movimento,context)
				lista_ascendente.append(conta_razao)
				logger.info('REFERENCIA DA CONTA PROBLEMATICA %s' %str(conta_movimento.ref))
				
				for ascendentes in lista_ascendente:
					
					lancamentos_conta_razao_periodo_id=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[
																								('conta_id','=',ascendentes.id)
																								])
					
					if len(lancamentos_conta_razao_periodo_id)>0:
						lancamento_object=self.pool.get('dotcom.contabilidade.balancete.linha').browse(cr,uid,lancamentos_conta_razao_periodo_id[0])
						total_debito_local=lancamento_object.debito_periodo+total_debito
						total_credito_local=lancamento_object.credito_periodo+total_credito
						total_saldo_local=0
						if total_debito_local>total_credito_local:
							total_saldo_local=total_debito_local-total_credito_local
						
						elif total_credito_local>total_debito_local:
							total_saldo_local=total_credito_local-total_debito_local
						self.pool.get('dotcom.contabilidade.balancete.linha').write(cr,uid,lancamento_object.id,{
																										'debito_periodo':total_debito_local,
																										'credito_periodo':total_credito_local,
																										'saldo_periodo':total_saldo_local,
																										'credito_contavel':total_credito_local,
																										'debito_contavel':total_debito_local,
																										'saldo_contavel':total_saldo_local,
																										'somar':'',
																										})
					
					else:
						val_pai=val.copy()
						val_pai['conta_id']=ascendentes.id
						val_pai['somar']=''
						self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val_pai)
				
				
				self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
				
				for lancamento_anterior in lista_lancamentos_anteriores_ids:
					lancamento_anterior=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_anterior)
					
					if documento.conversao_moeda=='mp':
						total_debito_anterior=total_debito_anterior+lancamento_anterior.debito_primario_arredondado
						total_credito_anterior=total_credito_anterior+lancamento_anterior.credito_primario_arredondado
					elif documento.conversao_moeda=='ms':
						total_debito_anterior=total_debito_anterior+lancamento_anterior.debito_secundario_arredondado
						total_credito_anterior=total_credito_anterior+lancamento_anterior.credito_secundario_arredondado
					
				
				total_debito_acumulado=total_debito_anterior+total_debito
				total_credito_acumulado=total_credito_anterior+total_credito
				total_saldo_acumulado=0
				if total_debito_acumulado>total_credito_acumulado:
					total_saldo_acumulado=total_debito_acumulado-total_credito_acumulado
					
				elif total_credito_acumulado>total_debito_acumulado:
					total_saldo_acumulado=total_credito_acumulado-total_debito_acumulado
						
				val_acumulado={
						'conta_id':conta_movimento.id,
						'debito_acumulado':total_debito_acumulado,
						'credito_acumulado':total_credito_acumulado,
						'saldo_acumulado':total_saldo_acumulado,
						'balancete_acumulado_id':documento.id,
						'pai':'true',
						
						'credito_contavel':total_credito_acumulado,
						'debito_contavel':total_debito_acumulado,
						'saldo_contavel':total_saldo_acumulado,
						'ref':conta_movimento.ref
					}
				
				
				for ascendentes in lista_ascendente:
					lancamentos_conta_razao_acumulados_id=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[
																								('conta_id','=',ascendentes.id)
																								])
					
					if len(lancamentos_conta_razao_acumulados_id)>0:
						lancamento_object=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').browse(cr,uid,lancamentos_conta_razao_acumulados_id[0])
						total_debito_local=lancamento_object.debito_acumulado+total_debito_acumulado
						total_credito_local=lancamento_object.credito_acumulado+total_credito_acumulado
						total_saldo_local=0
						if total_debito_local>total_credito_local:
							total_saldo_local=total_debito_local-total_credito_local
						
						elif total_credito_local>total_debito_local:
							total_saldo_local=total_credito_local-total_debito_local
						self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').write(cr,uid,lancamento_object.id,{
																										'debito_acumulado':total_debito_local,
																										'credito_acumulado':total_credito_local,
																										'saldo_acumulado':total_saldo_local,
																										'credito_contavel':total_credito_local,
																										'debito_contavel':total_debito_local,
																										'saldo_contavel':total_saldo_local,
																										'somar':'',
																										})
					
					else:
						val_pai=val_acumulado.copy()
						val_pai['conta_id']=ascendentes.id
						val_pai['somar']=''
						self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val_pai)
				
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val_acumulado)
				
		action={}
		#break
		if (documento.periodo=='periodo') or (documento.periodo=='acumulado'):
			action = {
				'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
				'view_id': False,
				'res_model': 'dotcom.contabilidade.balancete',
				'report_name': 'dotcom_contabilidade_balancete_analitico_report',
				'domain': [],
				'context': dict(context, active_ids=ids),
				'type': 'ir.actions.report.xml',
				'report_type': 'pdf',
				'res_id': ids and ids[0] or False
			}
			
		elif documento.periodo=='periodo_acumulado':
			action = {
				'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
				'view_id': False,
				'res_model': 'dotcom.contabilidade.balancete',
				'report_name': 'dotcom_contabilidade_balancete_analitico_acumulado_report',
				'domain': [],
				'context': dict(context, active_ids=ids),
				'type': 'ir.actions.report.xml',
				'report_type': 'pdf',
				'res_id': ids and ids[0] or False
			}
				
		return action
				
				
				
	
	def pesquisar_linhas_balancete(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		total_debito_geral=0
		total_credito_geral=0
		total_debito_geral_acumulado=0
		total_credito_geral_acumulado=0
		sequencia=1
		
		for documento in self.browse(cr,uid,ids):
			
			linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[])
			
			for linha in linhas_balancete_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha)
				
			linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[])
			for linha in linhas_balancete_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha)
			
			lancamento_ids=None
			
			periodos=[]
			periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_start','>=',documento.periodo_inicio_id.date_start),
								('date_stop','<=',documento.periodo_fim_id.date_stop),
								('special','=',False),
								('closing','=',False)
							])
			
			periodos_fecho_ids=[]
			if documento.periodo_inicio_id.special==True:
				periodos_intermediarios_ids.append(documento.periodo_inicio_id.id)
			
			logger.info('PROCESSO INICIADO COM SUCESSO' )
			if documento.periodo_fim_id.closing==True:
				ref=documento.periodo_fim_id.code
				ref_reduzida=ref[:2]
				
				if ref_reduzida=='13':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					
				if ref_reduzida=='14':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					ref_anterior='13/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					
					
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
						
				if ref_reduzida=='15':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					ref_anterior='13/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
						
					ref_anterior='14/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
				   
		
			if len(documento.contas_ids)>0:
				
				logger.info('INICIOU O PROCESSO COM CONTAS SELECCIONADAS')
				lista_todas_contas_seleccionadas=documento.contas_ids
				#logger.info('ENTROU NO PROCESSO')
				antecessores=[]
				lancamento_ids=[]
				lista_antecessores=[]
				for conta in documento.contas_ids:
					#conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta.id)
					
					antecessores_novos=validator.get_antecessores(cr,uid,conta)
					iterator=len(antecessores)
					lista_antecessores=[]
					while iterator!=0:
						antecessor=antecessores[iterator-1]
						lista_antecessores.append(antecessor)
						iterator=iterator-1
				#logger.info('LISTA DOS ANTECESSORES %s' %str(lista_antecessores))
				
				for conta in documento.contas_ids:
					lista_contas=[]
					if conta.tipo_interno!='m':
						conta_ids=self.pool.get('dotcom.contabilidade.iva').get_filhos(cr,uid,ids,conta)					   
						
						for conta_local in conta_ids:
							lista_contas=conta_ids
							
					else:
						lista_contas.append(conta.id)
						
									
					if bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==True:
						
						for periodo in periodos_intermediarios_ids:
							periodos.append(periodo)
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','in',lista_contas),
													('state','=','emitido'),
													('periodo_id','in',periodos)											
											])
					elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==True:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','in',lista_contas),
													('state','=','emitido'),
													('periodo_id','<=',documento.periodo_fim_id.id)
											])
					elif bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==False:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','in',lista_contas),
													('state','=','emitido'),
													('periodo_id','>=',documento.periodo_inicio_id.id)
											])
					elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==False:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','in',lista_contas),
													('state','=','emitido'),
											])
					
					
					total_debito=0
					total_credito=0
					saldo=0
					
					logger.info('PROCESSO EM EXECUCAO %s' %str(lancamento_ids))
					for lancamento in lancamento_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if documento.conversao_moeda=='mp':
							total_debito=total_debito+round(lancamento.debito_moeda_base,2)
							total_credito=total_credito+round(lancamento.credito_moeda_base,2)
						elif documento.conversao_moeda=='ms':
							total_debito=total_debito+lancamento.debito_secundario_arredondado
							total_credito=total_credito+lancamento.credito_secundario_arredondado
					
					if total_credito>total_debito:
						saldo=total_credito-total_debito
						
					elif total_debito>total_credito:
						saldo=total_debito-total_credito
					
					
						
					
					if len(lancamento_ids)>0:
						logger.info('INICIADA A PESQUISA DE CONTAS')
						for conta in lista_antecessores:
							val={
								'conta_id':conta.id,
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'balancete_id':documento.id,
								
								'credito_contavel':total_credito,
								'debito_contavel':total_debito,
								'saldo_contavel':saldo,
								
							}
							#if conta.tipo_interno!='m':
								#val['somar']=''
							
							
							if lista_todas_contas_seleccionadas.__contains__(conta.parent_id):
								val['somar']=''
							else:
								val['somar']='true'
								
							
							self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
						
						val={
							'conta_id':conta.id,
							'debito_periodo':total_debito,
							'credito_periodo':total_credito,
							'saldo_periodo':saldo,
							'balancete_id':documento.id,
							
							'credito_contavel':0,
							'debito_contavel':0,
							'somar':'true',
							'saldo_contavel':0,
						}
						
						antecessor_topo=validator.get_getAntecessor_topo(cr,uid,conta)
						logger.info('ANTECESSOR DE TOPO ACHADO %s' %str(antecessor_topo))
						
						if lista_todas_contas_seleccionadas.__contains__(antecessor_topo):
							logger.info('teste')
						else:
							val['pai']='true'
								
						if lista_todas_contas_seleccionadas.__contains__(conta.parent_id):
								val['somar']=''
						else:
							val['somar']='true'
						self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
						
						valores=None
						if bool(documento.periodo_inicio_id.id)==True:
							valores=self.get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.ano_fiscal_id.id)
						else:
							periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
							valores=self.get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],documento.ano_fiscal_id.id)
						
						#logger.info('VALORES ACUMULADOS %s' %str(valores))
						
						for conta in lista_antecessores:
							val={
								'conta_id':conta.id,
								'debito_acumulado':valores['debito_acumulado']+total_debito,
								'credito_acumulado':valores['credito_acumulado']+total_credito,
								'saldo_acumulado':valores['saldo_acumulado']+saldo,
								'balancete_acumulado_id':documento.id,
								
								'credito_contavel':valores['credito_acumulado']+total_credito,
								'debito_contavel':valores['debito_acumulado']+total_debito,
								'saldo_contavel':valores['saldo_acumulado']+saldo,
							}
							#if conta.tipo_interno!='m':
							#	val['somar']=''
							
							if lista_todas_contas_seleccionadas.__contains__(conta.parent_id):
								val['somar']=''
							else:
								val['somar']='true'
							self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
						
						val={
							'conta_id':conta.id,
							'debito_acumulado':valores['debito_acumulado']+total_debito,
							'credito_acumulado':valores['credito_acumulado']+total_credito,
							'saldo_acumulado':valores['saldo_acumulado']+saldo,
							'balancete_acumulado_id':documento.id,
							'somar':'true',
							
						}
						#if conta.tipo_interno!='m':
						#	val['somar']=''
						
						antecessor_topo=validator.get_getAntecessor_topo(cr,uid,conta)
						logger.info('ANTECESSOR DE TOPO ACHADO %s' %str(antecessor_topo))
						
						if lista_todas_contas_seleccionadas.__contains__(antecessor_topo):
							logger.info('teste')
						else:
							val['pai']='true'
						
						if lista_todas_contas_seleccionadas.__contains__(conta.parent_id):
								val['somar']=''
						else:
							val['somar']='true'
						
						self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
		   
			else:			 
								
				lista_contas_lancamentos_ids=[]
				
				todos_lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('state','=','emitido'),
												('periodo_id','in',periodos_intermediarios_ids),
												('ano_fiscal_id','=',documento.ano_fiscal_id.id),
											   ])
				
				contas_movimento_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																				('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																				('tipo_interno','=','m')
																				])
				#for conta in contas_movimento_ids:
				 #   conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
				  #  if len(conta.movimentos_ids)>0:
				   #	 lista_contas_lancamentos_ids.append(conta.id)
				
		   
				for lancamento in todos_lancamento_diarios_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
				
					if lista_contas_lancamentos_ids.__contains__(lancamento.conta_id.id):
						logger.info('CONTA JA EXISTENTE NA LISTA %s' %str(lancamento.conta_id.ref))
						#continue
					else:
				#		if lancamento.conta_id.ref[:2]=='11':
				#			logger.info('CONTA JA EXISTENTE NA LISTA %s' %str(lancamento.conta_id.ref))
						lista_contas_lancamentos_ids.append(lancamento.conta_id.id)
			  
				for conta in lista_contas_lancamentos_ids:
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('conta_id','=',conta),
												('state','=','emitido'),
												('periodo_id','in',periodos_intermediarios_ids)
										])
					logger.info('PROCESSO DE BALANCETE INICIADO %s' %str(lancamento_ids))
								   
					lista_normal=[]
					lista_acumulados=[]						
					
					total_debito=0
					total_credito=0
					total_debito_periodo=0
					total_credito_periodo=0
					total_debito_acumulado=0
					total_credito_acumulado=0
					total_credito_periodo_acumulado=0
					total_debito_periodo_acumulado=0
					saldo=0
					saldo_acumulado=0
					conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
					
					if len(lancamento_ids)>0:
						for lancamento in lancamento_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if documento.conversao_moeda=='mp':
								total_debito=total_debito+lancamento.debito_moeda_base
								total_credito=total_credito+lancamento.credito_moeda_base
							elif documento.conversao_moeda=='ms':
								total_debito=total_debito+lancamento.debito_secundario_arredondado
								total_credito=total_credito+lancamento.credito_secundario_arredondado

						val={
							'conta_id':conta.id,
							'debito_periodo':total_debito,
							'credito_periodo':total_credito,					   
							'balancete_id':documento.id,
							'credito_contavel':0,
							'debito_contavel':0,
							'saldo_contavel':0,
							'somar':'true',
							'ref':conta.ref
						}
					
						if total_credito>total_debito:
							saldo=total_credito-total_debito
						elif total_debito>total_credito:
							saldo=total_debito-total_credito
							
						val['saldo_periodo']=saldo
						lista_normal.append(val)
						
					
 
					if  (documento.periodo=='acumulado' or documento.periodo=='periodo_acumulado') :
						local_debito_acumulado=0
						local_credito_acumulado=0
						lancamentos_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																								('conta_id','=',conta.id),
																								('state','=','emitido'),
																								('periodo_id','<',documento.periodo_inicio_id.id)])
						for lancamento_anterior in lancamentos_anteriores_ids:
							lancamento_anterior=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_anterior)
							if documento.conversao_moeda=='mp':
								local_debito_acumulado=local_debito_acumulado+round(lancamento_anterior.debito_moeda_base,2)
								local_credito_acumulado=local_credito_acumulado+round(lancamento_anterior.credito_moeda_base,2)
							elif documento.conversao_moeda=='ms':
								local_debito_acumulado=local_debito_acumulado+lancamento_anterior.debito_secundario_arredondado
								local_credito_acumulado=local_credito_acumulado+lancamento_anterior.credito_secundario_arredondado
							
						#valores=self.get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.ano_fiscal_id.id)
						total_debito_acumulado=total_debito_acumulado+local_debito_acumulado+total_debito
						total_credito_acumulado=total_credito_acumulado+local_credito_acumulado+total_credito
						
						if total_debito_acumulado>total_credito_acumulado:
							saldo_acumulado=total_debito_acumulado-total_credito_acumulado
						elif total_debito_acumulado<total_credito_acumulado:
							saldo_acumulado=total_credito_acumulado-total_debito_acumulado
							
						if(total_debito_acumulado>0 or total_credito_acumulado>0 or saldo_acumulado>0):
							
								
							val={
									'conta_id':conta.id,
									'debito_acumulado':total_debito_acumulado,
									'credito_acumulado':total_credito_acumulado,
									'saldo_acumulado':saldo_acumulado,
									'balancete_acumulado_id':documento.id,
									'credito_contavel':0,
									'debito_contavel':0,
									'saldo_contavel':0,
									'somar':'true',
									'ref':conta.ref
								}
							lista_acumulados.append(val)
						
				  
					total_debito_periodo=total_debito_periodo+total_debito
					total_credito_periodo=total_credito_periodo+total_credito
										
					if total_debito_periodo>total_credito_periodo:
						total_saldo_periodo=total_debito_periodo-total_credito_periodo
					elif total_debito_periodo<total_credito_periodo:
						total_saldo_periodo=total_credito_periodo-total_debito_periodo
					else:
						total_saldo_periodo=0
					
					
					if  (documento.periodo=='acumulado' or documento.periodo=='periodo_acumulado') :
						total_credito_periodo_acumulado=total_credito_periodo_acumulado+total_credito_acumulado
						total_debito_periodo_acumulado=total_debito_periodo_acumulado+total_debito_acumulado
						if total_debito_periodo_acumulado>total_credito_periodo_acumulado:
							total_saldo_periodo_acumulado=total_debito_periodo_acumulado-total_credito_periodo_acumulado
						elif total_debito_periodo_acumulado<total_credito_periodo_acumulado:
							total_saldo_periodo_acumulado=total_credito_periodo_acumulado-total_debito_periodo_acumulado
						else:
							total_saldo_periodo_acumulado=0
					
										
					pai_id=None
					conta_pai=validator.get_getAntecessor_topo(cr,uid,conta)
					logger.info('CONTA PAI ACHADA %s' %str(total_debito_periodo))
					logger.info('CONTA PAI ACHADA %s' %str(total_credito_periodo))
					
					if (total_debito_periodo>0 or total_credito_periodo>0):
						#logger.info('ENTROU NO PERIODO')						
						val={
							'conta_id':conta_pai.id,
							'debito_periodo':total_debito_periodo,
							'credito_periodo':total_credito_periodo,
							'saldo_periodo':total_saldo_periodo,
							'balancete_id':documento.id,
							'pai':'true',
							'credito_contavel':total_credito_periodo,
							'debito_contavel':total_debito_periodo,
							'saldo_contavel':total_saldo_periodo,
							'ref':conta_pai.ref,
							'sequence':sequencia,
						}
						lista_normal.append(val)
						total_debito_geral=total_debito_geral+total_debito_periodo
						total_credito_geral=total_credito_geral+total_credito_periodo
						
						lista_normal = sorted(lista_normal, key=lambda d: (d['ref']))
																		
						for normal in lista_normal:
							
							conta_object_id=normal['conta_id']
							conta_obj=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_object_id)
							
							lista_retornada=self.get_ascendente_totalizador(cr,uid,conta_obj)
							
								
							lista_retornada.append(conta_obj)
							
							ascendete_totalizador_id=0
							if len(lista_retornada)>0:
								for conta_obj in lista_retornada:
		
									ascendete_totalizador_id=conta_obj.parent_id.id
									outro_normal=normal.copy()
									outro_normal['conta_id']=conta_obj.id
									outro_normal['sequence']=sequencia
									
									if conta_obj.tipo_interno!='m':
										outro_normal['somar']=''
									
									linhas_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[('conta_id','=',conta_obj.id)])

									if len(linhas_ids)>0:
										obj=self.pool.get('dotcom.contabilidade.balancete.linha').browse(cr,uid,linhas_ids[0])
										local_cre=obj.credito_periodo
										local_deb=obj.debito_periodo
									   
										local_sal=0
										if (local_deb+outro_normal['debito_periodo'])>(local_cre+outro_normal['credito_periodo']):
											local_sal=(local_deb+outro_normal['debito_periodo'])-(local_cre+outro_normal['credito_periodo'])
										elif (local_deb+outro_normal['debito_periodo'])<(local_cre+outro_normal['credito_periodo']):
											local_sal=(local_cre+outro_normal['credito_periodo'])-(local_deb+outro_normal['debito_periodo'])
										
										self.pool.get('dotcom.contabilidade.balancete.linha').write(cr,uid,linhas_ids[0],{
																		'debito_periodo':obj.debito_periodo+outro_normal['debito_periodo'],
																		'credito_periodo':obj.credito_periodo+outro_normal['credito_periodo'],
																		'saldo_periodo':local_sal,
							 
																		'credito_contavel':obj.credito_contavel+outro_normal['credito_contavel'],
																		'debito_contavel':obj.debito_contavel+outro_normal['debito_contavel'],
																		'saldo_contavel':local_sal,})
										
									else:
										if conta_obj.ano_fiscal_id.id==documento.ano_fiscal_id.id:
											self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,outro_normal)
										
									
									normal['parent_totalizador_id']=int(ascendete_totalizador_id)
									
									sequencia=sequencia+1
									
								normal['parent_id']=int(conta_pai.ref) 
							else:
								
								linhas_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[
															('conta_id','=',conta_obj.id)
													])
								if len(linhas_ids)>0:
									obj=self.pool.get('dotcom.contabilidade.balancete.linha').browse(cr,uid,linhas_ids[0])
									
									local_cre=obj.credito_periodo
									local_deb=obj.debito_periodo
									local_sal=0
									if (local_deb+normal['debito_periodo'])>(local_cre+normal['credito_periodo']):
										local_sal=(local_deb+normal['debito_periodo'])-(local_cre+normal['credito_periodo'])
									elif (local_deb+normal['debito_periodo'])<(local_cre+normal['credito_periodo']):
										local_sal=(local_cre+normal['credito_periodo'])-(local_deb+normal['debito_periodo'])
									
									self.pool.get('dotcom.contabilidade.balancete.linha').write(cr,uid,linhas_ids[0],{
																	'debito_periodo':obj.debito_periodo+normal['debito_periodo'],
																	'credito_periodo':obj.credito_periodo+normal['credito_periodo'],
																	'saldo_periodo':local_sal,
						 
																	'credito_contavel':obj.credito_contavel+normal['credito_contavel'],
																	'debito_contavel':obj.debito_contavel+normal['debito_contavel'],
																	'saldo_contavel':local_sal,
																})
									
								else:
									self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,normal)
								
												 
					if (documento.periodo=='acumulado' or documento.periodo=='periodo_acumulado') and (total_debito_periodo_acumulado>0 or total_credito_periodo_acumulado>0):	
																	   
						val={
							'conta_id':conta_pai.id,
							'debito_acumulado':total_debito_periodo_acumulado,
							'credito_acumulado':total_credito_periodo_acumulado,
							'saldo_acumulado':total_saldo_periodo_acumulado,
							'balancete_acumulado_id':documento.id,
							'pai':'true',
							
							'credito_contavel':total_credito_periodo_acumulado,
							'debito_contavel':total_debito_periodo_acumulado,
							'saldo_contavel':total_saldo_periodo_acumulado,
							'ref':conta_pai.ref
						}
						
						sequencia=sequencia+1
						
						lista_acumulados.append(val)	
						
						total_debito_geral_acumulado=total_debito_geral_acumulado+total_debito_periodo_acumulado
						total_credito_geral_acumulado=total_credito_geral_acumulado+total_credito_periodo_acumulado
										  
						lista_acumulados = sorted(lista_acumulados, key=lambda d: (d['ref']))	 
						for acumulado in lista_acumulados:
							
							
							conta_object_id=acumulado['conta_id']
							conta_obj=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_object_id)
							ascendete_totalizador_id=0
							
							lista_retornada=self.get_ascendente_totalizador(cr,uid,conta_obj)
							
							if len(lista_retornada)>0:
								for conta_obj in lista_retornada:
	
									outro_normal=acumulado.copy()
									outro_normal['conta_id']=conta_obj.id
									outro_normal['somar']=''
									
									linhas_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[('conta_id','=',conta_obj.id),])
		 
									if len(linhas_ids)>0:	
										obj=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').browse(cr,uid,linhas_ids[0])
										local_deb=obj.debito_acumulado
										local_cre=obj.credito_acumulado
										local_sal=0
										if(local_deb+outro_normal['debito_acumulado'])>(local_cre+outro_normal['credito_acumulado']):
											local_sal=(local_deb+outro_normal['debito_acumulado'])-(local_cre+outro_normal['credito_acumulado'])
										elif(local_deb+outro_normal['debito_acumulado'])<(local_cre+outro_normal['credito_acumulado']):
											local_sal=(local_cre+outro_normal['credito_acumulado'])-(local_deb+outro_normal['debito_acumulado'])
										
										
										self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').write(cr,uid,linhas_ids[0],{
															'debito_acumulado':obj.debito_acumulado+outro_normal['debito_acumulado'],
															'credito_acumulado':obj.credito_acumulado+outro_normal['credito_acumulado'],
															'saldo_acumulado':local_sal,
															'credito_contavel':obj.credito_contavel+outro_normal['credito_contavel'],
															'debito_contavel':obj.debito_contavel+outro_normal['debito_contavel'],
															'saldo_contavel':local_sal,
											})
									else:
										self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,outro_normal)
								self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,acumulado)
							
							else:
								conta_local_id=acumulado['conta_id']
								linhas_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[('conta_id','=',conta_obj.id)])		   
								if len(linhas_ids)>0:
									obj=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').browse(cr,uid,linhas_ids[0])
									local_deb=obj.debito_acumulado
									local_cre=obj.credito_acumulado
									local_sal=0
									if(local_deb+acumulado['debito_acumulado'])>(local_cre+acumulado['credito_acumulado']):
										local_sal=(local_deb+acumulado['debito_acumulado'])-(local_cre+acumulado['credito_acumulado'])
									elif(local_deb+acumulado['debito_acumulado'])<(local_cre+acumulado['credito_acumulado']):
										local_sal=(local_cre+acumulado['credito_acumulado'])-(local_deb+acumulado['debito_acumulado'])
									
									
									self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').write(cr,uid,linhas_ids[0],{
														'debito_acumulado':obj.debito_acumulado+acumulado['debito_acumulado'],
														'credito_acumulado':obj.credito_acumulado+acumulado['credito_acumulado'],
														'saldo_acumulado':local_sal,
														'credito_contavel':obj.credito_contavel+acumulado['credito_contavel'],
														'debito_contavel':obj.debito_contavel+acumulado['debito_contavel'],
														'saldo_contavel':local_sal,})
								else:
									self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,acumulado)
								
								
			self.write(cr,uid,documento.id,{
											'total_debito':total_debito_geral,
											'total_credito':total_credito_geral,
											'total_acumulado_debito':total_debito_geral_acumulado,
											'total_acumulado_credito':total_credito_geral_acumulado
											})
			
			action={}
			#break
			if (documento.periodo=='periodo') or (documento.periodo=='acumulado'):
				action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.balancete',
					'report_name': 'dotcom_contabilidade_balancete_analitico_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
				
			elif documento.periodo=='periodo_acumulado':
				action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.balancete',
					'report_name': 'dotcom_contabilidade_balancete_analitico_acumulado_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
				
		return action
		
	
	def get_ascendente_totalizador(self,cr,uid,conta,context=None):
		if context is None:
			context,{}
		lista=[]
		valores={}
		
		
			
		if bool(conta.parent_id)==True and (conta.parent_id.tipo_interno=='t'):
			conta_ascendente=conta.parent_id
			if conta.ref=='429001':
				logger.info('PARENTE DA CONTA ACHADO')
			
			
			lista.append(conta.parent_id)
			outra_lista=self.get_ascendente_totalizador(cr,uid,conta_ascendente)
			
			for outro in outra_lista:
				lista.append(outro)
			#lista=sorted(lista, key=lambda d: (d['ref']))
		return lista
			
		
	
	def actualizar_balancete_razao(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			for linha in documento.linhas_balancete_razao_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha.id)
			
			for linha in documento.linhas_acumulados_balancete_razao_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha.id)
			
			conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
							('ano_fiscal_id','=',documento.ano_fiscal_id.id),
							('tipo_interno','=','r')
						])
			
			
			if bool(documento.conta_razao_id.id)==True:
				lancamento_ids=[]
				#logger.info('CONTA PAI %s' %str(documento.conta_razao_id.ref))
				if bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==True:
					periodos=[]
					contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,documento.conta_razao_id)
					for conta_filho in contas_filhos_ids:
						#logger.info('CONTA FILHO %s' %str(conta_filho.ref))
						periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
										('id','>=',documento.periodo_inicio_id.id),
										('id','<=',documento.periodo_fim_id.id),
									])
						for periodo in periodos_intermediarios_ids:
							periodos.append(periodo)
						lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta_filho.id),
													('state','=','emitido'),
													('periodo_id','in',periodos)											
										])
						#logger.info('LANCAMENTOS ACHADOS LOCAL %s' %str(lancamento_local_ids))
						for lancamento in lancamento_local_ids:
							lancamento_ids.append(lancamento)
							
				elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==True:
					contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,documento.conta_razao_id)				  
					for conta_filho in contas_filhos_ids:
						#logger.info('CONTA FILHO %s' %str(conta_filho.ref))
						lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta_filho.id),
													('state','=','emitido'),
													('periodo_id','<=',documento.periodo_fim_id.id)
											])
						for lancamento in lancamento_local_ids:
							lancamento_ids.append(lancamento)
							
				elif bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==False:
					contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,documento.conta_razao_id)				  
					for conta_filho in contas_filhos_ids:
						#logger.info('CONTA FILHO %s' %str(conta_filho.ref))
						lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta_filho.id),
													('state','=','emitido'),
													('periodo_id','>=',documento.periodo_inicio_id.id)
											])
						for lancamento in lancamento_local_ids:
							lancamento_ids.append(lancamento)
							
				elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==False:
					contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,documento.conta_razao_id)				  
					for conta_filho in contas_filhos_ids:
						#logger.info('CONTA FILHO %s' %str(conta_filho.ref))
						lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',conta_filho.id),
													('state','=','emitido'),
											])
						for lancamento in lancamento_local_ids:
							lancamento_ids.append(lancamento)
				
				#logger.info('LANCAMENTOS ACHADOS %s' %str(lancamento_ids))
				total_debito=0
				total_credito=0
				saldo=0
				
				for lancamento in lancamento_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					if documento.conversao_moeda=='mp':
						total_debito=total_debito+lancamento.debito_moeda_base
						total_credito=total_credito+lancamento.credito_moeda_base
					elif documento.conversao_moeda=='ms':
						total_debito=total_debito+lancamento.debito_moeda_secundaria
						total_credito=total_credito+lancamento.credito_moeda_secundaria
				
				if total_credito>total_debito:
					saldo=total_credito-total_debito
				elif total_debito>total_credito:
					saldo=total_debito-total_credito
				
				val={
					'conta_id':documento.conta_razao_id.id,
					'debito_periodo':total_debito,
					'credito_periodo':total_credito,
					'saldo_periodo':saldo,
					'balancete_razao_id':documento.id,
					'credito_contavel':total_credito,
					'debito_contavel':total_debito,
					'saldo_contavel':saldo,
				}
				self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
				
				valores=None
				if bool(documento.periodo_inicio_id.id)==True:
					valores=self.get_valores_acumulados_razao(cr,uid,ids,documento.conta_id,documento.periodo_inicio_id.id)
				else:
					periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
					valores=self.get_valores_acumulados_razao(cr,uid,ids,documento.conta_id,periodos_ids[0])
				
				val={
					'conta_id':documento.conta_razao_id.id,
					'debito_acumulado':valores['debito_acumulado']+total_debito,
					'credito_acumulado':valores['credito_acumulado']+total_credito,
					'saldo_acumulado':valores['saldo_acumulado']+saldo,
					'balancete_acumulado_razao_id':documento.id,
					'credito_contavel':valores['credito_acumulado']+total_credito,
					'debito_contavel':valores['debito_acumulado']+total_debito,
					'saldo_contavel':valores['saldo_acumulado']+saldo,
					
					
				}
				
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
			else:
				
				for conta in conta_ids:
					lancamento_ids=[]
					conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
					contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,conta)
				
					if bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==True:
						periodos=[]
						periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
										('id','>=',documento.periodo_inicio_id.id),
										('id','<=',documento.periodo_fim_id.id),
									])
						
						for periodo in periodos_intermediarios_ids:
							periodos.append(periodo)
						
						for conta_filho in contas_filhos_ids:
							lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',conta_filho.id),
														('state','=','emitido'),
														('periodo_id','in',periodos),					 
												])
		   
							for lancamento in lancamento_local_ids:
								lancamento_ids.append(lancamento)
							
					elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==True:
						for conta_filho in contas_filhos_ids:
							lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',conta_filho.id),
														('state','=','emitido'),
														('periodo_id','<=',documento.periodo_fim_id.id)
												])
						   
							for lancamento in lancamento_local_ids:
								lancamento_ids.append(lancamento)
								
					elif bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==False:
						#contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,conta)
						for conta_filho in contas_filhos_ids:
							lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',conta_filho.id),
														('state','=','emitido'),
														('periodo_id','>=',documento.periodo_inicio_id.id)
												])
													 
							for lancamento in lancamento_local_ids:
								lancamento_ids.append(lancamento)
								
					else:
						#contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,conta)
						for conta_filho in contas_filhos_ids:
							lancamento_local_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',conta_filho.id),
														('state','=','emitido'),
											])
							
							for lancamento in lancamento_local_ids:
									lancamento_ids.append(lancamento)
									
					#logger.info('REFERENCIA CONTA %s' %str(conta.ref))
					#logger.info('LANCAMENTOS ACHADOS %s' %str(lancamento_ids))
					#logger.info('LANCAMENTOS ACHADOS %s' %str(lancamento_ids))
					total_debito=0
					total_credito=0
					saldo=0
					
					if len(lancamento_ids)>0:
						for lancamento in lancamento_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if documento.conversao_moeda=='mp':
								total_debito=total_debito+lancamento.debito_moeda_base
								total_credito=total_credito+lancamento.credito_moeda_base
							elif documento.conversao_moeda=='ms':
								total_debito=total_debito+lancamento.debito_moeda_secundaria
								total_credito=total_credito+lancamento.credito_moeda_secundaria
						
						if total_credito>total_debito:
							saldo=total_credito-total_debito
							
				
							val={
								'conta_id':conta.id,
								
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,						   
								'balancete_razao_id':documento.id,
								'credito_contavel':total_credito,
								'debito_contavel':total_debito,
								'saldo_contavel':saldo,
							}
	
							self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,documento.periodo_inicio_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,periodos_ids[0])
	 
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':valores['saldo_acumulado']+saldo,
									'balancete_acumulado_razao_id':documento.id,
									'credito_contavel':valores['credito_acumulado']+total_credito,
									'debito_contavel':valores['debito_acumulado']+total_debito,
									'saldo_contavel':valores['saldo_acumulado']+saldo,
								}
							
							self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
						elif total_debito>total_credito:
							saldo=total_debito-total_credito
						   
							val={
								'conta_id':conta.id,
								
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'balancete_razao_id':documento.id,
								
								'credito_contavel':total_credito,
								'debito_contavel':total_debito,
								'saldo_contavel':saldo,
							}
							
							
	
							self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,documento.periodo_inicio_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,periodos_ids[0])
							
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':valores['saldo_acumulado']+saldo,
									'balancete_acumulado_razao_id':documento.id,
									
									'credito_contavel':valores['credito_acumulado']+total_credito,
									'debito_contavel':valores['debito_acumulado']+total_debito,
									'saldo_contavel':valores['saldo_acumulado']+saldo,
								}
							self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
							
							
						else:
							saldo=total_debito-total_credito
							
							val={
								'conta_id':conta.id,
								
								'debito_periodo':total_debito,
								'credito_periodo':total_credito,
								'saldo_periodo':saldo,
								'balancete_razao_id':documento.id,
								
								'credito_contavel':total_credito,
								'debito_contavel':total_debito,
								'saldo_contavel':saldo,
							}
							
							
	
							self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
							
							valores=None
							if bool(documento.periodo_inicio_id.id)==True:
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,documento.periodo_inicio_id.id)
							else:
								periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
								valores=self.get_valores_acumulados_razao(cr,uid,ids,conta,periodos_ids[0])
							
							val={
									'conta_id':conta.id,
									'debito_acumulado':valores['debito_acumulado']+total_debito,
									'credito_acumulado':valores['credito_acumulado']+total_credito,
									'saldo_acumulado':valores['saldo_acumulado']+saldo,
									'balancete_acumulado_razao_id':documento.id,
									
									'credito_contavel':valores['credito_acumulado']+total_credito,
									'debito_contavel':valores['debito_acumulado']+total_debito,
									'saldo_contavel':valores['saldo_acumulado']+saldo,
								}
							self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
		return {}
		
		
		
	def get_valores_acumulados(self,cr,uid,ids,conta_id,periodo_id,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		#periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('id','<',periodo_id),('fiscalyear_id','=',ano_fiscal_id)])
		#for periodo in periodos_ids:
		#	periodo=self.pool.get('configuration.period').browse(cr,uid,periodo)
		
		lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
				('conta_id','=',conta_id),
				('state','=','emitido'),
				('periodo_id','<',periodo_id),					 
			])
		  

		credito_acumulado=0
		debito_acumulado=0
		saldo_acumulado=0
		if len(lancamento_ids)>0:
			
			for lancamento in lancamento_ids:
				lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
				debito_acumulado=debito_acumulado+lancamento.debito_moeda_base
				credito_acumulado=credito_acumulado+lancamento.credito_moeda_base
			if credito_acumulado>debito_acumulado:
				saldo_acumulado=credito_acumulado-debito_acumulado
			elif debito_acumulado>credito_acumulado:
				saldo_acumulado=debito_acumulado>credito_acumulado
	
			
		return {'credito_acumulado':credito_acumulado,
				'debito_acumulado':debito_acumulado,
				'saldo_acumulado':saldo_acumulado}
		
	
	
	
	def get_valores_acumulados_razao(self,cr,uid,ids,conta_id,periodo_id,context=None):
		if context is None:
			context={}
		
		contas_filhos_ids=self.pool.get('dotcom.contabilidade.resultados').get_filhos(cr,uid,ids,conta_id)
		lista_lancamentos_ids=[]
		for conta_filho in contas_filhos_ids:
			lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
					('conta_id','=',conta_filho.id),
					('state','=','emitido'),
					('periodo_id','<',periodo_id),					 
				])
			for lancamento in lancamento_ids:
				lista_lancamentos_ids.append(lancamento)
			
			
		credito_acumulado=0
		debito_acumulado=0
		saldo_acumulado=0
		if len(lista_lancamentos_ids)>0:
			for lancamento in lista_lancamentos_ids:
				lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
				debito_acumulado=debito_acumulado+lancamento.debito_moeda_base
				credito_acumulado=credito_acumulado+lancamento.credito_moeda_base
			if credito_acumulado>debito_acumulado:
				saldo_acumulado=credito_acumulado-debito_acumulado
			elif debito_acumulado>credito_acumulado:
				saldo_acumulado=debito_acumulado>credito_acumulado
		
		val={
			'credito_acumulado':credito_acumulado,
			'debito_acumulado':debito_acumulado,
			'saldo_acumulado':saldo_acumulado
		}
		
		return val
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																				('ano_fiscal_id','=',ano_fiscal_id),
																				('state','=','emitidotido')])
		
		if len(lancamentos_ids)>0:
			ultimo_lancamento_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamentos_ids[len(lancamentos_ids)-1])
			primeiro_lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamentos_ids[0])
			return {'value':{'contas_ids':False,
						 'periodo_inicio_id':primeiro_lancamento.periodo_id.id,
						 'periodo_fim_id':ultimo_lancamento_object.periodo_id.id}}
		else:
			ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
			periodo_inicial=ano_fiscal_object.period_ids[0]
			periodo_final=ano_fiscal_object.period_ids[len(ano_fiscal_object.period_ids)-1]
			return {'value':{'contas_ids':False,
							'periodo_inicio_id':periodo_inicial.id,
							'periodo_fim_id':periodo_final.id}}
	#def get_parent_conta(self,cr,uid,ids,conta_id,context=None):
	#	if context is None:
	
	
dotcom_balancete()


class dotcom_linha_balancete(osv.osv):
	_name='dotcom.contabilidade.balancete.linha'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True),
		'descricao':fields.char('Descricao',size=50),
		
		'debito_periodo':fields.float('Debito (Periodo)'),
		'credito_periodo':fields.float('Credito (Periodo)'),
		'saldo_periodo':fields.float('Saldo (Periodo)'),
		'credito_contavel':fields.float('Credito'),
		'debito_contavel':fields.float('Debito'),
		'saldo_contavel':fields.float('Saldo'),
		'somar':fields.char('Somar', size=20,),
		'pai':fields.char('pai',size=20),
		'balancete_id':fields.many2one('dotcom.contabilidade.balancete','Balancete'),
		'balancete_razao_id':fields.many2one('dotcom.contabilidade.balancete','Balancete'),
		
		'balancete_razao_object_id':fields.many2one('dotcom.contabilidade.balancete.razao','Balancete Razao'),
		
		'parent_id': fields.integer('Sub-contas' ),
		'parent_totalizador_id':fields.integer('Sub-contas Totalizadora' ),
		
		
		'sequence':fields.integer('Sequencia'),
		'saldo_credito':fields.float('Saldo Credito'),
		'saldo_debito':fields.float('Saldo Debito'),
		'ref':fields.char('Ref', size=40)
		#'parent_id': fields.many2one('dotcom.contabilidade.balancete.linha', 'Ascendente', required=False, ondelete="cascade"),
	}
	
	_rec_name='conta_id'
	
dotcom_linha_balancete()


class dotcom_linha_balancete_acumulado(osv.osv):
	_name='dotcom.contabilidade.balancete.linha.acumulado'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True),
		'debito_acumulado':fields.float('Debito (Acum)'),
		'credito_acumulado':fields.float('Credito (Acum)'),
		'saldo_acumulado':fields.float('Saldo (Acum)'),
		
		'credito_contavel':fields.float('Credito'),
		'debito_contavel':fields.float('Debito'),
		'saldo_contavel':fields.float('Saldo'),
		'somar':fields.char('Somar', size=20,),
		'pai':fields.char('pai',size=20),
		'balancete_acumulado_id':fields.many2one('dotcom.contabilidade.balancete','Balancete'),
		'balancete_acumulado_razao_id':fields.many2one('dotcom.contabilidade.balancete','Balancete'),
		
		'balancete_razao_object_id':fields.many2one('dotcom.contabilidade.balancete.razao','Balancete Razao'),
		'ref':fields.char('Ref', size=40)
	}
	_rec_name='debito_acumulado'
	
dotcom_linha_balancete()



class dotcom_contabilidade_balancete_razao(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	_name='dotcom.contabilidade.balancete.razao'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		
		'contas_ids':fields.many2many('dotcom.contabilidade.plano.contas','balanccete_razao_conta_rel','balancete_id','conta_id','Conta',required=False),
		
		#'conta_razao_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Razao',required=False),
		'periodo_inicio_id':fields.many2one('configuration.period','Início',required=True),
		'periodo_fim_id':fields.many2one('configuration.period','Fim',required=True),
		
		'periodo':fields.selection([
			('periodo','Período'),
			('acumulado','Acumulado'),
			('periodo_acumulado','Período e Acumulado')
			],'Período',required=True),
		'total_debito':fields.float('Total Debito',readonly=True),
		'total_credito':fields.float('Total Credito', readonly=True),
		'total_acumulado_debito':fields.float('Total Debito Acumulado',readonly=True),
		'total_acumulado_credito':fields.float('Total Credito Acumulado', readonly=True),
		
		'conversao_moeda':fields.selection(_acerto,'Moeda', required=True,),
		'linhas_balancete_ids':fields.one2many('dotcom.contabilidade.balancete.linha','balancete_razao_object_id','Linhas do Balancete',readonly=True),
		#'linhas_balancete_razao_ids':fields.one2many('dotcom.contabilidade.balancete.linha','balancete_razao_id','Linhas do Balancete',readonly=True),
		'linhas_acumulados_balancete_ids':fields.one2many('dotcom.contabilidade.balancete.linha.acumulado','balancete_razao_object_id','Linhas do Balancete',readonly=True),
		#'linhas_acumulados_balancete_razao_ids':fields.one2many('dotcom.contabilidade.balancete.linha.acumulado','balancete_acumulado_razao_id','Linhas do Balancete',readonly=True),
		
	}
	
	_defaults={
		'periodo':'periodo',
		'ano_fiscal_id':validator._get_default_year,
		#'periodo_inicio_id':validator._get_default_openning_period,
		#'periodo_fim_id':validator._get_periodo_ultimo_movimento,
		'conversao_moeda':'mp'
	}
	
	
	def carregar_balancete_razao(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[])
			#logger.info('LINHAS ACHADAS DO BALANCETE %s' %str(linhas_balancete_ids))
			
		for linha in linhas_balancete_ids:
			self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha)
			
		linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[])
		
		
		
		for linha in linhas_balancete_ids:
			self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha)
				
		for documento in self.browse(cr,uid,ids):
			
			periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_start','>=',documento.periodo_inicio_id.date_start),
								('date_stop','<=',documento.periodo_fim_id.date_stop),
								('special','=',False),
								('closing','=',False)
							])
			
			periodos_fecho_ids=[]
			if documento.periodo_inicio_id.special==True:
				periodos_intermediarios_ids.append(documento.periodo_inicio_id.id)
			
			logger.info('PROCESSO INICIADO COM SUCESSO' )
			if documento.periodo_fim_id.closing==True:
				ref=documento.periodo_fim_id.code
				ref_reduzida=ref[:2]
				
				if ref_reduzida=='13':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					
				if ref_reduzida=='14':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					ref_anterior='13/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					
					
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
						
				if ref_reduzida=='15':
					periodos_intermediarios_ids.append(documento.periodo_fim_id.id)
					ref_anterior='13/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
						
					ref_anterior='14/'+documento.ano_fiscal_id.name
					periodo_final_intermedirario_ids=self.pool.get('configuration.period').search(cr,uid,[
								('date_stop','=',documento.periodo_fim_id.date_stop),
								('closing','=','True'),
								('code','=',ref_anterior)])
					for intermedio in periodo_final_intermedirario_ids:
						periodos_intermediarios_ids.append(intermedio)
			
			lista_contas_razao=[]
			
			if len(documento.contas_ids)>0:
				for conta in documento.contas_ids:
					lista_contas_razao.append(conta.id)
			else:
				lista_contas_razao=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																										('tipo_interno','=','r'),
																										])
			
			for conta_razao in lista_contas_razao:
				lista_contas_movimento=[]
				conta_razao=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_razao)
				logger.info('CONTA DE RAZAO PAI %s' %str(conta_razao.ref))

				lista_contas_movimento_ids=validator.get_filhos_id(cr,uid,conta_razao,context)
				logger.info('LISTA DE CONTAS FILHAS %s' %str(len(lista_contas_movimento_ids)))
				
				lista_lancamentos_periodo_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','in',lista_contas_movimento_ids),
																			('periodo_id','in',periodos_intermediarios_ids),
																			('state','=','emitido'),
						])
				
				lista_lancamentos_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																			('conta_id','in',lista_contas_movimento_ids),
																			('data_lancamento','<',documento.periodo_inicio_id.date_start),
																			('state','=','emitido'),
						])
				
				total_credito_anterio=0
				total_debito_anterior=0
				for lancamento_anterior in lista_lancamentos_anteriores_ids:
					lancamento_anterior=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_anterior)
					if documento.conversao_moeda=='mp':
						total_debito_anterior=total_debito_anterior+round(lancamento_anterior.debito_moeda_base,2)
						total_credito_anterio=total_credito_anterio+round(lancamento_anterior.credito_moeda_base,2)
					elif documento.conversao_moeda=='ms':
						total_debito_anterior=total_debito_anterior+lancamento_anterior.debito_secundario_arredondado
						total_credito_anterio=total_credito_anterio+lancamento_anterior.credito_secundario_arredondado
					
				
				
				total_debito=0
				total_credito=0
				total_saldo=0
				if len(lista_lancamentos_periodo_ids)>0:
					
					for lancamento in lista_lancamentos_periodo_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if documento.conversao_moeda=='mp':
							total_debito=total_debito+round(lancamento.debito_moeda_base,2)
							total_credito=total_credito+round(lancamento.credito_moeda_base,2)
							logger.info('VALORES A DEBITO %s' %str(total_debito))
							logger.info('VALORES A CREDITO %s' %str(total_credito))
						elif documento.conversao_moeda=='ms':
							total_debito=total_debito+lancamento.debito_secundario_arredondado
							total_credito=total_credito+lancamento.credito_secundario_arredondado
					
					
					if total_debito>total_credito:
						total_saldo=total_debito-total_credito
					elif total_debito<total_credito:
						total_saldo=total_credito-total_debito
					
					
					val={
							'conta_id':conta_razao.id,
							'debito_periodo':total_debito,
							'credito_periodo':total_credito,
							'saldo_periodo':total_saldo,
							'balancete_razao_object_id':documento.id,
							
							'credito_contavel':0,
							'debito_contavel':0,
							'somar':'true',
							'saldo_contavel':0,
						}
					self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
				
				total_debito_acumulado=total_debito_anterior+total_debito
				total_credito_acumulado=total_credito_anterio+total_credito
				total_salddo_acumulado=0
				
				if total_debito_acumulado>total_credito_acumulado:
					total_salddo_acumulado=total_debito_acumulado-total_credito_acumulado
				elif total_debito_acumulado<total_credito_acumulado:
					total_salddo_acumulado=total_credito_acumulado-total_debito_acumulado
					
				val={
						'conta_id':conta_razao.id,
						'debito_acumulado':total_debito_acumulado,
						'credito_acumulado':total_credito_acumulado,
						'saldo_acumulado':total_salddo_acumulado,
						'balancete_razao_object_id':documento.id,
						'somar':'true',
						
					}
						
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
					
					
		action={}
		if (documento.periodo=='periodo') or (documento.periodo=='acumulado'):
			action = {
				'name': _('Balancete Razao Periodo ou Acumulado: %s') % str(ids and ids[0]),
				'view_id': False,
				'res_model': 'dotcom.contabilidade.balancete.razao',
				'report_name': 'dotcom_contabilidade_balancete_razao_report',
				'domain': [],
				'context': dict(context, active_ids=ids),
				'type': 'ir.actions.report.xml',
				'report_type': 'pdf',
				'res_id': ids and ids[0] or False
			}
			
		elif documento.periodo=='periodo_acumulado':
			action = {
				'name': _('Balancete Razao Periodo e Acumulado: %s') % str(ids and ids[0]),
				'view_id': False,
				'res_model': 'dotcom.contabilidade.balancete.razao',
				'report_name': 'dotcom_contabilidade_balancete_razao_teste_acumulado_report',
				'domain': [],
				'context': dict(context, active_ids=ids),
				'type': 'ir.actions.report.xml',
				'report_type': 'pdf',
				'res_id': ids and ids[0] or False
			}
				
		return action
					
					
				

	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																				('ano_fiscal_id','=',ano_fiscal_id),
																				('state','=','emitidotido')])
		
		if len(lancamentos_ids)>0:
			ultimo_lancamento_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamentos_ids[len(lancamentos_ids)-1])
			primeiro_lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamentos_ids[0])
			return {'value':{'contas_ids':False,
						 'periodo_inicio_id':primeiro_lancamento.periodo_id.id,
						 'periodo_fim_id':ultimo_lancamento_object.periodo_id.id}}
		else:
			ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
			periodo_inicial=ano_fiscal_object.period_ids[0]
			periodo_final=ano_fiscal_object.period_ids[len(ano_fiscal_object.period_ids)-1]
			return {'value':{'contas_ids':False,
							'periodo_inicio_id':periodo_inicial.id,
							'periodo_fim_id':periodo_final.id}}
	
	
	def get_filhos(self,cr,uid,ids,conta,context=None):
		if context is None:
			context={}
		lista=[]
		if (conta.tipo_interno=='r' or conta.tipo_interno=='t') and len(conta.child_id)>0:
			for conta_interna in conta.child_id:
				if conta_interna.tipo_interno=='m':
					lista.append(conta_interna)
				else:
					lista2=self.get_filhos(cr,uid,ids,conta_interna)
					for outro in lista2:
						lista.append(outro)
		return lista
	
	
	def pesquisar_linhas_balancete(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		total_debito_geral=0
		total_credito_geral=0
		#
		sequencia=1
		for documento in self.browse(cr,uid,ids):
			total_debito_geral_acumulado=0
			total_geral_credito_acumulado=0
			total_credito_geral_acumulado=0
			
						
			linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha').search(cr,uid,[])
			#logger.info('LINHAS ACHADAS DO BALANCETE %s' %str(linhas_balancete_ids))
			
			for linha in linhas_balancete_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha').unlink(cr,uid,linha)
				
			linhas_balancete_ids=self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').search(cr,uid,[])
			for linha in linhas_balancete_ids:
				self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').unlink(cr,uid,linha)
			
			lancamento_ids=None
			
			if len(documento.contas_ids)>0:
				filhos=[]
				#for conta in documento.contas_ids:
				#	filhos=self.get_filhos(cr,uid,ids,conta.conta_id)
							
				for conta in documento.contas_ids:
					total_debito_geral=0
					total_credito_geral=0
					saldo_geral=0
					filhos=self.get_filhos(cr,uid,ids,conta)
					for filho in filhos:
						logger.info('REFERENCIA DAS CONTAS FILHAS %s' %str(filho.ref))
					
						if bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==True:
							periodos=[]
							periodos_intermediarios_ids=self.pool.get('configuration.period').search(cr,uid,[
												('id','>=',documento.periodo_inicio_id.id),
												('id','<=',documento.periodo_fim_id.id),
											])
							for periodo in periodos_intermediarios_ids:
								periodos.append(periodo)
							lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',filho.id),
														('state','=','emitido'),
														('periodo_id','in',periodos)											
												])
						elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==True:
							lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',filho.id),
														('state','=','emitido'),
														('periodo_id','<=',documento.periodo_fim_id.id)
												])
						elif bool(documento.periodo_inicio_id.id)==True and bool(documento.periodo_fim_id.id)==False:
							lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',filho.id),
														('state','=','emitido'),
														('periodo_id','>=',documento.periodo_inicio_id.id)
												])
						elif bool(documento.periodo_inicio_id.id)==False and bool(documento.periodo_fim_id.id)==False:
							lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
														('conta_id','=',filho.id),
														('state','=','emitido'),
												])
						
						
						total_debito=0
						total_credito=0
						saldo=0
			   
						
						for lancamento in lancamento_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if documento.conversao_moeda=='mp':
								total_debito=total_debito+lancamento.debito_primario_arredondado
								total_credito=total_credito+lancamento.credito_primario_arredondado
							elif documento.conversao_moeda=='ms':
								total_debito=total_debito+lancamento.debito_secundario_arredondado
								total_credito=total_credito+lancamento.credito_secundario_arredondado
						
						total_credito_geral=total_credito_geral+total_credito
						total_debito_geral=total_debito_geral+total_debito
						
						#for conta in lista_antecessores:
							#val={
							#	'conta_id':conta.id,
							#	'debito_periodo':total_debito,
							#	'credito_periodo':total_credito,
							#	'saldo_periodo':saldo,
							#	'balancete_id':documento.id,
							#	
							#	'credito_contavel':total_credito,
							#	'debito_contavel':total_debito,
							#	'saldo_contavel':saldo,
							#	
							#}
							#self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
					if total_debito_geral>total_credito_geral:
						saldo_geral=total_debito_geral-total_credito_geral
					else:
						saldo_geral=total_credito_geral-total_debito_geral
					
					if total_debito_geral!=0 or total_credito_geral!=0:	
						val={
							'conta_id':conta.id,
							'debito_periodo':total_debito_geral,
							'credito_periodo':total_credito_geral,
							'saldo_periodo':saldo_geral,
							'balancete_razao_object_id':documento.id,
							
							'credito_contavel':0,
							'debito_contavel':0,
							'somar':'true',
							'saldo_contavel':0,
						}
						self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
						
						valores=None
						if bool(documento.periodo_inicio_id.id)==True:
							valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,documento.periodo_inicio_id.id,documento.ano_fiscal_id.id)
						else:
							periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',documento.ano_fiscal_id.id)])
							valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta.id,periodos_ids[0],documento.ano_fiscal_id.id)
						
						#logger.info('VALORES ACUMULADOS %s' %str(valores))
						
						#for conta in lista_antecessores:
						#	val={
						#		'conta_id':conta.id,
						#		'debito_acumulado':valores['debito_acumulado']+total_debito,
						#		'credito_acumulado':valores['credito_acumulado']+total_credito,
						#		'saldo_acumulado':valores['saldo_acumulado']+saldo,
						#		'balancete_acumulado_id':documento.id,
						#		
						#		'credito_contavel':valores['credito_acumulado']+total_credito,
						#		'debito_contavel':valores['debito_acumulado']+total_debito,
						#		'saldo_contavel':valores['saldo_acumulado']+saldo,
						#	}
						#	self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
						
						val={
							'conta_id':conta.id,
							'debito_acumulado':valores['debito_acumulado']+total_debito,
							'credito_acumulado':valores['credito_acumulado']+total_credito,
							'saldo_acumulado':valores['saldo_acumulado']+saldo,
							'balancete_razao_object_id':documento.id,
							'somar':'true',
							
						}
						
						self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
		   
			else:
				conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
									('ano_fiscal_id','=',documento.ano_fiscal_id.id),
									('tipo_interno','=','r')
					])
		
				#antecessores=[]
				lancamento_ids=[]
			
				for conta in conta_ids:
					total_debito_geral=0
					total_credito_geral=0
					saldo_geral=0
					
					saldo_geral_acumulado=0
					total_debito_geral_acumulado=0
					total_credito_geral_acumulado=0
					
					conta_object=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
					filhos=self.get_filhos(cr,uid,ids,conta_object)
					logger.info('CONTAS RAZAO ACHADAS %s' %str(conta_object.ref))
					for filho in filhos:
						lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',filho.id),
													('state','=','emitido'),
													('periodo_id','>=',documento.periodo_inicio_id.id),
													('periodo_id','<=',documento.periodo_fim_id.id)   
											])
						
						lancamento_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
													('conta_id','=',filho.id),
													('state','=','emitido'),
													('periodo_id','<',documento.periodo_inicio_id.id),
													#('periodo_id','<=',documento.periodo_fim_id.id)   
											])
						
						for lancamento in lancamento_anteriores_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							if documento.conversao_moeda=='mp':
								total_debito_geral_acumulado=total_debito_geral_acumulado+lancamento.debito_primario_arredondado
								total_credito_geral_acumulado=total_credito_geral_acumulado+lancamento.credito_primario_arredondado
							elif documento.conversao_moeda=='ms':
								total_debito_geral_acumulado=total_debito_geral_acumulado+lancamento.debito_secundario_arredondado
								total_credito_geral_acumulado=total_credito_geral_acumulado+lancamento.credito_secundario_arredondado
						
						lista_normal=[]
						lista_acumulados=[]						
						
						total_debito=0
						total_credito=0
						total_debito_periodo=0
						total_credito_periodo=0
						total_debito_acumulado=0
						total_credito_acumulado=0
						#total_credito_geral_acumulado=0
						total_debito_periodo_acumulado=0
						saldo=0
						saldo_acumulado=0
												
						if len(lancamento_ids)>0:	 
							for lancamento in lancamento_ids:
								lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
								if documento.conversao_moeda=='mp':
									total_debito=total_debito+lancamento.debito_primario_arredondado
									total_credito=total_credito+lancamento.credito_primario_arredondado
								elif documento.conversao_moeda=='ms':
									total_debito=total_debito+lancamento.debito_secundario_arredondado
									total_credito=total_credito+lancamento.credito_secundario_arredondado
	
								
						#valores=self.pool.get('dotcom.contabilidade.balancete').get_valores_acumulados(cr,uid,ids,conta,documento.periodo_inicio_id.id,documento.ano_fiscal_id.id)
  
						
						
						total_debito_periodo=total_debito_periodo+total_debito
						total_debito_periodo_acumulado=total_debito_periodo_acumulado+total_debito_acumulado
						total_credito_periodo=total_credito_periodo+total_credito
						total_credito_geral_acumulado=total_credito_geral_acumulado+total_credito_acumulado
						
						
						total_debito_geral=total_debito_geral+total_debito_periodo
						total_credito_geral=total_credito_geral+total_credito_periodo
						#total_debito_geral_acumulado=total_debito_geral_acumulado+total_debito_periodo_acumulado
						#total_credito_geral_acumulado=total_credito_geral_acumulado+total_credito_geral_acumulado
										   
					
					if total_debito_geral>total_credito_geral:
						saldo_geral=total_debito_geral-total_credito_geral
					else:
						saldo_geral=total_credito_geral-total_debito_geral
					
					if total_debito_geral!=0 or total_credito_geral!=0:
						val={
								'conta_id':conta,
								'debito_periodo':total_debito_geral,
								'credito_periodo':total_credito_geral,
								'saldo_periodo':saldo_geral,
								'balancete_razao_object_id':documento.id,
								
								'credito_contavel':total_credito_geral,
								'debito_contavel':total_debito_geral,
								'saldo_contavel':saldo_geral,
								'ref':conta_object.ref,
								#'sequence':sequencia,
							}
						#logger.info('VALOR A SER CRIADO NO PROCESSO %s' %str(val))
						self.pool.get('dotcom.contabilidade.balancete.linha').create(cr,uid,val)
					
					if total_debito_geral_acumulado>total_credito_geral_acumulado:
						saldo_geral_acumulado=total_debito_geral_acumulado-total_credito_geral_acumulado
					else:
						saldo_geral_acumulado=total_credito_geral_acumulado-total_debito_geral_acumulado
					
					if total_debito_geral_acumulado+total_debito_geral!=0 or total_credito_geral_acumulado+total_credito_geral!=0:
						val={
							'conta_id':conta,
							'debito_acumulado':total_debito_geral_acumulado+total_debito_geral,
							'credito_acumulado':total_credito_geral_acumulado+total_credito_geral,
							'saldo_acumulado':saldo_geral_acumulado,
							'balancete_razao_object_id':documento.id,
							'somar':'true',
							
						}
						
						self.pool.get('dotcom.contabilidade.balancete.linha.acumulado').create(cr,uid,val)
						
			self.write(cr,uid,documento.id,{
											'total_debito':total_debito_geral,
											'total_credito':total_credito_geral,
											'total_acumulado_debito':total_debito_geral_acumulado,
											'total_acumulado_credito':total_credito_geral_acumulado
											})
			
			action={}
			#logger.info('NUMERO DE LINHAS ACUMULADAS %s' %str(len(documento.linhas_acumulados_balancete_ids)))
			if (documento.periodo=='periodo') or (documento.periodo=='acumulado'):
				action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.balancete.razao',
					'report_name': 'dotcom_contabilidade_balancete_razao_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
				
			elif documento.periodo=='periodo_acumulado':
				action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.balancete.razao',
					'report_name': 'dotcom_contabilidade_balancete_razao_teste_acumulado_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
				
		return action
	
dotcom_contabilidade_balancete_razao()