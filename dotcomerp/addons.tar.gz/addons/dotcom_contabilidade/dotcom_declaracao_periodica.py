# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
from validators import validator 
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')
from random import randrange


class dotcom_declaracao_periodica(osv.osv):
	_name='dotcom.contabilidade.declaracao.periodica.modelo'
	_columns={
		'periodo_id':fields.many2one('configuration.period','Período',readonly=False,),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',),
		#'linha_declaracao_ids':fields.one2many('dotcom.contabilidade.declaracao.priodica.linha','declaracao_id','Linhas da Declarao Periodica', readonly=True),
		
		##
		'campo_1':fields.float('1',readonly=True),
		'campo_2':fields.float('2',readonly=True),
		'campo_3':fields.float('3',readonly=True),
		'campo_4':fields.float('4',readonly=True),
		'campo_5':fields.float('5',readonly=True),
		'campo_6':fields.float('6',readonly=True),
		'campo_7':fields.float('7',readonly=True),
		'campo_8':fields.float('8',readonly=True),
		'campo_9':fields.float('9',readonly=True),
		'campo_10':fields.float('10',readonly=True),
		
		#Espacamento
		'espacamento_linhas':fields.float('Espacamento'),
		##Somas
		'soma_base_trubutavel':fields.float('11',readonly=True),
		'soma_impostos_spassivo':fields.float('12',readonly=True),
		'sima_impostos_estado':fields.float('13',readonly=True),
		'campo_14':fields.float('14',readonly=True),
		'campo_15':fields.float('15',readonly=True),
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	
	def actualizar_campos(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			lista=[]
			lista.append('campo_1')
			lista.append('campo_2')
			lista.append('campo_3')
			lista.append('campo_4')
			lista.append('campo_5')
			lista.append('campo_6')
			lista.append('campo_7')
			lista.append('campo_8')
			lista.append('campo_9')
			lista.append('campo_10')
			lista.append('campo_16')
			lista.append('campo_17')
		   
			soma_base_trubutavel=0
			soma_impostos_spassivo=0
			sima_impostos_estado=0
		
			for item_iva in lista:
				
				lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
											('state','=','emitido'),
											('periodo_id','=',documento.periodo_id.id),
											('modelo_A_campos','=',item_iva)	
							])
				logger.info('NUMERO DE ITENS ACHADOSL %s' %str(lancamentos_ids))
				if len(lancamentos_ids)>0:
					total_credito=0
					total_debito=0
					saldo=0
					for lancamento in lancamentos_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						total_credito=total_credito+lancamento.credito_moeda_base
						total_debito=total_debito+lancamento.debito_moeda_base
					if total_debito>total_credito:
						saldo=total_debito-total_credito
					elif total_credito>total_debito:
						saldo=total_credito-total_debito
					
					if item_iva=='campo_1':
						soma_base_trubutavel=soma_base_trubutavel+saldo
						self.write(cr,uid,documento.id,{'campo_1':saldo})
						
					if item_iva=='campo_2':
						sima_impostos_estado=sima_impostos_estado+saldo
						self.write(cr,uid,documento.id,{'campo_2':saldo})
					if item_iva=='campo_3':
						soma_base_trubutavel=soma_base_trubutavel+saldo
						self.write(cr,uid,documento.id,{'campo_3':saldo})
				   
					if item_iva=='campo_4':
						soma_base_trubutavel=soma_base_trubutavel+saldo
						self.write(cr,uid,documento.id,{'campo_4':saldo})
						
					if item_iva=='campo_5':
						soma_impostos_spassivo=soma_impostos_spassivo+saldo
						self.write(cr,uid,documento.id,{'campo_5':saldo})
				  
					if item_iva=='campo_6':
						soma_impostos_spassivo=soma_impostos_spassivo+saldo
						self.write(cr,uid,documento.id,{'campo_6':saldo})
						
					if item_iva=='campo_7':
						soma_impostos_spassivo=soma_impostos_spassivo+saldo
						self.write(cr,uid,documento.id,{'campo_7':saldo})
				   
					if item_iva=='campo_8':
						soma_impostos_spassivo=soma_impostos_spassivo+saldo
						self.write(cr,uid,documento.id,{'campo_8':saldo})
						
					if item_iva=='campo_9':
						soma_impostos_spassivo=soma_impostos_spassivo+saldo
						self.write(cr,uid,documento.id,{'campo_9':saldo})
						
					if item_iva=='campo_10':
						sima_impostos_estado=sima_impostos_estado+saldo
						self.write(cr,uid,documento.id,{'campo_10':saldo})
			logger.info('VALOR A SER GUARDADO %s' %str(sima_impostos_estado))
			
			campo_14=0
			campo_15=0
			if sima_impostos_estado>soma_impostos_spassivo:
				campo_14=sima_impostos_estado-soma_impostos_spassivo
			elif sima_impostos_estado<soma_impostos_spassivo:
				campo_15=soma_impostos_spassivo-sima_impostos_estado
				
			self.write(cr,uid,documento.id,{'soma_impostos_spassivo':soma_impostos_spassivo,
											'sima_impostos_estado':sima_impostos_estado,
											'soma_base_trubutavel':soma_base_trubutavel,
											'campo_14':campo_14,
											'campo_15':campo_15})
			
		return  {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.declaracao.periodica.modelo',
					'report_name': 'dotcom_contabilidade_declaracao_periodica_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
			
	
	
	def on_change_periodo(self, cr,uid,ids,periodo_id,context=None):
		if context is None:
			context={}
		
		lista=[]
		lista.append('campo_1')
		lista.append('campo_2')
		lista.append('campo_3')
		lista.append('campo_4')
		lista.append('campo_5')
		lista.append('campo_6')
		lista.append('campo_7')
		lista.append('campo_8')
		lista.append('campo_9')
		lista.append('campo_10')
		lista.append('campo_16')
		lista.append('campo_17')
	   
		soma_base_trubutavel=0
		soma_impostos_spassivo=0
		sima_impostos_estado=0
		
		lista_items=[]
		val={}
		for item_iva in lista:
			logger.info('NUMERO DE ITENS ACHADOSL %s' %str(item_iva))
			lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
										('state','=','emitido'),
										('periodo_id','=',periodo_id),
										('modelo_A_campos','=',item_iva)	
						])
			logger.info('NUMERO DE ITENS ACHADOSL %s' %str(lancamentos_ids))
			if len(lancamentos_ids)>0:
				total_credito=0
				total_debito=0
				saldo=0
				for lancamento in lancamentos_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					total_credito=total_credito+lancamento.credito_moeda_base
					total_debito=total_debito+lancamento.debito_moeda_base
				if total_debito>total_credito:
					saldo=total_debito-total_credito
				elif total_credito>total_debito:
					saldo=total_credito-total_debito
				
				if item_iva=='campo_1':
						soma_base_trubutavel=soma_base_trubutavel+saldo
						val['campo_1']=saldo
						
				if item_iva=='campo_2':
					sima_impostos_estado=sima_impostos_estado+saldo
					val['campo_2']=saldo
				if item_iva=='campo_3':
					soma_base_trubutavel=soma_base_trubutavel+saldo
					val['campo_3']=saldo
			   
				if item_iva=='campo_4':
					soma_base_trubutavel=soma_base_trubutavel+saldo
					val['campo_4']=saldo
					
				if item_iva=='campo_5':
					soma_impostos_spassivo=soma_impostos_spassivo+saldo
					val['campo_5']=saldo
			  
				if item_iva=='campo_6':
					soma_impostos_spassivo=soma_impostos_spassivo+saldo
					val['campo_6']=saldo
					
				if item_iva=='campo_7':
					soma_impostos_spassivo=soma_impostos_spassivo+saldo
					val['campo_7']=saldo
			   
				if item_iva=='campo_8':
					soma_impostos_spassivo=soma_impostos_spassivo+saldo
					val['campo_8']=saldo
					
				if item_iva=='campo_9':
					soma_impostos_spassivo=soma_impostos_spassivo+saldo
					val['campo_9']=saldo
					
				if item_iva=='campo_10':
					sima_impostos_estado=sima_impostos_estado+saldo
					val['campo_10']=saldo
		#logger.info('VALOR A SER GUARDADO %s' %str(sima_impostos_estado))
		val['soma_impostos_spassivo']=soma_impostos_spassivo
		val['sima_impostos_estado']=sima_impostos_estado
		val['soma_base_trubutavel']=soma_base_trubutavel
		
		if sima_impostos_estado>soma_impostos_spassivo:
			val['campo_14']=sima_impostos_estado-soma_impostos_spassivo
		elif sima_impostos_estado<soma_impostos_spassivo:
			val['campo_15']=soma_impostos_spassivo-sima_impostos_estado
		return {'value':val}
			

dotcom_declaracao_periodica()


class dotcom_declracao_periodica_linha(osv.osv):
	_name='dotcom.contabilidade.declaracao.priodica.linha'
	_columns={
		'base_tributavel':fields.float('Base Tributavel'),
		'imposto_sujeito_passivo':fields.float('Impostos a Favor do Sujeito Passivo'),
		'imposto_estado':fields.float('Impostos a Foavor do Estado'),
		'declaracao_id':fields.many2one('dotcom.contabilidade.declaracao.periodica.modelo'),
	}
	
dotcom_declracao_periodica_linha()
