# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
import pooler
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_copia_movimentos(osv.osv):

	_name ='dotcom.contabilidade.copia.movimentos'
	_columns = {
				'data':fields.date('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=True,required=True, states={'rascunho':[('readonly',False)]}),
				'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'numero_diario':fields.char('Número Diário',readonly=True,size=50),
				'periodo':fields.many2one('configuration.period','Período',readonly=True),
				'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'numero_documento':fields.char('Número Documento',readonly=True,size=50),
				'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)]}),
				'total_debito':fields.float('Debito',readonly=True), 
				'descricao':fields.char('Descrição',size=50,readonly=True, states={'rascunho':[('readonly',False)]}),
				'notas_internas':fields.char('Notas',size=100,readonly=True, states={'rascunho':[('readonly',False)]}),
				'state':fields.selection([
					('rascunho','Rascunho'),
					('emitido','Emitido'),
					('cancelado','Cancelado'),
					('outro_rascunho','Rascunho'),
					],'Estado'),
				
				'alteracao_movimento_id':fields.many2one('dotcom.contabilidade.alteracoes.movimentos','Alteracao'),
				'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento',required=True),

				}
	
	_rec_name='numero_documento'
	
	_order='create_date desc'

dotcom_copia_movimentos()

class dotcom_movimentos(osv.osv):
	
	#def _cambio_label(self, cr, uid, ids, field, arg, context=None):
	#	res = {}
	#	logging.info('ENTROU')
	#	for movimento in self.browse(cr, uid, ids, context=context):
	#		moeda_lancamento = movimento.moeda_secundaria_id  or ''
	#		
	#		friendly_name = moeda_lancamento.name or ''
	#		res[movimento.id] = friendlyon_change="on_change_conta(credito,debito,acerto,conta_id,data_lancamento,periodo_id,ano_fiscal_id,moeda_documento,

	#	return res
	
	
	def cambio_secundario(self,cr,uid,context=None):
		if context is None:
			context={}
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr,uid, context=context)
		cambio=1
		moeda_secund=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
		logger.info('MOEDA SECUNDARIA CAMBIO %s' %str(moeda_secund.rate))
		return moeda_secund.rate
	
	
	def cambio_principal(self, cr,uid,context=None):
		if context is None:
			contexrt={}
		
		moeda_principal_id=self.pool.get('res.company').get_mueda_principal(cr,uid, context=context)
		moeda_principal=self.pool.get('res.currency').browse(cr,uid,moeda_principal_id)
		return moeda_principal.rate
	
	
	def _ano_fiscal_company(self, cr, uid, ids, field, args, context=None):
		if context is None:
			context={}
			
		res = {}
		company_ids=self.pool.get('res.company').search(cr,uid,[])
		company_object=self.pool.get('res.company').browse(cr,uid,company_ids[0])
		for each in self.browse(cr, uid, ids):
			if company_object.ano_fiscal_id.id:
						logger.info('ANO FISCAL ACHADO NA COPANHIA %s' %str(company_object.ano_fiscal_id.code))		   
						res[each.id] = company_object.ano_fiscal_id.id
		logger.info('ANO FISCAL ACHADO NA COPANHIA %s' %str(res))	
		return res

	def _check_balanceamento_MS_company(self, cr, uid, ids, field, args, context=None):
		if context is None:
			context={}
			
		res = {}
		company_ids=self.pool.get('res.company').search(cr,uid,[])
		company_object=self.pool.get('res.company').browse(cr,uid,company_ids[0])
		for each in self.browse(cr, uid, ids):
			if company_object.check_balanceamento_MS:		  
						res[each.id] = company_object.check_balanceamento_MS
   
		return res
	def _get_default_balanceamento(self,cr, uid, context=None):
		pool2= pooler.get_pool(cr.dbname)
	
		company_pool=pool2.get('res.company')	
		ano_ids=company_pool.search(cr,uid,[])
		retorno=False
		object=ano_ids[0]
		object=company_pool.browse(cr,uid,object)
	
		#lancamentos_diarios=
		if object.check_balanceamento_MS:
		   retorno=object.check_balanceamento_MS
		return retorno

   


	_name ='dotcom.contabilidade.movimentos'
	_columns = {
				'data':fields.date('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'data_final_ano':fields.date('Data Final'),
				'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=True,required=True, states={'rascunho':[('readonly',False)]}),
				'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'numero_diario':fields.char('Número Diário',readonly=True,size=50),
				'periodo':fields.many2one('configuration.period','Período',readonly=False, ),
				'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'numero_documento':fields.char('Número Documento',readonly=True,size=50),
				'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
				'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)]}),
				'actualizacao_debito_credito_id':fields.many2one('dotcom.contabilidade.credito.debito','Movimentos',readonly=True,required=False,),
				'moeda_secundaria_id': fields.many2one('res.currency','Moeda Secundária',),
				'cambio_secundario':fields.float('Câmbio MP/MS', help='Cámbio da moeda Principal(MP) para a moeda secundária(MS)',readonly=True, states={'rascunho':[('readonly',False)]}),
				
				'descricao':fields.char('Descrição',size=100,readonly=True, states={'rascunho':[('readonly',False)]}),
				'notas_internas':fields.char('Notas',size=100,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
				'centro_custos_ids':fields.one2many('dotcom.contabilidade.centros.custos','movimento_id','Centro de Custos',readonly=True, states={'rascunho':[('readonly',False)]}),
				'lancamentos_diarios_ids':fields.one2many('dotcom.contabilidade.lancamentos.diarios','movimento_id','Lançamentos',ondelete="cascade",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
				'movimentos_reflexao_custo_ids':fields.one2many('dotcom.contabilidade.movimento.custo.fluxo','movimento_reflexao_id','Movimentos de Reflexao',readonly=True, states={'rascunho':[('readonly',False)]}),				
				'state':fields.selection([
					('rascunho','Rascunho'),
					('emitido','Emitido'),
					('cancelado','Cancelado'),
					('outro_rascunho','Rascunho'),
					],'Estado'),
				
				'wizard_id':fields.many2one('dotcom.contabilidade.movimento.visualizar'),
				'wizard_id2':fields.many2one('dotcom.contabilidade.movimento.visualizar'),
				
				'iva_id':fields.many2one('dotcom.contabilidade.iva','Apuramento Iva'),
				
				'total_debito':fields.float('Debito',readonly=True),
				'total_credito':fields.float('Credito',readonly=True),
				'total_debito_base':fields.float('Debito',readonly=True),
				'total_credito_base':fields.float('Credito',readonly=True),
				'total_debito_secundario':fields.float('Debito',readonly=True),
				'total_credito_secundario':fields.float('Credito',readonly=True),
						 
				
				'lancamento_centro_custos_id':fields.one2many('dotcom.contabilidade.lancamento.centro.custo.linha','movimento_id','Centro Custos'),
				
				'adicao_centro_custo_id':fields.many2one('dotcom.contabilidade.adicao.linhas.centro','Lancamentos Custos',ondelete="cascade"),
				'lancamento_abertura':fields.boolean('Lançamento Abertura',readonly=True,states={'rascunho':[('readonly',False)],}),
				'lancamento_abertura_copia':fields.boolean('Lançamento Fecho',readonly=True,states={'rascunho':[('readonly',False)]}),
				'lancamento_fecho':fields.boolean('Lançamento Apuramento',readonly=True,states={'rascunho':[('readonly',False)]}),
				'lancamento_fecho_copia':fields.boolean('Lançamento Fecho'),
				'lancamento_abertura_fecho':fields.boolean('Lancamento Abertura e Fecho'),
				
				'closing':fields.boolean('closing',),
				'is_auto':fields.boolean('closing',),

			
				# 'balanceamento_parent':fields.function(_check_balanceamento_MS_company, type='boolean', string='Balanceamento check Company', method=True, store=True),

				'balanceamento_local':fields.boolean('Obrigar Balanceamento Moeda Sec.',help="Quando activo, a aplicacao faz o controle de balanceamento na moeda secundaria",states={'rascunho':[('readonly',False)]}),
				
				'ano_fiscal_company': fields.function(_ano_fiscal_company, type='many2one', relation='configuration.fiscalyear', string='Ano Company', method=True, store=True),
				#'ano_actual': fields.function(_ano_actual, type='boolean',  string='Ano Actual', method=True),

				'conta_3_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta 3'),
				}
	
	_rec_name='numero_documento'
	
	_order='create_date desc'
	
	_sql_constraints = [
		('name_uniq', 'unique (documento_id, numero_documento)', 'O numero deve ser Unico !'),
		('name_uniq', 'unique (diario_id, numero_diario)', 'O numero deve ser Unico !'),
	]
	
	
	_defaults={
		'data':validator.get_data_movimento,
		'state':'rascunho',
		'moeda_secundaria_id': lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=c),
		'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
		'cambio':lambda self,cr,uid,c: self.cambio_principal(cr, uid, context=c),
		#'periodo':get_period_id()
		'diario_id':validator.diario_movimento,
		'documento_id':validator.documento_movimento,
		'ano_fiscal_id':validator._get_default_year,
		'balanceamento_local':_get_default_balanceamento,
		'moeda_lancamento_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=c),
	}
	
	
	def copy(self, cr, uid, id, default=None, context=None):
		if default is None:
			default = {}
			
		if context is None:
			context={}
		
		value={}
		value['numero_documento']=False
		value['numero_diario']=False
		value['state']='rascunho'
		default.update(value)
		return super(dotcom_movimentos, self).copy(cr, uid, id, default, context) 
	
	
	def abrir_movimento(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		movimento_id=None
		for documento in self.browse(cr,uid,ids):
			movimento_id=documento.id
		
		logger.info('PROCESSO INICIADO %s' %str(movimento_id))
		return {
			'type': 'ir.actions.act_window',
			'name': 'Conversão Moeda',
			'view_mode': 'form',
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.movimentos',
			'res_id':movimento_id,
			'target': 'new',
			'context': context,
			'nodestroy': True,
		}


	def abrir_centros_custos(self,cr,uid,ids,context={}):
		if context is None:
			context={}

		for documento in self.browse(cr,uid,ids):
			cont_lanc_reflectidos=0
			cont_lanc_com_reflexao=0
			cont_lanc_sem_reflexao=0
			valor=0
			natureza=''
			conta_id=''
			for lanc in documento.lancamentos_diarios_ids:
				logger.info('if lanc.conta_id.tem_ref_custo: ========== %s' %str(lanc.conta_id.tem_ref_custos))
				if lanc.conta_id.tem_ref_custos==True:
					cont_lanc_com_reflexao=cont_lanc_com_reflexao+1
					logger.info('cont_lanc_com_reflexao ========== %s' %str(cont_lanc_com_reflexao))
				else:
					cont_lanc_sem_reflexao=cont_lanc_sem_reflexao+1
					logger.info('cont_lanc_sem_reflexao ========== %s' %str(cont_lanc_sem_reflexao))

				
				if lanc.conta_id.tem_ref_custos==True:
					logger.info('if lanc.adicao_centro_custo_id: ========== %s' %str(lanc.adicao_centro_custo_id))
					if bool(lanc.adicao_centro_custo_id) != False:
						cont_lanc_reflectidos=cont_lanc_reflectidos+1
						logger.info('cont_lanc_reflectidos ======== %s' %str(cont_lanc_reflectidos))


			if cont_lanc_sem_reflexao == len(documento.lancamentos_diarios_ids):
				raise osv.except_osv(_('Acção Inválida !'), _('Nenhuma das Contas lançadas tem Centros de custos activo!!'))
			if cont_lanc_reflectidos !=0 and cont_lanc_com_reflexao != 0:
				if cont_lanc_reflectidos == cont_lanc_com_reflexao:
					raise osv.except_osv(_('Acção Inválida !'), _('Todas as Contas com Centros de custos ja foram lançadas\nPara editar use o botão PLUS(+) das linhas!!'))


		model_account_selection= self.pool.get('dotcom.contabilidade.centros.custos.account.selection')
		ids_to_remove=model_account_selection.search(cr,uid,[])
		model_account_selection.unlink(cr,uid,ids_to_remove)

		movimento_id=None
		ano_fiscal_id=None
		for documento in self.browse(cr,uid,ids):
			movimento_id=documento.id
			ano_fiscal_id=documento.ano_fiscal_id.id
			

			for lanc in documento.lancamentos_diarios_ids:
				if lanc.conta_id.tem_ref_custos==True and (bool(lanc.adicao_centro_custo_id)==False or lanc.adicao_centro_custo_id == None ):
					conta_id = lanc.conta_id.id
					if lanc.credito>lanc.debito:
						valor = lanc.credito
						natureza='credito'
					elif lanc.debito>lanc.credito:
						valor =lanc.debito
						natureza='debito'
					dict_data={
						'conta_id':conta_id,
						'valor':valor,
						'natureza':natureza,
						'lancamento_id':lanc.id,
					}
					model_account_selection.create(cr,uid,dict_data)
		vals={
			'movimento_id':movimento_id,
			}

		identificador=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').create(cr,uid,vals)
		self.calcular_light(cr,uid,ids)


		return {
			'type': 'ir.actions.act_window',
			'name': 'Centro de Custos',
			'view_mode': 'form',
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.adicao.linhas.centro',
			'res_id':identificador,
			'target': 'new',
			'context': context,
			'nodestroy': True,
		}
		
	
	# def on_change_lines(self,cr,uid,ids,linhas,context=None):
	#	 if context is None:
	#		 context={}
	#	 logger.info('ENTROU NO PROCESSO DE TROCA DE LINHAS %s' %str(linhas))

	#	 return {}

	# def on_change_lancamentos_diarios_ids(self,cr,uid,ids,lancamentos_diarios_ids,context=None):
	#	 if context is None:
	#		 context={}
	#	 logger.info('ENTROU NO PROCESSO DE TROCA DE LINHAS %s' %str(lancamentos_diarios_ids))
		
		
	#	 return {}
	 
 
	def extornar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			
			movimento_val={
					'data':documento.data,
					'ano_fiscal_id':documento.ano_fiscal_id.id,
					'diario_id':documento.diario_id.id,
					'documento_id':documento.documento_id.id,
					'periodo':documento.periodo.id,
					'moeda_lancamento_id':documento.moeda_lancamento_id.id,
					'moeda_secundaria_id':documento.moeda_secundaria_id.id,
					'cambio':documento.cambio,
					'cambio_secundario':documento.cambio_secundario,
					'lancamento_abertura':documento.lancamento_abertura,
					'lancamento_fecho':documento.lancamento_fecho,
					#'notas_internas':str(documento.notas_internas)+" (Extorno)",
					'state':'rascunho',
				}
			
			if documento.notas_internas==False:
				 movimento_val['notas_internas']="Extorno"
			else:
				 movimento_val['notas_internas']=str(documento.notas_internas)+" (Estorno)"
			movimento_id=self.create(cr,uid,movimento_val)
			
			for lancamento_diario in documento.lancamentos_diarios_ids:
				 lancamento_novo={
									'conta_id':lancamento_diario.conta_id.id,
									'data_lancamento':lancamento_diario.data_lancamento,
									'ano_fiscal_id':documento.ano_fiscal_id.id,
									'periodo_id':documento.periodo.id,
									'debito':lancamento_diario.credito,
									'credito':lancamento_diario.debito,
									'movimento_id':movimento_id,
									'reflexao_iva':lancamento_diario.reflexao_iva,
									'reflexao_centro':lancamento_diario.reflexao_centro,
									'fluxo_caixa':lancamento_diario.fluxo_caixa,
									'acerto':lancamento_diario.acerto,
									'moeda_documento':lancamento_diario.moeda_documento.id,
									'moeda_secundaria_id':lancamento_diario.moeda_secundaria_id.id,
									'moeda_lancamento_id':lancamento_diario.moeda_lancamento_id.id,
									'moeda_primaria_id':lancamento_diario.moeda_primaria_id.id,
									'cambio':lancamento_diario.cambio,
									'cambio_secundario':lancamento_diario.cambio_secundario,
									'descricao':lancamento_diario.descricao,
									'tipo_lancamento':lancamento_diario.tipo_lancamento,
									'state':'rascunho',
									#'natureza_fluxo_caixa':lancamento_diario.natureza_fluxo_caixa,
									'modelo_A_campos':lancamento_diario.modelo_A_campos,
									
								}
				 self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento_novo)
				 
			return {
						'type': 'ir.actions.act_window',
						'name': 'Estorno Movimentos',
						'view_mode': 'form',
						'view_type': 'form',
						'res_model': 'dotcom.contabilidade.movimentos',
						'res_id':movimento_id,
						'target': 'new',
						'context': context,
						'nodestroy': True,
					}
				
	 
	def pegar_ano_fiscal_company(self, cr, uid, ids, context=None):
		if context is None:
			context={}
			
		res = {}
		company_ids=self.pool.get('res.company').search(cr,uid,[])
		company_object=self.pool.get('res.company').browse(cr,uid,company_ids[0])
		#for each in self.browse(cr, uid, ids):
		if company_object.ano_fiscal_id.id:
			  
			return company_object.ano_fiscal_id.id
		else:
			return None
	 
		
	def on_change_lancamentos(self,cr,uid,ids,lancamentos,context=None):
		if context is None:
			context={}
		
		logger.info('ENTROU NO ONCHANGE')
		return {}
	
	
	def on_change_periodo(self,cr,uid,ids,periodo_id,context=None):
		if context is None:
			context={}
		
		logger.info('ENTROU NO PROCESSO')
		
		if bool(periodo_id)!=False:
			periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodo_id)
			if periodo_object.trancar_periodo==True:
				raise osv.except_osv(_('Acção Inválida !'), _('Período seleccionado já trancado..!!'))
		self.write(cr,uid,ids,{'periodo':periodo_object.id})
		return {'periodo':periodo_object.id}
	
	
	def on_change_abertura(self,cr,uid,ids,abertura,fecho,ano_fiscal_id,context=None):
		if context is None:
			context={}
		val={}
		if abertura==True:
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('special','=',True)
				])
			periodo_objet=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
			val={
				 'lancamento_fecho':False,
				 'lancamento_fecho_copia':False,
				 'closing':False,
				 'lancamento_abertura_copia':True,
				 'data':periodo_objet.date_start,
				 'periodo':periodo_objet.id}
		else:
			if fecho==False:
				logger.info('ABERTURA IGUAL A FALSE')
				data_ultimo_movimento=validator.get_data_movimento(self,cr,uid)
				periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('special','=',False)
				])
				
				val={
					'data':data_ultimo_movimento,
					'periodo':periodo_ids[0]
				}
			logger.info('VALOR A SER RETORNADO %s' %str(val))
		return {'value':val}
	
	
	def on_change_fecho(self,cr,uid,ids,fecho,abertura,ano_fiscal_id,data,context=None):
		if context is None:
			context={}
		val={}
		if fecho==True:
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('closing','=',True)
				])
			periodo_objet=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
			val={'lancamento_abertura':False,
				 'lancamento_fecho_copia':True,
				 'lancamento_abertura_copia':False,
				 'closing':True,
				 'lancamento_abertura_fecho':True,
				 'data':periodo_objet.date_start,
				 'periodo':periodo_objet.id,
				}
		else:
			if abertura==False:
				periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('closing','=',False),
																('date_start','<=',data),
																('date_stop','>=',data),
																('special','=',False),
				])
				periodo_objet=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
				val={
					'lancamento_abertura_fecho':False,
					'lancamento_fecho_copia':False,
					'periodo':periodo_objet.id,
				}
		return {'value':val}
	
	
	def validar_on_change(self,cr,uid,ids,data,closing,periodo,lancamento_abertura,is_auto,lancamento_fecho,context=None):
		if context is None:
			context={}

		data=str(data)	
		logger.info('LANCAMENTO DE ABER TURA%s' %str(lancamento_abertura))
		logger.info('ESTADO DO CLOSING%s' %str(closing))
		logger.info('periodo0 ======== %s' % periodo)
		logger.info('periodo type ======== %s' % type(periodo))
		if type(periodo) == list or  type(periodo) == int:
			periodo= self.pool.get('configuration.period').browse(cr,uid,periodo)
		logger.info('periodo1 ======== %s' % periodo)
		if is_auto==True:
			periodo=periodo
			logger.info('periodo2 ======== %s' % periodo)
		elif lancamento_fecho == True:
			
			if periodo.closing==True:
				periodo=periodo
				logger.info('periodo3 ======== %s' % periodo)
		else:
			ano_fiscal_id=self.pegar_ano_fiscal(cr,uid,ids,data)
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('closing','=',closing),
																('date_start','<=',data),
																('date_stop','>=',data),
																('special','=',lancamento_abertura),
				])
		
			logger.info('PERIODOS ACHADOS %s' %str(periodo_ids))
			if len(periodo_ids)>0:
				periodo=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
				logger.info('periodo4 ======== %s' % periodo)
		data=datetime.strptime(data, '%Y-%m-%d')
		logger.info('data.year ======== %s' %data.year)

		ano_fiscal_id=self.pool.get('configuration.fiscalyear').search(cr,uid,[('code','=',data.year)])
		ano_fiscal_id=ano_fiscal_id and ano_fiscal_id[0]
		ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data_final=ano_fiscal_object.date_stop
		logger.info('periodoF ======== %s' % periodo)
		val={'periodo':periodo.id,'ano_fiscal_id':ano_fiscal_id,'data_final_ano':data_final}
		return val
			
			
	def on_change_data(self,cr,uid,ids,data,closing,periodo,lancamento_abertura,is_auto,lancamento_fecho,context=None):
		if context is None:
			context={}
		
		val=self.validar_on_change(cr,uid,ids,data,closing,periodo,lancamento_abertura,is_auto,lancamento_fecho,context)
		return {'value':val}
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		val={}
		for elemento in self.browse(cr,uid,ids):
			for lancamento in elemento.lancamentos_diarios_ids:
				logger.info('Lancamentos diarios NO BROWSER ##### %s' %str(lancamento))
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').unlink(cr,uid,lancamento.id)
		movimentos_ano_fiscal=self.search(cr,uid,[
					('ano_fiscal_id','=',ano_fiscal_id)			
			])
		logger.info('IDENTIFICADOR DO ANO FISCAL %s' %str(ano_fiscal_id))
		if len(movimentos_ano_fiscal)>0:
			logger.info('IF ENtra')
			ultimo_movimento_id=movimentos_ano_fiscal[0]
			ultimo_movimento=self.browse(cr,uid,ultimo_movimento_id)
			val={
					'data':ultimo_movimento.data,
					'diario_id':ultimo_movimento.diario_id.id,
					'documento_id':ultimo_movimento.documento_id.id,
					'lancamentos_diarios_ids':None,
				}
		else:
			logger.info('Else ENtra')
			logger.info('IDENTIFICADOR DO ANO FISCAL %s' %str(ano_fiscal_id))
			ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
			val={
					'data':ano_fiscal.date_start,
					'diario_id':False,
					'documento_id':False,
					'lancamentos_diarios_ids':None,
				}
			
		return{'value':val}
	
	
	def imprimir_movimento(self,cr,uid,ids,context=None):
		 if context is None:
			context={}
			
			
		 action={}
		 contador=0
		 for documento in self.browse(cr,uid,ids):
			for lancamento in documento.lancamentos_diarios_ids:
				if lancamento.adicao_centro_custo_id.id!=False or lancamento.lancamentos_custo_id.id!=False:
					contador=contador+1

		 if contador>0:
			action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.movimentos',
					'report_name': 'dotcom_contabilidade_movimento_centro_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
			logger.info('COM REFLEXAO A CENTRO')
		 else:
			action = {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.movimentos',
					'report_name': 'dotcom_contabilidade_movimento_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
				}
			logger.info('SEM REFLEXAO A CENTRO')
			
		 return action
	
   
	def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
		if context is None:
			context = {}
		result = super(dotcom_movimentos, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
		a = []
		
		#logger.info('\nFIELDS VIEW GET \n%s' %str(result))
		moeda_lancamento_id=self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=context)
		moeda_lancamento=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento_id)

		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context)
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
		
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		dicionario= moeda_primaria_id[0]
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,dicionario)
		
		simbolo_moeda=moeda_secundaria.name
		
		
		
		nome_moeda_lancamento=str(moeda_lancamento and moeda_lancamento.name)
		nome_moeda_primaria = str(moeda_primaria and moeda_primaria.name)
		nome_moeda_secundaria=str(moeda_secundaria and moeda_secundaria.name)
		
		logger.info('SIMBOLO MOEDA LANCA %s' %str(nome_moeda_lancamento))

		fields = result['fields']
		if fields.has_key('cambio_secundario'):
			documento = fields['cambio_secundario']
			documento['string'] = "Cambio "+moeda_primaria.name+'/'+simbolo_moeda
			fields['cambio_secundario'] = documento
		if fields.has_key('cambio'):
			logger.info('CAMBIO ENCONTRADO')
			documento = fields['cambio']
			documento['string'] = 'Cambio '+moeda_primaria.name
			fields['cambio'] = documento	
			
		result['fields'] = fields
		
		#logger.info('\nCHAVES TIPO %s E CHAVES %s' % (type(result['arch']),str(result['arch'])))
		#logger.info('\nMoeda Principal %s , tipo %s' %(type(nome_moeda_primaria), nome_moeda_primaria))
		view = result['arch']
		#view = view
		if nome_moeda_primaria:
			view = view.replace('MoedaB','Moeda Principal ('+nome_moeda_primaria+')')
		if nome_moeda_secundaria:
			view=view.replace('MoedaC','Moeda Secundaria ('+nome_moeda_secundaria+')')
		if nome_moeda_lancamento:
			view=view.replace('MoedaA','Moeda Lançamento ('+nome_moeda_lancamento+')')
		
		view=view.replace('VM',nome_moeda_primaria+'/'+nome_moeda_secundaria)
		view=view.replace('TB','Valor')	
			
		
		result['arch'] = view

		#result['fields'] = fields
		#logger.info('RESULT VIEW %s' % result)
		return result
	
	
	def get_total_credito(self,cr,uid,movimento_id,context=None):
		if context is None:
			context={}
		documento=self.browse(cr,uid,movimento_id)
		total_credito=0
		for lancamento in documento.lancamentos_diarios_ids:
			total_credito=total_credito+lancamento.credito
		return total_credito
 
   
	def get_total_debito(self,cr,uid,movimento_id,context=None):
		if context is None:
			context={}
		documento=self.browse(cr,uid,movimento_id)
		total_credito=0
		for lancamento in documento.lancamentos_diarios_ids:
			total_credito=total_credito+lancamento.debito
		return total_credito
 
   
	def voltar_rascunho(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			
			for lancamento in documento.lancamentos_diarios_ids:
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'state':'rascunho'})
				
				lancamento_diario_ids=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,[('lancamento_diario_id','=',lancamento.id)])
				if len(lancamento_diario_ids)>0:
					self.pool.get('dotcom.contabilidade.extratos.diario.linhas').unlink(cr,uid,lancamento_diario_ids)
				
				
				saldo_conta_periodo_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[
																												('conta_id','=',lancamento.conta_id.id),
																												('periodo_id','=',documento.periodo.id),
																												])
				
				
				if(len(saldo_conta_periodo_ids)>0):
					saldo_conta_periodo_object=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').browse(cr,uid,saldo_conta_periodo_ids[0])
					total_credito_base=saldo_conta_periodo_object.total_credito_primaria-lancamento.credito_primario_arredondado
					total_debito_base=saldo_conta_periodo_object.total_debito_primaria-lancamento.debito_primario_arredondado
	   
					self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,saldo_conta_periodo_object.id,{
																															'total_debito_primaria':saldo_conta_periodo_object.total_debito_primaria-lancamento.debito_moeda_base,
																															'total_credito_primaria':saldo_conta_periodo_object.total_credito_primaria-lancamento.credito_moeda_base,
																															'total_debito_secundaria':saldo_conta_periodo_object.total_debito_primaria-lancamento.debito_moeda_secundaria,
																															'total_credito_secundaria':saldo_conta_periodo_object.total_debito_primaria-lancamento.credito_moeda_secundaria
																															})
				
				
				if  bool(lancamento.movimento_fluxo_caixa_id.id)!=False:
					 if lancamento.movimento_fluxo_caixa_id.state=='rascunho':
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').unlink(cr,uid,lancamento.movimento_fluxo_caixa_id.id)
					 else:
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').write(cr,uid,lancamento.movimento_fluxo_caixa_id.id,{'state':'outro_rascunho'})
				
				
				if bool(lancamento.lancamentos_custo_id.id)==True:
					#logger('LANCAMENTO COM CENTRO DE CUSTOS %s' %str(lancamento))
					for linha_centro in lancamento.lancamentos_custo_id.lancamentos_custo_linhas:
						self.pool.get('dotcom.contabilidade.lancamento.centro.custo.linha').write(cr,uid,linha_centro.id,{'state':'rascunho'})
						
						#for lancamento_linha in linha_centro.adicao_lancamento_id:
						self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,linha_centro.adicao_lancamento_id.id,{'state':'rascunho'})
			zero=0.0
			vals_ras={
						'state':'outro_rascunho',
						'total_debito':zero,
						'total_credito':zero,
						'total_debito_base':zero,
						'total_credito_base':zero,
						'total_debito_secundario':zero,
						'total_credito_secundario':zero,	 
				  }
			self.write(cr,uid,documento.id,vals_ras)
		return True
	

	def cancelar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			for lancamento in documento.lancamentos_diarios_ids:
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'state':'cancelado'})
				
				if  bool(lancamento.movimento_fluxo_caixa_id.id)!=False:
					 if lancamento.movimento_fluxo_caixa_id.state=='rascunho':
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').unlink(cr,uid,lancamento.movimento_fluxo_caixa_id.id)
					 else:
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').write(cr,uid,lancamento.movimento_fluxo_caixa_id.id,{'state':'cancelado'})
						
				# if lancamento.fluxo_caixa==True and bool(lancamento.movimento_fluxo_caixa_id.id)!=False:
				# 	 self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').write(cr,uid,lancamento.movimento_fluxo_caixa_id.id,{'state':'cancelado'})
			self.write(cr,uid,documento.id,{'state':'cancelado'})
		return {}
	
	
	def apagar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		lancamentos=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[])
		for ids in lancamentos:
			logger.info('APAGAR %s'%str(ids))
			self.pool.get('dotcom.contabilidade.lancamentos.diarios').unlink(cr,uid,ids)
		return {}
   
	
	def actualizar(self,cr,uid,context=None):
		if context is None:
			context={}
		logger.info('FUNCIONOU')
		return {}
		
		   
	def on_change_cambio(self,cr,uid,ids,ano_fiscal_id,diario_id,data,documento_id,periodo,moeda_secundaria_id,cambio,cambio_secundario,moeda_lancamento_id,context=None):
		if context is None:
			context={}
			
		logger.info('IDENTIFICADOR DO DOCUMENTO NO MOMENTO %s' %str(ids))
		identificador=None
		if len(ids)>0:
			identificador=ids[0]
		if len(ids)<=0:
			val={
				'ano_fiscal_id':ano_fiscal_id,
				'diario_id':diario_id,
				'data':data,
				'documento_id':documento_id,
				'periodo':periodo,
				'moeda_secundaria_id':moeda_secundaria_id,
				'cambio':cambio,
				'moeda_lancamento_id':moeda_lancamento_id
			}
			logger.info('MOVIMENTO A SER CRIADO %s' %str(val))
			identificador=self.create(cr,uid,val)
		
		return {'values':{'identificador':identificador}}
		  
	
	def on_change_currency(self, cr, uid, ids, currency_id,moeda_secundaria_id, context=None):
		if context is None:
			context = {}
		res = {}
		if currency_id:
			moeda = self.pool.get('res.currency').browse(cr, uid, currency_id)
			moeda_secundaria=self.pool.get('res.currency').browse(cr, uid, moeda_secundaria_id)
			cambio = moeda.rate or 1
			res['cambio'] = cambio
			res['cambio_secundario']=moeda_secundaria.rate or 1
			for documento in self.browse(cr,uid,ids):
				#logger.info('MAIS DE 1 LANCAMENTO')
				if len(documento.lancamentos_diarios_ids)>0:
					for lancamento in documento.lancamentos_diarios_ids:
						self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{
										'moeda_documento':currency_id,
										'moeda_lancamento_id':currency_id,
										'cambio':cambio,
										'cambio_secundario':moeda_secundaria.rate
							
							})
					
		return {'value':res}
	   
	
	def lancar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		retorno={}
		for documento in self.browse(cr,uid,ids):
			ultimo_lancamento=None
			if len(documento.lancamentos_diarios_ids)==1:
				ultimo_lancamento=documento.lancamentos_diarios_ids[len(documento.lancamentos_diarios_ids)-1]
			else:
				outro=documento.lancamentos_diarios_ids[len(documento.lancamentos_diarios_ids)-1]
				if outro.reflexao_centro==True:
					ultimo_lancamento=outro
				else:
					ultimo_lancamento=documento.lancamentos_diarios_ids[len(documento.lancamentos_diarios_ids)-2]
			if ultimo_lancamento.reflexao_centro==True:
				
				natureza=None
				valor=0
				if bool(ultimo_lancamento.credito)==True and bool(ultimo_lancamento.debito)==False:
					natureza='credito'
					valor=ultimo_lancamento.credito
				elif bool(ultimo_lancamento.debito)==True and bool(ultimo_lancamento.credito)==False:
					natureza='debito'
					valor=ultimo_lancamento.debito
				#logger.info('NATUREZA %s'%str(natureza))
				#logger.info('CONTA ORIGEM%s'%str(ultimo_lancamento.conta_id))
				
				lancamento_id=self.pool.get('dotcom.lancamento.movimento.custo').create(cr,uid,{'valor_origem':valor})			
				
				linha_lancamento={
								'conta_id':ultimo_lancamento.conta_id.id,
								'valor':valor,
								'natureza':natureza,
								'lancamento_id':lancamento_id
							}
				#logger.info('LANCAMENTO %s'%str(linha_lancamento))
				#logger.info('NATUREZA %s'%str(lancamento_id))
				#logger.info('NATUREZA %s'%str(ids))
				linha_id=self.pool.get('dotcom.contabilidade.movimento.custo.fluxo').create(cr,uid,linha_lancamento)
				
				
				retorno={
						'type': 'ir.actions.act_window',
						'name': 'Lancamentos',
						'view_mode': 'form',
						'view_type': 'form',
						'res_model': 'dotcom.lancamento.movimento.custo',
						'res_id':lancamento_id,
						'target': 'self',
						'context': context,
						'nodestroy': True,
					}
		#logger.info('RETORNO %s'%str(retorno))
		return retorno
			
	
	def write(self,cr,uid,ids,values,context=None):
		if context is None:
			context={}
		
		reads =self.read(cr, uid, ids, ['lancamento_abertura','ano_fiscal_id','lancamento_fecho','id'])
		if reads:
			if type(reads) == list:
				read_ids=reads[0]
			elif type(reads) == dict:
				read_ids=reads
			read_lancamento_abertura=read_ids['lancamento_abertura']
			read_lancamento_fecho=read_ids['lancamento_fecho']
			ano_fiscal_id=read_ids['ano_fiscal_id']
			id=read_ids['id']
			
			if bool(values.has_key('data'))==True:
				data=values['data']
			if bool(values.has_key('periodo'))==True:
				periodo=values['periodo']
			if bool(values.has_key('is_auto'))==True:
				is_auto=values['is_auto']

				
				valores_retornados=self.on_change_data(cr,uid,ids,data,read_lancamento_fecho,periodo,read_lancamento_abertura,is_auto,read_lancamento_fecho)
				valores_retornados=valores_retornados['value']
				#logger.info('*******VALORES ACHADOS NA ESCRITA DO MOVIMENTO %s' %str(valores_retornados))
				periodo_id=valores_retornados['periodo']
				
				values['periodo']=periodo_id
			
			else:
				if bool(values.has_key('lancamento_abertura'))==True:
					if  values ['lancamento_abertura']==True:	
						periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																							  ('fiscalyear_id','=',ano_fiscal_id),
																							  ('closing','=',False),
																							  ('special','=',True),
																							  #('date_start','<=',values['data']),
																							  #('date_stop','>=',values['data'])
																							  ])
						values['periodo']=periodo_ids[0]
							  
					elif values ['lancamento_abertura']==False and bool(values.has_key('periodo'))==False:
						periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',ano_fiscal_id),
																					('closing','=',False),
																					('special','=',False),
																					#('date_start','<=',values['data']),
																					#('date_stop','>=',values['data'])
																					])
						values['periodo']=periodo_ids[0]
			
			
						
			super(dotcom_movimentos, self).write(cr, uid,id, values,context=context)
			return {}
	
		
	def create(self,cr,uid,values,context=None):
		if context is None:
			context={}
		#data=None16
		chaves=values.keys()
		
		if chaves.__contains__('lancamentos_diarios_ids'):
			lista_lancamentos_diarios=values['lancamentos_diarios_ids']
			
			if len(lista_lancamentos_diarios)<=0:
				raise osv.except_osv(_('Acção Invalida !'), _('O Movimento Sem Lancamentos efectuados!!'))
			#logger.info('VALOR DO MOVIMENTO A SER CRIADO %s' %str(values['lancamentos_diarios_ids']))
		ano_fiscal_id=values['ano_fiscal_id']
		if values['lancamento_abertura']==True :
			#logger.info('PERIODOS ACHADOS %s' %str(values['periodo']))
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('special','=',True)
				])
			periodo_objet=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
			values['periodo']=periodo_objet.id
			values['data']=periodo_objet.date_start
			#logger.info('CONTEM LANCAMENTO DE ABERTURA')
			
		elif values['lancamento_fecho']==True:
			#   logger.info('CONTEM LANCAMENTO DE FECHO')
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('closing','=',True)
				])
			periodo_objet=self.pool.get('configuration.period').browse(cr,uid,periodo_ids[0])
			#values['periodo']=periodo_objet.id
			values['data']=periodo_objet.date_start
			
		else:
			#logger.info('LANCAMENTO DE FECHO ULTIMA OPCAO')
			periodo_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',ano_fiscal_id),
																('closing','=',False),
																('special','=',False),
																('date_start','<=',values['data']),
																('date_stop','>=',values['data'])
																])
			logger.info('')
			values['periodo']=periodo_ids[0]
		
		periodo_id=values['periodo']
		periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodo_id)
		if periodo_object.trancar_periodo==True:
			raise osv.except_osv(_('Acção Inválida !'), _('Período seleccionado já trancado..!!'))
			
		return super(dotcom_movimentos, self).create(cr, uid, values, context=context)
			
	
	def actualizar_documento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		return True
	def actualizar_cambios(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		cambio=5.0
		cambio_secundario= 63.0

		for documento in self.browse(cr,uid,ids):
			cambio=documento.cambio
			cambio_secundario= documento.cambio_secundario
			logger.info('cambio %s' %str(cambio))
			logger.info('cambio_secundario %s' %str(cambio_secundario))
			for lancamento in documento.lancamentos_diarios_ids:
				 self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'cambio':cambio,'cambio_secundario':cambio_secundario})

		res={  
			'cambio':cambio,
			'cambio_secundario':cambio_secundario,
			'total_debito':0.0,
			'total_credito':0.0,
			'total_debito_base':0.0,
			'total_credito_base':0.0,
			'total_debito_secundario':0.0,
			'total_credito_secundario':0.0,

		}
		
		self.write(cr,uid,ids,res)				
		return res
	
	def calcular_totais_lancamentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			
			self.actualizar_documento(cr,uid,ids)			
			
			total_credito_secundario=0
			total_debito_secundario=0
			total_credito_base=0
			total_debito_base=0
			total_credito=0
			total_debito=0
			for linha in documento.lancamentos_diarios_ids:
				ano_fiscal_conta_lancamento=linha.conta_id.ano_fiscal_id
				if ano_fiscal_conta_lancamento !=documento.ano_fiscal_id:
					raise osv.except_osv(_('Invalid action !'), _('A conta '+linha.conta_id.friendly_name+' não corresponde ao Ano Fiscal do Movimento!'))

				total_credito_secundario=total_credito_secundario+round(linha.credito_moeda_secundaria,2)
				total_debito_secundario=total_debito_secundario+round(linha.debito_moeda_secundaria,2)
				total_credito_base=total_credito_base+linha.credito_moeda_base
				total_debito_base=total_debito_base+linha.debito_moeda_base
				
				#logger.info('TIPO DE CONVERSAO MOEDA ACHADA %s' %str(linha.acerto))
				if linha.acerto=='all':
					total_credito=total_credito+linha.credito
					total_debito=total_debito+linha.debito
			#logger.info('DEBITO %s' %str(total_debito))
			#logger.info('CREDITO %s' %str(total_credito))
			#logger.info('DEBITO B %s' %str(total_debito_base))
			#logger.info('CREDITO B%s' %str(total_credito_base))
			#logger.info('DEBITO S %s' %str(total_debito_secundario))
			#logger.info('CREDITO S %s' %str(total_credito_secundario))
			#total_credito_primario=round(total_credito_primario, 2)
			#total_debito_primario=round(total_debito_primario, 2)
			self.write(cr,uid,documento.id,{
						'total_debito':total_debito,
						'total_credito':total_credito,
						'total_debito_base':round(total_debito_base,2),
						'total_credito_base':round(total_credito_base,2),
						'total_debito_secundario':total_debito_secundario,
						'total_credito_secundario':total_credito_secundario,
				})
		return True
	
	
	def criar_lancamentos_centro_custos(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			
			#for lancamento in documento.lancamentos_diarios_ids:
				
			for lancamento in documento.lancamentos_diarios_ids:
				if lancamento.reflexao_centro==True:
					valor=0
					natureza=None
					if lancamento.credito>0:
						valor=lancamento.credito
						natureza='credito'
					elif lancamento.debito>0:
						valor=lancamento.debito
						natureza='debito'
					val={
						'conta_id':lancamento.conta_id.id,
						'movimento_id':documento.id,
						'valor':valor,
						'valor_disponivel':valor,
						'natureza':natureza,
					}

					self.pool.get('dotcom.contabilidade.lancamento.centro.custo.linha').create(cr,uid,val)

		return {}
	
	def calcular_light(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		
		total_debito=0
		total_credito=0
		total_debito_primario=0
		total_credito_primario=0
		total_debito_secundario=0
		total_credito_secundario=0

			 
		
		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			logger.info('#calculando o movimento######################## %s' %str(len(documento.lancamentos_diarios_ids)))
			if len(documento.lancamentos_diarios_ids)<=0:
				raise osv.except_osv(_('Acção Invalida !'), _('O Movimento Sem Lancamentos efectuados!!'))
			
			primeiro_lancamento=documento.lancamentos_diarios_ids[0]
			acerto=primeiro_lancamento.acerto
			acerto_boolean=True
			
			
			#======================
			periodo_actual={}
			periodo_actual=self.validar_on_change(cr,uid,ids,documento.data,documento.lancamento_fecho,documento.periodo, documento.lancamento_abertura ,documento.is_auto,documento.lancamento_fecho)
			periodo_actual=periodo_actual.get('periodo')
			self.write(cr,uid,ids,{'periodo':periodo_actual})
			#======================
			
			
			for lancamento in documento.lancamentos_diarios_ids:
				if lancamento.acerto==acerto:
					acerto_boolean==False
					break
			contador=0
			logger.info('\n\n\n\n\n\n\n') 
			for lancamento in documento.lancamentos_diarios_ids:
				if bool(lancamento.sequencia)==False:
					contador=contador+1
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'sequencia':contador})
						
				if lancamento.acerto!=acerto:
					acerto_boolean=False
					
				
			   
				if lancamento.conta_id.tipo_interno!='m':
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com tipo de nao permitido!!'))
				if lancamento.credito>0 and lancamento.debito>0:
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com Credito e Debito maior que zero(0)!!'))							  
				if  lancamento.acerto=='all':
					total_debito=total_debito+lancamento.debito
					total_credito=total_credito+lancamento.credito   
						   
				
				total_debito_primario=total_debito_primario+round(lancamento.debito_moeda_base,2)
				total_credito_primario=total_credito_primario+round(lancamento.credito_moeda_base,2)
				
				total_debito_secundario=total_debito_secundario+round(lancamento.debito_moeda_secundaria, 2)
				total_credito_secundario=total_credito_secundario+round(lancamento.credito_moeda_secundaria, 2)
				
			ultimo_lancamento=documento.lancamentos_diarios_ids[len(documento.lancamentos_diarios_ids)-1]
			
			
			
					   
			
			if (ultimo_lancamento.reflexao_iva==False) and(ultimo_lancamento.debito==0 and ultimo_lancamento.credito==0):
					  
				if total_debito>total_credito:
					diferenca=total_debito-total_credito
					credito_moeda_secundaria=ultimo_lancamento.cambio*diferenca/ultimo_lancamento.cambio_secundario
					credito_moeda_base=ultimo_lancamento.cambio*diferenca
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,ultimo_lancamento.id,{
						'credito':diferenca,
						'credito_moeda_secundaria':credito_moeda_secundaria,
						'credito_moeda_base':round(credito_moeda_base,2)
						})
					
				elif total_credito>total_debito:
					diferenca=total_credito-total_debito
					debito_moeda_secundaria=ultimo_lancamento.cambio*diferenca/ultimo_lancamento.cambio_secundario
					debito_moeda_base=ultimo_lancamento.cambio*diferenca
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,ultimo_lancamento.id,{
						'debito':diferenca,
						'debito_moeda_secundaria':debito_moeda_secundaria,
						'debito_moeda_base':round(debito_moeda_base,2)
						})
				
			else:
				logger.info('***VALOR DO ULTIMO LCANCAMENTO DEBITO*** %s' %str(round(total_debito_primario,2)))
				logger.info('***VALOR DO ULTIMO LCANCAMENTO CREDITO*** %s' %str(round(total_credito_primario,2)))
				total_debito=round(total_debito, 2)
				total_credito=round(total_credito, 2)
				
				
				if total_debito!=total_credito:
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda de lançamento!!'))
				
				total_credito_primario=round(total_credito_primario, 2)
				total_debito_primario=round(total_debito_primario, 2)

				
				logger.info('***VALOR DO ULTIMO LCANCAMENTO DEBITO=====*** %s' %str(total_debito_primario))
				logger.info('***VALOR DO ULTIMO LCANCAMENTO CREDITO====*** %s' %str(total_credito_primario))
				
				if total_credito_primario!=total_debito_primario:
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda Principal!!'))
				
				total_credito_secundario=round(total_credito_secundario, 2)
				total_credito_secundario=round(total_credito_secundario, 2)

				logger.info('########TOTAL CREDITO MP%s' %str(total_credito_secundario))
				logger.info('########TOTAL DEBITO MP%s' %str(total_debito_secundario))  
				if documento.balanceamento_local and (total_debito_secundario!=total_credito_secundario):
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda Secundaria!!')) 

					
			
		self.calcular_totais_lancamentos(cr,uid,ids)   
		
		for object in self.browse(cr,uid,ids):	
			for lancamento in object.lancamentos_diarios_ids:
				if lancamento.credito==0 and lancamento.debito==0:
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com Credito e Debito iguais 0 zero(0)!!'))		  
		return {}


	def handle_fluxo_de_caixa(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			for lancamento in documento.lancamentos_diarios_ids:
				if bool(lancamento.movimento_fluxo_caixa_id)!=False:
					valor=0
					if credito>debito:
						valor=credito
					elif credito<debito:
						valor=debito
					logger.info('IDENTIFICADOR Fluxo de caixa===============%s' %str(movimento_fluxo_caixa_id))
					self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').write(cr,uid,movimento_fluxo_caixa_id,{'valor_total':valor})





	def calcular(self, cr,uid,ids,context=None):
		if context is None:
			context={}
		
		
		total_debito=0
		total_credito=0
		total_debito_primario=0
		total_credito_primario=0
		total_debito_secundario=0
		total_credito_secundario=0

			 
		
		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			logger.info('#calculando o movimento######################## %s' %str(len(documento.lancamentos_diarios_ids)))
			if len(documento.lancamentos_diarios_ids)<=0:
				raise osv.except_osv(_('Acção Invalida !'), _('O Movimento Sem Lancamentos efectuados!!'))
			
			primeiro_lancamento=documento.lancamentos_diarios_ids[0]
			acerto=primeiro_lancamento.acerto
			acerto_boolean=True
			
			logger.info('documento.periodo ######################### %s' %str(documento.periodo))
			#======================
			periodo_actual={}
			periodo_actual=self.validar_on_change(cr,uid,ids,documento.data,documento.lancamento_fecho,documento.periodo,documento.lancamento_abertura,documento.is_auto,documento.lancamento_fecho)
			periodo_actual=periodo_actual.get('periodo')
			self.write(cr,uid,ids,{'periodo':periodo_actual})
			#======================
			
			
			for lancamento in documento.lancamentos_diarios_ids:
				if lancamento.acerto==acerto:
					acerto_boolean==False
					break
			#logger.info('PROCESSO CONTINUOU A CORRER %s' %str(lancamento.acerto))
			contador=0
			logger.info('\n\n\n\n\n\n\n') 
			for lancamento in documento.lancamentos_diarios_ids:
				if bool(lancamento.sequencia)==False:
					contador=contador+1
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'sequencia':contador})
						
				if lancamento.acerto!=acerto:
					acerto_boolean=False
					
				
			   
				if lancamento.conta_id.tipo_interno!='m':
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com tipo de nao permitido!!'))
				if lancamento.credito>0 and lancamento.debito>0:
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com Credito e Debito maior que zero(0)!!'))
				#logger.info('ACERTO DOS LANCAMENTOS %s' %str(acerto))							  
				if  lancamento.acerto=='all':
					total_debito=total_debito+lancamento.debito
					total_credito=total_credito+lancamento.credito   
						   
				
				total_debito_primario=total_debito_primario+round(lancamento.debito_moeda_base,2)
				total_credito_primario=total_credito_primario+round(lancamento.credito_moeda_base,2)
				
				total_debito_secundario=total_debito_secundario+round(lancamento.debito_moeda_secundaria, 2)
				total_credito_secundario=total_credito_secundario+round(lancamento.credito_moeda_secundaria, 2)
				
				#self.write(cr,uid,ids,{'total_debito_base':total_debito_primario,'total_credito_base':})
				#logger.info()
				
				if bool(lancamento.adicao_centro_custo_id.id)==True:
					#logger('LANCAMENTO COM CENTRO DE CUSTOS %s' %str(lancamento))
						
					if bool(lancamento.adicao_centro_custo_id.id)==True:
						natureza=''
						if lancamento.debito>lancamento.credito:
							natureza='debito'
							if lancamento.debito!=lancamento.adicao_centro_custo_id.valor_total:
								raise osv.except_osv(_('Invalid action !'), _('O valor da reflexão nos centros de custos referente a conta '+lancamento.conta_id.friendly_name+' não corresponde ao valor lançado!'))
						elif lancamento.credito>lancamento.debito:
							natureza='credito'
							if lancamento.credito!=lancamento.adicao_centro_custo_id.valor_total:
								raise osv.except_osv(_('Invalid action !'), _('O valor da reflexão nos centros de custos referente a conta '+lancamento.conta_id.friendly_name+' não corresponde ao valor lançado!'))
						self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,lancamento.adicao_centro_custo_id.id,{'natureza':natureza})
						for linha_centro in lancamento.adicao_centro_custo_id.linhas_adicao_ids:
							self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').write(cr,uid,linha_centro.id,{'natureza':natureza})
				
				
				if lancamento.reflexao_centro==True:
					if bool(lancamento.adicao_centro_custo_id.id)==True: 
						#centro_custo=self.pool.get('dotcom.contabilidade.lancamentos.centro.custo').browse(cr,uid,lancamento.lancamentos_custo_id.id)
						if len(lancamento.adicao_centro_custo_id.linhas_adicao_ids)<=0:
							raise osv.except_osv(_('Acção Invalida !'), _('Conta com Reflexao a Centro de Custo Nao Lancada!! \n Clique no Botão Centros de Custos para Lancar'))
					else:
						raise osv.except_osv(_('Acção Invalida !'), _('Conta com Reflexao a Centro de Custo Nao Lancada!! \n Clique no Botão Centros de Custos para Lancar'))
						
				if lancamento.conta_id.tem_ref_custos==True and documento.is_auto==False:
					if bool(lancamento.adicao_centro_custo_id.id)==True: 
						#centro_custo=self.pool.get('dotcom.contabilidade.lancamentos.centro.custo').browse(cr,uid,lancamento.lancamentos_custo_id.id)
						if len(lancamento.adicao_centro_custo_id.linhas_adicao_ids)<=0:
							raise osv.except_osv(_('Acção Invalida !'), _('Conta com Reflexao a Centro de Custo Nao Lancada!!\n Clique no Botão Centros de Custos para Lancar '))
					else:
						raise osv.except_osv(_('Acção Invalida !'), _('Conta com Reflexao a Centro de Custo Nao Lancada!!\n Clique no Botão Centros de Custos para Lancar'))
				# if lancamento.fluxo_caixa==True:
				# 	self.handle_fluxo_de_caixa(cr,uid,ids)
			ultimo_lancamento=documento.lancamentos_diarios_ids[len(documento.lancamentos_diarios_ids)-1]
			
			
			
					   
			
			if (ultimo_lancamento.reflexao_iva==False) and(ultimo_lancamento.debito==0 and ultimo_lancamento.credito==0):
					  
				if total_debito>total_credito:
					diferenca=total_debito-total_credito
					credito_moeda_secundaria=ultimo_lancamento.cambio*diferenca/ultimo_lancamento.cambio_secundario
					credito_moeda_base=ultimo_lancamento.cambio*diferenca
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,ultimo_lancamento.id,{
						'credito':diferenca,
						'credito_moeda_secundaria':credito_moeda_secundaria,
						'credito_moeda_base':round(credito_moeda_base,2)
						})
					
				elif total_credito>total_debito:
					diferenca=total_credito-total_debito
					debito_moeda_secundaria=ultimo_lancamento.cambio*diferenca/ultimo_lancamento.cambio_secundario
					debito_moeda_base=ultimo_lancamento.cambio*diferenca
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,ultimo_lancamento.id,{
						'debito':diferenca,
						'debito_moeda_secundaria':debito_moeda_secundaria,
						'debito_moeda_base':round(debito_moeda_base,2)
						})
				
			else:
				logger.info('***VALOR DO ULTIMO LCANCAMENTO DEBITO*** %s' %str(round(total_debito_primario,2)))
				logger.info('***VALOR DO ULTIMO LCANCAMENTO CREDITO*** %s' %str(round(total_credito_primario,2)))
				total_debito=round(total_debito, 2)
				total_credito=round(total_credito, 2)
				
				
				if total_debito!=total_credito:
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda de lançamento!!'))
				
				total_credito_primario=round(total_credito_primario, 2)
				total_debito_primario=round(total_debito_primario, 2)

				
				logger.info('***VALOR DO ULTIMO LCANCAMENTO DEBITO=====*** %s' %str(total_debito_primario))
				logger.info('***VALOR DO ULTIMO LCANCAMENTO CREDITO====*** %s' %str(total_credito_primario))
				
				if total_credito_primario!=total_debito_primario:
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda Principal!!'))
				
					
				
				total_debito_secundario=round(total_debito_secundario, 2)
				total_credito_secundario=round(total_credito_secundario, 2)
				logger.info('########TOTAL CREDITO MP%s' %str(total_credito_secundario))
				logger.info('######## if documento.balanceamento_local and (total_debito_secundario!=total_credito_secundario)::: if %s and (%s!=%s):' %(documento.balanceamento_local,total_debito_secundario,total_credito_secundario))  
				if documento.balanceamento_local and (total_debito_secundario!=total_credito_secundario):
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda Secundaria!!')) 
					#logger.info('TOTAL DEBITO SECUNDARIO %s ' %str(total_credito_secundario))
					#logger.info('TOTAL CREDITO SECUNDARIO %s ' %str(total_debito_secundario))
					
			
		self.calcular_totais_lancamentos(cr,uid,ids)   
		self.write(cr,uid,ids,{'total_debito_secundario':total_debito_secundario,'total_credito_secundario':total_credito_secundario})
		for object in self.browse(cr,uid,ids):	
			for lancamento in object.lancamentos_diarios_ids:
				if lancamento.credito==0 and lancamento.debito==0:
					raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(lancamento.conta_id.ref)+' com Credito e Debito iguais 0 zero(0)!!'))
			#self.criar_lancamentos_centro_custos(cr,uid,ids)		  
		return True
				
		
	def on_change_documento(self,cr,uid,documento,context=None):
		if context is None:
			context={}
			
		objecto=self.pool.get('dotcom.contabilidade.documento').browse(cr,uid,documento)
		
		if documento is not None:
			val={'numero_documento':objecto.numero_por_periodo}
			logger.info('ASC: %s' % str(objecto.numero_por_periodo))
		return {'value':val}
	   
		
	def pegar_ano_fiscal(self,cr,uid,ids,data,context=None):
		if context is None:
			context={}
		data=datetime.strptime(data, '%Y-%m-%d')
		ano=data.year
		logger.info('ANO %s'  %str(ano))
		ano_fiscal_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[('code','=',str(ano))])
		logger.info('ANOS FISCAL %s' %str(ano_fiscal_ids))
		retorno=False
		if len(ano_fiscal_ids)>0:
			retorno=ano_fiscal_ids[0]
		logger.info('ANO%s' %str(ano_fiscal_ids))
		return retorno

	
	def get_period_id(self, cr, uid, ids, date, context=None):
		if context is None:
			context = {}
		period_id = None
		logger.info('DATA ACHADA ATE AO MOMENTO %s'%str(date))
		given_date = datetime(*(time.strptime(date, '%Y-%m-%d')[0:6]))
		
		fiscal_period = self.pool.get('configuration.period').search(cr,uid,[('date_start','<=',given_date),('date_stop','>=',given_date)],limit=1)
		if fiscal_period and len(fiscal_period)>0:
			period_id = fiscal_period[0]

		return period_id
	
	
	#def voltar_rascunho(self,cr,uid,ids,context=None):
	#	if context is None:
	#		context={}
	#	for documento in self.browse(cr,uid,ids):
	#		for lancamento in documento.lancamentos_diarios_ids:
	#				self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'state':'emitido'})
	#		self.write(cr,uid,documento.id,{'state':'rascunho'})
	#	return {}
	
	
	def local_processing(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			if bool(documento.numero_documento)==False:			
				
				if bool(documento.documento_id.id)==False:
					raise osv.except_osv(_('Acção Invalida !'), _('Seleccione o Documento correspondente!!'))
				
				sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',documento.periodo.id),
					('documento_id','=',documento.documento_id.id)
					])
			
				logger.info('*****************PERIODO ACTUAL DO MOVIMENTO %s' %str(documento.documento_id.id))
				logger.info('*******SEQUENCIAS DO DOCUMENTO NO PERIODO******* %s' %str(documento.periodo.code))
				logger.info('SEQUENCIAS DO DOCUMENTO NO PERIODO %s' %str(sequencia_ids))
				#sequencia_ids=[]
				if len(sequencia_ids)<=0:
					raise osv.except_osv(_('Acção Invalida !'), _('Documento sem Sequencias!!'))
				sequencia_id=sequencia_ids[0]
				numero_documento=self.pool.get('dotcom.contabilidade.documento').generate_sequence(cr,uid,sequencia_id,documento.data,documento.documento_id.id,documento.id)
			
			if bool(documento.numero_diario)==False:   
				sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',documento.periodo.id),
					('diario_id','=',documento.diario_id.id)])
				sequencia_id=sequencia_ids[0]
				numero_diario=self.pool.get('dotcom.contabilidade.diario').generate_sequence(cr,uid,sequencia_id,documento.data,documento.diario_id.id,documento.id)
		return True
   
		
	def processar_emitir(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		conta_a_definir=0

		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			
			data=documento.data
			periodo_actual={}
			periodo_actual=self.validar_on_change(cr,uid,ids,documento.data,documento.lancamento_fecho,documento.periodo,documento.lancamento_abertura,documento.is_auto,documento.lancamento_fecho)
			periodo_actual=periodo_actual.get('periodo')
			
			#periodo_actual=periodo_actual['value']
			#periodo_actual=periodo_actual['periodo']
			
			logger.info('PERIOD ACHADO %s' %str(documento.id))
			#self.write(cr,uid,documento.id,{'periodo':periodo_actual})
			logger.info('*****************PERIODO ACTUAL DO MOVIMENTO************ %s' %str(periodo_actual))
			
			
			self.calcular(cr,uid,ids)
			total_debito_secundario=0
			total_credito_secundario=0
			for lancamento in documento.lancamentos_diarios_ids:
				total_debito_secundario=total_debito_secundario+round(lancamento.debito_moeda_secundaria, 2)
				total_credito_secundario=total_credito_secundario+round(lancamento.credito_moeda_secundaria, 2)
			if documento.balanceamento_local and (total_debito_secundario!=total_credito_secundario):
					raise osv.except_osv(_('Acção Invalida !'), _('O Movimento não está balanceado na Moeda Secundaria!!')) 
			
			if bool(documento.numero_documento)==False:			
				
				if bool(documento.documento_id.id)==False:
					raise osv.except_osv(_('Acção Invalida !'), _('Seleccione o Documento correspondente!!'))
					
							   
				sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',documento.periodo.id),
					('documento_id','=',documento.documento_id.id)
					])
			
				logger.info('SEQUENCIAS DO DOCUMENTO NO PERIODO %s' %str(sequencia_ids))
				logger.info('*******SEQUENCIAS DO DOCUMENTO NO PERIODO******* %s' %str(documento.periodo.code))
				#sequencia_ids=[]
				if len(sequencia_ids)<=0:
					raise osv.except_osv(_('Acção Invalida !'), _('Documento sem Sequencias!!'))
				sequencia_id=sequencia_ids[0]
				numero_documento=self.pool.get('dotcom.contabilidade.documento').generate_sequence(cr,uid,sequencia_id,data,documento.documento_id.id,documento.id)
			
			if bool(documento.numero_diario)==False:   
				sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',documento.periodo.id),
					('diario_id','=',documento.diario_id.id)])
				sequencia_id=sequencia_ids[0]
				numero_diario=self.pool.get('dotcom.contabilidade.diario').generate_sequence(cr,uid,sequencia_id,data,documento.diario_id.id,documento.id)
			
			for lancamento in documento.lancamentos_diarios_ids:
				ano_fiscal_conta_lancamento=lancamento.conta_id.ano_fiscal_id
				if ano_fiscal_conta_lancamento !=documento.ano_fiscal_id:
					raise osv.except_osv(_('Invalid action !'), _('A conta '+lancamento.conta_id.friendly_name+' não corresponde ao Ano Fiscal do Movimento!'))
			
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'state':'emitido','periodo_id':documento.periodo.id,'moeda_lancamento_id':documento.moeda_lancamento_id.id})
				if bool(lancamento.adicao_centro_custo_id.id)==True:
					#logger('LANCAMENTO COM CENTRO DE CUSTOS %s' %str(lancamento))
					
					natureza=''
					if lancamento.debito>lancamento.credito:
						natureza='debito'
						if lancamento.debito!=lancamento.adicao_centro_custo_id.valor_total:
							raise osv.except_osv(_('Invalid action !'), _('O valor da reflexão nos centros de custos referente a conta '+lancamento.conta_id.friendly_name+' não corresponde ao valor lançado!'))
					elif lancamento.credito>lancamento.debito:
						natureza='credito'
						if lancamento.credito!=lancamento.adicao_centro_custo_id.valor_total:
							raise osv.except_osv(_('Invalid action !'), _('O valor da reflexão nos centros de custos referente a conta '+lancamento.conta_id.friendly_name+' não corresponde ao valor lançado!'))
					
					self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,lancamento.adicao_centro_custo_id.id,{'natureza':natureza})
					for linha_centro in lancamento.adicao_centro_custo_id.linhas_adicao_ids:
						self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').write(cr,uid,linha_centro.id,{'natureza':natureza})
				
				if lancamento.fluxo_caixa==True and bool(lancamento.movimento_fluxo_caixa_id.id)==False:
					movimento_fluxo_caixa_val={
						'data':lancamento.movimento_id.data,
						'periodo_id':lancamento.movimento_id.periodo.id,
						'ano_fiscal_id':lancamento.movimento_id.ano_fiscal_id.id,
						'conta_id':lancamento.conta_id.id,
						'diario_id':lancamento.movimento_id.diario_id.id,
						'documento_id':lancamento.movimento_id.documento_id.id,
						'movimento_id':documento.id,
						'notas_internas':documento.notas_internas,
						'lancamento_diario_id':lancamento.id,
					}
					conta_a_definir=lancamento.conta_id.id
					valor=0
					natureza=''
					if lancamento.debito>lancamento.credito:
						valor=lancamento.debito
						natureza='debito'
					elif lancamento.credito>lancamento.debito:
						valor=lancamento.credito
						natureza='credito'
					movimento_fluxo_caixa_val['valor_total']=valor
					movimento_fluxo_caixa_val['natureza']=natureza
					logger.info('OBJECTO ENCONTRADO movimento_fluxo_caixa_val =============== %s' % movimento_fluxo_caixa_val)
					movimento_fluxo_id=self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').create(cr,uid,movimento_fluxo_caixa_val)
					logger.info('OBJECTO ENCONTRADO 4564 movimento_fluxo_id =============== %s' % movimento_fluxo_id)
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'movimento_fluxo_caixa_id':movimento_fluxo_id})
			
					if bool(lancamento.fluxo_caixa_id.id)!=False:
						lancamento_fluxo_linha_val={
							  'fluxo_caixa_id':lancamento.fluxo_caixa_id.id,
							  'valor':valor,
							  'movimento_fluxo_id':movimento_fluxo_id,
							  'natureza_fluxo_caixa':lancamento.natureza_fluxo_caixa,
						}
						self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').create(cr,uid,lancamento_fluxo_linha_val)
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').emitir(cr,uid,[movimento_fluxo_id])
				elif  lancamento.fluxo_caixa==True and bool(lancamento.movimento_fluxo_caixa_id.id)!=False:
					self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').emitir(cr,uid,[lancamento.movimento_fluxo_caixa_id.id])
				elif  lancamento.fluxo_caixa==False and bool(lancamento.movimento_fluxo_caixa_id.id)!=False:
					self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').write(cr,uid,lancamento.movimento_fluxo_caixa_id.id,{'state':'cancelado'})
						
				
				
				credito_base_local=round(lancamento.credito_moeda_base,2)
				debito_base_local=round(lancamento.debito_moeda_base,2)
				credito_secundario_local=round(lancamento.credito_moeda_secundaria,2)
				debito_secundario_local=round(lancamento.debito_moeda_secundaria,2)
				logger.info('ENTROU NO PROCESSO %s' %str(credito_base_local))
				logger.info('ENTROU NO PROCESSO %s' %str(debito_base_local))
				
				val={
					'data':lancamento.data_lancamento,
					'diario_id':lancamento.diario_id.id,
					'numero_diario':lancamento.numero_diario,
					'documento_id':lancamento.documento_id.id,
					'numero_documento':lancamento.numero_documento,
					'movimento_id':lancamento.movimento_id.id,
					'conta_id':lancamento.conta_id.id,
					'descricao':lancamento.descricao,
					'periodo_id':lancamento.periodo_id.id,
					#'extrato_diario_lancamento_id':documento.id,
					'lancamento_diario_id':lancamento.id,
					'debito':lancamento.debito,
					'credito':lancamento.credito,
					'debito_moeda_primaria':debito_base_local,
					'credito_moeda_primaria':credito_base_local,
					'debito_ms':debito_secundario_local,
					'credito_ms':credito_secundario_local,
				}
				logger.info('VALOR A SER CRIADO %s' %str(val))
				self.pool.get('dotcom.contabilidade.extratos.diario.linhas').create(cr,uid,val)
				
				
				saldo_conta_periodo_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[
																												('conta_id','=',lancamento.conta_id.id),
																												('periodo_id','=',documento.periodo.id),
																												])
				
				
				if len(saldo_conta_periodo_ids)<=0:
					#for periodo in documento.ano_fiscal_id.period_ids:
					#	logger.info('VARIOS PERIODOS ACHADOS')
						#if periodo.id!=documento.periodo.id:
					val={
						'total_debito_primaria':lancamento.debito_moeda_base,
						'total_credito_primaria':lancamento.credito_moeda_base,
						'total_debito_secundaria':lancamento.debito_moeda_secundaria,
						'total_credito_secundaria':lancamento.credito_moeda_secundaria,
						'periodo_id':documento.periodo.id,
						'conta_id':lancamento.conta_id.id,
						#'saldos_ids':documento.id,
					}
					self.pool.get('dotcom.contabilidade.saldo.contas.periodo').create(cr,uid,val)
						
						#else:
						#	val={
						#		'total_debito_primaria':lancamento.debito_moeda_base,
						#		'total_credito_primaria':lancamento.credito_moeda_base,
						#		'total_debito_secundaria':lancamento.debito_moeda_secundaria,
						#		'total_credito_secundaria':lancamento.credito_moeda_secundaria,
						#		'periodo_id':periodo.id,
						#		'conta_id':lancamento.conta_id.id,
						#	}
						#	self.pool.get('dotcom.contabilidade.saldo.contas.periodo').create(cr,uid,val)
						
				else:
					saldo_conta_periodo_object=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').browse(cr,uid,saldo_conta_periodo_ids[0])
					total_credito_base=lancamento.credito_moeda_base+saldo_conta_periodo_object.total_credito_primaria
					total_debito_base=lancamento.debito_moeda_base+saldo_conta_periodo_object.total_debito_primaria
					logger.info('########VALOR ACHADO NO OBJECTO %s' %str(total_credito_base))
					logger.info('++++++++VALOR ACHADO NO OBJECTO %s' %str(total_debito_base))

					self.pool.get('dotcom.contabilidade.saldo.contas.periodo').write(cr,uid,saldo_conta_periodo_object.id,{
																															'total_debito_primaria':lancamento.debito_moeda_base+saldo_conta_periodo_object.total_debito_primaria,
																															'total_credito_primaria':lancamento.credito_moeda_base+saldo_conta_periodo_object.total_credito_primaria,
																															'total_debito_secundaria':lancamento.debito_moeda_secundaria+saldo_conta_periodo_object.total_debito_primaria,
																															'total_credito_secundaria':lancamento.credito_moeda_secundaria+saldo_conta_periodo_object.total_debito_primaria,
																															})
			
			if bool(documento.periodo.id)==False:
				self.write(cr,uid,ids,{'state':'emitido','periodo':periodo_actual})
				plano_contas_model=self.pool.get('dotcom.contabilidade.plano.contas')
				for lancamento in documento.lancamentos_diarios_ids:
						#logger.info('######### Conta lancamento id ############################################# %s' %str(lancamento.conta_id.id))
						#logger.info('######### Conta lancamento state ############################################# %s' %str(lancamento.conta_id.state))
						if(lancamento.conta_id.state=='draft'):
									conta_movimentada=lancamento.conta_id.id		  
									self.post_conta(cr,uid,conta_movimentada,context)
						if lancamento.adicao_centro_custo_id:
									for linha_centro in lancamento.adicao_centro_custo_id.linhas_adicao_ids:
												if linha_centro.centro_id.has_moviments=='no':
													   centro=linha_centro.centro_id.id	 
													   self.post_centro(cr,uid,centro,context) 
				
			else:
				self.write(cr,uid,ids,{'state':'emitido','periodo':periodo_actual})								
				#self.write(cr,uid,ids,{'state':'emitido',})
				plano_contas_model=self.pool.get('dotcom.contabilidade.plano.contas')
				for lancamento in documento.lancamentos_diarios_ids:
						#logger.info('######### Conta lancamento id ############################################# %s' %str(lancamento.conta_id.id))
						#logger.info('######### Conta lancamento state ############################################# %s' %str(lancamento.conta_id.state))
						if(lancamento.conta_id.state=='draft'):
									conta_movimentada=lancamento.conta_id.id		  
									self.post_conta(cr,uid,conta_movimentada,context)
						if lancamento.adicao_centro_custo_id:
									for linha_centro in lancamento.adicao_centro_custo_id.linhas_adicao_ids:
												if linha_centro.centro_id.has_moviments=='no':
													   centro=linha_centro.centro_id.id	 
													   self.post_centro(cr,uid,centro,context)	  
			 
			#logger.info('DIARIO %s' %str(""))
			#self.calcular(cr,uid,ids)

		return True
			
		
	def post_conta(self, cr,uid,conta,context=None):
		   
		parent_state={
			'state':'post',
		}
		self.pool.get('dotcom.contabilidade.plano.contas').write(cr,uid,conta,parent_state)
			
		conta_object=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
		asc_id=conta_object.parent_id.id
		   
		if asc_id !=None and asc_id!=0:
			conta_ascendente_object=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,asc_id)
			if conta_ascendente_object.state=='draft':
				self.post_conta(cr,uid,asc_id,context)
		return True
	def post_centro(self, cr,uid,centro,context=None):
		   
		parent_state={
			'has_moviments':'yes',
		}
		self.pool.get('dotcom.contabilidade.conta.centro.custos').write(cr,uid,centro,parent_state)
			
		centro_object=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro)
		asc_id=centro_object.parent_id.id
		   
		if asc_id !=None and asc_id!=0:
			centro_ascendente_object=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,asc_id)
			if centro_ascendente_object.has_moviments=='no':
				self.post_centro(cr,uid,asc_id,context)
		return True


	def visualisar_moeda_principal(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		
		
		base_id=0
		for documento in self.browse(cr,uid,ids):
			moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
				
			moeda_seciundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_seciundaria_id[0])
			logger.info('PRIMARIA %s' %str(moeda_seciundaria_id))
			
			base_id=self.pool.get('dotcom.contabilidade.visualizacao.lancamentos.base').create(cr,uid,{
				'moeda_documento_id':moeda_primaria.name,
				'moeda_lancamento_id':moeda_secundaria.name})
			for lancamento in documento.lancamentos_diarios_ids:
				logger.info('LANCAMENTO %s' %str(lancamento.acerto))
				if lancamento.acerto=='all':
					logger.info('ENTROU 1')
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'visualizacao_base_mp_id':base_id})
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'visualizacao_base_ms_id':base_id})
				elif lancamento.acerto=='mp':
					logger.info('ENTROU 2')
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'visualizacao_base_mp_id':base_id})
				elif lancamento.acerto=='ms':
					logger.info('ENTROU 3')
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'visualizacao_base_ms_id':base_id})
				
		return {
			'type': 'ir.actions.act_window',
			'name': 'Conversão Moeda',
			'view_mode': 'form',
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.visualizacao.lancamentos.base',
			'res_id':base_id,
			'target': 'new',
			'context': context,
			'nodestroy': True,
		}
  
		
	def action_multiple_confirmation(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		visualizacao_id = self.pool.get("dotcom.contabilidade.movimento.visualizar").create(
			cr, uid, {}, context=context)
		
		movimentos = context and context['active_ids']
		logger.info('Movimentos %s' % movimentos)
		if movimentos:
			self.pool.get('dotcom.contabilidade.movimentos').write(cr, uid, movimentos, {
				'wizard_id':visualizacao_id,
				'wizard_id2':visualizacao_id})
		
		return {
			'name':_("Impressao"),
			'view_mode': 'form',
			'view_id': False,
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.movimento.visualizar',
			'res_id': visualizacao_id,
			'type': 'ir.actions.act_window',
			'nodestroy': True,
			'target': 'new',
			'domain': '[]',
			'context': context
		}
		
		
		
	def unlink(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		logger.info('TIPO DOS IDS %s' %str(type(ids)))
		lista=[]
		if type(ids)==list:
			lista=ids
		else:
			lista.append(ids)
		logger.info('LISTA DOS DOS IDS %s' %str(lista))
		#
		lista_apagavel=[]
		for elemento in lista:
			movimento=self.browse(cr,uid,elemento,context=context)
			#state=movimento.state
			if movimento.state!='rascunho':
				raise osv.except_osv(_('Acção Invalida !'), _('Movimento Já emitido!!'))
			lancamentos_id=movimento.lancamentos_diarios_ids
			for lancamento in lancamentos_id:
				logger.info('LANCAMENTO A APAGAR %s' %str(lancamento))
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').unlink(cr,uid,lancamento.id)
			lista_apagavel.append(movimento.id)
			
		logger.info('LISTA %s' %str(lista_apagavel))			
		osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)
		return {
				'type': 'ir.actions.act_window',
				'name': 'Lista Movimentos',
				'view_mode': 'tree',
				'view_type': 'form',
				'res_model': 'dotcom.contabilidade.movimentos',
				'res_id':None,
				'target': 'self',
				'context': context,
				'nodestroy': True,
			}
	
	
dotcom_movimentos()


class visualisacao_moeda_base(osv.osv):
	_name='dotcom.contabilidade.visualizacao.lancamentos.base'
	_columns={
		'moeda_documento_id': fields.char('Moeda Documento',size=20, readonly=True,required=True),
		'moeda_lancamento_id': fields.char('Moeda Documento',size=20, readonly=True,required=True),
		'lancamentos_diarios_ids':fields.one2many('dotcom.contabilidade.lancamentos.diarios','visualizacao_base_mp_id','Lançamentos',readonly=True,),
		
		'lancamentos_diarios_ms_ids':fields.one2many('dotcom.contabilidade.lancamentos.diarios','visualizacao_base_ms_id','Lançamentos',readonly=True,),

	}
	
	
	
	def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
		if context is None:
			context = {}
		result = super(visualisacao_moeda_base, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
		a = []

		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context)
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
		
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		dicionario= moeda_primaria_id[0]
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,dicionario)
		
		simbolo_moeda=moeda_secundaria.name

		nome_moeda_primaria = str(moeda_primaria and moeda_primaria.name)
		nome_moeda_secundaria=str(moeda_secundaria and moeda_secundaria.name)
		
		
		view = result['arch']
  
		if nome_moeda_primaria:
			view = view.replace('MP',nome_moeda_primaria)
		if nome_moeda_secundaria:
			view=view.replace('MS',nome_moeda_secundaria)
		#if nome_moeda_lancamento:
		#	view=view.replace('MoedaA','Moeda Lançamento ('+nome_moeda_lancamento+')')
		
		result['arch'] = view

		#result['fields'] = fields
		#logger.info('RESULT VIEW %s' % result)
		return result
	
	
	def fechar_poupup(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		self.unlink(cr,uid,ids)
		return{}
		
visualisacao_moeda_base()


class visualizar_movimento(osv.osv):
	_name='dotcom.contabilidade.movimento.visualizar'
	_columns={
		'data':fields.date('Data',),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',),
		'periodo':fields.many2one('configuration.period','Período',readonly=True),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',),
		
		'movimento_ids':fields.one2many('dotcom.contabilidade.movimentos','wizard_id','Movimentos'),
		'movimentos_ids_pesquisa':fields.one2many('dotcom.contabilidade.movimentos','wizard_id2','Movimentos')
	}
	
	_rec_name='data'
	
	
	def actualizar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		lista1=[]
		lista2=[]
		for documento in self.browse(cr,uid,ids):
			for movimento in documento.movimento_ids:
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'wizard_id':False})
			
			for movimento in documento.movimentos_ids_pesquisa:
				if bool(documento.diario_id)==True and bool(documento.documento_id)==True:
					logger.info('ENTROU')
					if (movimento.diario_id.id==documento.diario_id.id) and (movimento.documento_id.id==documento.documento_id.id):
						lista1.append(movimento)
				elif bool(documento.diario_id)==True and bool(documento.documento_id)==False:
					if (movimento.diario_id.id==documento.diario_id.id):
						lista1.append(movimento)
				elif bool(documento.diario_id)==False and bool(documento.documento_id)==True:
					if (movimento.documento_id.id==documento.documento_id.id):
						lista1.append(movimento)
			
			logger.info('LISTA %s' %str(lista1))
			for movimento in lista1:	
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'wizard_id':documento.id})
		return True
	
	
	def limpar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			for movimento in documento.movimentos_ids_pesquisa:
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'wizard_id':documento.id})
			
visualizar_movimento()
