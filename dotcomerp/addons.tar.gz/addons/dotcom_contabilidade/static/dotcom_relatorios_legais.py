# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
from dateutil.relativedelta import relativedelta
logger = logging.getLogger('DOTCOM_PLANO_CONTAS=====')


class dotcom_configuracao_balanco(osv.osv):
	_name='dotcom.comtabilidade.relatorios.legais.balanco.conf'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual' ),
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=False,readonly=True ),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=False, readonly=True),
		
		'linha_ids':fields.one2many('dotcom.comtabilidade.rl.linha','conf_id','Activos', readonly=True),
		'ref':fields.char('Ref', size=25,required=True,),
		'descricao':fields.char('Descricao',size=100,required=True,),
		'operacao':fields.char('Operacao', size=150,required=False,readonly=False),
		'resultado_operacao':fields.char('Operador',size=2,readonly=False),
		'valor_demonstracao':fields.float('Valor Dem. Result.', readonly=True),
		
	}
	_defaults={
		'resultado_operacao':'+'
	}
	_rec_name="descricao"
	
	
	def actualizar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			for linha in documento.linha_ids:
				self.pool.get('dotcom.comtabilidade.rl.linha').unlink(cr,uid,linha.id)
			
			lista_ref=[]	
			lista_ref.append(documento.ref)
			
			activos_correntes_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			
			#activos_correntes_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)
			
			for activo in activos_correntes_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,activo)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
								
				saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,activo)
							
		return True
	
	
dotcom_configuracao_balanco()


class dotcom_configuracao_balanco_linha(osv.osv):
	_name='dotcom.comtabilidade.rl.linha'
	_columns={
		'ref':fields.char('Ref', size=25,required=False,),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Activos',required=True, ),
		'saldo':fields.float('Saldo'),
		'natureza':fields.selection([('credito','Credito'),('debito','Debito')],'Natureza do Saldo'),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=False, ),
		'operador':fields.float('Operador'),
		
		'conf_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco.conf',)
	}

	_rec_name='ref'
	
   
dotcom_configuracao_balanco_linha()


class dotcom_balanco(osv.osv):
	 
	
	
	_name='dotcom.comtabilidade.relatorios.legais.balanco'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=True, ),
		'ano_fiscal_anterio_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Anterior',required=False, readonly=True),
		
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=True, domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=True, domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		
		'activos_nao_correntes_ids':fields.one2many('dotcom.comtabilidade.relatorios.legais.balanco.linha','balanco_activo_nao_corente_id', 'Activos Nao Correntes', ),
		'activos_correntes_ids':fields.one2many('dotcom.comtabilidade.relatorios.legais.balanco.linha','balanco_activo_corente_id','Activos Correntes', ),
		'capital_proprio_ids':fields.one2many('dotcom.comtabilidade.relatorios.legais.balanco.linha','balanco_capital_proprio_id','Capital Proprio', ),
		'passivos_nao_correntes_ids':fields.one2many('dotcom.comtabilidade.relatorios.legais.balanco.linha','balanco_passivo_nao_corrente_id','Passivos Nao Correntes', ),
		'passivos_correntes_ids':fields.one2many('dotcom.comtabilidade.relatorios.legais.balanco.linha','balanco_passivo_corrente_id','Passivos Correntes', ),
		
		#totalizadores
		'incluir_periodos':fields.boolean('Incluir Periodos'),
		'total_activos_actual':fields.float('Actual',readonly=True),
		'total_activos_anterior':fields.float('Antrior',readonly=True),
		#Passivos
		'total_passivos_actual':fields.float('Actual', readonly=True),
		'total_passivos_anterior':fields.float('Anterior', readonly=True),
		#Capital Proprio e Passivos
		'capital_proprio_passivos_actual':fields.float('Actual',readonly=True),
		'capital_proprio_passivos_anterior':fields.float('Anterior',readonly=True),
		'notas':fields.text('Notas',),
	}
	
	rec_name='ano_fiscal_id'
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'periodo_inicial_id':validator._get_default_openning_period,
		'periodo_final_id':validator._get_default_present_period
	}
	
	
	def actualizar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			contet={}
		
		for documento in self.browse(cr,uid,ids):
			
			linhas_configuracao_ids=self.pool.get('dotcom.comtabilidade.rl.linha').search(cr,uid,[])
			for linha in linhas_configuracao_ids:
				self.pool.get('dotcom.comtabilidade.rl.linha').unlink(cr,uid,linha)
			for activos in documento.activos_correntes_ids:
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').unlink(cr,uid,activos.id)
			for activos_nao in documento.activos_nao_correntes_ids:
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').unlink(cr,uid,activos_nao.id)
			for capital in documento.capital_proprio_ids:
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').unlink(cr,uid,capital.id)
			for passivo_nao in documento.passivos_nao_correntes_ids:
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').unlink(cr,uid,passivo_nao.id)
			for passivo in documento.passivos_correntes_ids:
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').unlink(cr,uid,passivo.id)
			
		  
			ano_anterior_id=self.on_change_ano_id(cr,uid,ids,documento.ano_fiscal_id.id)
			ano_anterior_id=ano_anterior_id['value']
			if ano_anterior_id=={}:
				ano_anterior_id=False
			else:
				ano_anterior_id=ano_anterior_id['ano_fiscal_anterio_id']
				self.write(cr,uid,documento.id,{'ano_fiscal_anterio_id':ano_anterior_id})
				
			lista_ref=[]
			lista_ref.append('AC01')
			lista_ref.append('AC02')
			lista_ref.append('AC03')
			lista_ref.append('AC04')
			lista_ref.append('AC05')
			lista_ref.append('AC06')
			
			
			activos_correntes_ids=conf_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
									('ref','in',lista_ref),
									('ano_fiscal_id','=',documento.ano_fiscal_id.id)
			])
			#activos_correntes_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)
			
			ano_anterior_boolen=False
			periodos_anteriores_ids=[]
			plano_contas_anterior_ids=[]
			if bool(ano_anterior_id)!=False:
				ano_anterior_boolen=True
				data_inicio_anterior=documento.periodo_inicial_id.date_start
				logger.info('DATA DE INICIO DO ANO ANTERIRO %s' %str(data_inicio_anterior))
				data_inicio_anterior = datetime(*(time.strptime(data_inicio_anterior, '%Y-%m-%d')[0:6]))
				data_inicio_anterior = data_inicio_anterior - relativedelta(years=1)
				
				data_fim_anterior=documento.periodo_final_id.date_stop
				data_fim_anterior = datetime(*(time.strptime(data_fim_anterior, '%Y-%m-%d')[0:6]))
				data_fim_anterior = data_fim_anterior - relativedelta(years=1)
				
				plano_contas_anterior_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_anterior_id)])
				
				logger.info('DATA DE INICIO DO ANO ANTERIRO %s' %str(data_inicio_anterior))
				logger.info('DATA DE FIM DO ANO ANTERIRO %s' %str(data_fim_anterior))
				periodos_anteriores_ids=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',ano_anterior_id),
																					('date_start','>=',data_inicio_anterior),
																					('date_stop','<=',data_fim_anterior),
																					])
				logger.info('LISTA DE PERIODOS ACHADOS ANTERIORMENTE %s' %str(periodos_anteriores_ids))
			
			for activo in activos_correntes_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,activo)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,activo)
				
				
				saldo_anterior=0
				if ano_anterior_id!=False:
					saldo_anterior=self.calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],activo)
				
				val={
					'conta_conf_id':activo,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'tipo':'sys',
					'balanco_activo_corente_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolen,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,activo,{
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			lista_ref=[]
			lista_ref.append('ANC01')
			lista_ref.append('ANC02')
			lista_ref.append('ANC03')
			lista_ref.append('ANC04')
			lista_ref.append('ANC05')
			lista_ref.append('ANC06')
			lista_ref.append('ANC07')
			lista_ref.append('ANC08')
			lista_ref.append('ANC09')
			
			activos_nao_correntes_ids=conf_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
									('ref','in',lista_ref),
									('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			#activos_nao_correntes_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)
			for nao_corrente in activos_nao_correntes_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,nao_corrente)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,nao_corrente)
				
				saldo_anterior=0
				if ano_anterior_id!=False:	 
					if len(periodos_anteriores_ids)<=0:
						raise osv.except_osv(_('Acção Invalida !'), _('Periodos anteriores nao definidos!!'))
					saldo_anterior=self.calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],nao_corrente)
				
				val={
					'conta_conf_id':nao_corrente,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'tipo':'sys',
					'balanco_activo_nao_corente_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolen,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').create(cr,uid,val)
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,nao_corrente,{
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			lista_ref=[]
			lista_ref.append('CP01')
			lista_ref.append('CP02')
			lista_ref.append('CP03')
			lista_ref.append('CP04')
			lista_ref.append('CP05')
			lista_ref.append('CP06')
			
			capital_proprio_ids=conf_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
									('ref','in',lista_ref),
									('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			#capital_proprio_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)
			for capital in capital_proprio_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,capital)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,capital)
				
				saldo_anterior=0
				if ano_anterior_id!=False:				
					saldo_anterior=self.calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],capital)
				
				val={
					'conta_conf_id':capital,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'tipo':'sys',
					'balanco_capital_proprio_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolen,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,capital,{
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			lista_ref=[]
			lista_ref.append('PNC01')
			lista_ref.append('PNC02')
			lista_ref.append('PNC03')
			lista_ref.append('PNC04')
			lista_ref.append('PNC05')
			passivos_nao_correntes_ids=conf_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
									('ref','in',lista_ref),
									('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			#passivos_nao_correntes_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)
			
			for passivo_nao_corrente in passivos_nao_correntes_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,passivo_nao_corrente)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,passivo_nao_corrente)
				
				saldo_anterior=0
				if ano_anterior_id!=False:	 
					saldo_anterior=self.calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],passivo_nao_corrente)
				val={
					'conta_conf_id':passivo_nao_corrente,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'tipo':'sys',
					'balanco_passivo_nao_corrente_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolen,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,passivo_nao_corrente,{
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			lista_ref=[]
			lista_ref.append('PC01')
			lista_ref.append('PC02')
			lista_ref.append('PC03')
			lista_ref.append('PC04')
			lista_ref.append('PC05')
			lista_ref.append('PC06')
			passivos_correntes_ids=conf_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').search(cr,uid,[
									('ref','in',lista_ref),
									('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			#passivos_correntes_ids=self.pesquisar_configuracoe(cr,uid,ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',lista_referencias=lista_ref,context=context)

			for passivo_corrente in passivos_correntes_ids:
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,passivo_corrente)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,passivo_corrente)
				
				saldo_anterior=0
				if ano_anterior_id!=False:	 
					saldo_anterior=self.calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],passivo_corrente)
				
				val={
					'conta_conf_id':passivo_corrente,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'tipo':'sys',
					'balanco_passivo_corrente_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolen,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,passivo_corrente,{
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
		self.calcular_totalizadores(cr,uid,ids,context)
		return {}
			
	
	def calcular_saldo(self,cr,uid,ano_fiscal_id,retorno_operacao,periodo_inicial,periodo_final,configuracao_id,context=None):
		if context is None:
			context={}
		
		geral_saldo=0
		operador='+'
		#operador_inicial='+'
		contador=0
		
		saldo_demosntracao=0
		
		for retorno in retorno_operacao:				
			if len(retorno[0])==1:
				operador=retorno[0]
			
			if len(retorno[0])>1:
				valor_conta=retorno[0]
				tipo_saldo=valor_conta[:1]
				conta_ref=valor_conta[1:]
				
				
				contas_operacoes_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
												('ref','=',conta_ref),
												('ano_fiscal_id','=',ano_fiscal_id)
							])
				
				#logger.info('CONTA DE ENTRADA %s' %str(contas_operacoes_ids))
				
				lista_contas=[]
				for conta in contas_operacoes_ids:
					conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
					lista_contas=validator.get_filhos_ids(cr,uid,conta,context=context)

				saldo=0
				credito=0
				debito=0
				
				#lacamentos_todas_contas=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
				#								('conta_id','in',lista_contas),
				#								('periodo_id','>=',periodo_inicial),
				#								('periodo_id','<=',periodo_final),
				#								('state','=','emitido')
				#							])
				
				saldos_periodicos_contas=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[
																											('conta_id','in',lista_contas),
																											('periodo_id','>=',periodo_inicial),
																											('periodo_id','<=',periodo_final),
																										])
			
				
				contador_moves=0
				#reads_todos=self.pool.get('dotcom.contabilidade.lancamentos.diarios').read(cr, uid, lacamentos_todas_contas, ['credito_moeda_base','debito_moeda_base'], context=context)		  
				for lancamento in saldos_periodicos_contas:
					contador_moves=contador_moves+1
					saldo_object=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').browse(cr,uid,lancamento)
					credito=credito+saldo_object.total_credito_primaria
					debito=debito+saldo_object.total_debito_primaria
					logger.info('CONTADOR DE MOVIMENTOS================================================= %s' %str(contador_moves))
					logger.info('aCUMULADOR DE CREDITOS================================================= %s' %str(credito))
				   logger.info('aCUMULADOR DE DEBITOS================================================= %s' %str(debito))
					logger.info('TOTAL CREDITO PRIMARIO========================================== %s' %str(saldo_object.total_credito_primaria))
					logger.info('TOTAL DEBITO PRIMARIO================================================= %s' %str(saldo_object.total_debito_primaria))
					 
				natureza=''
				valor_natureza=0
				
				if tipo_saldo=='N':
					if debito>credito:
						saldo=debito-credito
						natureza='debito'
						logger.info('SALDO ANTES DO PROCESSAMENTO DEBITO %s' %str(saldo))
						valor_natureza=saldo
						if operador=='-':
							valor_natureza=saldo*-1
						#logger.info('SALDO DEPOIS DO PROCESSAMENTO DEBITO %s' %str(saldo))
					elif debito<credito:
						saldo=credito-debito
						natureza='credito'
						saldo=saldo*-1
						#logger.info('SALDO ANTES DO PROCESSAMENTO CREDITO %s' %str(saldo))
						valor_natureza=saldo
						if operador=='-':
							valor_natureza=saldo*-1
				
				
				elif tipo_saldo=='+':
					if debito>credito:
						saldo=debito-credito
						natureza='debito'
						#logger.info('SALDO ANTES DO PROCESSAMENTO DEBITO %s' %str(saldo))
						if operador=='-':
							valor_natureza=saldo*-1
						logger.info('SALDO DEPOIS DO PROCESSAMENTO DEBITO %s' %str(saldo))
				
				elif tipo_saldo=='-':
					if debito<credito:
						saldo=credito-debito
						natureza='credito'
						saldo=saldo*-1
						#logger.info('SALDO ANTES DO PROCESSAMENTO CREDITO %s' %str(saldo))
						valor_natureza=saldo
						if operador=='-':
							valor_natureza=saldo*-1

				if len(contas_operacoes_ids)>0:
					val={
						'conta_id':contas_operacoes_ids[0],
						'saldo':saldo,
						'conf_id':configuracao_id,
						'operador':valor_natureza,
						'natureza':natureza
					}
					self.pool.get('dotcom.comtabilidade.rl.linha').create(cr,uid,val)
		
					saldo_demosntracao=saldo_demosntracao+valor_natureza

				if operador=='+':
					geral_saldo=geral_saldo+saldo
				elif operador=='-':
					geral_saldo=geral_saldo-saldo

			elif len(retorno[0])==1:
				operador=retorno[0]
			contador=contador+1

		configuracao_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,configuracao_id)
		self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,configuracao_id,
																				   {'valor_demonstracao':saldo_demosntracao})
		
		return geral_saldo
   
	
	def calcular_totalizadores(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			total_activos_actual=0
			total_activos_anterior=0
			for nao_correntes in documento.activos_nao_correntes_ids:
				total_activos_actual=total_activos_actual+nao_correntes.saldo_actual
				total_activos_anterior=total_activos_anterior+nao_correntes.saldo_anterior
			
			for correntes in documento.activos_correntes_ids:
				total_activos_actual=total_activos_actual+correntes.saldo_actual
				total_activos_anterior=total_activos_anterior+correntes.saldo_anterior
						
			total_passivos_actual=0
			total_passivos_anterior=0
			for nao_correntes in documento.passivos_nao_correntes_ids:
				total_passivos_actual=total_passivos_actual+nao_correntes.saldo_actual
				total_passivos_anterior=total_passivos_anterior+nao_correntes.saldo_anterior
				
			for correntes in documento.passivos_correntes_ids:
				total_passivos_actual=total_passivos_actual+correntes.saldo_actual
				total_passivos_anterior=total_passivos_anterior+correntes.saldo_anterior
						
			capital_proprio_passivos_actual=0
			capital_proprio_passivos_anterior=0
			for capital_proprio in documento.capital_proprio_ids:
				capital_proprio_passivos_actual=capital_proprio_passivos_actual+capital_proprio.saldo_actual
				capital_proprio_passivos_anterior=capital_proprio_passivos_anterior+capital_proprio.saldo_anterior
			capital_proprio_passivos_actual=capital_proprio_passivos_actual+total_passivos_actual
			capital_proprio_passivos_anterior=capital_proprio_passivos_anterior+total_passivos_anterior
			
			self.write(cr,uid,documento.id,{'total_activos_actual':total_activos_actual,
											'total_activos_anterior':total_activos_anterior,
											'total_passivos_actual':total_passivos_actual,
											'total_passivos_anterior':total_passivos_anterior,
											'capital_proprio_passivos_actual':capital_proprio_passivos_actual,
											'capital_proprio_passivos_anterior':capital_proprio_passivos_anterior})
		
		return True
			
	
	def pesquisar_configuracoe(self,cr,uid,ano_fiscal_id,classe,lista_referencias=[],context=None):
		if context is None:
			context={}
		conf_ids=self.pool.get(classe).search(cr,uid,[
									('ref','in',lista_referencias),
									('ano_fiscal_id','=',ano_fiscal_id)
			])
		
		if len(conf_ids)>0:
			return conf_ids
		else:
			raise osv.except_osv(_('Invalid action !'), _('Configurações não definidas.!!'))
		#logger.info('ANO FISCAL DO DOCUMENTO %s' %str(conf_object.ano_fiscal_id.code))
		
		

	
	def on_change_ano_id(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		val={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		ano_anterior=ano_actual-1
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')		
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
			periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
			data_fecho=periodo_abertura.date_stop
			val={'ano_fiscal_anterio_id':ano_anterior_ids[0]}
		else:
			val={'ano_fiscal_anterio_id':False}
		ano_actual=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		val['periodo_inicial_id'] =  ano_actual.period_ids[0].id
 
		return {'value':val}
		

dotcom_balanco()


class dotcom_balanco_linha(osv.osv):
	
	#def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
	#	if context is None:
	#		context = {}
	#	result = super(dotcom_balanco_linha, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
	#	a = []
	#	
	#	ano_actual_id=validator._get_default_year(self,cr,uid,context=context)
	#	ano_actual=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_actual_id)
	#	ano_codigo=ano_actual.name
	#	
	#
	#	view = result['arch']
	#	logger.info('ANO ACTUAL %s' %str(view))
	#	view = view.replace('ACTUAL',str(ano_codigo))
	#	result['arch'] = view
	#	return result
	
	
	_name='dotcom.comtabilidade.relatorios.legais.balanco.linha'
	_columns={
		'conta_conf_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco.conf','Activos',readonly=True),
		'saldo_actual':fields.float('Actual',readonly=True),
		'saldo_anterior':fields.float('Anterior',readonly=False),
		'notas':fields.char('Notas',size=50),
		'tipo':fields.selection([('sys','Sistema'),('novo','Novo')]),
		
		'balanco_activo_nao_corente_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco','Balanco'),
		'balanco_activo_corente_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco','Balanco'),
		'balanco_capital_proprio_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco','Balanco'),
		'balanco_passivo_nao_corrente_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco','Balanco'),
		'balanco_passivo_corrente_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco','Balanco'),
		'tem_ano_anterior':fields.boolean('Ano Anterior'),
	}
	 
	_rec_name='notas'
	_defaults={
		'tipo':'novo'
	}
	
	#def unlink(self,cr,uid,ids,context=None):
	#	if context is None:
	#		context={}
	#	linhas=self.browse(cr,uid,ids)
	#	lista_apagavel=[]
	#	for linha in linhas:
	#		if (linha.tipo== 'novo' ):
	#			lista_apagavel.append(linha.id)
	#		else:
	#			raise osv.except_osv(_('Invalid action !'), _('Não é possível remover este Contrato pois já foi registado.!!'))
	#		osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)
	#	return True   
	
dotcom_balanco_linha()


class dotcom_demostracao_resultados(osv.osv):
	_name='dotcom.comtabilidade.demostracao.resultados'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Actual',required=True, ),
		'ano_fiscal_anterio_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Anterior',required=False, readonly=True),
		'periodo_inicial_id':fields.many2one('configuration.period','Periodo Inicio',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'periodo_final_id':fields.many2one('configuration.period','Periodo Fim',required=True,domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		
		'resultado_antes_imposto_actual':fields.float('Actual',readonly=True),
		'resultado_antes_imposto_anterior':fields.float('Anterior',readonly=True),
		'resultado_poc_actual':fields.float('Actual',readonly=True),
		'resultado_poc_anterior':fields.float('Anterior',readonly=True),
		'resultado_liquido_actual':fields.float('Actual',readonly=True),
		'resultado_liquido_anterior':fields.float('Anterior',readonly=True),
		
		'incluir_periodos':fields.boolean('Incluir Periodos'),
		
		'linhas_resultados_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','resultado_id', 'Activos Nao Correntes', readonly=False),
		'resultados_impostos_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','resultado_imposto_id','Activos Correntes', readonly=False),
		'resultados_liquido_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','liquido_id','Capital Proprio', readonly=False),
		'resultado_operacoe_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','r_operacoes_id','Passivos Correntes', readonly=False),
		'resultado_aimpostos_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','r_aimpostos_id','Passivos Correntes', readonly=False),
		'resultado_accao_ids':fields.one2many('dotcom.comtabilidade.demostracao.resultados.linha','r_accao_id','Passivos Correntes', readonly=False),
		
		'notas':fields.text('Notas',),
	
	
	
	}
	
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'periodo_inicial_id':validator._get_default_openning_period,
		'periodo_final_id':validator._get_default_present_period
	}
	
	def actualizar_linhas_demostracao(self,cr,uid,ids,context=None):
		logger.info('actualizar_linhas_demostracao ================================================== %s'  %str(ids))
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			
			linhas_configuracao_ids=self.pool.get('dotcom.comtabilidade.rl.linha').search(cr,uid,[])
			for linha in linhas_configuracao_ids:
				self.pool.get('dotcom.comtabilidade.rl.linha').unlink(cr,uid,linha)
			
			for resultado in documento.linhas_resultados_ids:
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').unlink(cr,uid,resultado.id)
			for impostos in documento.resultados_impostos_ids:
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').unlink(cr,uid,impostos.id)
			for liquido in documento.resultados_liquido_ids:
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').unlink(cr,uid,liquido.id)
			for operacoes in documento.resultado_operacoe_ids:
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').unlink(cr,uid,operacoes.id)
				
			ano_anterior_id=self.on_change_ano_id(cr,uid,ids,documento.ano_fiscal_id.id)
			ano_anterior_id=ano_anterior_id['value']
			
			logger.info('ANO ANTERIOR ============== %s' %str(ano_anterior_id))
			
			if ano_anterior_id=={}:
				ano_anterior_id=False
			else:
				ano_anterior_id=ano_anterior_id.get('ano_fiscal_anterio_id',False)
			
			
			
			#logger.info('ANO ANTERIOR ACHADO %s' %str(ano_anterior_id))
			
			ano_anterior_boolean=False
			periodos_anteriores_ids=[]
			plano_contas_anterior_ids=[]
			if bool(ano_anterior_id)==True:
				ano_anterior_boolean=True
				data_inicio_anterior=documento.periodo_inicial_id.date_start
				#logger.info('DATA DE INICIO DO ANO ANTERIRO %s' %str(data_inicio_anterior))
				data_inicio_anterior = datetime(*(time.strptime(data_inicio_anterior, '%Y-%m-%d')[0:6]))
				data_inicio_anterior = data_inicio_anterior - relativedelta(years=1)
				
				data_fim_anterior=documento.periodo_final_id.date_stop
				data_fim_anterior = datetime(*(time.strptime(data_fim_anterior, '%Y-%m-%d')[0:6]))
				data_fim_anterior = data_fim_anterior - relativedelta(years=1)
				
				plano_contas_anterior_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('ano_fiscal_id','=',ano_anterior_id)])
				#if bool(documento.ano_fiscal_anterior_id.id)!=False:
				periodos_anteriores_ids=self.pool.get('configuration.period').search(cr,uid,[
																					('fiscalyear_id','=',ano_anterior_id),
																					('date_start','>=',data_inicio_anterior),
																					('date_stop','<=',data_fim_anterior),
																					])
			#logger.info('PERIODOS DO ANO ANTERIRO %s' %str(plano_contas_anterior_ids))
				
			
			
			lista_ref=[]
			lista_ref.append('RAI01')
			lista_ref.append('RAI02')
			lista_ref.append('RAI03')
			lista_ref.append('RAI04')
			lista_ref.append('RAI05')
			lista_ref.append('RAI06')
			lista_ref.append('RAI07')
			lista_ref.append('RAI08')
			lista_ref.append('RAI09')
			lista_ref.append('RAI10')
			lista_ref.append('RAI11')
			lista_ref.append('RAI12')
			lista_ref.append('RAI13')
			lista_ref.append('RAI14')
			lista_ref.append('RAI15')
			resultados_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			
			saldo_actual_geral=0
			saldo_anterior_geral=0
			sequence=0
			for resultado in resultados_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,resultado)
				logger.info('SALDO GERAL DOS RESULTADOS %s' %str(resultado))
				
				#self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').actualizar_linhas(cr,uid,[object_nao.id])
				
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				#saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,resultado)
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,resultado)
				
				
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],resultado)
				
				saldo_actual_geral=saldo_actual_geral+object_nao.valor_demonstracao
				saldo_anterior_geral=saldo_anterior_geral+saldo_anterior
				
				result_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,resultado)
				val={
					'conta_conf_id':resultado,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'resultado_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,resultado,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			#logger.info('SAIDA SALDO ACTUAL %s' %str(saldo_actual_geral))
			#logger.info('SAIDA SALDO ANTERIOR %s' %str(saldo_anterior_geral))
			
			
			lista_ref=[]
			lista_ref.append('RAI101')
			lista_ref.append('RAI102')
			lista_ref.append('RAI102')
			lista_ref.append('RAI102')
			lista_ref.append('RAI102')
			lista_ref.append('RAI103')
			impostos_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			sequence=0
			#saldo_actual_geral=0
			#saldo_anterior_geral=0
			for imposto in impostos_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,imposto)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,imposto)
							
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],imposto)
				
				saldo_actual_geral=saldo_actual_geral+object_nao.valor_demonstracao
				saldo_anterior_geral=saldo_anterior_geral+saldo_anterior

				imposto_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,imposto)
				
				val={
					'conta_conf_id':imposto,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'resultado_imposto_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,imposto,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			self.write(cr,uid,documento.id,{
				'resultado_antes_imposto_actual':saldo_actual_geral,
				'resultado_antes_imposto_anterior':saldo_anterior_geral})
			
			lista_ref=[]
			lista_ref.append('RPOC01')
			resultados_operacoes_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			#logger.info('RESULTADOS DAS OPERACOES ENCONTRADOS %s' %str(resultados_operacoes_ids))
			actual_operacoes=0
			anterior_operacoes=0
			sequence=0
			for reultado in resultados_operacoes_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				logger.info('ANO ANTERIOR ENTRA ===================================== %s' %str(documento.ano_fiscal_id.id))
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,reultado)
			   
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],reultado)
				
				actual_operacoes=actual_operacoes+saldo_geral
				anterior_operacoes=anterior_operacoes+saldo_anterior
				
				reultado_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
				
				val={
					'conta_conf_id':reultado,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'r_operacoes_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,reultado,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			actual_operacoes=actual_operacoes+saldo_actual_geral
			anterior_operacoes=anterior_operacoes+ saldo_anterior_geral   
			self.write(cr,uid,documento.id,{
				'resultado_poc_actual':actual_operacoes,
				'resultado_poc_anterior':anterior_operacoes})			 
			
			
			lista_ref=[]
			lista_ref.append('RLP2')
			liquidos_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			#logger.info('RESULTADOS LIQUIDOS ENCONTRADOS %s' %str(liquidos_ids))
			
			resultados_liquido_actual=0
			resultados_liquido_anterior=0
			sequence=0
			for liquido in liquidos_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,liquido)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,liquido)
							   
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],liquido)
				
				resultados_liquido_actual=resultados_liquido_actual+saldo_geral
				resultados_liquido_anterior=resultados_liquido_anterior+saldo_anterior
				
				reultado_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,liquido)
  
				val={
					'conta_conf_id':liquido,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'liquido_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,liquido,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
			
			resultados_liquido_actual=resultados_liquido_actual+actual_operacoes
			resultados_liquido_anterior=resultados_liquido_anterior+anterior_operacoes
			self.write(cr,uid,documento.id,{
				'resultado_liquido_actual':resultados_liquido_actual,
				'resultado_liquido_anterior':resultados_liquido_anterior})   
			
			lista_ref=[]
			lista_ref.append('ARLP01')
			lista_ref.append('ARLP02')
			lista_ref.append('ARLP03')
			resultados_operacoes_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			
			sequence=0
			for reultado in resultados_operacoes_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,reultado)
								
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],reultado)
				
				
				reultado_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
			  
				val={
					'conta_conf_id':reultado,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'r_aimpostos_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,reultado,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
				
			
			lista_ref=[]
			lista_ref.append('ARLP04')
			resultados_operacoes_ids=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').pesquisar_configuracoe(cr,uid,
									ano_fiscal_id=documento.ano_fiscal_id.id,classe='dotcom.comtabilidade.relatorios.legais.balanco.conf',
									lista_referencias=lista_ref,context=context)
			
			sequence=0
			for reultado in resultados_operacoes_ids:
				sequence=sequence+1
				object_nao=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
				retorno_operacao=validator.get_parcelas_operacao(cr,uid,object_nao.operacao,context=context)
				saldo_geral=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,documento.ano_fiscal_id.id,retorno_operacao,documento.periodo_inicial_id.id,documento.periodo_final_id.id,reultado)
								
				saldo_anterior=0
				if ano_anterior_id!=False:
					#periodos_anteriores=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_anterior_id)])
					saldo_anterior=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco').calcular_saldo(cr,uid,ano_anterior_id,retorno_operacao,periodos_anteriores_ids[0],periodos_anteriores_ids[len(periodos_anteriores_ids)-1],reultado)
				
				
				reultado_object=self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').browse(cr,uid,reultado)
								
				val={
					'conta_conf_id':reultado,
					'saldo_actual':saldo_geral,
					'saldo_anterior':saldo_anterior,
					'notas':'',
					'r_accao_id':documento.id,
					'tem_ano_anterior':ano_anterior_boolean,
					'sequence':sequence,
				}
				if len(plano_contas_anterior_ids)>0:
					val['tem_ano_anterior']=True
				else:
					val['tem_ano_anterior']=False
				self.pool.get('dotcom.comtabilidade.demostracao.resultados.linha').create(cr,uid,val)
				
				self.pool.get('dotcom.comtabilidade.relatorios.legais.balanco.conf').write(cr,uid,reultado,{
																						'valor_demonstracao':saldo_geral,
																						'periodo_inicial_id':documento.periodo_inicial_id.id,
																						'periodo_final_id':documento.periodo_final_id.id})
		self.calcular_valores(cr,uid,ids)
			
		return {}	
				
	
	def calcular_valores(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			resultado_antes_imposto_actual=0
			resultado_antes_imposto_anterior=0
			
			for linha in documento.linhas_resultados_ids:
				resultado_antes_imposto_actual=resultado_antes_imposto_actual+linha.saldo_actual
				resultado_antes_imposto_anterior=resultado_antes_imposto_anterior+linha.saldo_anterior
				
			for linha in documento.resultados_impostos_ids:
				resultado_antes_imposto_actual=resultado_antes_imposto_actual+linha.saldo_actual
				resultado_antes_imposto_anterior=resultado_antes_imposto_anterior+linha.saldo_anterior
				
			self.write(cr,uid,documento.id,{'resultado_antes_imposto_actual':resultado_antes_imposto_actual,
											'resultado_antes_imposto_anterior':resultado_antes_imposto_anterior})
			
			
			for linha in documento.resultado_operacoe_ids:
				resultado_antes_imposto_actual=resultado_antes_imposto_actual+linha.saldo_actual
				resultado_antes_imposto_anterior=resultado_antes_imposto_anterior+linha.saldo_anterior
				
			self.write(cr,uid,documento.id,{'resultado_poc_actual':resultado_antes_imposto_actual,
											'resultado_poc_anterior':resultado_antes_imposto_anterior})
			
		return True
	
		
	
	def on_change_ano_id(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		val={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		#logger.info('ANO ACTUAL %s' %str(ano_fiscal.date_start))
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		#logger.info('ANO ACTUAL %s' %str(ano_actual))
		ano_anterior=ano_actual-1
		#logger.info('ANO ANTERIOR %s' %str(ano_anterior))
		
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
		
		
		#logger.info('DATA INICIO ANO ANTERIOR %s' %str(data_inicio_novo_ano))
		
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			#ano_anterior=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_anterior_ids[0])
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
			periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
			data_fecho=periodo_abertura.date_stop
			val={'ano_fiscal_anterio_id':ano_anterior_ids[0]}
		#else:
		#	raise osv.except_osv(_('Acao Invalida !'), _('Ano fiscal anterior a '+str(ano_actual)+' inesistente')) 
		ano_actual=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		val['periodo_inicial_id'] =  ano_actual.period_ids[0].id
		val['periodo_final_id']=False
		
		return {'value':val}
	
	
dotcom_demostracao_resultados()


class dotcom_demostracao_resultados_linha(osv.osv):
	_name='dotcom.comtabilidade.demostracao.resultados.linha'
	_columns={
		'conta_conf_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco.conf','Activos',readonly=True),
		'saldo_actual':fields.float('Saldo', readonly=True),
		'saldo_anterior':fields.float('Saldo Anterior',readonly=False),
		'notas':fields.char('Notas',size=50),
		
		'resultado_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'resultado_imposto_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'liquido_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		#'resultado_periodo_oc_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'r_operacoes_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'r_aimpostos_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'r_accao_id':fields.many2one('dotcom.comtabilidade.demostracao.resultados','Demosntracao de Resultados'),
		'tem_ano_anterior':fields.boolean('Ano Anterior'),
		'sequence':fields.integer('Sequencia',readonly=True),
		
	}
	
	_rec_name="notas"
	_order='sequence asc'
	
	
dotcom_demostracao_resultados_linha()
