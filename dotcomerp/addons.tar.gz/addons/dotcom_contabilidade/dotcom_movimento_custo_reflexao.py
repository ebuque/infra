# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')

class dotcom_movimento_custo_reflexao(osv.osv):
		
	_name='dotcom.contabilidade.movimento.custo.fluxo'
	_columns={
		'conta_origem_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Conta Origem',required=True),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano de C. Custo',required=True),
		'centro_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','C. Custo',required=True),
		'valor':fields.float('Valor',required=True),
		'valor_total':fields.float('Valor',required=True),
		#'valor_disponivel':fields.float('Valor',required=True),
		'movimento_reflexao_id':fields.many2one('dotcom.contabilidade.movimentos','Movimentos'),
		'lancamento_custo_id':fields.many2one('dotcom.contabilidade.lancamento.movimento.custo','Lancamento'),
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True),
		'percentagem':fields.float('Percentagem (%)',required=True),
		'state':fields.selection([('pai','pai'),('filho','filho')]),
		'parente_sup':fields.many2one('dotcom.contabilidade.movimento.custo.fluxo','Parente'),
		'acerto':fields.selection([('all','MP/MS'),('mp','MP'),('ms','MS')],'Conversão Moeda',help='*MP - Moeda Principal\n*MS - Moeda Secundária'),
	}
	
	_defaults={
		'lancamento_custo_id':lambda self, cr, uid, c: c.get('active_id', False),
		'valor':lambda self, cr, uid, c: c.get('valor', 0),
		'valor_total':lambda self, cr, uid, c: c.get('valor_total', 0),
		'plano_centro_id':lambda self, cr, uid, c: c.get('plano_centro_id', False),
		'natureza':lambda self, cr, uid, c: c.get('natureza', False),
		'conta_origem_id':lambda self, cr, uid, c: c.get('conta_origem_id', False),
		#'movimento_reflexao_id':lambda self, cr, uid, c: c.get('movimento_reflexao_id', False),
		
	}
	_rec_name='natureza'
	
	
	def on_change_plano(self,cr,uid,ids,conta_origem_id,plano,context=None):
		if context==None:
			context={}
		
		conta_origem=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,conta_origem_id)
	   
		logger.info('VALOR %s' % valor)
		return {'value':{'valor':valor}}
		
	
	def on_change_percentagem(self,cr,uid,ids,percentagem,valor,context=None):
		if context==None:
			context={}
		
		logger.info('ENTROU %s' %str(percentagem))
		logger.info('ENTROU %s' %str(valor))
		valor=valor*percentagem/100
		val={'valor':valor}
		return{'value':val}
		
	def on_change_valor(self,cr,uid,ids,valor,valor_total,context=None):
		if context==None:
			context={}
		percentagem=(valor*100)/valor_total
		logger.info('PERCENTAGEM %s' %str(percentagem))
		val={'percentagem':percentagem}
		return{'value':val}

	
	def create(self,cr,uid,values,context=None):
		if context is None:
			context ={}
			
		logger.info('ENTROU %s' %str(values))	 
		parente_directos_ids=self.search(cr,uid,[
			('plano_centro_id','=',values['plano_centro_id']),
			('lancamento_custo_id','=',values['lancamento_custo_id']),
			('conta_origem_id','=',values['conta_origem_id'])
			])
		parente_ids=self.search(cr,uid,[
			('plano_centro_id','!=',values['plano_centro_id']),
			('lancamento_custo_id','=',values['lancamento_custo_id']),
			('conta_origem_id','=',values['conta_origem_id'])
			])
		
		all_parente_ids=self.search(cr,uid,[
				('lancamento_custo_id','=',values['lancamento_custo_id']),
				('conta_origem_id','=',values['conta_origem_id'])
				])
		
		
		logger.info('PARENTES %s' %str(parente_ids))
		logger.info('PARENTES DIRECTOS%s' %str(parente_directos_ids))
		logger.info('TODOS PARENTES %s' %str(parente_directos_ids))
		
		valor=values['valor']
		lancamento_custo_id=values['lancamento_custo_id']
		conta_origem_id=values['conta_origem_id']
		conta_origem=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,conta_origem_id)		   
		
			   
		lancamento_custo=self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').browse(cr,uid,lancamento_custo_id)
		logger.info('LANCAMENTO ORIGEM %s' %str(conta_origem))

		valor_disponivel=lancamento_custo.valor_disponivel
		if len(all_parente_ids)>0:
			if parente_ids.__contains__(all_parente_ids[len(all_parente_ids)-1]):
				logger.info('VALOR %s' %str(all_parente_ids[len(all_parente_ids)-1]))
				valor_disponivel=lancamento_custo.valor_origem
				
			if valor>valor_disponivel:
				raise osv.except_osv(_('Acção Invalida !'), _('O valor de lancamento para o plano nao pode ser superior a '+str(valor_disponivel)))
			linha_lancamento_custo_id=lancamento_custo_id
			conta_origem=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,conta_origem_id)
			
			if len(parente_ids)>0:
				if conta_origem.conta_id.refectir_multipla==True:
					
					logger.info('TODOS PARENTES %s' %str(all_parente_ids))
					lancamento=self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').browse(cr,uid,lancamento_custo_id) 
					#values['movimento_reflexao_id']=lancamento_custo.movimento_id.id
					logger.info('MOVIMENTO ID %s' %str(lancamento_custo.movimento_id.id))
					linha_lancamento_custo_id=super(dotcom_movimento_custo_reflexao, self).create(cr, uid, values, context=context)
					valor_actual=valor_disponivel-valor
				
					self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').write(cr,uid,lancamento_custo_id,{'valor_disponivel':valor_actual})
				else:
					raise osv.except_osv(_('Acção Invalida !'), _('Conta de Origem '+conta_origem.friendly_name+' sem permissao para Reflectir em Multipla Dimensao'))
			else:
				linha_lancamento_custo_id=super(dotcom_movimento_custo_reflexao, self).create(cr, uid, values, context=context)
				valor_actual=valor_disponivel-valor
				
				self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').write(cr,uid,lancamento_custo_id,{'valor_disponivel':valor_actual})
		else:
			lancamento=self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').browse(cr,uid,lancamento_custo_id) 
			#values['movimento_reflexao_id']=lancamento_custo.movimento_id.id
			logger.info('MOVIMENTO ID %s' %str(values))
			linha_lancamento_custo_id=super(dotcom_movimento_custo_reflexao, self).create(cr, uid, values, context=context)
			valor_actual=valor_disponivel-valor
			logger.info('CRIADO COM SUCESSO')
			logger.info('DOCUMENTO PAI %s' %str(lancamento_custo_id))
			self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').write(cr,uid,lancamento_custo_id,{'valor_disponivel':valor_actual})
		
		return linha_lancamento_custo_id
	
	
	def get_antecessor(self,cr,uid,vals,context=None):
		if context is None:
			context={}
			
		conta_id=vals['conta_origem_id']
		#movimento_id=vals['movimento_reflexao_id']
		lancamento_custo_id=vals['lancamento_custo_id']
		lancamento=self.pool.get('dotcom.contabilidade.lancamento.movimento.custo').browse(cr,uid,lancamento_custo_id)
		parentes_ids=self.search(cr,uid,[
			('conta_origem_id','=',conta_id),
			('state','=','pai'),
			('lancamento_custo_id','=',lancamento_custo_id),
			('valor','=',lancamento.valor_origem)
			])
		if len(parentes_ids)>0:
			parente_id=parentes_ids[len(parentes_ids)-1]
			parente=self.browse(cr,uid,parente_id)
		else:
			parente=None
		return parente
	
	
	#def validar_valor(self,cr,uid,vals,valor,context=None):
	#	if context is None:
	#		context={}
	#	lancamento_custo_id=vals['lancamento_custo_id']			
			
			

dotcom_movimento_custo_reflexao()



class dotcom_contabilidade_lancamento_movimento_custo(osv.osv):
	_name='dotcom.contabilidade.lancamento.movimento.custo'
	_columns={
		'lancamentos_reflexao_custo_ids':fields.one2many('dotcom.contabilidade.movimento.custo.fluxo','lancamento_custo_id','Lancamentos'),
		'valor_origem':fields.float('Valor', readonly=True),
		'valor_disponivel':fields.float('Valor'),
		'state':fields.selection([('rascunho','Rascunho'),('emitido','Emitido')]),
		'conta_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Origem',readonly=True),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano de C. Custo'),
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimentos'),
	}
	
	_rec_name='valor_origem'
 
 
	def actualizar(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		return True
	
	
	def fechar(self,cr,uid,ids,context=None):
		if context==None:
			context={}		
		for documento in self.browse(cr,uid,ids):
			lista_planos=[]
			for linha in documento.lancamentos_reflexao_custo_ids:
				if lista_planos.__contains__(linha.plano_centro_id.id):
					continue
				else:
					lista_planos.append(linha.plano_centro_id.id)
			
			for plano in lista_planos:
				plano_obj=self.pool.get('dotcom.contabilidade.centros.custos').browse(cr,uid,plano)
				linhas_lancamento_ids=self.pool.get('dotcom.contabilidade.movimento.custo.fluxo').search(cr,uid,[
										('plano_centro_id','=',plano),
										('lancamento_custo_id','=',documento.id)
					])
				total_plano=0
				for linhas_plano in linhas_lancamento_ids:
					linha_obj=self.pool.get('dotcom.contabilidade.movimento.custo.fluxo').browse(cr,uid,linhas_plano)
					total_plano=total_plano+linha_obj.valor
				if total_plano<documento.valor_origem:
					raise osv.except_osv(_('Acção Invalida !'), _('O valor Total para o plano '+str(plano_obj.ref)+' nao pode ser inferior a '+str(documento.valor_origem)))
				elif total_plano>documento.valor_origem:
					raise osv.except_osv(_('Acção Invalida !'), _('O valor Total para o plano '+str(plano_obj.ref)+' nao pode ser superior a '+str(documento.valor_origem)))
			
			for linha in documento.lancamentos_reflexao_custo_ids:
				self.pool.get('dotcom.contabilidade.movimento.custo.fluxo').write(cr,uid,linha.id,{
					'movimento_reflexao_id':documento.movimento_id.id
					})
		return {}	
			
dotcom_contabilidade_lancamento_movimento_custo()