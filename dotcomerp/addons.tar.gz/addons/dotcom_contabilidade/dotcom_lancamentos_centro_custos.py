# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from validators import validator
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')



class dotcom_lancamentos_centro_custo(osv.osv):
	
	def _valor_moeda_base(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
			
		res={}
		for documento in self.browse(cr,uid,ids):
			
			moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.id)
																											])
			
			if len(lancamento_diarios_ids)>0:
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_primaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					#moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)
					
									
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					res[documento.id]=valor_lancamento_cambiado
				
		return res
	
	
	def _valor_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		for documento in self.browse(cr,uid,ids):
			
			moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.id)
																											])
			if len(lancamento_diarios_ids)>0:	
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_secundaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_secundario=lancamento_diario_object.cambio_secundario
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					
					
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_secundario
					res[documento.id]=valor_cambiado_moeda_secundaria
				
		return res
	
	
	
		
	_name='dotcom.contabilidade.lancamentos.centro.custo'
	_columns={
		#'conta_origem_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Conta Origem',required=True),
		
		
		'valor':fields.float('Valor',readonly=True),		
		'valor_moeda_base':fields.function(_valor_moeda_base, type='float', string='Valor na M. Base', method=True, store=True),
		'valor_moeda_secundaria':fields.function(_valor_moeda_secundaria, type='float', string='Valor na M. Secundaria', method=True, store=True),
		
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Origem',required=False,readonly=True ),
		'valor_total':fields.float('Valor',),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos'),
		'data':fields.date('Data'),
		'lancamentos_custo_linhas':fields.one2many('dotcom.contabilidade.lancamento.centro.custo.linha','lancamento_custo_id','Lancamentos',ondelete="cascade"),
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True),
		'multi_dimention':fields.boolean('Multi-Dimention',readonly=True),
		'acerto':fields.selection([('all','MP/MS'),('mp','MP'),('ms','MS')],'Conversão Moeda',help='*MP - Moeda Principal\n*MS - Moeda Secundária'),
		'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=False,readonly=True, ),
		#'lancamento_diario_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Movimento')
		'estado_moviimento':fields.related('movimento_id','state',type='char',relation='dotcom.contabilidade.movimentos',string='Estado',store=True),
	}
	
	_defaults={
		'valor_total':0,
		'valor':0
	}
	
	_rec_name='valor'
	
	
	
	def unlink(self, cr,uid,ids,context):
		if context is None:
			contex={}
		documento = self.browse(cr,uid,ids[0])
		logger.info('CENTRO DE CUSTO A SER APAGADO %s' %str(documento.id))
		
		lista=[]
		lista.append(documento.id)
		for linha in documento.lancamentos_custo_linhas:
			self.pool.get('dotcom.contabilidade.lancamento.centro.custo.linha').unlink(cr,uid,linha.id)
		osv.osv.unlink(self, cr, uid, lista, context=context)
		return True
			  
	
	def actualizar_lancamento(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		logger.info('\n\nIDS: %s' % ids)
		for documento in self.browse(cr,uid,ids):
			if len(documento.lancamentos_custo_linhas)>1:
				if documento.multi_dimention==False and len(documento.lancamentos_custo_linhas)>1:
					raise osv.except_osv(_('Acção Inválida !'), _('Conta sem permissão para Lançamentos em Múltipla Dimensão!!'))
		return {}
	

	def write(self,cr,uid,ids,values,context=None):
		if context is None:
			context={}
		
		done = super(dotcom_lancamentos_centro_custo, self).write(cr, uid, ids, values, context=context)
		chaves=values.keys()
		logger.info('IDENTIFICADOR PROVENIENTE DA LEITURA %s' %str(ids))
		#identificador=ids[0]
		
		parsed_ids = []
		try:
			if type(ids) in [list,tuple]:
				for each in ids:
					res = None
					if type(each) is tuple:
						res = each and each[0]
					else:
						res = each
					parsed_ids.append(res)
			else:
				parsed_ids.append(ids)
		except Exception:
			pass
		
		logger.info('PARSED: %s' % parsed_ids)
		
		#if type(ids)!=list:
		#	lista=[]
		#	lista.append(ids)
		#	ids=lista
		reads = []
		
		#
		#read(cr, uid, ids, ['lancamentos_custo_linhas','natureza','valor','id'])
		#for
		for reads in self.browse(cr, uid, parsed_ids):
			#id = reads.id
			#reads = self.browse(cr,uid,id)
			#logger.info('IDENTIFICADOR DO OBJECTO %s' %str(reads))
			lancamentos_custo_linhas = reads.lancamentos_custo_linhas
			logger.info('CUSTO LINHAS: %s' % lancamentos_custo_linhas)
			for lancamentos_linhas in lancamentos_custo_linhas:
				for chave in chaves:
					writes = {}
					if chave=='natureza':
						writes['natureza'] = values.get('natureza', False)
					if chave == 'valor':
						writes['valor'] = values.get('valor', False)
					self.pool.get('dotcom.contabilidade.lancamento.centro.custo.linha').write(cr,uid,lancamentos_linhas.id, writes)
		return done



dotcom_lancamentos_centro_custo()

class dotcom_lancamento_centro_custo_linha(osv.osv):
	
	def _valor_moeda_base(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
			
		res={}
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.lancamento_custo_id.id)
																											])
			
			if len(lancamento_diarios_ids)>0:
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_primaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					#moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)
					
									
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					res[documento.id]=valor_lancamento_cambiado
				
		return res
	
	
	def _valor_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.lancamento_custo_id.id)
																											])
			
			if len(lancamento_diarios_ids)>0:
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_secundaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_secundario=lancamento_diario_object.cambio_secundario
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					
					
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_secundario
					res[documento.id]=valor_cambiado_moeda_secundaria
				
		return res
	
	
	_name='dotcom.contabilidade.lancamento.centro.custo.linha'
	_columns={
		
		'valor':fields.float('Valor Total', readonly=True),
		'valor_moeda_base':fields.function(_valor_moeda_base, type='float', string='Valor na M. Base', method=True, store=True),
		'valor_moeda_secundaria':fields.function(_valor_moeda_secundaria, type='float', string='Valor na M. Secundaria', method=True, store=True),
		'percentagem':fields.float('Percentagem (%)',),
		'valor_disponivel':fields.float('Valor Disponivel'),
		'data':fields.date('Data'),
		'state':fields.selection([('rascunho','Rascunho'),('emitido','Emitido')]),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano C. Custo',required=False),
		
		'lancamento_custo_id':fields.many2one('dotcom.contabilidade.lancamentos.centro.custo','Lancamento'),
		
		'adicao_lancamento_id':fields.many2one('dotcom.contabilidade.adicao.linhas.centro','Adicao',ondelete="cascade"),
		
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento'),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=False,),
		'gravado':fields.boolean('Gravado'),
		'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		#'state':fields.related('Estado', size=30),
		#'state':fields.related('lancamento_custo_id','estado_moviimento',type='char',relation='dotcom.contabilidade.lancamentos.centro.custo',string='Estado',store=True),
	}
	
	_defaults={
		#'state':lambda self, cr, uid, c: c.get('state', False),
		'movimento_id':lambda self, cr, uid, c: c.get('movimento_id', False),
		'lancamento_custo_id':lambda self, cr, uid, c: c.get('lancamento_custo_id', False),
		'data':lambda self, cr, uid, c: c.get('data', 0),
		'valor':lambda self, cr, uid, c: c.get('valor', 0),
		'periodo_id':lambda self, cr, uid, c: c.get('periodo_id', 0),
		'conta_id':lambda self, cr, uid, c: c.get('conta_id', 0),
		'natureza':lambda self, cr, uid, c: c.get('natureza', 0),
	}
	
	
	_sql_constraints = [
		('name_uniq', 'unique (plano_centro_id, lancamento_custo_id)', 'Plano seleccionado já tem lançamento nas linhas anteriores !'),
	]
	
	_rec_name='data'
	
	
	def unlink(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		
		lista=[]
		if type(ids)==list:
			lista=ids
		else:
			lista.append(ids)
		lista_apagavel=[]
		
		for item in lista:
			local_object=self.browse(cr,uid,item)
			logger.info('DOCUMENTOS A SEREM AOPAGADOS %s' %str(local_object))
			
			if bool(local_object.adicao_lancamento_id.id)==True:		
				osv.osv.unlink(self, cr, uid, [local_object.id], context=context)
				self.pool.get('dotcom.contabilidade.adicao.linhas.centro').unlink(cr,uid,local_object.adicao_lancamento_id.id,context=context)
			else:
				osv.osv.unlink(self, cr, uid, [local_object.id], context=context)
		
		return True
	
	
	def guardar_linha(self,cr,uid,ids,context=None):
		if context is None:
			context={}		   
		return{}

	
	def create(self,cr,uid,values,context=None):
		if context is None:
			ccontext={}
		values['gravado']=True
		lancamento_id=values['lancamento_custo_id']
		lancamento=self.pool.get('dotcom.contabilidade.lancamentos.centro.custo').browse(cr,uid,lancamento_id)
		
		values['natureza']=lancamento.natureza
		ident=False
		if (lancamento.multi_dimention==False) and len(lancamento.lancamentos_custo_linhas)>=1:
			raise osv.except_osv(_('Invalid action !'), _('Conta sem permissão para Lançamentos em Múltipla Dimensão!!'))
		else:
			
			values['valor']=lancamento.valor
			
			ident=super(dotcom_lancamento_centro_custo_linha, self).create(cr, uid, values, context=context)
		return ident
	
	
	def on_change_plano(self,cr,uid,ids,valor,plano_centro_id,lancamento_custo_id,context=None):
		if context is None:
			context={}
		
		identificador=None
		lancamento_object=self.pool.get('dotcom.contabilidade.lancamentos.centro.custo').browse(cr,uid,lancamento_custo_id)
		logger.info('OBJECT AXHADO NA PESQUISA %s' %str(ids))
		#if (lancamento_object.multi_dimention==False) :
		#	if (len(lancamento_object.lancamentos_custo_linhas)>0):
		#		raise osv.except_osv(_('Invalid action !'), _('Conta sem Reflexao a Multipla Dimensao!!'))
		
		if len(ids)<=0:
			
			val={
			   'valor':valor,
			   'plano_centro_id':plano_centro_id,
			   'lancamento_custo_id':lancamento_custo_id
			}
			identificador=self.create(cr,uid,val)
			logger.info('ENTROU PRA CRIAR O OBJECTO %s' %str(identificador))
		else:
			identificador=ide[0]
		context['identificador']=identificador
		return{}
			
	
	def adicionar_linhas_lancamento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		idenificador=None
		estado=False
		for documento in self.browse(cr,uid,ids):
			logger.info('IDENTIFICAOR DO PLANO DO VIEW ADICAO 1 %s' %str(documento.adicao_lancamento_id.id))
			#movimento_id=documento.lancamento_custo_id.estado_moviimento
			estado=documento.lancamento_custo_id.estado_moviimento
			
			if bool(documento.adicao_lancamento_id.id)==False:
				if bool(documento.plano_centro_id.id)==False:
					raise osv.except_osv(_('Invalid action !'), _('Seleccione o Plano de Centro de Custos!!'))
				val={
					'valor_total':documento.valor,
					'valor_disponivel':documento.valor,
					'plano_id':documento.plano_centro_id.id,
					'lancamento_id':documento.lancamento_custo_id.id,
					'periodo_id':documento.periodo_id.id,
					'conta_id':documento.conta_id.id,
					'natureza':documento.natureza,
					'data':documento.data
				}
				logger.info('IDENTIFICAOR DO VIEW ADICAO %s' %str(val))
			
				idenificador=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').create(cr,uid,val)
				self.write(cr,uid,documento.id,{'adicao_lancamento_id':idenificador})
			else:
				idenificador=documento.adicao_lancamento_id.id
		
		self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,idenificador,{'state':estado}) 
		return {
			'type': 'ir.actions.act_window',
			'name': 'Adicionar Linhas ao Lancamento',
			'view_mode': 'form',
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.adicao.linhas.centro',
			'res_id':idenificador,
			'target': 'new',
			'context': context,
			'nodestroy': False,
		}
		
	def on_change_plano_centro(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		
		val= self.adicionar_linhas_lancamento(cr,uid,ids)
		logger.info('ENTROU NO ON-CHANGE PRESTE ATENCAO %s' %str(val))
		return{'value':val}

dotcom_lancamento_centro_custo_linha()


class dotcom_adicao_linhas_centro_custos(osv.osv):
	
	def _valor_moeda_base(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
			
		res={}
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			logger.info('IDENTIFICADOR DO OBJECTO ACHADO %s' %str(documento.lancamento_id))
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.lancamento_id.id)
																											])
			
			if len(lancamento_diarios_ids)>0:
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_primaria_id:
					res[documento.id]=documento.valor_total
				
				else:
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					#moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)
					
									
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor_total
					res[documento.id]=valor_lancamento_cambiado
				
		return res
	
	
	def _valor_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
																											('lancamentos_custo_id','=',documento.lancamento_id.id)
																											])
			
			if len(lancamento_diarios_ids)>0:
				lancamento_diario_object=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento_diarios_ids[0])
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_secundaria_id:
					res[documento.id]=documento.valor_total
				
				else:
					cambio_secundario=lancamento_diario_object.cambio_secundario
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					
					
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor_total
					valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_secundario
					res[documento.id]=valor_cambiado_moeda_secundaria
				
		return res
	
	
	_name='dotcom.contabilidade.adicao.linhas.centro'
	_columns={
		'valor_total':fields.float('Valor Total',readonly=True),
		#'data':fields.date('Data'),

		'data':fields.related('movimento_id','data',type='date',string='Data',readonly=True,store=True),

		'ano_fiscal_id':fields.related('movimento_id','ano_fiscal_id',type='many2one',relation='configuration.fiscalyear',string='Ano Fiscal',readonly=True,store=True),
		#'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False,readonly=True,),
		'valor_moeda_base':fields.function(_valor_moeda_base, type='float', string='Valor na M. Base', method=True, store=True),
		'valor_moeda_secundaria':fields.function(_valor_moeda_secundaria, type='float', string='Valor na M. Secundaria', method=True, store=True),

		'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=False,readonly=True),
		#'moeda_lancamento_id':fields.related('movimento_id','moeda_lancamento_id',type='many2one',relation='res.currency',string='Moeda',readonly=True,store=True),

		#'moeda_primaria_id':fields.related('movimento_id','moeda_primaria_id',type='many2one',relation='res.currency',string='Moeda Primaria',readonly=False,store=True),

		'valor_disponivel':fields.float('Valor Disponivel',readonly=True),
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True,),
		'plano_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano C. Custo',readonly=True),
		'linha_lancamento_id':fields.many2one('dotcom.contabilidade.lancamento.centro.custo.linha','Lancamento'),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',readonly=True,),
		#'conta_id':fields.related('lancamento_diario_id','conta_id',type='many2one',relation='dotcom.contabilidade.plano.contas',string='Conta',readonly=True,),
		'conta_selection':fields.many2one('dotcom.contabilidade.centros.custos.account.selection','Conta a Reflectir'),

		'hide_selection_field':fields.selection([
			 ('yes','Hide'),
			 ('no','Show')],'Show selection field'),

		'lancamento_id':fields.many2one('dotcom.contabilidade.lancamentos.centro.custo','Lancamento'),
		'lancamento_diario_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios', 'Lancamento Diario'),
		#'periodo_id':fields.many2one('configuration.period','Período',readonly=True),

		'periodo_id':fields.related('movimento_id','periodo',type='many2one',relation='configuration.period',string='Periodo',readonly=True,store=True),

		'linhas_adicao_ids':fields.one2many('dotcom.contabilidade.adicao.linhas.centro.linha','adicao_id','Linhas',ondelete="cascade"),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos'),
		'estado_moviimento':fields.related('movimento_id','state',type='char',relation='dotcom.contabilidade.movimentos',string='Estado',store=True),
		'state':fields.char('Estado', size=30),
	}
	
	_rec_name='valor_total'
	
	
	def unlink(self, cr,uid,ids,context):
		if context is None:
			contex={}
		lista=[]
		if type(ids)==list:
			lista=ids
		else:
			lista.append(ids)	
		documento = self.browse(cr,uid,lista[0])
		logger.info('IDENTIFICADORES ACHADOS %s' %str(documento))
		lista=[]
		lista.append(documento.id)
		for linha in documento.linhas_adicao_ids:
			self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').unlink(cr,uid,linha.id)
		osv.osv.unlink(self, cr, uid, lista, context=context)
		return True
	
	def guardar_linhas(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			total_percentagem=0
			total_valor=0
			for linha in documento.linhas_adicao_ids:
				total_percentagem=total_percentagem+linha.percentagem
				total_valor=total_valor+linha.valor
				
				if documento.ano_fiscal_id.id!=linha.centro_id.ano_fiscal_id.id:
					raise osv.except_osv(_('Invalid action !'), _('O centro de custos '+linha.centro_id.friendly_name+' não corresponde ao ano fiscal do lançamento!!'))
				
			total_valor=round(total_valor, 2)
			valor_documento=round(documento.valor_total, 2)
			logger.info('PENCENTAGEM JA OCUPADA %s' %str(total_percentagem))
			logger.info('VALOR JA OCUPADO %s' %str(total_valor))
			logger.info('VALOR JA OCUPADO %s' %str(documento.valor_total))
			
			if (total_valor!=valor_documento) or (total_percentagem!=100):
				raise osv.except_osv(_('Invalid action !'), _('O valor total lançado no(s) centro(s) de custos não pode ser diferente de 100%!!'))
			
			lancamento_diario_model=self.pool.get('dotcom.contabilidade.lancamentos.diarios')
			dict_lancamento_data={
				'activar_popup_centro_custos':True,
				'adicao_centro_custo_id':documento.id,
			}
			lanc_id=documento.lancamento_diario_id.id
			logger.info('VALOR lanc_id %s' %str(lanc_id))
			lancamento_diario_model.write(cr,uid,lanc_id,dict_lancamento_data)
			self.write(cr,uid,ids,{'hide_selection_field':'yes'})

			model_account_selection= self.pool.get('dotcom.contabilidade.centros.custos.account.selection')
			account_selection_ids =model_account_selection.search(cr,uid,[])

			lanc_obj=lancamento_diario_model.browse(cr,uid,lanc_id)
			vals={
			'movimento_id':lanc_obj.movimento_id.id,
			}
			

			logger.info('documento.conta_selection %s' %str(documento.conta_selection.id))
			id_selection_element=documento.conta_selection.id
			model_account_selection.unlink(cr,uid,id_selection_element)
			if len(account_selection_ids)==0:
				return True

			identificador=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').create(cr,uid,vals)
			
		return {
			'type': 'ir.actions.act_window',
			'name': 'Centro de Custos',
			'view_mode': 'form',
			'view_type': 'form',
			'res_model': 'dotcom.contabilidade.adicao.linhas.centro',
			'res_id':identificador,
			'target': 'new',
			'context': context,
			'nodestroy': True,
		}



	def on_change_conta_selection(self,cr,uid,ids,conta_selection,context=None):
		if context is None:
			context={}
		
		logger.info('conta_selection %s' %str(conta_selection))
		model_account_selection= self.pool.get('dotcom.contabilidade.centros.custos.account.selection')

		conta_selection_objet=model_account_selection.browse(cr,uid,conta_selection)
		logger.info('conta_selection_objet %s' %str(conta_selection_objet))
		values={
			'valor_total':conta_selection_objet.valor,
			'natureza':conta_selection_objet.natureza,
			'conta_id':conta_selection_objet.conta_id.id,
			'lancamento_diario_id':conta_selection_objet.lancamento_id.id,

		}
		self.write(cr,uid,ids,values)
		logger.info('on_change_conta_selection  %s' %str(values))
		return {'value':values}
	
dotcom_adicao_linhas_centro_custos()


class dotcom_adicao_linhas_centro_linha(osv.osv):
	
  
	def _valor_moeda_base(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
			
		res={}
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			#logger.info('IDENTIFICADOR DO OBJECTO ACHADO %s' %str(documento.lancamento_id))
			
			#lancamento_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
			#																								('adicao_centro_custo_id','=',documento.adicao_id.lancamento_diario_id.id)
			#																								])
			
			logger.info('NUMERO DE LANCAMENTOS ACHADOS NO MOMENTO %s' %str(documento.adicao_id.lancamento_diario_id))
			if documento.adicao_id.lancamento_diario_id.id!=False:
				lancamento_diario_object=documento.adicao_id.lancamento_diario_id
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_primaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					#moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)
					
									
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					res[documento.id]=valor_lancamento_cambiado or 0
				
		return res
	
	
	def _valor_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		
		logger.info('-------PROCESSO DE MOEDAS A INICIAR------')
		for documento in self.browse(cr,uid,ids):
			
			#moeda_lancamento=documento.moeda_lancamento_id
			moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
			moeda_secundaria_id=moeda_secundaria_id[0]
			
			
			logger.info('NUMERO DE LANCAMENTOS ACHADOS NO MOMENTO %s' %str(documento.adicao_id.lancamento_diario_id))
			
			if documento.adicao_id.lancamento_diario_id.id!=False:
				lancamento_diario_object=documento.adicao_id.lancamento_diario_id
				if lancamento_diario_object.moeda_lancamento_id.id==lancamento_diario_object.moeda_secundaria_id:
					res[documento.id]=documento.valor
				
				else:
					cambio_secundario=lancamento_diario_object.cambio_secundario
					cambio_moeda_lancamento=lancamento_diario_object.cambio
					
					
					valor_lancamento_cambiado=cambio_moeda_lancamento*documento.valor
					valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_secundario
					res[documento.id]=valor_cambiado_moeda_secundaria or 0
				
		return res
	
	def _estado(self,cr,uid,ids,field,arg,context=None):
		if context is None:
			context={}
		
		res={}
		
		logger.info('-------PROCESSO DE MOEDAS A INICIAR------')
		for documento in self.browse(cr,uid,ids):
			
			if documento.estado_movimento=='rascunho':
				estado='Rascunho'
			elif documento.estado_movimento=='emitido':
				estado='Emitido'
			if documento.estado_movimento=='cancelado':
				estado='Cancelado'
			if documento.estado_movimento=='outro_rascunho':
				estado='Rascunho'
			res[documento.id]=estado
				
		return res
	
	
	_name='dotcom.contabilidade.adicao.linhas.centro.linha'
	_columns={
		'adicao_id':fields.many2one('dotcom.contabilidade.adicao.linhas.centro','Adicao Linhas'),
		#'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=True),
		'ano_fiscal_id':fields.related('adicao_id','ano_fiscal_id',type='many2one',relation='configuration.fiscalyear',string='Ano Fiscal',readonly=True,store=True),
		#'data':fields.date('Data'),
		'data':fields.related('movimento_id','data',type='date',string='Data',readonly=True,store=True),

		'valor':fields.float('Valor'),
		'valor_moeda_base':fields.function(_valor_moeda_base, type='float', string='Valor na M. Base', method=True, store=True),
		'valor_moeda_secundaria':fields.function(_valor_moeda_secundaria, type='float', string='Valor na M. Secundaria', method=True,store=True),
		
		'valor_anterior':fields.float('Valor Anterior'),
		'percentagem':fields.float('Percentagem (%)'),
		#'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		'periodo_id':fields.related('movimento_id','periodo',type='many2one',relation='configuration.period',string='Periodo',readonly=True,store=True),
		'plano_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano C. Custo'),
		#'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',readonly=True,),
		'conta_id':fields.related('adicao_id','conta_id',type='many2one',relation='dotcom.contabilidade.plano.contas',string='Conta',readonly=True,store=True),
		'natureza':fields.selection([('debito','D'),('credito','C')],'Natureza',readonly=True),
		'centro_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','C. Custo', domain="[('ano_fiscal_id','=',ano_fiscal_id)]",required=True),
		
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos'),
		'estado_movimento':fields.related('movimento_id','state',type='char',relation='dotcom.contabilidade.movimentos',string='Estado'),
		'state': fields.function(_estado, type='char', string='Estado', method=True,),
		#'valor_moeda_primaria':fields.float('Valor MP'),
		#'valor_moeda_secundaria':fields.float('Valor MS'),
		'moeda_primaria_id':fields.many2one('res.currency','Moeda Primaria',),
		#'moeda_primaria_id':fields.related('movimento_id','moeda_primaria_id',type='many2one',relation='res.currency',string='Moeda Primaria',readonly=False,store=True),

		'moeda_lancamento_id': fields.many2one('res.currency','Moeda de Lançamento',required=False,readonly=True),
		#'moeda_lancamento_id':fields.related('movimento_id','moeda_lancamento_id',type='many2one',relation='res.currency',string='Moeda de Lançamento',readonly=False,store=True),

		'moeda_secundaria_id': fields.many2one('res.currency','Moeda Secundária',required=False),
		#'moeda_secundaria_id':fields.related('movimento_id','moeda_secundaria_id',type='many2one',relation='res.currency',string='Moeda Secundária',readonly=False,store=True),

	}
	
	
	_defaults={
		'adicao_id':lambda self, cr, uid, c: c.get('adicao_id', False),
		'data':lambda self, cr, uid, c: c.get('data', 0),
		'valor_anterior':0,
		#'plano_id':lambda self, cr, uid, c: c.get('plano_id', False),
		'periodo_id':lambda self, cr, uid, c: c.get('periodo_id', False),
		'conta_id':lambda self, cr, uid, c: c.get('conta_id', 0),
		'natureza':lambda self, cr, uid, c: c.get('natureza', 0),
		'ano_fiscal_id':lambda self, cr, uid, c: c.get('ano_fiscal_id', 0),
	}
	
	
	def create(self,cr,uid,values,context=None):
		if context is None:
			ccontext={}
		
		centro_id=values['centro_id']
		centro_objet=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro_id)
		if centro_objet.tipo_interno!='m':
			raise osv.except_osv(_('Acção Inválida !'), _('Tipo de Conta não permitido!!'))
		
		lancamento_id=values['adicao_id']
		
		logger.info('lancamento_id ID %s' %str(lancamento_id))
		
		
		lancamento=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,lancamento_id)
		logger.info('lancamento ID %s' %str(lancamento))
		logger.info('lancamento lancamento diario conta ID %s' %str(lancamento.lancamento_diario_id))
		#logger.info('ADICAO ID %s' %str(lancamento))
		values['natureza']=lancamento.natureza
		values['conta_id']=lancamento.conta_id.id
		values['movimento_id']=lancamento.movimento_id.id
		logger.info('VALOR A SER CRIADO NO MOMENTO %s' %str(values))
		ident=super(dotcom_adicao_linhas_centro_linha, self).create(cr, uid, values, context=context)
		return ident
	
	
	def on_change_centro_custos(self,cr,uid,ids,centro_id,context=None):
		if context is None:
			context={}
		
		logger.info('IDENTIFICADOR DO CENTRO DE CUSTOS %s' %str(centro_id))
		centro_objet=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,centro_id)
		logger.info('IDENTIFICADOR DO CENTRO DE CUSTOS %s' %str(centro_objet))
		if centro_objet.tipo_interno!='m':
			raise osv.except_osv(_('Acção Inválida !'), _('Tipo de Conta não permitido!!'))
		return {}
	
	def on_change_valor(self,cr,uid,ids,valor,valor_anterior,adicao_id,context=None):
		if context is None:
			context={}
		
		
		logger.info('VALOR DISPONIVEL NO PAI %s' %str(valor_anterior))
		val={}
		
		adicao_object=False
		if adicao_id!=False:
			adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,adicao_id)
		
		else:
			for documento in self.browse(cr,uid,ids):
				adicao_object=documento.adicao_id
		
		#
		#else:
		if valor_anterior>valor:
			diferenca_valores=0
			diferenca_valores=valor_anterior-valor
			self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,adicao_object.id,{
									'valor_disponivel':adicao_object.valor_disponivel+diferenca_valores
								})
			
			#adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,adicao_id)
			diferenca_totais=0
			diferenca_totais=adicao_object.valor_total-adicao_object.valor_disponivel
			if diferenca_totais>adicao_object.valor_total:
				raise osv.except_osv(_('Invalid action !'), _('Valor introduzido superior ao disponivel (if)' ))
			
		elif valor_anterior<valor:
			diferenca_valores=0
			diferenca_valores=valor-valor_anterior
			self.pool.get('dotcom.contabilidade.adicao.linhas.centro').write(cr,uid,adicao_object.id,{
									'valor_disponivel':adicao_object.valor_disponivel+diferenca_valores
								})
			
			#adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,adicao_id)
			diferenca_totais=0
			diferenca_totais=adicao_object.valor_total-adicao_object.valor_disponivel
			logger.info('VALOR diferenca_totais %s' %str(diferenca_totais))
			logger.info('VALOR adicao_object.valor_total NO PAI %s' %str(adicao_object.valor_total))
			if diferenca_totais>adicao_object.valor_total:
				raise osv.except_osv(_('Invalid action !'), _('Valor introduzido superior ao disponivel (elif)'))
				
		percentagem=valor*100/adicao_object.valor_total
	
		val={'percentagem':percentagem,'valor_anterior':valor}
		
		return {'value':val}
		
		
		
	
	def on_change_percentagem(self,cr,uid,ids,percentagem,adicao_id,context=None):
		if context is None:
			context={}
			
		val={}
		
		if percentagem>100:
				raise osv.except_osv(_('Acção Inválida !'), _('Percentagem não deve ser superior a 100 (%)!!'))
			
		if adicao_id!=False:
			adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,adicao_id)
			valor=percentagem*0.01*adicao_object.valor_total
			val={'valor':valor}
			logger.info('PERCENTAGEM INSERIDA %s' %str(percentagem))
		
		else:
			for documento in self.browse(cr,uid,ids):
				logger.info('PERCENTAGEM INSERIDA %s' %str(percentagem))
			
			
				adicao_object=documento.adicao_id
				valor=percentagem*0.01*adicao_object.valor_total
				val={'valor':valor}
		return {'value':val}

dotcom_adicao_linhas_centro_linha()