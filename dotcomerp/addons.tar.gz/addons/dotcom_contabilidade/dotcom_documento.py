# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')

class dotcom_contabilidade_documento(osv.osv):
	
	def _friendly_name(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			nome = plano.nome or ''
			friendly_name = '['+ref + '] ' + nome
			res[plano.id] = friendly_name
		return res
	
	
	def _referencia_gerada(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for plano in self.browse(cr, uid, ids, context=context):
			ref = plano.ref and plano.ref or ''
			ano = plano.ano_fiscal_id.code or ''
			friendly_name = ref + '/' + ano
			res[plano.id] = friendly_name
		return res
	
	
	_name='dotcom.contabilidade.documento'
	_columns={
			'ref':fields.char('Ref',required=True,size=25),
			'nome':fields.char('Nome',required=True,size=50),
			'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=False),
			'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
			'conta_defeito_debito':fields.many2one('dotcom.contabilidade.plano.contas','Conta Defeito Débito'),
			'conta_defeito_credito':fields.many2one('dotcom.contabilidade.plano.contas','Conta Defeito Crédito'),
			'balanceamento_financeira':fields.boolean('Balanceamento Financeiro'),
			'balanceamento_analitica':fields.boolean('Balanceamento Analítico'),
			'fluxo_de_caixa_id':fields.many2one('dotcom.contabilidade.fluxo.caixa','Fluxo de Caixa',required=False),
			'numero_por_periodo':fields.char('Numero por periodo',size=50,readonly=True),
			'sequenciador_ids':fields.one2many('dotcom.contabilidade.sequenciador','documento_id','Sequênciador', readonly=True),
			
			'friendly_name': fields.function(_friendly_name, type='char', string='Documento', method=True, store=True),
			'referencia_gerada': fields.function(_referencia_gerada, type='char', string='Referencia Gerada', method=True, store=True),
		}
	
	_rec_name='friendly_name'
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	
	_sql_constraints = [
		('name_uniq', 'unique (referencia_gerada,ano_fiscal_id)', 'Já foi criado o Documento para este Ano Fiscal!!'),
	]
	
			
	
	def create(self,cr,uid,vals,context=None):
		if context is None:
			context={}
		values={}
   
		values['padding']=3
		values['number_increment']=1
		values['fiscal_year_id']=vals['ano_fiscal_id']
		logger.info('VALUES %s' % str(values))
		documento_id=super(dotcom_contabilidade_documento, self).create(cr,uid,vals,context=context)
		values['documento_id']=documento_id
		sequencia_ids=self.pool.get('dotcom.contabilidade.sequenciador').create(cr,uid,values)
		#logger.info('SEQUENCIA %s' % str(sequencia_ids))
		
		
		#logger.info('DIARIO %s' % str(documento_id))
		#for seq in sequencia_ids:
		#	self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,seq,{'documento_id':documento_id})
		return  documento_id
	
	
	def generate_sequence(self, cr, uid,sequence_id,data, document_id,movimento_id,context=None):
		documento_pool = self.pool.get('dotcom.contabilidade.documento')
		documento = documento_pool.browse(cr,uid,document_id)
		movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento_id)
		doc_number = ''
		if movimento.numero_documento is False or movimento.numero_documento=='':
			#sequence_id = documento.sequence_id.id
			if sequence_id:
				sequence_obj = self.pool.get('dotcom.contabilidade.sequenciador')
				sequence = sequence_obj.browse(cr,uid,sequence_id)

				now = datetime.now()
				year = int(now.year)
				
				day = data
				doc_date = datetime(*(time.strptime(day, '%Y-%m-%d')[0:6]))
				date_year = doc_date.strftime('%Y')
				logger.info('SEQUENCIA %s' %str(sequence.periodo_id.code))
				if (int(sequence.fiscal_year_id.code)!=int(date_year)):
					raise osv.except_osv(_('Invalid action !'), _('The document date - Fiscal year ERROR'))
				else:
					doc_number =sequence_obj.next_by_id(cr, uid, sequence_id) or sequence_obj.next_by_code(cr, uid, sequence.code)
		else:
			doc_number = documento.numero_por_periodo
		
		documento_pool.write(cr,uid,documento.id,{'document_number':doc_number})
		self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'numero_documento':doc_number})
		return doc_number
	
dotcom_contabilidade_documento()
