# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_RESULTADOS')

class dotcom_simulacao_resultados(osv.osv):
	_name='dotcom.contabilidade.simulacao.resultado'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True,),
		'data':fields.date('Data'),
		'periodo':fields.many2one('configuration.period','Mês',readonly=False, required=True, domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		
		#Configuração do balaço
		'apuramentos_ids':fields.one2many('dotcom.contabilidade.simulacao.apuramento','simulacao_resultado_id','Apuramentos'),
		
		#Linhas do balanço
		'activos_nao_correntes_ids':fields.one2many('dotcom.contabilidade.simulacao.balanco.linha','balanco_activo_nao_corente_id', 'Activos Nao Correntes', ),
		'activos_correntes_ids':fields.one2many('dotcom.contabilidade.simulacao.balanco.linha','balanco_activo_corente_id','Activos Correntes', ),
		'capital_proprio_ids':fields.one2many('dotcom.contabilidade.simulacao.balanco.linha','balanco_capital_proprio_id','Capital Proprio', ),
		'passivos_nao_correntes_ids':fields.one2many('dotcom.contabilidade.simulacao.balanco.linha','balanco_passivo_nao_corrente_id','Passivos Nao Correntes', ),
		'passivos_correntes_ids':fields.one2many('dotcom.contabilidade.simulacao.balanco.linha','balanco_passivo_corrente_id','Passivos Correntes', ),
		
		#linhas da Demonstracao de Resultados
		'resultado_antes_imposto_actual':fields.float('Actual',readonly=True),
		'resultado_antes_imposto_anterior':fields.float('Anterior',readonly=True),
		'resultado_poc_actual':fields.float('Actual',readonly=True),
		'resultado_poc_anterior':fields.float('Anterior',readonly=True),
		'resultado_liquido_actual':fields.float('Actual',readonly=True),
		'resultado_liquido_anterior':fields.float('Anterior',readonly=True),
		
		
		'linhas_resultados_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','resultado_id', 'Activos Nao Correntes', readonly=False),
		'resultados_impostos_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','resultado_imposto_id','Activos Correntes', readonly=False),
		'resultados_liquido_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','liquido_id','Capital Proprio', readonly=False),
		'resultado_operacoe_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','r_operacoes_id','Passivos Correntes', readonly=False),
		'resultado_aimpostos_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','r_aimpostos_id','Passivos Correntes', readonly=False),
		'resultado_accao_ids':fields.one2many('dotcom.contabilidade.simulacao.demonstracao.resultados.linha','r_accao_id','Passivos Correntes', readonly=False),
	}
	
	_defaults={
		#'state':'rascunho',
		'ano_fiscal_id':validator._get_default_year,
	}
	
	def pesquisar_apuramentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			#apuramentos_simulacao_ids=self.pool.get('dotcom.contabilidade.simulacao.apuramento').search(cr,uid,[])
			for apuramento in documento.apuramentos_ids:
				self.pool.get('dotcom.contabilidade.simulacao.apuramento').unlink(cr,uid,apuramento.id)
			
			apuramentos_ids=self.pool.get('dotcom.contabilidade.apuramentos').search(cr,uid,[
																							('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																							('tipo_apuramento','=','resultado')
																							])
			for apuramento in apuramentos_ids:
				apuramento=self.pool.get('dotcom.contabilidade.apuramentos').browse(cr,uid,apuramento)
				apuramento_value={
									'ref':apuramento.ref,
									'nome':apuramento.nome,
									'tipo_apuramento':apuramento.tipo_apuramento,
									'diario_id':apuramento.diario_id.id,
									'documento_id':apuramento.documento_id.id,
									'contra_partida_id':apuramento.contra_partida_id.id,
									'ano_fiscal_id':documento.ano_fiscal_id.id,
									'simulacao_resultado_id':documento.id,
									'apuramento_id':apuramento.id ,
									'periodo':documento.periodo.id,
								}
				self.pool.get('dotcom.contabilidade.simulacao.apuramento').create(cr,uid,apuramento_value)
		return True
	
dotcom_simulacao_resultados()


class dotcom_simulacao_apuramento(osv.osv):
	_name='dotcom.contabilidade.simulacao.apuramento'
	_columns={
		'ref':fields.char('Ref',required=True,size=100, readonly=True),
		'nome':fields.char('Nome',required=True,size=100, readonly=True),
		'tipo_apuramento':fields.selection([('resultado','Resultado'),('iva','IVA'),('outro','Outro')],'Tipo de apuramento', required=True, readonly=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True, readonly=True),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True, readonly=True),
		'contra_partida_id':fields.many2one('dotcom.contabilidade.plano.contas','Contra Partida',required=True, readonly=True),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, readonly=True),
		'periodo':fields.many2one('configuration.period','Mês',readonly=False, domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'simulacao_resultado_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Simulacao'),
		'apuramento_id':fields.many2one('dotcom.contabilidade.apuramentos','Apuramento'),
		'state':fields.selection([('rascunho','Rascunho'),('emitido','Emitido')],'Estado'),
		'progress_bar':fields.float('Processamento', readonly=True),
	}
	
	_defaults={
		'state':'rascunho'
	}
	
	def processar_apuramento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			self.write(cr,uid,documento.id,{'state':'emitido','progress_bar':100})
			
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			
			for apuramento in documento.simulacao_resultado_id.apuramentos_ids:
				if apuramento.id<documento.id and apuramento.state=='rascunho':
					raise osv.except_osv(_('Acção Invalida !'), _('Processe antes todas as Linhas anteriores a esta..!'))
			
	
		return True
		
	
dotcom_simulacao_apuramento()


class dotcom_simulacao_balanco_linha(osv.osv):
	_name='dotcom.contabilidade.simulacao.balanco.linha'
	_columns={
		'conta_conf_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco.conf','Activos',readonly=True),
		'saldo_actual':fields.float('Actual',readonly=True),
		'saldo_anterior':fields.float('Anterior',readonly=False),
		'notas':fields.char('Notas',size=50),
		'tipo':fields.selection([('sys','Sistema'),('novo','Novo')]),
		
		'balanco_activo_nao_corente_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Balanco'),
		'balanco_activo_corente_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Balanco'),
		'balanco_capital_proprio_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Balanco'),
		'balanco_passivo_nao_corrente_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Balanco'),
		'balanco_passivo_corrente_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Balanco'),
		'tem_ano_anterior':fields.boolean('Ano Anterior'),
	}
dotcom_simulacao_balanco_linha()


class dotcom_simulacao_demonstracao_resultaos_linha(osv.osv):
	_name='dotcom.contabilidade.simulacao.demonstracao.resultados.linha'
	_columns={
		
		'conta_conf_id':fields.many2one('dotcom.comtabilidade.relatorios.legais.balanco.conf','Activos',readonly=True),
		'saldo_actual':fields.float('Saldo', readonly=True),
		'saldo_anterior':fields.float('Saldo Anterior',readonly=False),
		'notas':fields.char('Notas',size=50),
		
		'resultado_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'resultado_imposto_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'liquido_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		#'resultado_periodo_oc_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'r_operacoes_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'r_aimpostos_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'r_accao_id':fields.many2one('dotcom.contabilidade.simulacao.resultado','Demosntracao de Resultados'),
		'tem_ano_anterior':fields.boolean('Ano Anterior'),
		
	}

