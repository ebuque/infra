# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
from dotcom_doc import amount_to_text
from validators import validator
import time
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_utilitario_contabilidade(osv.osv):
	_name='dotcom.contabilidade.utilitarios'
	_columns={
		'data_inicio':fields.date('Data Inicio',required=True),
		'data_fim':fields.date('Data Fim',required=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário', domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		
		'lancamentos_diarios_ids':fields.one2many('dotcom.contabilidade.utilitarios.linha','utilitario_id','Utilitarios'),
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		value={}
		if bool(ano_fiscal_id)!=False:
			ano_fiscal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
			value={'data_inicio':ano_fiscal_object.date_start,
				   'data_fim':ano_fiscal_object.date_stop}
			
		return {'value':value}
	
	
	def pesquisar_lancamentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			
			for linha in documento.lancamentos_diarios_ids:
				self.pool.get('dotcom.contabilidade.utilitarios.linha').unlink(cr,uid,linha.id)
			
			movimentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
																							('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																							('state','=','emitido'),
																							('data','>=',documento.data_inicio),
																							('data','<=',documento.data_fim)
																							])
			for movimento in movimentos_ids:
				movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
				for lancamento in movimento.lancamentos_diarios_ids:
					if lancamento.conta_id.fluxo_caixa==True and bool(lancamento.movimento_fluxo_caixa_id.id)==False:
						logger.info('ENTROU NO PROCESSO')
						val={
							'conta_id':lancamento.conta_id.id,
							'ano_fiscal_id':documento.ano_fiscal_id.id,
							'utilitario_id':documento.id,
							'movimento_id':lancamento.movimento_id.id,
							'debito':lancamento.debito,
							'credito':lancamento.credito,
							'descricao':lancamento.descricao,
							'lancamento_diario_id':lancamento.id,
						}
						
						if lancamento.credito>lancamento.debito:
							val['natureza_fluxo_caixa']='pagamento'
						elif lancamento.credito<lancamento.debito:
							val['natureza_fluxo_caixa']='recebimento'
						self.pool.get('dotcom.contabilidade.utilitarios.linha').create(cr,uid,val)
						
		return True
	
	
	def criar_moviemnto_fluxo_caixa(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			contador=0
			if len (documento.lancamentos_diarios_ids)>0:
				for lancamento in documento.lancamentos_diarios_ids:
					#if lancamento.select==True:
					contador=contador+1
					movimento_fluxo_caixa_val={
								'data':lancamento.movimento_id.data,
								'periodo_id':lancamento.movimento_id.periodo.id,
								'ano_fiscal_id':lancamento.movimento_id.ano_fiscal_id.id,
								'conta_id':lancamento.conta_id.id,
								'diario_id':lancamento.movimento_id.diario_id.id,
								'documento_id':lancamento.movimento_id.documento_id.id,
								'movimento_id':lancamento.movimento_id.id,
								'notas_internas':lancamento.movimento_id.notas_internas,
								'lancamento_diario_id':lancamento.lancamento_diario_id.id
							}
							
					valor=0
					natureza=''
					if lancamento.debito>lancamento.credito:
						valor=lancamento.debito
						natureza='debito'
					elif lancamento.credito>lancamento.debito:
						valor=lancamento.credito
						natureza='credito'
					movimento_fluxo_caixa_val['valor_total']=valor
					movimento_fluxo_caixa_val['natureza']=natureza
					
					movimento_fluxo_id=self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').create(cr,uid,movimento_fluxo_caixa_val)
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.lancamento_diario_id.id,
																						{'movimento_fluxo_caixa_id':movimento_fluxo_id,
																						 'fluxo_caixa':True})
			
					if bool(lancamento.fluxo_caixa_id.id)!=False:
						lancamento_fluxo_linha_val={
							  'fluxo_caixa_id':lancamento.fluxo_caixa_id.id,
							  'valor':valor,
							  'movimento_fluxo_id':movimento_fluxo_id,
						}
						self.pool.get('dotcom.contabilidade.lancamentos.movimento.fluxo.caixa').create(cr,uid,lancamento_fluxo_linha_val)
						self.pool.get('dotcom.contabilidade.movimento.fluxo.caixa').emitir(cr,uid,[movimento_fluxo_id])
					
					
					self.pool.get('dotcom.contabilidade.utilitarios.linha').unlink(cr,uid,lancamento.id)
			else:
				raise osv.except_osv(_('Acção Invalida !'), _('Nenhuma linha seleccionada!!'))
			
		return True
		
	
dotcom_utilitario_contabilidade()


class dotcom_utilitario_contabilidade_linhas(osv.osv):
	_name='dotcom.contabilidade.utilitarios.linha'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True, readonly=True),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'utilitario_id':fields.many2one('dotcom.contabilidade.utilitarios','Utilitarios'),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos', 'Movimento',readonly=True),
		'fluxo_caixa_id':fields.many2one('dotcom.contabilidade.fluxo.caixa','Fluxo caixa', ),
		'debito':fields.float('Débito',required=True,readonly=True),
		'credito':fields.float('Crédito',required=True,readonly=True),
		'descricao':fields.char('Descrição',size=100,readonly=True),
		'select':fields.boolean('Seleccionar'),
		'natureza_fluxo_caixa':fields.selection([('pagamento','Fluxo de Saída'),('recebimento','Fluxo de Entrada')],'Natureza F. caixa'),
		'lancamento_diario_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Lancamento'),
	}
	
dotcom_utilitario_contabilidade_linhas()



class dotcom_utilitario_movimento(osv.osv):
	_name='dotcom.contabilidade.utilitarios.movimento'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'periodo_id':fields.many2one('configuration.period','Período', required=True, domain="[('fiscalyear_id','=',ano_fiscal_id)]"),
		'linhas_utilitario_ids':fields.one2many('dotcom.contabilidade.utilitarios.movimento.linha','utilitario_id','Linhas'),
	}
	
	
	def pesquisar_movimentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			
			for movimento in documento.linhas_utilitario_ids:
				self.pool.get('dotcom.contabilidade.utilitarios.movimento.linha').unlink(cr,uid,movimento.id)
			
			#movimentos_ids=[]
			#if documento.periodo_id.special==False:
			#	logger.info('ENTROU NO PROCESSO 1')
			#	#movimentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
			#	#									('periodo','=',documento.periodo_id.id),
			#	#									('ano_fiscal_id','=',documento.ano_fiscal_id.id),
			#	#									('numero_diario','!=',False),
			#	#									('numero_documento','!=',False),
			#	#									])
			#
			#	movimentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
			#										('data','>=',documento.periodo_id.date_start),
			#										('data','<=',documento.periodo_id.date_stop),
			#										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
			#										('lancamento_abertura','=',False),
			#										('numero_diario','!=',False),
			#										('numero_documento','!=',False),
			#										])
			#else:
			movimentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('periodo','=',documento.periodo_id.id),
								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
								('numero_diario','!=',False),
								('numero_documento','!=',False),
								])
				
			logger.info('MOVIMENTOS ACHADOS PARA O RE-ORDENAMENTO %s' %str(movimentos_ids))
				
			
			for movimento in movimentos_ids:
				movimento_object=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
				value={
					'movimento_id':movimento_object.id,
					'data':movimento_object.data,
					'diario_id':movimento_object.diario_id.id,
					'numero_diario':movimento_object.numero_diario,
					'periodo':movimento_object.periodo.id,
					'documento_id':movimento_object.documento_id.id,
					'numero_documento':movimento_object.numero_documento,
					'state':movimento_object.state,
					'utilitario_id':documento.id,
				}
				linha=self.pool.get('dotcom.contabilidade.utilitarios.movimento.linha').create(cr,uid,value)
		return True
	
	
	def ordenar_movimentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			
			diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
			
			for diario in diarios_ids:
				movimentos_diarios_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
																										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																										('periodo','=',documento.periodo_id.id),
																										('diario_id','=',diario),
																										('state','!=','rascunho'),
																										], )
				
				numero_maior=0
				
				if len(movimentos_diarios_ids)>0:
					
					for movimento in movimentos_diarios_ids:
						movimento_diario_object=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
						
						parcelas_numero_diario=movimento_diario_object.numero_diario.split('/')
						numero_actual=int(parcelas_numero_diario[2])
						logger.info('MAIOR NUMERO ACHADO %s' %str(parcelas_numero_diario))
						if numero_actual>numero_maior:
							numero_maior=numero_actual
						
				sequencia_diario_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
				('periodo_id','=',documento.periodo_id.id),
				('diario_id','=',diario)])
				
				logger.info('MAIOR NUMERO ACHADO %s' %str(numero_maior))
				sequencia_object=self.pool.get('dotcom.contabilidade.sequenciador').browse(cr,uid,sequencia_diario_ids[0])
				self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_diario_ids[0],{'number_next':numero_maior+1})
			
				#else:
				#	sequencia_diario_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
				#	('periodo_id','=',documento.periodo_id.id),
				#	('diario_id','=',diario)])
				#	self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_diario_ids[0],{'number_next':1})

			
			for documento_movimento in documentos_ids:
				movimentos_documentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
																										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																										('periodo','=',documento.periodo_id.id),
																										('documento_id','=',documento_movimento),
																										('state','!=','rascunho'),
																										], )
				
				numero_maior=0
				if len(movimentos_documentos_ids)>0:
					
					for movimento in movimentos_documentos_ids:
						movimento_documento_object=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
						parcelas_numero_documento=movimento_documento_object.numero_documento.split('/')
						numero_actual=int(parcelas_numero_documento[2])
						if numero_actual>numero_maior:
							numero_maior=numero_actual
					
				
				sequencia_diario_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
				('periodo_id','=',documento.periodo_id.id),
				('documento_id','=',documento_movimento)])
				
				self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_diario_ids[0],{'number_next':numero_maior+1})
			
				
					
			#for movimento in documento.linhas_utilitario_ids:
			#	inicial_numerador=movimento.numero_diario[:2]
			#	codigo=inicial_numerador+"/"+documento.ano_fiscal_id.code
				#logger.info('IDENTIFICADOR DO SEQUECIADOR %s' %str(codigo))
				
				
				#periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
				#																('fiscalyear_id','=',documento.ano_fiscal_id.id),
				#																('code','=',codigo)])
				#
				#sequencia_diario_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
				#	('periodo_id','=',periodos_ids[0]),
				#	('diario_id','=',movimento.diario_id.id)])
				#sequencia_object=self.pool.get('dotcom.contabilidade.sequenciador').browse(cr,uid,sequencia_diario_ids[0])
				#
				#procimo_numero=sequencia_object.number_next-1
				#if procimo_numero<=1:
				#	procimo_numero=1
				#self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_object.id,{'number_next':procimo_numero})
				##logger.info('IDENTIFICADOR DO PERIODO %s' %str(sequencia_object.periodo_id.name))
				#
				#sequencia_documentos_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
				#	('periodo_id','=',periodos_ids[0]),
				#	('documento_id','=',movimento.documento_id.id)])
				#sequencia_object=self.pool.get('dotcom.contabilidade.sequenciador').browse(cr,uid,sequencia_diario_ids[0])
				#procimo_numero_documento=sequencia_object.number_next-1
				#if procimo_numero_documento<=1:
				#	procimo_numero_documento=1
				#self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_object.id,{'number_next':procimo_numero_documento})
				#
				#
				#self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequencia_documentos_ids[0],{'number_next':1})
				#
				#self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.movimento_id.id,{'numero_diario':False,'numero_documento':False})
				#logger.info('IDENTIFICADOR DO PERIODO %s' %str(sequencia_object.periodo_id.name))

			#break
			
			for movimento in documento.linhas_utilitario_ids:
				self.pool.get('dotcom.contabilidade.utilitarios.movimento.linha').unlink(cr,uid,movimento.id)
			#	#self.pool.get('dotcom.contabilidade.movimentos').processar_emitir(cr,uid,[movimento.movimento_id.id])
			#	periodo_actual_ids=[]
			#	
			#	#if 
			#	periodo_actual=self.pool.get('configuration.period').search(cr,uid,[
			#																	('date_start','<=',movimento.movimento_id.data),
			#																	('date_stop','>=',movimento.movimento_id.data)])
			#	
			#	periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
			#																	('fiscalyear_id','=',documento.ano_fiscal_id.id),
			#																	('code','=',codigo)])
				
			   
				#periodo_ctual_object=self.pool.get('configuration.period').browse(cr,uid,periodo_actual[0])
				
				#self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.movimento_id.id,{'periodo':documento.periodo_id.id})
				
				
				#numero_documento=self.pool.get('dotcom.contabilidade.documento').generate_sequence(cr,uid,sequencia_documento_object.id,movimento.movimento_id.data,movimento.documento_id.id,movimento.movimento_id.id)
				
				#self.pool.get('dotcom.contabilidade.movimentos').local_processing(cr,uid,[movimento.movimento_id.id])
				#self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.movimento_id.id,{'numero_diario':numero_diario,'numero_documento':numero_documento})				
				#self.pool.get('dotcom.contabilidade.utilitarios.movimento.linha').unlink(cr,uid,movimento.id)
				
		return True	
	
dotcom_utilitario_movimento()


class dotcom_utilitarios_movimento_linhas(osv.osv):
	_name='dotcom.contabilidade.utilitarios.movimento.linha'
	_columns={
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento'),
		'data':fields.date('Data',required=True,readonly=True,),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True,readonly=True, ),
		'numero_diario':fields.char('Número Diário',readonly=True,size=50),
		'periodo':fields.many2one('configuration.period','Período',readonly=False, ),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True,readonly=True, ),
		'numero_documento':fields.char('Número Documento',readonly=True,size=50),
		'state':fields.selection([
					('rascunho','Rascunho'),
					('emitido','Emitido'),
					('cancelado','Cancelado'),
					('outro_rascunho','Rascunho'),
					],'Estado'),
		
		'utilitario_id':fields.many2one('dotcom.contabilidade.utilitarios.movimento','Utilitario'),
		
	}
	
dotcom_utilitarios_movimento_linhas()


