# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')

class dotcom_alteracoes_movimentos(osv.osv):
	_name='dotcom.contabilidade.alteracoes.movimentos'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'data_inicio':fields.date('Data Início', required=True),
		'data_fim':fields.date('Data Fim', required=True),
		'diario_pesquisa_id':fields.many2one('dotcom.contabilidade.diario','Diário',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'documento_pesquisa_id':fields.many2one('dotcom.contabilidade.documento','Documento',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'nova_data':fields.date('Nova Data'),
		'ano_fiscal_novo_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',domain="[('ano_fiscal_id','=',ano_fiscal_novo_id)]"),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',domain="[('ano_fiscal_id','=',ano_fiscal_novo_id)]"),
		'numero_diario':fields.char('Num. Diário', size=20,),
		'num_documento':fields.char('Num. Documento', size=20),
		'movimentos_ids':fields.one2many('dotcom.contabilidade.copia.movimentos','alteracao_movimento_id','Movimentos',readonly=True)
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data_fim= datetime.now().strftime('%Y-%m-%d')
		
		
		
		return {'value':{'data_inicio':ano_fiscal.date_start,'data_fim':data_fim}}
		
	
	def on_change_novo_ano(self,cr,uid,ids,novo_ano_id,diario_id,documento_id,context=None):
		if context is None:
			context={}
		
		val={}
		logger.info('NOVO ANO ACHADO %s' %str(novo_ano_id))
		logger.info('DIARIO ACHADO %s' %str(diario_id))
		logger.info('DOCUMENTO ACHADO %s' %str(documento_id))
		if bool(diario_id)!=False: 
			diario_object=self.pool.get('dotcom.contabilidade.diario').browse(cr,uid,diario_id)
			diarios_ids=self.pool.get('dotcom.contabilidade.diario').search(cr,uid,[
																					('ref','=',diario_object.ref),
																					('ano_fiscal_id','=',novo_ano_id)])
			if len(diarios_ids)>0:
				val['diario_id']=diarios_ids[0]
		
		if bool(documento_id)!=False:	
			documento_object=self.pool.get('dotcom.contabilidade.documento').browse(cr,uid,documento_id)
			documentos_ids=self.pool.get('dotcom.contabilidade.documento').search(cr,uid,[
																					('ref','=',diario_object.ref),
																					('ano_fiscal_id','=',novo_ano_id)])
			if len(documentos_ids)>0:
				val['documento_id']=documentos_ids[0]
			
		#logger.info('LISTA DE DIARIOS ACHADA %s' %str(diarios_ids))
		#logger.info('LISTA DE DOCUMENTOS ACHADA %s' %str(documentos_ids))
		
		return {'value':val}
		
	
	def actualisar_linhas_movimentos(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		estados=[]
		estados.append('emitido')
		estados.append('outro_rascunho')
		
		copia_moviimentos_ids=self.pool.get('dotcom.contabilidade.copia.movimentos').search(cr,uid,[])
		for copia_movimento in copia_moviimentos_ids:
			self.pool.get('dotcom.contabilidade.copia.movimentos').unlink(cr,uid,copia_movimento)
		
		for documento in self.browse(cr,uid,ids):
			logger.info('NUMERO DE DIARIO ACHADO %s' %str(documento.numero_diario))
			
			
			lancamentos_ids=[]
			if bool(documento.diario_pesquisa_id.id)==True and bool(documento.documento_pesquisa_id.id)==True:
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('documento_id','=',documento.documento_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('documento_id','=',documento.documento_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('documento_id','=',documento.documento_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('documento_id','=',documento.documento_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
			elif bool(documento.diario_pesquisa_id.id)==True and bool(documento.documento_pesquisa_id.id)==False:
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('diario_id','=',documento.diario_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
			
			elif bool(documento.diario_pesquisa_id.id)==False and bool(documento.documento_pesquisa_id.id)==True:
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('documento_id','=',documento.documento_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('documento_id','=',documento.documento_pesquisa_id.id),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('documento_id','=',documento.documento_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('documento_id','=',documento.documento_pesquisa_id.id),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
			elif bool(documento.diario_pesquisa_id.id)==False and bool(documento.documento_pesquisa_id.id)==False:
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==True and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
				
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==True:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								('numero_documento','like','%%%s%%'%documento.num_documento),
					])
					
				if bool(documento.numero_diario)==False and bool(documento.num_documento)==False:
					lancamentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('state','in',estados),
								#('numero_diario','like','%%%s%%'%documento.numero_diario),
								#('numero_documento','like','%%%s%%'%documento.num_documento),
					])
		
			for movimento in lancamentos_ids:
				movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
				val={
					'data':movimento.data,
					'ano_fiscal_id':movimento.ano_fiscal_id.id,
					'diario_id':movimento.diario_id.id,
					'numero_diario':movimento.numero_diario,
					'periodo':movimento.periodo.id,
					'documento_id':movimento.documento_id.id,
					'numero_documento':movimento.numero_documento,
					'total_debito':movimento.total_debito,
					'moeda_lancamento_id':movimento.moeda_lancamento_id.id,
					'cambio':movimento.cambio,
					'descricao':movimento.descricao,
					'notas_internas':movimento.notas_internas,
					'state':movimento.state,
					'alteracao_movimento_id':documento.id,
					'movimento_id':movimento.id,
				}
				self.pool.get('dotcom.contabilidade.copia.movimentos').create(cr,uid,val)
				
		return True
		
	
	def processar(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			
			if bool(documento.ano_fiscal_novo_id.id)==False :
				raise osv.except_osv(_('Acção Invalida !'), _('Seleccione o ano fiscal dos novos dados!!'))
			
			#logger.info('######################################LANCAMENTOS ACHADOS %s' %str(documento.movimentos_ids))
			if documento.ano_fiscal_novo_id.date_start<= documento.nova_data<=documento.ano_fiscal_novo_id.date_stop:
				logger.info('PROCESSANDO')
			else:
				if documento.ano_fiscal_novo_id.id!=False:
					raise osv.except_osv(_('Acção Invalida !'), _('A data seleccionada nao é do ano em questão!!'))
		
			nova_data=None
			novo_documento_id=None
			novo_diario_id=None
			novo_ano_fical_id=None
			periodo_id=None
			
			for movimento in documento.movimentos_ids:
				if bool(documento.ano_fiscal_novo_id.id)==False:
					novo_ano_fical_id=movimento.ano_fiscal_id.id
				else:
					novo_ano_fical_id=documento.ano_fiscal_novo_id.id
				
				if bool(documento.nova_data)==False:
					nova_data=movimento.data
					periodo_id=movimento.periodo.id
				else:
					nova_data=documento.nova_data
					periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
																('fiscalyear_id','=',novo_ano_fical_id),
																('date_start','<=',nova_data),
																('date_stop','>=',nova_data),
																])
					
					periodo_id=periodos_ids[0]
				
				
				if bool(documento.diario_id.id)==False and (documento.ano_fiscal_novo_id.id==documento.ano_fiscal_id.id or bool(documento.ano_fiscal_novo_id.id)==False):
					novo_diario_id=movimento.diario_id.id
					
				elif bool(documento.diario_id.id)==False and bool(documento.ano_fiscal_novo_id.id)!=False and documento.ano_fiscal_novo_id.id!=documento.ano_fiscal_id.id:
					raise osv.except_osv(_('Acção Invalida !'), _('Seleccione o Diario correspondente!!'))
				else:
					novo_diario_id=documento.diario_id.id
				
				if bool(documento.documento_id.id)==False and (documento.ano_fiscal_novo_id.id==documento.ano_fiscal_id.id or bool(documento.ano_fiscal_novo_id.id)==False):
					novo_documento_id=movimento.documento_id.id
					
				elif bool(documento.documento_id.id)==False and bool(documento.ano_fiscal_novo_id.id)!=False and documento.ano_fiscal_novo_id.id!=documento.ano_fiscal_id.id:
					raise osv.except_osv(_('Acção Invalida !'), _('Seleccione o Documento correspondente!!'))
				else:
					novo_documento_id=documento.documento_id.id
								
				
				logger.info('PERIODO ACHADO %s' %str(novo_documento_id))
				logger.info('PERIODO ACHADO %s' %str(novo_diario_id))
				logger.info('PERIODO ACHADO %s' %str(novo_ano_fical_id))
				logger.info('PERIODO ACHADO %s' %str(nova_data))
				movimentos_posteriores_diario_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
																												('periodo','=',movimento.movimento_id.periodo.id),
																												('diario_id','=',movimento.movimento_id.diario_id.id),
																												('id','>',movimento.movimento_id.id)
																													])
				
				movimentos_posteriores_documento_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
																												('periodo','=',movimento.movimento_id.periodo.id),
																												('documento_id','=',movimento.movimento_id.documento_id.id),
																												('id','>',movimento.movimento_id.id)
																													])
				
				if len(movimentos_posteriores_diario_ids)<=0:
					
					sequencia_diario_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',movimento.movimento_id.periodo.id),
					('diario_id','=',movimento.movimento_id.diario_id.id)])
				
					sequenciador_diario=self.pool.get('dotcom.contabilidade.sequenciador').browse(cr,uid,sequencia_diario_ids[0])
					proximo_numero_diario=sequenciador_diario.number_next-1
					
					self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequenciador_diario.id,{'number_next':sequenciador_diario.number_next-1})
				
				
				if len(movimentos_posteriores_documento_ids)<=0:
					#logger.info('ENTROU NO DOCUMENTO')
					
					sequencia_documento_ids=self.pool.get('dotcom.contabilidade.sequenciador').search(cr,uid,[
					('periodo_id','=',movimento.movimento_id.periodo.id),
					('documento_id','=',movimento.movimento_id.documento_id.id)])
				
					sequenciador_documento=self.pool.get('dotcom.contabilidade.sequenciador').browse(cr,uid,sequencia_documento_ids[0])
					proximo_numero_documento=sequenciador_documento.number_next-1
					
					self.pool.get('dotcom.contabilidade.sequenciador').write(cr,uid,sequenciador_documento.id,{'number_next':sequenciador_documento.number_next-1})
				
				#logger.info('PROXIMO NUMERO A SER ATRIBUIDO PARA O SEQUENCIADOR %s' %str(movimento.movimento_id.lancamentos_diarios_ids))
				for lancamento in movimento.movimento_id.lancamentos_diarios_ids:
					contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																								('ref','=',lancamento.conta_id.ref),
																								('ano_fiscal_id','=',novo_ano_fical_id)
																								])
					if len(contas_ids)>0:
						self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{'conta_id':contas_ids[0],'ano_fiscal_id':novo_ano_fical_id})
					else:
						novo_ano_object=self.poo.get('configuration.fiscalyear').browse(cr,uid,novo_ano_fical_id)
						raise osv.except_osv(_('Invalid action !'), _('A conta '+lancamento.conta_id.friendly_name +'Não existe para o ano fiscal de ' + str(novo_ano_object.name)+ '.!'))
				
				
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.movimento_id.id,{
																										'data':nova_data,
																										'periodo':periodo_id,
																										'ano_fiscal_id':novo_ano_fical_id,
																										'diario_id':novo_diario_id,
																										'documento_id':novo_documento_id,
																										'numero_diario':'',
																										'numero_documento':'',
																										})
				
				
				self.pool.get('dotcom.contabilidade.movimentos').processar_emitir(cr,uid,[movimento.movimento_id.id])
				
				self.pool.get('dotcom.contabilidade.copia.movimentos').unlink(cr,uid,movimento.id)
				#self.pool.get('dotcom.contabilidade.movimentos').processar_emitir(cr,uid,movimento.id)
				
		return True
	
dotcom_alteracoes_movimentos()


class dotcom_alteracao_conta_lancamento(osv.osv):
	
	_name='dotcom.contabilidade.alteracoes.lancamentos'
	_columns={
		'data_inicio':fields.date('Data Início',required=True),
		'data_fim':fields.date('Data Fim',required=True),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		
		'conta_actual_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Actual',required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'conta_lancar_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta a Lancar',required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'lancamentos_ids':fields.one2many('dotcom.contabilidade.lancamentos.diarios','alteracao_lancamento_id','Movimentos', readonly=True),
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data_fim= datetime.now().strftime('%Y-%m-%d')
		return {'value':{'data_inicio':ano_fiscal.date_start,'data_fim':data_fim}}
	
	
	def on_change_conta_origem(self,cr,uid,ids,conta_id,ano_fiscal_id,data_inicio,data_fim,context={}):
		if context is None:
			context={}
		
			
		lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
						('conta_id','=',conta_id),
						('data_lancamento','>=',data_inicio),
						('data_lancamento','<=',data_fim),
			])
		logger.info('IDENTIFICADOR DO DOCUMENTO %s' %str(lancamentos_ids))
		return {'value':{'lancamentos_ids':lancamentos_ids}}
	
	
	def on_change_conta_destino(self,cr,uid,ids,conta_id,context=None):
		if context is None:
			context={}
		
		conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_id)
		if conta.tipo_interno!='m':
			raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(conta.ref)+' com tipo de nao permitido!!'))
		
		return{}
		
	
	def processar(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		
		retorno=None
		for documento in self.browse(cr,uid,ids):
			conta_origem=documento.conta_actual_id
			conta_destino=documento.conta_lancar_id
			
			if conta_destino.tipo_interno!='m':
				raise osv.except_osv(_('Acção Invalida !'), _('Conta '+str(conta_destino.ref)+' com tipo de nao permitido!!'))
			
			logger.info('DATA DE INICIO %s' %str(documento.data_inicio))
			
			lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
						('conta_id','=',conta_origem.id),
						('data_lancamento','>=',documento.data_inicio),
						('data_lancamento','<=',documento.data_fim),
			])
			
			if len(lancamentos_ids)<=0:
				raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Lancamentos a processar!!'))
			else:
				for lancamento in lancamentos_ids:
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento,{
									'conta_id':conta_destino.id,
									'alteracao_lancamento_id':documento.id
									})
				
		msgalert = {'title':'Warning','message':'Processamento Efectuado com sucesso'}
		retorno= {'warning':msgalert}
				
		return retorno

dotcom_alteracao_conta_lancamento()