# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_conta(osv.osv):
	_name='dotcom.gestao.projectos.conta'
	_inherit = 'dotcom.gestao.projectos.conta'
	_columns={
		'plano_conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Plano Contas'),
	}
	_defaults={
		'contabilidade':True,
	}
	
dotcom_conta()