# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')




class dotcom_contabilidade_actualizacao_credito_debito(osv.osv):
	_name='dotcom.contabilidade.credito.debito'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'periodo_id':fields.many2one('configuration.period','Fim',required=True),
		'movimentos_ids':fields.one2many('dotcom.contabilidade.movimentos','actualizacao_debito_credito_id','Movimentos', readonly=True),
		'linhas_ids':fields.one2many('dotcom.contabilidade.credito.debito.linha','actualizacao_id','Linhas')
	
	}
	
	_rec_name='ano_fiscal_id'
	
	def actualizar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			movimentos_ids=self.pool.get('dotcom.contabilidade.movimentos').search(cr,uid,[
										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
										('periodo','=',documento.periodo_id.id),
										('state','=','emitido'),
				])
			
			
			for movimento in documento.movimentos_ids:
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'actualizacao_debito_credito_id':False})
			
			
			lista=[]
			for movimento in movimentos_ids:
				logger.info('PROCESSO EM EXECUCAO')
				movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento)
				val=self.calcular(cr,uid,movimento,documento)
				val=val['value']
				total_debito=val['total_debito']
				total_credito=val['total_credito']
				total_debito_primario=val['total_debito_primario']
				total_credito_primario=val['total_credito_primario']
				total_debito_secundario=val['total_debito_secundario']
				total_credito_secundario=val['total_credito_secundario']
				
				if (movimento.total_debito!=total_debito) or (movimento.total_credito!=total_credito) or (movimento.total_debito_base!=total_debito_primario) or (movimento.total_credito_base!=total_credito_primario) or (movimento.total_debito_secundario!=total_debito_secundario) or movimento.total_credito_secundario!=total_credito_secundario:
					self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'actualizacao_debito_credito_id':documento.id})
		return True
	
	
	def calcular(self, cr,uid,movimento_object,documento_object,context=None):
		if context is None:
			context={}
		
		
		total_debito=0
		total_credito=0
		total_debito_primario=0
		total_credito_primario=0
		total_debito_secundario=0
		total_credito_secundario=0


		#logger.info('#calculando o movimento######################## %s' %str(documento.lancamentos_diarios_ids))
		if len(movimento_object.lancamentos_diarios_ids)<=0:
			raise osv.except_osv(_('Acção Invalida !'), _('O Movimento Sem Lancamentos efectuados!!'))
		

		for lancamento in movimento_object.lancamentos_diarios_ids:
									 
			if  lancamento.acerto=='all':
				total_debito=total_debito+lancamento.debito
				total_credito=total_credito+lancamento.credito			   
			
			total_debito_primario=total_debito_primario+round(lancamento.debito_moeda_base,2)
			total_credito_primario=total_credito_primario+round(lancamento.credito_moeda_base,2)
			
			total_debito_secundario=total_debito_secundario+round(lancamento.debito_moeda_secundaria, 2)
			total_credito_secundario=total_credito_secundario+round(lancamento.credito_moeda_secundaria, 2)
			
			
		total_debito=round(total_debito, 2)
		total_credito=round(total_credito, 2)
		
		
		if total_debito!=total_credito:
			self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento_object.id,{'actualizacao_debito_credito_id':documento_object.id})
		
		total_credito_primario=round(total_credito_primario, 2)
		total_debito_primario=round(total_debito_primario, 2)
					
		if total_credito_primario!=total_debito_primario:
			self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento_object.id,{'actualizacao_debito_credito_id':documento_object.id})
		
			
		
		total_debito_secundario=round(total_debito_secundario, 2)
		total_credito_secundario=round(total_credito_secundario, 2)
		if total_debito_secundario!=total_credito_secundario:
			self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento_object.id,{'actualizacao_debito_credito_id':documento_object.id})
			#logger.info('TOTAL DEBITO SECUNDARIO %s ' %str(total_credito_secundario))
			#logger.info('TOTAL CREDITO SECUNDARIO %s ' %str(total_debito_secundario))
			
			
		val={'total_debito':total_debito,
			 'total_credito':total_credito,
			 'total_debito_primario':total_debito_primario,
			 'total_credito_primario':total_credito_primario,
			 'total_debito_secundario':total_debito_secundario,
			 'total_credito_secundario':total_credito_secundario
			 }   
		return {'value':val}
	
	
	def processar(self,cr,uid,ids,context={}):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			for movimento in documento.movimentos_ids:
				#self.pool.get('dotcom.contabilidade.movimentos').voltar_rascunho(cr,uid,[movimento.id])
				self.pool.get('dotcom.contabilidade.movimentos').processar_emitir(cr,uid,[movimento.id])
				self.pool.get('dotcom.contabilidade.movimentos').write(cr,uid,movimento.id,{'actualizacao_id':False})
		return True
   
	
	def actualizar_lancamentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		for documento in self.browse(cr,uid,ids):
			
			
			for linha in documento.linhas_ids:
				self.pool.get('dotcom.contabilidade.credito.debito.linha').unlink(cr,uid,linha.id)
			
			movimentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
										('state','=','emitido'),
										('periodo_id','=',documento.periodo_id.id)
				])
			lista=[]
			
			credito=0
			debito=0
			
			
			for movimento in movimentos_ids:
				
				movimento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,movimento)
				credito=credito+movimento.credito_primario_arredondado
				debito=debito+movimento.debito_primario_arredondado
				logger.info('PROCESSO EM EXECUCAO %s' %str(movimento.debito_primario_arredondado))
			saldo=debito-credito
			val={
				'debito':debito,
				'credito':credito,
				'saldo':saldo,
				'actualizacao_id':documento.id,
			}
			self.pool.get('dotcom.contabilidade.credito.debito.linha').create(cr,uid,val)
			
		return True
	
	
dotcom_contabilidade_actualizacao_credito_debito()


class contabilidade_actualizacao_credito_debito_linha(osv.osv):
	_name='dotcom.contabilidade.credito.debito.linha'
	_columns={
		'debito':fields.float('Debito'),
		'credito':fields.float('Credito'),
		'saldo':fields.float('Saldo'),
		'actualizacao_id':fields.many2one('dotcom.contabilidade.credito.debito','Actualizacao')
	}
	
contabilidade_actualizacao_credito_debito_linha()


class dotcom_contabilidade_extratos(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
		
		result=('ml','Moeda de Lancamento')
		this.append(result)
			
		return this
	
	def _moeda_lancamento(self,cr,uid,context=None):
		if context is None:
			context={}
		
		result=()
		this=[]   
		moedas_lancamento=self.pool.get('res.currency').search(cr,uid,[])
		for moeda in moedas_lancamento:
			moeda=self.pool.get('res.currency').browse(cr,uid,moeda)
			result=(str(moeda.id),moeda.name)
			this.append(result)
		
		result=('all','Todas Moedas')
		this.append(result)
		
		return this
	
	_name='dotcom.contabilidade.extratos'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'moeda_lancamento_id':fields.selection(_moeda_lancamento,'Moeda Lanc.',required=True),
		'conversao_moeda':fields.selection(_acerto,'Moeda Visualização', required=True),
		'conversao_moeda_centro':fields.selection(_acerto,'Moeda Visualização', required=True),
		'conversao_moeda_diario':fields.selection(_acerto,'Moeda Impressão', required=True),
		
		'data_inicio':fields.date('Data Início', required=True),
		'data_fim':fields.date('Data Fim',required=True),

		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta', domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		
		'conta_centro_custos_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','Conta C. Custo',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos', 'Plano C. Custos', domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),

		'fluxo_caixa_id':fields.many2one('dotcom.contabilidade.fluxo.caixa','Fluxo Caixa'),

		'tipo_lancamento':fields.selection([('novo','Novo')],'Tipo Lançamento'),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diario',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		
		
		'lancamentos_ids':fields.one2many('dotcom.contabilidade.extratos.contas.linhas','extrato_lancamento_id','Lancamentos',readonly=True),
		'lancamentos_diario_ids':fields.one2many('dotcom.contabilidade.extratos.diario.linhas','extrato_diario_lancamento_id','Lancamentos',readonly=True),
		'lancamentos_centros_ids':fields.one2many('dotcom.contabilidade.extratos.centro.linhas','extrato_centro_lancamento_id','Lancamentos Centro Custos',readonly=True),
		'movimento_abertura':fields.boolean('Movimento Abertura'),
		'movimento_fecho':fields.boolean('Movimento Fecho'),
		'imprimir_tudo':fields.boolean('Imprimir Tudo'),
	}
	
	
	_defaults={
		'movimento_abertura':True,
		'movimento_fecho':True,
		'ano_fiscal_id':validator._get_default_year,
		'data_inicio':validator._get_data_inicio_ano,
		'data_fim':validator.get_data_movimento,
		'moeda_lancamento_id': 'all',
		'conversao_moeda':'mp',
		'conversao_moeda_centro':'mp',
		'conversao_moeda_diario':'mp',
	}
	
	
	def adicionar_dias(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			data=str(documento.data_inicio)
			data=datetime.strptime(data, '%Y-%m-%d')
			logger.info('DATA ACHADA %s' %str(data))
			data_final=data+timedelta(days=10)
			logger.info('DATA ACHADA %s' %str(data_final))
			# logger.info('DATA FINAL %s' %str(data))
		return True
	
	
	def on_change_acerto(self,cr,uid,ids,lancamentos_ids,lancamentos_diario_ids,lancamentos_centros_ids,context=None):
		if context is None:
			context={}
		
		
		if len(lancamentos_ids):
			for lancamento_conta in lancamentos_ids:
				logger.info('LANCAMENTOS DO EXTRATO DE CONTAS %s' %str(lancamento_conta))
				self.pool.get('dotcom.contabilidade.extratos.contas.linhas').unlink(cr,uid,lancamento_conta[1])
				
		#if len(lancamentos_diario_ids):
		#	for lancamento_conta in lancamentos_diario_ids:
		#		logger.info('LANCAMENTOS DO EXTRATO DE CONTAS %s' %str(lancamento_conta))
		#		self.pool.get('dotcom.contabilidade.extratos.diario.linhas').write(cr,uid,lancamento_conta[1],{'extrato_diario_lancamento_id':False})
				
		if len(lancamentos_centros_ids):
			for lancamento_conta in lancamentos_centros_ids:
				logger.info('LANCAMENTOS DO EXTRATO DE CONTAS %s' %str(lancamento_conta))
				self.pool.get('dotcom.contabilidade.extratos.centro.linhas').unlink(cr,uid,lancamento_conta[1])
				
				
		return {'value':{
							'lancamentos_ids':None,
							'lancamentos_diario_ids':None,
							'lancamentos_centros_ids':None,
			}}	
	
	
	def carregar_linhas_centro_custos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		linhas_ids=self.pool.get('dotcom.contabilidade.extratos.centro.linhas').search(cr,uid,[])
		for linha in linhas_ids:
			self.pool.get('dotcom.contabilidade.extratos.centro.linhas').unlink(cr,uid,linha)
		
		for documento in self.browse(cr,uid,ids):
			
			lista_lancamentos=[]
			#if bool(documento.plano_centro_id.id)==False:
			#	raise osv.except_osv(_('Acção Inválida !'), _('Seleccione o Plano!!')) 
			
			if (documento.conta_centro_custos_id.id)==False or documento.conta_centro_custos_id.tipo_interno!='m':
				raise osv.except_osv(_('Acção Inválida !'), _('Seleccione um centro de custo de Movimento!!')) 
			
			lancamentos_centro_custos_ids=[]
			if bool(documento.conta_centro_custos_id.id)==True:
				logger.info('ENTROU NO PROCESSO')
				lancamentos_centro_custos_ids=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').search(cr,uid,[
												('data','>=',documento.data_inicio),
												('data','<=',documento.data_fim),
												('centro_id','=', documento.conta_centro_custos_id.id),
												('estado_movimento','=','emitido'),
												])
			else:
				contas_centro_ids=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[('ano_fiscal_id','=',documento.ano_fiscal_id.id)])
				lancamentos_centro_custos_ids=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								('centro_id','in', contas_centro_ids),
								('estado_moviimento','=','emitido'),
								])
			
			
			total_debito_acumulado=0
			total_credito_acumulado=0
			natureza=''
			for lancamento in lancamentos_centro_custos_ids:
				lancamento=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').browse(cr,uid,lancamento)
				credito=0
				debito=0
				saldo=0
				logger.info('NUMERO DE LANCAMENTOS ACHADOS PARA O PROCESSAMENTO %s' %str(lancamento.valor_moeda_base))
				if lancamento.movimento_id.state=='emitido':
					
					if lancamento.natureza=='debito':
						if documento.conversao_moeda_centro=='mp':
							logger.info('VALOR DE CREDITO ACHADO %s' %str(type(lancamento.valor_moeda_base)))
							logger.info('VALOR DE CREDITO ACHADO %s' %str(lancamento.valor_moeda_base))
							debito=lancamento.valor_moeda_base
						elif documento.conversao_moeda_centro=='ms':
							debito=lancamento.valor_moeda_secundaria
						#saldo=debito
					elif lancamento.natureza=='credito':
						if documento.conversao_moeda_centro=='mp':
							logger.info('VALOR DE CREDITO ACHADO %s' %str(type(lancamento.valor_moeda_base)))
							logger.info('VALOR DE CREDITO ACHADO %s' %str(lancamento.valor_moeda_base))
							credito=lancamento.valor_moeda_base
						elif documento.conversao_moeda_centro=='ms':
							credito=lancamento.valor_moeda_secundaria
						saldo=credito
					
					total_debito_acumulado=total_debito_acumulado+debito
					
					total_credito_acumulado=total_credito_acumulado+credito
					if total_debito_acumulado>total_credito_acumulado:
						saldo=total_debito_acumulado-total_credito_acumulado
						natureza='debito'
					
					elif total_debito_acumulado<total_credito_acumulado:
						saldo=total_credito_acumulado-total_debito_acumulado
						natureza='credito'
					
					
					adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,lancamento.adicao_id.id)
					#lancamentos_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
					#																	('lancamentos_custo_id','=',adicao_object.lancamento_id.id)])
					
					lancamento_diario_object=adicao_object.lancamento_diario_id
					
					
					
					movimento_object=lancamento_diario_object.movimento_id
					#logger.info('VALOR DO DOCUMENTO ACHADO %s' %str(movimento_object.documento_id.id))
					logger.info('VALOR DO DIARIO ACHADO %s' %str(movimento_object))
					
					if movimento_object!=False :
						if movimento_object.diario_id:
							val={
								'data':lancamento.data,
								'debito':debito,
								'credito':credito,
								'saldo':saldo,
								'natureza_saldo':natureza,
								'conta_id':lancamento_diario_object.conta_id.id,
								'diario_object_id':movimento_object.diario_id.id,
								'documento_object_id':movimento_object.documento_id.id,
								'descricao':lancamento_diario_object.descricao,
								'movimento_id':movimento_object.id,
								'documento_id':movimento_object.numero_documento,
								'diario_id':movimento_object.numero_diario,
								'conta_centro_custos_id':lancamento.centro_id.id,
								'plano_centro_id':lancamento.plano_id.id,
								'extrato_centro_lancamento_id':documento.id,
								
							}
						
						self.pool.get('dotcom.contabilidade.extratos.centro.linhas').create(cr,uid,val)
						lista_lancamentos.append(val)
						lista_lancamentos = sorted(lista_lancamentos, key=lambda d: (d['plano_centro_id']))
				
				else:
					logger.info('LANCAMENTO NAO EMITIDO')
			#for linha in lista_lancamentos:
				
				
		return True	   

  
	def imprimir_todos_centros_custos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		
		
			
		
		for documento in self.browse(cr,uid,ids):
			lista_lancamentos=[]
			#if bool(documento.plano_centro_id.id)==False:
			#	raise osv.except_osv(_('Acção Inválida !'), _('Seleccione o Plano!!'))
			
			lista_centros_custos=self.pool.get('dotcom.contabilidade.conta.centro.custos').search(cr,uid,[
																					#('centro_id','=',documento.plano_centro_id.id),
																					('tipo_interno','=','m'),
																					('ano_fiscal_id','=',documento.ano_fiscal_id.id)
																					])
			
			#logger.info('NUMERO DE CENTROS DE CUSTOS DO REFERIDO PLANO %s' %str(lista_centros_custos))
			
			if documento.imprimir_tudo==True:
				
				linhas_ids=self.pool.get('dotcom.contabilidade.extratos.centro.linhas').search(cr,uid,[])
				for linha in linhas_ids:
					self.pool.get('dotcom.contabilidade.extratos.centro.linhas').unlink(cr,uid,linha)
				
				for centro_custo in lista_centros_custos:
					lancamentos_centro_custos_ids=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').search(cr,uid,[
									('data','>=',documento.data_inicio),
									('data','<=',documento.data_fim),
									('estado_movimento','=','emitido'),
									('centro_id','=', centro_custo)
									])
				
					total_debito_acumulado=0
					total_credito_acumulado=0
					natureza=''
					for lancamento in lancamentos_centro_custos_ids:
						lancamento=self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').browse(cr,uid,lancamento)
						credito=0
						debito=0
						saldo=0
						if lancamento.movimento_id.state=='emitido':
							if lancamento.natureza=='debito':
								if documento.conversao_moeda=='mp':
									debito=lancamento.valor_moeda_base
								elif documento.conversao_moeda=='ms':
									debito=lancamento.valor_moeda_secundaria
								#saldo=debito
							elif lancamento.natureza=='credito':
								if documento.conversao_moeda=='mp':
									credito=lancamento.valor_moeda_base
								elif documento.conversao_moeda=='ms':
									credito=lancamento.valor_moeda_secundaria
								saldo=credito
							
							total_debito_acumulado=total_debito_acumulado+debito
							total_credito_acumulado=total_credito_acumulado+credito
							if total_debito_acumulado>total_credito_acumulado:
								saldo=total_debito_acumulado-total_credito_acumulado
								natureza='debito'
							
							elif total_debito_acumulado<total_credito_acumulado:
								saldo=total_credito_acumulado-total_debito_acumulado
								natureza='credito'
							
							
							adicao_object=self.pool.get('dotcom.contabilidade.adicao.linhas.centro').browse(cr,uid,lancamento.adicao_id.id)
					#lancamentos_diarios_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
					#																	('lancamentos_custo_id','=',adicao_object.lancamento_id.id)])
					
							lancamento_diario_object=adicao_object.lancamento_diario_id
							
							
							
							movimento_object=lancamento_diario_object.movimento_id
							
							
							val={
								'data':lancamento.data,
								'debito':debito,
								'credito':credito,
								'saldo':saldo,
								'natureza_saldo':natureza,
								'conta_id':lancamento_diario_object.conta_id.id,
								'diario_object_id':movimento_object.diario_id.id,
								'documento_object_id':movimento_object.documento_id.id,
								'descricao':lancamento_diario_object.descricao,
								'movimento_id':movimento_object.id,
								'documento_id':movimento_object.numero_documento,
								'diario_id':movimento_object.numero_diario,
								'conta_centro_custos_id':lancamento.centro_id.id,
								'plano_centro_id':lancamento.plano_id.id,
								'extrato_centro_lancamento_id':documento.id,
								
							}
							logger.info('VALOR DO MOVIMENTO ACHADO %s' %str(lancamento.conta_id.id))
							self.pool.get('dotcom.contabilidade.extratos.centro.linhas').create(cr,uid,val)
							lista_lancamentos.append(val)
							lista_lancamentos = sorted(lista_lancamentos, key=lambda d: (d['conta_centro_custos_id']))
						
					
					#for linha in lista_lancamentos:
						
		
				
		
		return  {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.extratos',
					'report_name': 'dotcom_contabilidade_extrato_centro_custos_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
			}
				
  
  
	def on_change_conta_centro(self,cr,uid,ids,conta_centro_id,context=None):
		if context is None:
			context={}
		#
		#conta_centro_object=self.pool.get('dotcom.contabilidade.conta.centro.custos').browse(cr,uid,conta_centro_id)
		#if conta_centro_object.tipo_interno!='m':
		#	raise osv.except_osv(_('Acção Inválida !'), _('Tipo de Conta de Centro de custo não permitido!!')) 
		
		return True
			
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		retorno={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data_inicio=ano_fiscal.date_start
		
		ano_default_id=validator._get_default_year(self,cr,uid,context=context)
		if ano_default_id!=ano_fiscal_id:
			retorno={
						'data_inicio':data_inicio,
						'conta_id':False,
						'diario_id':False,
						'conta_centro_custos_id':False
					}
		else:
			data_inicio=validator._get_data_inicio_ano(self,cr,uid,context=context)
			data_fim=validator._get_actual(self,cr,uid,context=context)
			retorno={
					'data_inicio':data_inicio,
					'conta_id':False,
					'diario_id':False,
					'conta_centro_custos_id':False
					}
		return{'value':retorno}

	
	def carregar_linhas_lancamentos(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		lista_modedas_ids=self.pool.get('res.currency').search(cr,uid,[])
		
		for documento in self.browse(cr,uid,ids):
			moeda_lanc=documento.moeda_lancamento_id
			#logger.info('MOEDA DE LANCAMENTO %s' %str(moeda_lanc))
			
			if bool(documento.conta_id.id)==False:
				raise osv.except_osv(_('Acção Invalida !'), _('Seleccione a Conta!!'))	
			
			if documento.moeda_lancamento_id!='all':
				lista_modedas_ids=[]
				lista_modedas_ids.append(int(documento.moeda_lancamento_id))
			conta=documento.conta_id
			#logger.info('MOEDA DE LANCAMENTO%s'%str(lista_modedas_ids))
			
			
			for lanc in documento.lancamentos_ids:
				self.pool.get('dotcom.contabilidade.extratos.contas.linhas').unlink(cr,uid,lanc.id)
			
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',documento.ano_fiscal_id.id),
							('closing','=',False),
				])
			
			periodos_fecho=[]
			if documento.movimento_fecho==True:
				periodos_fecho=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',documento.ano_fiscal_id.id),
							('closing','=',True),])
			logger.info('PERIODOS DE FECHO ACHADOS %s' %str(periodos_ids))
			for periodo in periodos_fecho:
				periodos_ids.append(periodo)
			#logger.info('PERIODOS DO ANO FISCAL %s' %str(periodos_ids))
			
			tipo_lancamento=False
			tipos_lancamentos=[]
			tipos_lancamentos.append(tipo_lancamento)
			tipos_lancamentos.append('iva')
			tipos_lancamentos.append('normal')
			if documento.movimento_abertura==True:
				tipo_lancamento='abertura'
				tipos_lancamentos.append(tipo_lancamento)
				#logger.info('TIPOS DE LANCAMENTOS %s' %str(tipos_lancamentos))
			if bool(conta.id)!=False:
				logger.info('PROCESSO INICIADO COM SEUCESSO')
				if conta.tipo_interno!='m':
					raise osv.except_osv(_('Acção Invalida !'), _('Tipo de Conta Nao Permitido!!'))	
				
				lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
							('conta_id','=',conta.id),
							('moeda_lancamento_id','in',lista_modedas_ids),
							('state','=','emitido'),
							#('periodo_id','in',periodos_ids),
							('data_lancamento','>=',documento.data_inicio),
							('data_lancamento','<=',documento.data_fim),
							('tipo_lancamento','in',tipos_lancamentos),
					])
				
				
				lancamento_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
							('conta_id','=',conta.id),
							('moeda_lancamento_id','in',lista_modedas_ids),
							('state','=','emitido'),
							#('periodo_id','in',periodos_ids),
							('data_lancamento','<',documento.data_inicio),
							('ano_fiscal_id','=',documento.ano_fiscal_id.id)
					])
				
				
				
				#logger.info('LANCAMENTOS ACTUAIS %s' %str(lancamento_ids))
				#logger.info('LANCAMENTOS ANTERIORES %s' %str(lancamento_anteriores_ids))
				
				total_credito_anterior=0
				total_debito_anterior=0
				total_saldo_anterior=0
				natureza_anterior=None
				
				
				lista_lancamentos=[]
				for lancamento in lancamento_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					lista_lancamentos.append({'id':lancamento.id,'data':lancamento.data_lancamento})
					
				#lista_lancamentos.sort(['data'])
				lista_lancamentos=sorted(lista_lancamentos, key=lambda d: (d['data']))
				lancamento_ids=[]
				for lancamento in lista_lancamentos:
					#logger.info('LISTA ORDENADA DE LANCAMENTOS %s' %str(lancamento))
					lancamento_ids.append(lancamento['id'])
				
				if documento.conversao_moeda=='mp':
					for lancamento in lancamento_anteriores_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						total_credito_anterior=total_credito_anterior+lancamento.credito_moeda_base
						total_debito_anterior=total_debito_anterior+lancamento.debito_moeda_base
						if total_credito_anterior>total_debito_anterior:
							total_saldo_anterior=total_credito_anterior-total_debito_anterior
							natureza_anterior='credito'
						elif total_credito_anterior<total_debito_anterior:
							total_saldo_anterior=total_debito_anterior-total_credito_anterior
							natureza_anterior='debito'
				
				if documento.conversao_moeda=='ms':
					for lancamento in lancamento_anteriores_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						total_credito_anterior=total_credito_anterior+lancamento.credito_secundario_arredondado
						total_debito_anterior=total_debito_anterior+lancamento.debito_secundario_arredondado
						if total_credito_anterior>total_debito_anterior:
							total_saldo_anterior=total_credito_anterior-total_debito_anterior
							natureza_anterior='credito'
						elif total_credito_anterior<total_debito_anterior:
							total_saldo_anterior=total_debito_anterior-total_credito_anterior
							natureza_anterior='debito'
				
				if documento.conversao_moeda=='ml':
					for lancamento in lancamento_anteriores_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						total_credito_anterior=total_credito_anterior+lancamento.credito
						total_debito_anterior=total_debito_anterior+lancamento.debito
						if total_credito_anterior>total_debito_anterior:
							total_saldo_anterior=total_credito_anterior-total_debito_anterior
							natureza_anterior='credito'
						elif total_credito_anterior<total_debito_anterior:
							total_saldo_anterior=total_debito_anterior-total_credito_anterior
							natureza_anterior='debito'
				
				
				
				
				total_credito=0
				total_debito=0
				contador=0
				for lancamento in lancamento_ids:
					lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					#logger.info('TIPOS DE LANCAMENTOS %s' %str(lancamento.tipo_lancamento))
					if documento.conversao_moeda=='mp':
						total_credito=total_credito+lancamento.credito_primario_arredondado
						total_debito=total_debito+lancamento.debito_primario_arredondado
						if contador==0:
							total_credito=total_credito+total_credito_anterior
							total_debito=total_debito+total_debito_anterior
							
						saldo=0
						natureza_saldo=None
						if total_credito>total_debito:
							saldo=total_credito-total_debito
							natureza_saldo='credito'
						elif total_credito<total_debito:
							saldo=total_debito-total_credito
							natureza_saldo='debito'
							
						val={
							'data':lancamento.data_lancamento,
							'diario_id':lancamento.movimento_id.diario_id.id,
							'numero_diario':lancamento.movimento_id.numero_diario,
							'documento':lancamento.movimento_id.documento_id.id,
							'num_doc':lancamento.movimento_id.numero_documento,
							'conta_id':lancamento.conta_id.id,
							'movimento_id':lancamento.movimento_id.id,
							'descricao':lancamento.descricao,
							'debito':lancamento.debito_primario_arredondado,
							'credito':lancamento.credito_primario_arredondado,
							'centro_custo':lancamento.reflexao_centro,
							'saldo':saldo,
							'natureza_saldo':natureza_saldo,
							'periodo_id':lancamento.periodo_id.id,
							'extrato_lancamento_id':documento.id,
							'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
						
							'debito_anterior':0,
							'credito_anterior':0,
							'saldo_anterior':0,
							'natureza_anteriro':natureza_anterior,
							
						}
						if contador==0:
							val['debito_anterior']=total_debito_anterior
							val['credito_anterior']=total_credito_anterior
							if total_debito_anterior>total_credito_anterior:
								saldo_anterior=total_debito_anterior-total_credito_anterior
							else:
								saldo_anterior=total_credito_anterior-total_debito_anterior
							val['saldo_anterior']=saldo_anterior
						
						
						debito=val['debito']
						credito=val['credito']
						logger.info('VALORES MAIORES QUE ZERO %s' %str(debito))
						logger.info('VALORES MAIORES QUE ZERO %s' %str(credito))
						if debito>0 or credito>0:
							logger.info('VALORES MAIORES QUE ZERO')
							self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
						
						
					if documento.conversao_moeda=='ms':
						total_credito=total_credito+lancamento.credito_secundario_arredondado
						total_debito=total_debito+lancamento.debito_secundario_arredondado
						
						if contador==0:
							total_credito=total_credito+total_credito_anterior
							total_debito=total_debito+total_debito_anterior
							
						saldo=0
						natureza_saldo=None
						if total_credito>total_debito:
							saldo=total_credito-total_debito
							natureza_saldo='credito'
						elif total_credito<total_debito:
							saldo=total_debito-total_credito
							natureza_saldo='debito'
							
						val={
							'data':lancamento.data_lancamento,
							'diario_id':lancamento.movimento_id.diario_id.id,
							'numero_diario':lancamento.movimento_id.numero_diario,
							'documento':lancamento.movimento_id.documento_id.id,
							'num_doc':lancamento.movimento_id.numero_documento,
							'conta_id':lancamento.conta_id.id,
							'movimento_id':lancamento.movimento_id.id,
							'descricao':lancamento.descricao,
							'debito':lancamento.debito_secundario_arredondado,
							'credito':lancamento.credito_secundario_arredondado,
							'centro_custo':lancamento.reflexao_centro,
							'saldo':saldo,
							'natureza_saldo':natureza_saldo,
							'periodo_id':lancamento.periodo_id.id,
							'extrato_lancamento_id':documento.id,
							'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
						
							'debito_anterior':0,
							'credito_anterior':0,
							'saldo_anterior':0,
							'natureza_anteriro':natureza_anterior,
							
						}
						if contador==0:
							val['debito_anterior']=total_debito_anterior
							val['credito_anterior']=total_credito_anterior
							if total_debito_anterior>total_credito_anterior:
								saldo_anterior=total_debito_anterior-total_credito_anterior
							else:
								saldo_anterior=total_credito_anterior-total_debito_anterior
							val['saldo_anterior']=saldo_anterior
							
						logger.info('VAL %s'%str(val))
						
						debito=val['debito']
						credito=val['credito']
						if debito>0 or credito>0:
							logger.info('VALORES MAIORES QUE ZERO')
							#lista_lancamentos.append(val)
							self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
						#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
						
						
						
					if documento.conversao_moeda=='ml':
						total_credito=total_credito+lancamento.credito
						total_debito=total_debito+lancamento.debito
						if contador==0:
							total_credito=total_credito+total_credito_anterior
							total_debito=total_debito+total_debito_anterior
							
						saldo=0
						natureza_saldo=None
						if total_credito>total_debito:
							saldo=total_credito-total_debito
							natureza_saldo='credito'
						elif total_credito<total_debito:
							saldo=total_debito-total_credito
							natureza_saldo='debito'
							
						val={
							'data':lancamento.data_lancamento,
							'diario_id':lancamento.movimento_id.diario_id.id,
							'numero_diario':lancamento.movimento_id.numero_diario,
							'documento':lancamento.movimento_id.documento_id.id,
							'num_doc':lancamento.movimento_id.numero_documento,
							'conta_id':lancamento.conta_id.id,
							'movimento_id':lancamento.movimento_id.id,
							'descricao':lancamento.descricao,
							'debito':lancamento.debito,
							'credito':lancamento.credito,
							'centro_custo':lancamento.reflexao_centro,
							'saldo':saldo,
							'natureza_saldo':natureza_saldo,
							'periodo_id':lancamento.periodo_id.id,
							'extrato_lancamento_id':documento.id,
							'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
						
							'debito_anterior':0,
							'credito_anterior':0,
							'saldo_anterior':0,
							'natureza_anteriro':natureza_anterior,
							
						}
						if contador==0:
							val['debito_anterior']=total_debito_anterior
							val['credito_anterior']=total_credito_anterior
							if total_debito_anterior>total_credito_anterior:
								saldo_anterior=total_debito_anterior-total_credito_anterior
							else:
								saldo_anterior=total_credito_anterior-total_debito_anterior
							val['saldo_anterior']=saldo_anterior
							
						logger.info('VAL %s'%str(val))
						debito=val['debito']
						credito=val['credito']
						if debito>0 or credito>0:
							logger.info('VALORES MAIORES QUE ZERO')
							#lista_lancamentos.append(val)
							self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
						#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
					contador=contador+1
			else:
				#logger.info('ENTROU 2')
				#raise osv.except_osv(_('Acção Invalida !'), _('Seleccione a Conta!!'))
				
				conta_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
								('ano_fiscal_id','=',documento.ano_fiscal_id.id),
								('tipo_interno','=','m')
					])
				
				#logger.info('IDENTIFICADOR DA MOEDA DE LANCAMENTO %s' %str(conta_ids))
				
				for conta in conta_ids:
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
						('conta_id','=',conta),
						('moeda_lancamento_id','in',lista_modedas_ids),
						('state','=','emitido'),
						('periodo_id','in',periodos_ids),
						('data_lancamento','>=',documento.data_inicio),
						('data_lancamento','<=',documento.data_fim),
						('tipo_lancamento','in',tipos_lancamentos),
						])
					#logger.info('IDENTIFICADOR DA MOEDA DE LANCAMENTO %s' %str(lancamento_ids))
					
					lancamento_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
								('conta_id','=',conta),
								('moeda_lancamento_id','in',lista_modedas_ids),
								('state','=','emitido'),
								('periodo_id','in',periodos_ids),
								('data_lancamento','<',documento.data_inicio),
								('ano_fiscal_id','=',documento.ano_fiscal_id.id)
						])
					#logger.info('LANCAMENTOS ANTERIORES ACHADOS %s' %str(lancamento_anteriores_ids))
							
					
					total_credito_anterior=0
					total_debito_anterior=0
					total_saldo_anterior=0
					natureza_anterior=None
					for lancamento in lancamento_anteriores_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						
						if documento.conversao_moeda=='mp':
							for lancamento in lancamento_anteriores_ids:
								lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
								total_credito_anterior=total_credito_anterior+lancamento.credito_primario_arredondado
								total_debito_anterior=total_debito_anterior+lancamento.debito_primario_arredondado
								if total_credito_anterior>total_debito_anterior:
									total_saldo_anterior=total_credito_anterior-total_debito_anterior
									natureza_anterior='credito'
								elif total_credito_anterior<total_debito_anterior:
									total_saldo_anterior=total_debito_anterior-total_credito_anterior
									natureza_anterior='debito'
						
						if documento.conversao_moeda=='ms':
							for lancamento in lancamento_anteriores_ids:
								lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
								total_credito_anterior=total_credito_anterior+lancamento.credito_secundario_arredondado
								total_debito_anterior=total_debito_anterior+lancamento.debito_secundario_arredondado
								if total_credito_anterior>total_debito_anterior:
									total_saldo_anterior=total_credito_anterior-total_debito_anterior
									natureza_anterior='credito'
								elif total_credito_anterior<total_debito_anterior:
									total_saldo_anterior=total_debito_anterior-total_credito_anterior
									natureza_anterior='debito'
						
						if documento.conversao_moeda=='ml':
							for lancamento in lancamento_anteriores_ids:
								lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
								total_credito_anterior=total_credito_anterior+lancamento.credito
								total_debito_anterior=total_debito_anterior+lancamento.debito
								if total_credito_anterior>total_debito_anterior:
									total_saldo_anterior=total_credito_anterior-total_debito_anterior
									natureza_anterior='credito'
								elif total_credito_anterior<total_debito_anterior:
									total_saldo_anterior=total_debito_anterior-total_credito_anterior
									natureza_anterior='debito'
					#	
					#	total_credito_anterior=total_credito_anterior+lancamento.credito
					#	total_debito_anterior=total_debito_anterior+lancamento.debito
					#	if total_credito_anterior>total_debito_anterior:
					#		total_saldo_anterior=total_credito_anterior-total_debito_anterior
					#		natureza_anterior='credito'
					#	elif total_credito_anterior<total_debito_anterior:
					#		total_saldo_anterior=total_debito_anterior-total_credito_anterior
					#		natureza_anterior='debito' 
					#
					##logger.info('LANCAMENTOS%s' %str(lancamento_ids))
					#total_credito=0
					#total_debito=0
					#saldo=0
					#for lancamento in lancamento_ids:
					#	lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
					#	#logger.info('TIPOS DE LANCAMENTOS %s' %str(lancamento.tipo_lancamento))
					#	total_credito=total_credito+lancamento.credito
					#	total_debito=total_debito+lancamento.debito
					#	
					#	natureza_saldo=None
					#	if total_credito>total_debito:
					#		saldo=total_credito-total_debito
					#		natureza_saldo='credito'
					#	elif total_credito<total_debito:
					#		saldo=total_debito-total_credito
					#		natureza_saldo='debito'
					
					if len(lancamento_ids)>0:	 
						total_credito=0
						total_debito=0
						for lancamento in lancamento_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							logger.info('TIPOS DE LANCAMENTOS %s' %str(lancamento.tipo_lancamento))
							
							if documento.conversao_moeda=='mp':
								total_credito=total_credito+lancamento.credito_primario_arredondado
								total_debito=total_debito+lancamento.debito_primario_arredondado
								saldo=0
								natureza_saldo=None
								if total_credito>total_debito:
									saldo=total_credito-total_debito
									natureza_saldo='credito'
								elif total_credito<total_debito:
									saldo=total_debito-total_credito
									natureza_saldo='debito'
									
								val={
									'data':lancamento.data_lancamento,
									'diario_id':lancamento.movimento_id.diario_id.id,
									'numero_diario':lancamento.movimento_id.numero_diario,
									'documento':lancamento.movimento_id.documento_id.id,
									'num_doc':lancamento.movimento_id.numero_documento,
									'conta_id':lancamento.conta_id.id,
									'movimento_id':lancamento.movimento_id.id,
									'descricao':lancamento.conta_id.nome,
									'debito':lancamento.debito_primario_arredondado,
									'credito':lancamento.credito_primario_arredondado,
									'centro_custo':lancamento.reflexao_centro,
									'saldo':saldo,
									'natureza_saldo':natureza_saldo,
									'periodo_id':lancamento.periodo_id.id,
									'extrato_lancamento_id':documento.id,
									'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
								
									'debito_anterior':total_debito_anterior,
									'credito_anterior':total_credito_anterior,
									'saldo_anterior':total_saldo_anterior,
									'natureza_anteriro':natureza_anterior,
									
								}
								logger.info('VAL %s'%str(val))
								debito=val['debito']
								credito=val['credito']
								if debito>0 or credito>0:
									logger.info('VALORES MAIORES QUE ZERO')
									#lista_lancamentos.append(val)
									self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
								#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
								
								
							if documento.conversao_moeda=='ms':
								total_credito=total_credito+lancamento.credito_secundario_arredondado
								total_debito=total_debito+lancamento.debito_secundario_arredondado
								saldo=0
								natureza_saldo=None
								if total_credito>total_debito:
									saldo=total_credito-total_debito
									natureza_saldo='credito'
								elif total_credito<total_debito:
									saldo=total_debito-total_credito
									natureza_saldo='debito'
									
								val={
									'data':lancamento.data_lancamento,
									'diario_id':lancamento.movimento_id.diario_id.id,
									'numero_diario':lancamento.movimento_id.numero_diario,
									'documento':lancamento.movimento_id.documento_id.id,
									'num_doc':lancamento.movimento_id.numero_documento,
									'conta_id':lancamento.conta_id.id,
									'movimento_id':lancamento.movimento_id.id,
									'descricao':lancamento.conta_id.nome,
									'debito':lancamento.debito_secundario_arredondado,
									'credito':lancamento.credito_secundario_arredondado,
									'centro_custo':lancamento.reflexao_centro,
									'saldo':saldo,
									'natureza_saldo':natureza_saldo,
									'periodo_id':lancamento.periodo_id.id,
									'extrato_lancamento_id':documento.id,
									'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
								
									'debito_anterior':total_debito_anterior,
									'credito_anterior':total_credito_anterior,
									'saldo_anterior':total_saldo_anterior,
									'natureza_anteriro':natureza_anterior,
									
								}
								logger.info('VAL %s'%str(val))
								debito=val['debito']
								credito=val['credito']
								if debito>0 or credito>0:
									logger.info('VALORES MAIORES QUE ZERO')
									#lista_lancamentos.append(val)
									self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							
								#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
								
								
								
							if documento.conversao_moeda=='ml':
								total_credito=total_credito+lancamento.credito
								total_debito=total_debito+lancamento.debito
								saldo=0
								natureza_saldo=None
								if total_credito>total_debito:
									saldo=total_credito-total_debito
									natureza_saldo='credito'
								elif total_credito<total_debito:
									saldo=total_debito-total_credito
									natureza_saldo='debito'
									
								val={
									'data':lancamento.data_lancamento,
									'diario_id':lancamento.movimento_id.diario_id.id,
									'numero_diario':lancamento.movimento_id.numero_diario,
									'documento':lancamento.movimento_id.documento_id.id,
									'num_doc':lancamento.movimento_id.numero_documento,
									'conta_id':lancamento.conta_id.id,
									'movimento_id':lancamento.movimento_id.id,
									'descricao':lancamento.conta_id.nome,
									'debito':lancamento.debito,
									'credito':lancamento.credito,
									'centro_custo':lancamento.reflexao_centro,
									'saldo':saldo,
									'natureza_saldo':natureza_saldo,
									'periodo_id':lancamento.periodo_id.id,
									'extrato_lancamento_id':documento.id,
									'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
								
									'debito_anterior':total_debito_anterior,
									'credito_anterior':total_credito_anterior,
									'saldo_anterior':total_saldo_anterior,
									'natureza_anteriro':natureza_anterior,
									
								}
								logger.info('VAL %s'%str(val))
								debito=val['debito']
								credito=val['credito']
								if debito>0 or credito>0:
									logger.info('VALORES MAIORES QUE ZERO')
									#lista_lancamentos.append(val)
									self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
								#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
			
			#if moeda_lanc!='all':
			#	self.write(cr,uid,documento.id,{'moeda_lancamento_id':int(moeda_lanc)})
			#else:
			#	self.write(cr,uid,documento.id,{'moeda_lancamento_id':moeda_lanc})
		return {}
	   
		
	def carregar_linhas_lancamentos_diario(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		for documento in self.browse(cr,uid,ids):
			
			
			if bool(documento.diario_id.id)==False:
				raise osv.except_osv(_('Acção Inválida !'), _('Seleccione o Diário!!'))  
			
			lista_modedas_ids=self.pool.get('res.currency').search(cr,uid,[])		   
			if documento.moeda_lancamento_id!='all':
				lista_modedas_ids=[]
				lista_modedas_ids.append(int(documento.moeda_lancamento_id))
			
			#lancamentos_ids=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,[
			#					('extrato_diario_lancamento_id','=',documento.id),
			#		])
			for lancamento in documento.lancamentos_diario_ids:
				self.pool.get('dotcom.contabilidade.extratos.diario.linhas').write(cr,uid,lancamento.id,{'extrato_diario_lancamento_id':False})
			
			#self.pool.get('dotcom.contabilidade.extratos.diario.linhas').unlink(cr,uid,lancamentos_ids)	
			
			if bool(documento.diario_id.id)==True:
				lancamentos_ids=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,[
								('data','>=',documento.data_inicio),
								('data','<=',documento.data_fim),
								#('moeda_lancamento_id','in',lista_modedas_ids),
								('diario_id','=',documento.diario_id.id),
								('state','=','emitido'),
					])
				
				logger.info('CONTADOR ACHADO %s' %str(lancamentos_ids))
				contador =1
				for lancamento in lancamentos_ids:
					lancamento_object=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').browse(cr,uid,lancamento)
					#logger.info('CONTADOR ACHADO %s' %str(lancamento_object.debito))
					#logger.info('CONTADOR ACHADO %s' %str(lancamento_object.credito))
					self.pool.get('dotcom.contabilidade.extratos.diario.linhas').write(cr,uid,lancamento,{'extrato_diario_lancamento_id':documento.id})
					#if documento.conversao_moeda=='mp':
					#	val['debito']=lancamento.debito_moeda_base
					#	val['credito']=lancamento.credito_moeda_base
					#
					#elif documento.conversao_moeda=='ms':
					#	val['debito']=lancamento.debito_moeda_secundaria
					#	val['credito']=lancamento.credito_moeda_secundaria	
					
					contador=contador+1
					#self.pool.get('dotcom.contabilidade.extratos.diario.linhas').create(cr,uid,val)
					
				#self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamentos_ids,{'extrato_diario_lancamento_id':lancamentos_ids})
				
		return True
						
	
	def imprimir_todos_diarios(self,cr,uid,ids,context=None):
		if context is None:
			context={}
		
		for documento in self.browse(cr,uid,ids):
			logger.info('-----IMPRESSAO DE DIARIOS INICIADA-----')
			if documento.imprimir_tudo==True:

				query=[]
				query.append(('ano_fiscal_id','=',documento.ano_fiscal_id.id))
				query.append(('state','=','emitido'))
				query.append(('data','>=',documento.data_inicio))
				query.append(('data','<=',documento.data_fim))

				lista_modedas_ids=self.pool.get('res.currency').search(cr,uid,[])		   
				if documento.moeda_lancamento_id!='all':
					lista_modedas_ids=[]
					lista_modedas_ids.append(int(documento.moeda_lancamento_id))
				query.append(('moeda_lancamento_id','in',lista_modedas_ids))

				lista_lancamentos_ids=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,query)
				for lancamento in lista_lancamentos_ids:
					self.pool.get('dotcom.contabilidade.extratos.diario.linhas').write(cr,uid,lancamento,{'extrato_diario_lancamento_id':documento.id})


				# lista_lancamentos_ids=self.pool.get('dotcom.contabilidade.extratos.diario.linhas').search(cr,uid,[])
				# for lancamento in lista_lancamentos_ids:
				#	 self.pool.get('dotcom.contabilidade.extratos.diario.linhas').unlink(cr,uid,lancamento)
			
				
				# logger.info('-----IMPRESSAO DE DIARIOS A CORRER-----')
				# lista_modedas_ids=self.pool.get('res.currency').search(cr,uid,[])		   
				# if documento.moeda_lancamento_id!='all':
				#	 lista_modedas_ids=[]
				#	 lista_modedas_ids.append(int(documento.moeda_lancamento_id))
					
				# for lanc in documento.lancamentos_diario_ids:
				#	 self.pool.get('dotcom.contabilidade.extratos.diario.linhas').unlink(cr,uid,lanc.id)
				
				# periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
				#				 ('fiscalyear_id','=',documento.ano_fiscal_id.id)				
				#	 ])
				
				# lancamentos_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
				#				 ('data_lancamento','>=',documento.data_inicio),
				#				 ('data_lancamento','<=',documento.data_fim),
				#				 ('moeda_lancamento_id','in',lista_modedas_ids),
				#				 ('state','=','emitido'),
				#	 ])
				# total_credito=0
				# total_debito=0
				
				# logger.info('lancamentos_ids simples: ============================ %s' %str(lancamentos_ids))
				# lista_lancamentos=[]
				# for lancamento in lancamentos_ids:
				#	 lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
				#	 lista_lancamentos.append({'id':lancamento.id,'data':lancamento.data_lancamento})
					
				# lista_lancamentos=sorted(lista_lancamentos, key=lambda d: (d['data']))
				# lancamentos_ids=[]
				# for lancamento in lista_lancamentos:
				#	 lancamentos_ids.append(lancamento['id'])
				
				
				# credito_acumulado=0
				# debito_acumulado=0
				
				# lista_lancamentos=[]
				# for lancamento in lancamentos_ids:
				#	 lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
				#	 #if lancamento.movimento_id.diario_id.id==documento.diario_id.id:
				#	 total_credito=total_credito+lancamento.credito
				#	 total_debito=total_debito+lancamento.debito
				#	 saldo=0
				   
				#	 logger.info('-----IMPRESSAO DE DIARIOS A CORRER-----')
				#	 val={
				#		 'data':lancamento.movimento_id.data,
				#		 'movimento_id':lancamento.movimento_id.id,
				#		 'diario_id':lancamento.movimento_id.diario_id.id,
				#		 'numero_diario':lancamento.movimento_id.numero_diario,
				#		 'documento_id':lancamento.movimento_id.documento_id.id,
				#		 'numero_documento':lancamento.movimento_id.numero_documento,
				#		 'conta_id':lancamento.conta_id.id,
				#		 'ref_conta':lancamento.conta_id.ref,
				#		 'descricao':lancamento.descricao,
						
				#		 #'debito_acumulado':debito_acumulado,
				#		 'debito_acumulado':total_debito,

				#		 #'credito_acumulado':credito_acumulado,
				#		 'credito_acumulado':total_credito,

				#		 'centro_custo':lancamento.reflexao_centro,
				#		 'saldo':0,
				#		 'natureza_saldo':'debito',
				#		 'periodo_id':lancamento.periodo_id.id,
				#		 'extrato_diario_lancamento_id':documento.id,
				#	 }
					
				#	 if documento.conversao_moeda=='mp':
				#		 val['debito']=lancamento.debito_moeda_base
				#		 val['credito']=lancamento.credito_moeda_base
						
				#	 elif documento.conversao_moeda=='ms':
				#		 val['debito']=lancamento.debito_moeda_secundaria
				#		 val['credito']=lancamento.credito_moeda_secundaria
						
				#	 elif documento.conversao_moeda=='ml':
				#		 val['debito']=lancamento.debito
				#		 val['credito']=lancamento.credito
					
				#	 if val['debito']>0 or val['credito']>0:
				#		 lista_lancamentos.append(val)	
				#		 self.pool.get('dotcom.contabilidade.extratos.diario.linhas').create(cr,uid,val)
							
					#lista_lancamentos.append(val)
					
	   
		logger.info('-----IMPRESSAO DE DIARIOS EM EXECUCAO-----')   
		return {
					'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
					'view_id': False,
					'res_model': 'dotcom.contabilidade.extratos',
					'report_name': 'dotcom_contabilidade_extrato_diario_report',
					'domain': [],
					'context': dict(context, active_ids=ids),
					'type': 'ir.actions.report.xml',
					'report_type': 'pdf',
					'res_id': ids and ids[0] or False
			}
						 
	
	def imprimir_todas_contas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		lista_modedas_ids=self.pool.get('res.currency').search(cr,uid,[])
		action={}		
		for documento in self.browse(cr,uid,ids):
			logger.info('-----IMPRESSAO DE DIARIOS INICIADA-----')
			if documento.imprimir_tudo==True:
			
				lista_contas_movimento_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
																			('ano_fiscal_id','=',documento.ano_fiscal_id.id),
																			('tipo_interno','=','m'),
																			])			
				moeda_lanc=documento.moeda_lancamento_id
				if documento.moeda_lancamento_id!='all':
					lista_modedas_ids=[]
					lista_modedas_ids.append(int(documento.moeda_lancamento_id))
				
				lancamentos_locais_ids=self.pool.get('dotcom.contabilidade.extratos.contas.linhas').search(cr,uid,[])
				for lanc in lancamentos_locais_ids:
					self.pool.get('dotcom.contabilidade.extratos.contas.linhas').unlink(cr,uid,lanc)
				
				periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
								('fiscalyear_id','=',documento.ano_fiscal_id.id),
								('closing','=',False),
					])
				
				periodos_fecho=[]
				if documento.movimento_fecho==True:
					periodos_fecho=self.pool.get('configuration.period').search(cr,uid,[
								('fiscalyear_id','=',documento.ano_fiscal_id.id),
								('closing','=',True),])
				logger.info('PERIODOS DE FECHO ACHADOS %s' %str(periodos_ids))
				for periodo in periodos_fecho:
					periodos_ids.append(periodo)
				
				tipo_lancamento=False
				tipos_lancamentos=[]
				tipos_lancamentos.append(tipo_lancamento)
				tipos_lancamentos.append('iva')
				tipos_lancamentos.append('normal')
				if documento.movimento_abertura==True:
					tipo_lancamento='abertura'
					tipos_lancamentos.append(tipo_lancamento)
					
				for conta in lista_contas_movimento_ids:
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
								('conta_id','=',conta),
								('moeda_lancamento_id','in',lista_modedas_ids),
								('state','=','emitido'),
								('periodo_id','in',periodos_ids),
								('data_lancamento','>=',documento.data_inicio),
								('data_lancamento','<=',documento.data_fim),
								('tipo_lancamento','in',tipos_lancamentos),
						])
					logger.info('LANCAMENTOS  ACHADOS %s' %str(lancamento_ids))
					
					lancamento_anteriores_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
								('conta_id','=',conta),
								('moeda_lancamento_id','in',lista_modedas_ids),
								('state','=','emitido'),
								('periodo_id','in',periodos_ids),
								('data_lancamento','<',documento.data_inicio),
								('ano_fiscal_id','=',documento.ano_fiscal_id.id)
						])
					
									
					total_credito_anterior=0
					total_debito_anterior=0
					total_saldo_anterior=0
					natureza_anterior=None
					
					if documento.conversao_moeda=='mp':
						for lancamento in lancamento_anteriores_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							total_credito_anterior=total_credito_anterior+lancamento.credito_moeda_base
							total_debito_anterior=total_debito_anterior+lancamento.debito_moeda_base
							if total_credito_anterior>total_debito_anterior:
								total_saldo_anterior=total_credito_anterior-total_debito_anterior
								natureza_anterior='credito'
							elif total_credito_anterior<total_debito_anterior:
								total_saldo_anterior=total_debito_anterior-total_credito_anterior
								natureza_anterior='debito'
					
					if documento.conversao_moeda=='ms':
						for lancamento in lancamento_anteriores_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							total_credito_anterior=total_credito_anterior+lancamento.credito_moeda_secundaria
							total_debito_anterior=total_debito_anterior+lancamento.debito_moeda_secundaria
							if total_credito_anterior>total_debito_anterior:
								total_saldo_anterior=total_credito_anterior-total_debito_anterior
								natureza_anterior='credito'
							elif total_credito_anterior<total_debito_anterior:
								total_saldo_anterior=total_debito_anterior-total_credito_anterior
								natureza_anterior='debito'
					
					if documento.conversao_moeda=='ml':
						for lancamento in lancamento_anteriores_ids:
							lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
							total_credito_anterior=total_credito_anterior+lancamento.credito
							total_debito_anterior=total_debito_anterior+lancamento.debito
							if total_credito_anterior>total_debito_anterior:
								total_saldo_anterior=total_credito_anterior-total_debito_anterior
								natureza_anterior='credito'
							elif total_credito_anterior<total_debito_anterior:
								total_saldo_anterior=total_debito_anterior-total_credito_anterior
								natureza_anterior='debito'
					
					#logger.info('LANCAMENTOS%s' %str(documento.conversao_moeda))
					total_credito=0
					total_debito=0
					for lancamento in lancamento_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						#logger.info('TIPOS DE LANCAMENTOS %s' %str(lancamento.tipo_lancamento))
						if documento.conversao_moeda=='mp':
							total_credito=total_credito+lancamento.credito_moeda_base
							total_debito=total_debito+lancamento.debito_moeda_base
							saldo=0
							natureza_saldo=None
							if total_credito>total_debito:
								saldo=total_credito-total_debito
								natureza_saldo='credito'
							elif total_credito<total_debito:
								saldo=total_debito-total_credito
								natureza_saldo='debito'
								
							val={
								'data':lancamento.data_lancamento,
								'diario_id':lancamento.movimento_id.diario_id.id,
								'numero_diario':lancamento.movimento_id.numero_diario,
								'documento':lancamento.movimento_id.documento_id.id,
								'num_doc':lancamento.movimento_id.numero_documento,
								'conta_id':lancamento.conta_id.id,
								'movimento_id':lancamento.movimento_id.id,
								'descricao':lancamento.conta_id.nome,
								'debito':lancamento.debito_moeda_base,
								'credito':lancamento.credito_moeda_base,
								'centro_custo':lancamento.reflexao_centro,
								'saldo':saldo,
								'natureza_saldo':natureza_saldo,
								'periodo_id':lancamento.periodo_id.id,
								'extrato_lancamento_id':documento.id,
								'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
							
								'debito_anterior':total_debito_anterior,
								'credito_anterior':total_credito_anterior,
								'saldo_anterior':total_saldo_anterior,
								'natureza_anteriro':natureza_anterior,
								
							}
							#logger.info('VAL %s'%str(val))
							debito=val['debito']
							credito=val['credito']
							if debito>0 or credito>0:
								#logger.info('VALORES MAIORES QUE ZERO')
								#lista_lancamentos.append(val)
								self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							
							
						if documento.conversao_moeda=='ms':
							total_credito=total_credito+lancamento.credito_moeda_secundaria
							total_debito=total_debito+lancamento.debito_moeda_secundaria
							saldo=0
							natureza_saldo=None
							if total_credito>total_debito:
								saldo=total_credito-total_debito
								natureza_saldo='credito'
							elif total_credito<total_debito:
								saldo=total_debito-total_credito
								natureza_saldo='debito'
								
							val={
								'data':lancamento.data_lancamento,
								'diario_id':lancamento.movimento_id.diario_id.id,
								'numero_diario':lancamento.movimento_id.numero_diario,
								'documento':lancamento.movimento_id.documento_id.id,
								'num_doc':lancamento.movimento_id.numero_documento,
								'conta_id':lancamento.conta_id.id,
								'movimento_id':lancamento.movimento_id.id,
								'descricao':lancamento.conta_id.nome,
								'debito':lancamento.debito_moeda_secundaria,
								'credito':lancamento.credito_moeda_secundaria,
								'centro_custo':lancamento.reflexao_centro,
								'saldo':saldo,
								'natureza_saldo':natureza_saldo,
								'periodo_id':lancamento.periodo_id.id,
								'extrato_lancamento_id':documento.id,
								'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
							
								'debito_anterior':total_debito_anterior,
								'credito_anterior':total_credito_anterior,
								'saldo_anterior':total_saldo_anterior,
								'natureza_anteriro':natureza_anterior,
								
							}
							#logger.info('VAL %s'%str(val))
							debito=val['debito']
							credito=val['credito']
							if debito>0 or credito>0:
								#logger.info('VALORES MAIORES QUE ZERO')
								#lista_lancamentos.append(val)
								self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							
							
							
						if documento.conversao_moeda=='ml':
							total_credito=total_credito+lancamento.credito
							total_debito=total_debito+lancamento.debito
							saldo=0
							natureza_saldo=None
							if total_credito>total_debito:
								saldo=total_credito-total_debito
								natureza_saldo='credito'
							elif total_credito<total_debito:
								saldo=total_debito-total_credito
								natureza_saldo='debito'
								
							val={
								'data':lancamento.data_lancamento,
								'diario_id':lancamento.movimento_id.diario_id.id,
								'numero_diario':lancamento.movimento_id.numero_diario,
								'documento':lancamento.movimento_id.documento_id.id,
								'num_doc':lancamento.movimento_id.numero_documento,
								'conta_id':lancamento.conta_id.id,
								'movimento_id':lancamento.movimento_id.id,
								'descricao':lancamento.conta_id.nome,
								'debito':lancamento.debito,
								'credito':lancamento.credito,
								'centro_custo':lancamento.reflexao_centro,
								'saldo':saldo,
								'natureza_saldo':natureza_saldo,
								'periodo_id':lancamento.periodo_id.id,
								'extrato_lancamento_id':documento.id,
								'moeda_lancamento_id':lancamento.moeda_lancamento_id.id,	
							
								'debito_anterior':total_debito_anterior,
								'credito_anterior':total_credito_anterior,
								'saldo_anterior':total_saldo_anterior,
								'natureza_anteriro':natureza_anterior,
								
							}
							#logger.info('VAL %s'%str(val))
							debito=val['debito']
							credito=val['credito']
							if debito>0 or credito>0:
								logger.info('VALORES MAIORES QUE ZERO')
								#lista_lancamentos.append(val)
								self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
							#self.pool.get('dotcom.contabilidade.extratos.contas.linhas').create(cr,uid,val)
			logger.info('-----IMPRESSAO DE DIARIOS EM EXECUCAO-----')   
			action = {
				'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
				'view_id': False,
				'res_model': 'dotcom.contabilidade.extratos',
				'report_name': 'dotcom_contabilidade_extrato_conta_report',
				'domain': [],
				'context': dict(context, active_ids=ids),
				'type': 'ir.actions.report.xml',
				'report_type': 'pdf',
				'res_id': ids and ids[0] or False
			}
				
		return action
	
dotcom_contabilidade_extratos()


class dotcom_linhas_extrato_contas(osv.osv):
	_name='dotcom.contabilidade.extratos.contas.linhas'
	_columns={
		'data':fields.date('Data', readonly=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',readonly=True),
		'numero_diario':fields.char('N. Diário',size=50,readonly=True),
		'documento':fields.many2one('dotcom.contabilidade.documento','Doc',readonly=True),
		'num_doc':fields.char('N. Doc', size=50,readonly=True),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',readonly=True),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento',readonly=True),
		'descricao':fields.char('Descrição', size=60,readonly=True),
		'debito':fields.float('Débito',readonly=True),
		'credito':fields.float('Crédito',readonly=True),
		'saldo':fields.float('Saldo',readonly=True),
		'debito_anterior':fields.float('Débito Acumulado',readonly=True),
		'credito_anterior':fields.float('Crédito Acumulado',readonly=True),
		'saldo_anterior':fields.float('Saldo Acumulado',readonly=True),
		'natureza_anteriro':fields.selection([('credito','C'),('debito','D')],'Natureza',readonly=True),
		'natureza_saldo':fields.selection([('credito','C'),('debito','D')],'Natureza',readonly=True),
		'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
		'centro_custo':fields.boolean('C. Custo',readonly=True),
		'moeda_lancamento_id':fields.many2one('res.currency','Moeda Lanc', readonly=True),
		'extrato_lancamento_id':fields.many2one('dotcom.contabilidade.extratos','Extrato'),
		
		
		#'extrato_diario_lancamento_id':fields.many2one('dotcom.contabilidade.extratos','Extrato'),
	}
	
	_rec_name='data'
	
	
	def abrir_movimento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		movimento_id=None
		for documento in self.browse(cr,uid,ids):
			movimento_id=documento.movimento_id.id
			
		return {
						'type': 'ir.actions.act_window',
						'name': 'Estorno Movimentos',
						'view_mode': 'form',
						'view_type': 'form',
						'res_model': 'dotcom.contabilidade.movimentos',
						'res_id':movimento_id,
						'target': 'new',
						'context': context,
						'nodestroy': True,
					}
	
	def on_change_conta(self,cr,uid,ids,conta_id,context=None):
		if context is None:
			context={}
		conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_id)
		val={'descricao':conta.nome}
		return{'value':val}
		
dotcom_linhas_extrato_contas()


class dotcom_linhas_extrato_diario(osv.osv):
	_name='dotcom.contabilidade.extratos.diario.linhas'
	_columns={

		#'data':fields.date('Data', readonly=True),
		'data':fields.related('lancamento_diario_id','data_lancamento',type='date',relation='dotcom.contabilidade.lancamentos.diarios',string='Data',store=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário', readonly=True),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento', readonly=True),

		'numero_diario':fields.related('movimento_id','numero_diario',type='char',relation='dotcom.contabilidade.movimentos',string='Número Diário',store=True),
		'numero_documento':fields.related('movimento_id','numero_documento',type='char',relation='dotcom.contabilidade.movimentos',string='Número Documento',store=True),
		
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos', 'Movimento', readonly=True),
		'moeda_lancamento_id':fields.related('movimento_id','moeda_lancamento_id',type='many2one',relation='res.currency',string='Moeda de Lançamento',readonly=True),
		'lancamento_diario_id':fields.many2one('dotcom.contabilidade.lancamentos.diarios','Lancamento Diario'),
		'state':fields.related('lancamento_diario_id','state',type='char',relation='dotcom.contabilidade.lancamentos.diarios',string='Estado',readonly=True, store=True),
		
		'ano_fiscal_id':fields.related('lancamento_diario_id','ano_fiscal_id',type='many2one',relation='configuration.fiscalyear',string='Ano Fiscal',readonly=True,store=True),
		
		
		#'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta', readonly=True),
		'conta_id':fields.related('lancamento_diario_id','conta_id',type='many2one',relation='dotcom.contabilidade.plano.contas',string='Conta',readonly=True,store=True),
		

		#'descricao':fields.char('Descrição', size=100, readonly=True),
		'descricao':fields.related('lancamento_diario_id','descricao',type='char',string='Descrição',readonly=True,store=True),

		#'debito':fields.float('Débito', readonly=True),
		'debito':fields.related('lancamento_diario_id','debito',type='float',string='Débito',readonly=True,store=True),

		#'credito':fields.float('Crédito', readonly=True),
		'credito':fields.related('lancamento_diario_id','credito',type='float',string='Crédito',readonly=True,store=True),
		
		#'debito_moeda_primaria':fields.float('Débito MP', readonly=True, help="Débito na moeda principal"),
		'debito_moeda_primaria':fields.related('lancamento_diario_id','debito_moeda_base',type='float',string='Débito MP',readonly=True,store=True,help="Débito na moeda principal"),

		#'credito_moeda_primaria':fields.float('Crédito MP', readonly=True,help="Crédito na moeda principal"),
		'credito_moeda_primaria':fields.related('lancamento_diario_id','credito_moeda_base',type='float',string='Crédito MP',readonly=True,store=True,help="Débito na moeda principal"),


		#'debito_ms':fields.float('Débito MS', readonly=True,help="Débito na moeda secundária"),
		'debito_ms':fields.related('lancamento_diario_id','debito_moeda_secundaria',type='float',string='Débito MS',readonly=True,store=True,help="Débito na moeda secundária"),


		#'credito_ms':fields.float('Crédito MS', readonly=True,help="Crédito na moeda secundária"),
		'credito_ms':fields.related('lancamento_diario_id','credito_moeda_secundaria',type='float',string='Crédito MS',readonly=True,store=True,help="Crédito na moeda secundária"),
		
		'debito_anterior':fields.float('Debito Anterior', readonly=True),
		'credito_anterior':fields.float('Credito Anterio' , readonly=True),
		
		'debito_acumulado':fields.float('Debito Acumulado', readonly=True),
		'credito_acumulado':fields.float('Credito Acumulado' , readonly=True),
		
		'saldo':fields.float('Saldo', readonly=True),
		'natureza_saldo':fields.selection([('credito','C'),('debito','D')],'Natureza', readonly=True),
		'periodo_id':fields.related('lancamento_diario_id','periodo_id',type='many2one',relation='configuration.period',string='Periodo',readonly=True,store=True),
		'centro_custo':fields.boolean('C. Custo', readonly=True),
		'ref_conta':fields.char('Referencia', size=100, readonly=True),
		
		#'extrato_lancamento_id':fields.many2one('dotcom.contabilidade.extratos','Extrato'),
		'extrato_diario_lancamento_id':fields.many2one('dotcom.contabilidade.extratos','Extrato'),
	}
	
	
	
	def abrir_movimento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		movimento_id=None
		for documento in self.browse(cr,uid,ids):
			movimento_id=documento.movimento_id.id
			
		return {
						'type': 'ir.actions.act_window',
						'name': 'Estorno Movimentos',
						'view_mode': 'form',
						'view_type': 'form',
						'res_model': 'dotcom.contabilidade.movimentos',
						'res_id':movimento_id,
						'target': 'new',
						'context': context,
						'nodestroy': True,
					}
		
	
dotcom_linhas_extrato_diario()


class dotcom_linhas_extrato_centro_custos(osv.osv):
	_name='dotcom.contabilidade.extratos.centro.linhas'
	_columns={
		'data':fields.date('Data',readonly=True),
		
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Origem',readonly=True),
		'debito':fields.float('Débito',readonly=True),
		'credito':fields.float('Crédito',readonly=True),
		'saldo':fields.float('Saldo',readonly=True),
		'natureza_saldo':fields.selection([('credito','C'),('debito','D')],'Natureza',readonly=True),
		'descricao':fields.char('Descrição', size=100,),
		
		'ref_conta':fields.char('Refêrencia', size=100,readonly=True),
		'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento',readonly=True),
		# 'documento_id':fields.char('N. Documento', size=100,readonly=True,),
		# 'diario_id':fields.char('N. Diário', size=100,readonly=True),
		'diario_id':fields.related('movimento_id','numero_diario',type='char',relation='dotcom.contabilidade.movimentos',string='Número Diário',store=True),
		'documento_id':fields.related('movimento_id','numero_documento',type='char',relation='dotcom.contabilidade.movimentos',string='Número Documento',store=True),
		
		
		'diario_object_id':fields.many2one('dotcom.contabilidade.diario','Diário'),
		'documento_object_id':fields.many2one('dotcom.contabilidade.documento','Documento'),
		'conta_centro_custos_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','Conta C. Custo',readonly=True),
		'plano_centro_id':fields.many2one('dotcom.contabilidade.centros.custos', 'Plano C. Custos',readonly=True),
		'extrato_centro_lancamento_id':fields.many2one('dotcom.contabilidade.extratos','Extrato',),
	}
	
	def abrir_movimento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		movimento_id=None
		for documento in self.browse(cr,uid,ids):
			movimento_id=documento.movimento_id.id
			
		return {
						'type': 'ir.actions.act_window',
						'name': 'Estorno Movimentos',
						'view_mode': 'form',
						'view_type': 'form',
						'res_model': 'dotcom.contabilidade.movimentos',
						'res_id':movimento_id,
						'target': 'new',
						'context': context,
						'nodestroy': True,
					}
	
dotcom_linhas_extrato_centro_custos()




class dotcom_analise_orcamental(osv.osv):
	
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
		
		result=('ml','Moeda de Lancamento')
		this.append(result)
			
		return this
	
	_name='dotcom.contabilidade.analise.orcamental'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta ',),
		'periodo_id':fields.many2one('configuration.period','Período',required=True),
		'orcamento_id':fields.many2one('dotcom.contabilidade.orcamentos','Orcamento', required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id),('state','=','emitido')]"),
		'conversao_moeda':fields.selection(_acerto,'Moeda', required=True),
		'linha_orcamento_ids':fields.one2many('dotcom.contabilidade.analise.orcamental.linhas','orcamento_id','Linhas', readonly=True)
	}
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'conversao_moeda':'mp'
		}
	
	
	def on_change_ano_fiscal(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
		
		#periodos_ids=self.pool.get('configuration.period').search(cr,uid,[('fiscalyear_id','=',ano_fiscal_id)])
		logger.info('PROCESSO DO ANO FISCAL A CORRER')
		return {'value':{'periodo_id':False,'orcamento_id':False,'conta_id':False,'linha_orcamento_ids':[]}}
	
	def carregar_linhas_orcamento(self,cr,uid,ids,context=None):
		if context is None:
			context={}
							
		for documento in self.browse(cr,uid,ids):
			
			for linha in documento.linha_orcamento_ids:
				self.pool.get('dotcom.contabilidade.analise.orcamental.linhas').unlink(cr,uid,linha.id)
			
			periodo_code=documento.periodo_id.code[:2]
			periodo=self.get_periodo(cr,uid,ids,documento.periodo_id)
			if bool(documento.conta_id.id):
				
				
				
				orcamento_periodo_ids=self.pool.get('dotcom.custos.orcamentos').search(cr,uid,[
									('orcamento_id','=',documento.orcamento_id.id),
									('conta','=',documento.conta_id.id),
					])

				
				logger.info('PERIODO ACHADO %s' %str(periodo_code))
				
				if len(orcamento_periodo_ids)>0:
					orcamento_obj=self.pool.get('dotcom.custos.orcamentos').browse(cr,uid,orcamento_periodo_ids[0])
					valor_orcamentado_periodo=0
					
					if documento.conversao_moeda=='mp':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan_mp
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev_mp
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar_mp
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr_mp
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio_mp   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun_mp
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul_mp
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago_mp
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set_mp	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr_mp  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov_mp
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez_mp
					
					if documento.conversao_moeda=='ms':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan_ms
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev_ms
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar_ms
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr_ms
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio_ms   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun_ms
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul_ms
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago_ms
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set_ms	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr_ms  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov_ms
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez_ms
							
					if documento.conversao_moeda=='ml':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez  
					
					
					
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('conta_id','=',documento.conta_id.id),
												('state','=','emitido'),
												('periodo_id','=',documento.periodo_id.id)
										])
					
					logger.info('TESTE DE VALOR ORCAMENTADO PARA O PERIODO %s' %str(lancamento_ids))
					
					total_debito=0
					total_credito=0
					saldo=0
					natureza=None
					percentagem=0
					valor_desvio=0
					for lancamento in lancamento_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if documento.conversao_moeda=='mp':
								total_credito=total_credito+lancamento.credito_moeda_base
								total_debito=total_debito+lancamento.debito_moeda_base
						elif documento.conversao_moeda=='ms':
							total_credito=total_credito+lancamento.credito_moeda_secundaria
							total_debito=total_debito+lancamento.debito_moeda_secundaria
					
					if total_debito>total_credito:
						saldo=total_debito-total_credito
						natureza='d'
					elif total_credito>total_debito:
						saldo=total_credito-total_debito
						natureza='c'
					if saldo!=0:
						valor_desvio= 0
						if natureza=='d':
							valor_desvio=saldo-valor_orcamentado_periodo
						elif natureza=='c':
							valor_desvio=-saldo-valor_orcamentado_periodo
						
						percentagem=(valor_desvio*100)/valor_orcamentado_periodo
							
					val={
							'conta_id':documento.conta_id.id,
							'valor_orcamentado':valor_orcamentado_periodo,
							'valor_movimentado':saldo,
							'valor_desvio':valor_desvio,
							'percentagem':percentagem,
							'orcamento_id':documento.id
						}
					self.pool.get('dotcom.contabilidade.analise.orcamental.linhas').create(cr,uid,val)
				else:
					raise osv.except_osv(_('Acção Inválida !'), _('Conta não Orçamentada no documento seleccionado!!'))
			else:
				orcamento_periodo_ids=self.pool.get('dotcom.custos.orcamentos').search(cr,uid,[
							('orcamento_id','=',documento.orcamento_id.id),
					])
				
				logger.info(' ORCAMENTADO ACHADOS PARA O PERIODO %s' %str(orcamento_periodo_ids))
				orcamento_obj=self.pool.get('dotcom.custos.orcamentos').browse(cr,uid,orcamento_periodo_ids[0])
				
				for orcamento in orcamento_periodo_ids:
					orcamento_obj=self.pool.get('dotcom.custos.orcamentos').browse(cr,uid,orcamento)
					valor_orcamentado_periodo=0
					
					if documento.conversao_moeda=='mp':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan_mp
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev_mp
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar_mp
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr_mp
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio_mp   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun_mp
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul_mp
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago_mp
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set_mp	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr_mp  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov_mp
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez_mp
							
					if documento.conversao_moeda=='ms':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan_ms
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev_ms
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar_ms
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr_ms
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio_ms   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun_ms
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul_ms
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago_ms
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set_ms	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr_ms  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov_ms
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez_ms
							
					if documento.conversao_moeda=='ml':
						if periodo_code=='01':
							valor_orcamentado_periodo=orcamento_obj.jan
						elif periodo_code=='02':
							valor_orcamentado_periodo=orcamento_obj.fev
						if periodo_code=='03':
							valor_orcamentado_periodo=orcamento_obj.mar
						elif periodo_code=='04':
							valor_orcamentado_periodo=orcamento_obj.abr
						if periodo_code=='05':
							valor_orcamentado_periodo=orcamento_obj.maio   
						elif periodo_code=='06':
							valor_orcamentado_periodo=orcamento_obj.jun
						if periodo_code=='07':
							valor_orcamentado_periodo=orcamento_obj.jul
						elif periodo_code=='08':
							valor_orcamentado_periodo=orcamento_obj.ago
						if periodo_code=='09':
							valor_orcamentado_periodo=orcamento_obj.set	 
						elif periodo_code=='10':
							valor_orcamentado_periodo=orcamento_obj.abr  
						if periodo_code=='11':
							valor_orcamentado_periodo=orcamento_obj.nov
						elif periodo_code=='12':
							valor_orcamentado_periodo=orcamento_obj.dez	 
					
					
					logger.info('VALOR ORCAMENTADO PARA O PERIODO %s' %str(orcamento_obj.conta.ref))
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
												('conta_id','=',orcamento_obj.conta.id),
												('state','=','emitido'),
												('data_lancamento','>=',documento.periodo_id.date_start),
												('data_lancamento','<=',documento.periodo_id.date_stop),
												('periodo_id','=',documento.periodo_id.id)
										])
					logger.info('VALOR ORCAMENTADO PARA O PERIODO %s' %str(lancamento_ids))
					total_debito=0
					total_credito=0
					saldo=0
					natureza=None
					valor_desvio=0
					percentagem=0
					for lancamento in lancamento_ids:
						lancamento=self.pool.get('dotcom.contabilidade.lancamentos.diarios').browse(cr,uid,lancamento)
						if documento.conversao_moeda=='mp':
							total_credito=total_credito+lancamento.credito_moeda_base
							total_debito=total_debito+lancamento.debito_moeda_base
						elif documento.conversao_moeda=='ms':
							total_credito=total_credito+lancamento.credito_moeda_secundaria
							total_debito=total_debito+lancamento.debito_moeda_secundaria
					
					if total_debito>total_credito:
						saldo=total_debito-total_credito
						natureza='d'
					elif total_credito>total_debito:
						saldo=total_credito-total_debito
						natureza='c'
					if saldo!=0:
						valor_desvio= 0
						if natureza=='d':
							valor_desvio=saldo-valor_orcamentado_periodo
						elif natureza=='c':
							valor_desvio=-saldo-valor_orcamentado_periodo
						
						if valor_orcamentado_periodo>0:
							percentagem=(valor_desvio*100)/valor_orcamentado_periodo
							
					val={
							'conta_id':orcamento_obj.conta.id,
							'valor_orcamentado':valor_orcamentado_periodo,
							'valor_movimentado':saldo,
							'valor_desvio':valor_desvio,
							'percentagem':percentagem,
							'orcamento_id':documento.id
						}
					self.pool.get('dotcom.contabilidade.analise.orcamental.linhas').create(cr,uid,val)
				
		return {}
   
   
	def get_periodo(self,cr,uid,ids,periodo_id,context=None):
		if context is None:
			context={}
		periodo_code=periodo_id.code
		periodo_code=periodo_code[:2]
		periodo=None
		lista=[]
		if periodo_code=='01':
			jan=None
			lista.append(jan)
			
		elif periodo_code=='02':
			fev=None
			lista.append(fev)
			
		if periodo_code=='03':
			mar=None
			lista.append(mar)
			
		elif periodo_code=='04':
			abr=None
			lista.append(abr)
			
		if periodo_code=='05':
			maio=None
			lista.append(maio)
			
		elif periodo_code=='06':
			jun=None
			lista.append(jun)
			
		if periodo_code=='07':
			jul=None
			lista.append(jul)
			
		elif periodo_code=='08':
			ago=None
			lista.append(ago)
			
		if periodo_code=='09':
			set=None
			lista.append(set)
			
		elif periodo_code=='10':
			out=None
			lista.append(out)
			
		if periodo_code=='11':
			nov=None
			lista.append(nov)
			
		elif periodo_code=='12':
			dez=None
			lista.append(dez)
		
		return lista
	
		
dotcom_analise_orcamental()


class dotcom_analise_orcamental_linha(osv.osv):
	_name='dotcom.contabilidade.analise.orcamental.linhas'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta ',),
		'valor_orcamentado':fields.float('Valor Orcamentado'),
		'valor_movimentado':fields.float('Valor Movimentado'),
		'valor_desvio':fields.float('Desvio'),
		'percentagem':fields.float('Percentagem (%)'),
		'orcamento_id':fields.many2one('dotcom.contabilidade.analise.orcamental','Orcamentos')
	}
	
dotcom_analise_orcamental_linha()