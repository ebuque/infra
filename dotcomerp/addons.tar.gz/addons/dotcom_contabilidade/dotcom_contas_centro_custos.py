# -*- coding: utf-8 -*-


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from validators import validator
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')



class dotcom_conta_centro_custos(osv.osv):

	def _friendly_name(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for centro in self.browse(cr, uid, ids, context=context):
			ref = centro.centro
			nome = centro.nome or ''
			friendly_name = '['+ref+']' +  nome
			res[centro.id] = friendly_name
		return res
	
	_name='dotcom.contabilidade.conta.centro.custos'
	_columns={
		'centro':fields.char('Centro',required=True, size=25),
		'nome':fields.char('Nome',size=26,required=True),
		'tipo_interno':fields.selection([('r','Razão'),('t','Totalizadora'),('m','Movimento')],'Tipo Interno',readonly=True),
		'centro_id':fields.many2one('dotcom.contabilidade.centros.custos','Centro de Custos',required=False,),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		
		'lancametos_contas_centros_ids':fields.one2many('dotcom.contabilidade.adicao.linhas.centro.linha','centro_id','Lancamentos'),
		
		'parent_id': fields.many2one('dotcom.contabilidade.conta.centro.custos', 'Ascendente',readonly=True, required=False, ondelete="cascade"),
		'child_id': fields.one2many('dotcom.contabilidade.conta.centro.custos', 'parent_id', readonly=True, string='Sub-contas'),
		'parent_left': fields.integer('Left Parent', select=1),
		'parent_right': fields.integer('Right Parent', select=1),
		'friendly_name': fields.function(_friendly_name, type='char', string='Centro', method=True, store=True),
		'has_moviments': fields.selection([
						('no','Sem Movimentos'),
						('yes','Com Movimentos'),
						],'State', select=True, readonly=True),

	}
	
	_rec_name='friendly_name'
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
		'has_moviments':'no',
	}
	
	_sql_constraints = [
		('name_centro_uniq', 'unique (centro ,centro_id)', 'O número de conta do Centro deve ser único !')
	]
	
	_order='centro asc'
	
	
	def _check_recursion(self, cr, uid, ids, context=None):
		level = 100
		while len(ids):
			cr.execute('select distinct parent_id from dotcom_contabilidade_conta_centro_custos where id IN %s',(tuple(ids),))
			ids = filter(None, map(lambda x:x[0], cr.fetchall()))
			if not level:
				return False
			level -= 1
		return True

	_constraints = [
		(_check_recursion, 'Error ! You cannot create recursive categories.', ['parent_id'])
	]
	
	
	def unlink(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		plano_contas=self.browse(cr,uid,ids,context)
		lista_apagavel=[]
		for conta in plano_contas:
			if len(conta.lancametos_contas_centros_ids)>0:
				raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover este Centro de Custos pois já tem movimentos emitidos.!'))
			if conta.tipo_interno!='m' and len(conta.child_id)>0:
				raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover este Centro de Custos pois tem sub contas.!'))
			
			if conta.tipo_interno=='m' and len(conta.lancametos_contas_centros_ids)<=0:
				lista_apagavel.append(conta.id)
				
				if len(conta.parent_id.centro)>2 and (conta.parent_id.tipo_interno=='t' and len(conta.parent_id.child_id))==1:
					self.write(cr,uid,conta.parent_id.id,{'tipo_interno':'m'})
					logger.info('CONTA ASCENDENTE PASSA A SER Movimento')
			
			if conta.tipo_interno!='m' and len(conta.child_id)<=0:
				lista_apagavel.append(conta.id)
			osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)

		return True
	
	
	def child_get(self, cr, uid, ids):
		return [ids]

	
	def on_change_ref(self,cr,uid,ids,conta,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		retorno={}
		validator.validar_numero_caracteres(cr,uid,conta,context)
		
		conta_asc = validator.get_centro_ascendente(cr, uid, conta,ano_fiscal_id, context=context)
		logger.info('CONTA ASCENDENTE ACHADA %s' %str(conta_asc))
		if conta_asc !=None:
			ascendent_object=self.browse(cr,uid,conta_asc)
			lista_lancamentos=ascendent_object.lancametos_contas_centros_ids
			logger.info('ASC: %s' % conta_asc)
			val = {'parent_id':conta_asc}
		
			if len(lista_lancamentos)>0:
				msgalert = {'title':'Warning','message':'O Centro de Custos '+ ascendent_object.centro+' deixará de ser de movimento, os seus movimentos serão transferidos para a nova conta de movimento '+conta}
				retorno= {'value':val,'warning':msgalert}
			else:
				retorno= {'value':val}
			
		return retorno
	
	
	def on_chnage_referencia1(self,cr,uid,ids,referencia,context=None):
		if context is None:
			context={}
		
		nova_referencia=validator.validar_referencias(cr,uid,referencia)
		return {'value':{'centro':nova_referencia}}
		

	def write_recursive(self, cr, uid, conta_id, context=None):
		if context is None:
			context = {}
		conta = self.browse(cr, uid, conta_id)
		if conta.parent_id:
			self.write_recursive(cr, uid, conta.parent_id.id, context=context)
			if conta.child_id:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
			else:
				logger.info('A definir conta parent como Mov')
				self.write(cr, uid, conta.id, {'tipo_interno':'m'})
		else:
			if len(conta.centro)>2:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
			else:
				logger.info('A definir conta como Tot')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
		return True
	
	
	def write_recursive_children(self, cr, uid, conta_id ,context=None):
		if context is None:
			context = {}
		conta = self.browse(cr, uid, conta_id, context=context)
		if conta.child_id:
			for child in conta.child_id:
				if child.child_id:
					self.write_recursive_children(cr, uid, child.id, context=context)
			if len(conta.centro)==2:
				logger.info('A definir conta como Razao')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
			else:
				logger.info('A definir conta parent como Totalizadora')
				self.write(cr, uid, conta.id, {'tipo_interno':'t'})
		else:
			if len(conta.centro)==2:
				logger.info('A definir conta como Razao')
				self.write(cr, uid, conta.id, {'tipo_interno':'r'})
			else:
				logger.info('A definir conta parent como Movimento')
				self.write(cr, uid, conta.id, {'tipo_interno':'m'})
				
		return True	
	
	
	def create(self, cr, uid, vals, context=None):
		if context is None:
			context = {}
		conta = vals.get('centro')
		identificador=vals.get('centro_id')
		nada = validator.validar_numero_caracteres(cr, uid, conta, context=context)
		ano_fiscal_id=vals.get('ano_fiscal_id')
		
		pai_id = validator.get_centro_ascendente(cr, uid, conta,ano_fiscal_id, context=context)
		#logger.info('A iniciar processo de criação de Conta, ref: %s' % conta)
		logger.info('Resultado de procura de conta ascendente, ID: %s' % pai_id)
		father=None
		logger.info('PAI_ID, ref: %s' % pai_id)
		base=False
		
		centro_ref=vals['centro']
		logger.info('CENTRO REFERENCIA ACHADO NO MOMENTO %s' %str(centro_ref))
		if bool(centro_ref)!=False:
			if bool(pai_id)==False:
				logger.info('SEM PAI')
				logger.info('Conta ascendente não existe, a iniciar verificações')
				if len(conta)>2:
					logger.info('Conta possui mais de dois digitos, a iniciar processo de criação de conta ascendente')
					father_vals = vals.copy()
					logger.info('Conta copiada, a definir valores')
					father_vals['centro'] = conta[:2]
					father_vals['nome']='CENTRO '+str(conta[:2])
					#logger.info('PAI_ID, ref: %s' % father_vals['centro'])
					father_vals['tipo_interno'] = 'r'
					logger.info('Valores definidos, ref: %s, tipo interno: Razão' % father_vals.get('centro'))
					father = super(dotcom_conta_centro_custos, self).create(cr, uid, father_vals, context=context)
					logger.info('Conta ascendente criada, a definir na conta a criar %s' %father)
					vals['parent_id'] = father
					
				else:
					logger.info('Conta possui 2 digitos, será definida como conta de Razão')
					vals['parent_id'] = None
					vals['tipo_interno'] = 'r'
			else:
				vals['parent_id'] = pai_id
			logger.info('A criar conta...')
			
			logger.info('VALS %s' %str(vals))
			base = super(dotcom_conta_centro_custos, self).create(cr, uid, vals, context=context)
			teste=self.browse(cr,uid,base)
			logger.info('VALS %s' %str(teste.parent_id))		
			logger.info('Conta criada com ID: %s' % base)
			logger.info('Inicio do processo de actualização de contas semelhantes')
			sons = self.search(cr, uid, [('centro','like',conta),('parent_id','=',identificador)])
			logger.info('Resultado da procura de Semelhantes: %s' %sons)
			logger.info('..............................................................')
			
			if sons and len(sons)>0:
				
				logger.info('A ordenar lista: %s' %sons)
				sons = sorted(sons)
				logger.info('Lista ordenada: %s' %sons)
				reads = self.read(cr, uid, sons, ['centro','id','child_id'])
				reads = sorted(reads, key=lambda d: (d['id'], d['centro']), reverse=True)
				logger.info('A ler valores e actualizar cada conta')
				#logger.info('FILHO ACHADO PARA A CONTA %s' %str(reads['centro']))
				for read in reads:
					logger.info('A processar: %s' % read)
					me = read['id']
					my_ref = read['centro']
					my_father = validator.get_centro_ascendente(cr, uid, my_ref,identificador, context=context)
					if bool(my_father)==False:
						my_father=father
					self.write(cr, uid, me, {'parent_id':my_father})
			test = self.write_recursive(cr, uid, base, context=context)
			again = self.write_recursive_children(cr, uid, base, context=context)
			base_object=self.browse(cr,uid,base)
			parent_id=base_object.parent_id.id
			logger.info('VALS %s' %str(type(parent_id)))
			
			if parent_id!=False:
				lista_lancamentos=base_object.parent_id.lancametos_contas_centros_ids
				if len(lista_lancamentos)>0:
					
					for lancamento in lista_lancamentos:
						logger.info('LLANCAMENTO ACHADO %s' %str(lancamento))
						self.pool.get('dotcom.contabilidade.adicao.linhas.centro.linha').write(cr,uid,lancamento.id,{'centro_id':base})
		return base
	
dotcom_conta_centro_custos()