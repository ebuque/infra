# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_periodo_abertura(osv.osv):
	
	def _percentagem_processamento(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for documento in self.browse(cr, uid, ids, context=context):
			logger.info('VALOR ACTUAL DA PERCENTAGEM %s' %str(documento.valor_actual_percentagem))
			logger.info('ANO ACTUAL %s' %str(documento.valor_actual_percentagem))
			#ref = plano.ref and plano.ref or ''
			#nome = plano.nome or ''
			#friendly_name = '['+ref + '] ' + nome
			#res[plano.id] = friendly_name
		return res
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	
	_name='dotcom.contabilidade.periodo.abertura'
	_columns={
		'data':fields.date('Data',required=False,readonly=True ),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'ano_fiscal_base_id':fields.many2one('configuration.fiscalyear','Ano Fiscal Base',required=False,readonly=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'periodo':fields.many2one('configuration.period','Período',readonly=True),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True,domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'moeda_lancamento_id':fields.many2one('res.currency','Moeda Principal',required=True,readonly=True),
		'moeda_secundaria_id': fields.many2one('res.currency','Moeda Secundária',readonly=True),
		'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True,),
		'cambio_secundario':fields.float('Câmbio MP/MS', help='Cámbio para Moeda Principal(MP) para a moeda secundária(MS)',readonly=True),
		'conversao_moeda':fields.selection(_acerto,'Conv. Moeda', required=True),
		'percentagem_processamento':fields.function(_percentagem_processamento, type='float', string='Documento', method=True, store=True),
		'valor_actual_percentagem':fields.float('Estado'),
	}
	
	_defaults={
		'conversao_moeda':'mp',
		'moeda_lancamento_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=c),
		'moeda_secundaria_id':lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=c),
		'cambio_secundario':lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria_cambio(cr, uid,'dotcom.contabilidade.plano.contas', context=c),
	}
	
	
	def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
		if context is None:
			context = {}
		result = super(dotcom_periodo_abertura, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
		a = []
		
		#logger.info('\nFIELDS VIEW GET \n%s' %str(result))
		moeda_lancamento_id=self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=context)
		moeda_lancamento=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento_id)

		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context)
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
		
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		dicionario= moeda_primaria_id[0]
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,dicionario)
		
		simbolo_moeda=moeda_secundaria.name
		
		
		
		nome_moeda_lancamento=str(moeda_lancamento and moeda_lancamento.name)
		nome_moeda_primaria = str(moeda_primaria and moeda_primaria.name)
		nome_moeda_secundaria=str(moeda_secundaria and moeda_secundaria.name)
		
		logger.info('SIMBOLO MOEDA LANCA %s' %str(nome_moeda_lancamento))

		fields = result['fields']
		if fields.has_key('cambio_secundario'):
			documento = fields['cambio_secundario']
			documento['string'] = "Cambio "+moeda_primaria.name+'/'+simbolo_moeda
			fields['cambio_secundario'] = documento
			
		if fields.has_key('cambio'):
			logger.info('CAMBIO ENCONTRADO')
			documento = fields['cambio']
			documento['string'] = 'Cambio '+moeda_primaria.name
			fields['cambio'] = documento	
			
		result['fields'] = fields
		
		#logger.info('\nCHAVES TIPO %s E CHAVES %s' % (type(result['arch']),str(result['arch'])))
		#logger.info('\nMoeda Principal %s , tipo %s' %(type(nome_moeda_primaria), nome_moeda_primaria))
		view = result['arch']
		#view = view
		if nome_moeda_primaria:
			view = view.replace('MoedaB','Moeda Principal ('+nome_moeda_primaria+')')
		if nome_moeda_secundaria:
			view=view.replace('MoedaC','Moeda Secundaria ('+nome_moeda_secundaria+')')
		if nome_moeda_lancamento:
			view=view.replace('MoedaA','Moeda Lançamento ('+nome_moeda_lancamento+')')
		
		view=view.replace('VM',nome_moeda_primaria+'/'+nome_moeda_secundaria)
		view=view.replace('TB','Valor')	
			
		
		result['arch'] = view

		#result['fields'] = fields
		#logger.info('RESULT VIEW %s' % result)
		return result
	
	
	def on_change_acerto(self, cr,uid,ids, acerto,context=None):
		if context is None:
			context={}
		
		value={}
		if acerto=='mp':
			moeda_principal=self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas')
			logger.info('MOEDA PRINCIPAL %s' %str(moeda_principal))
			value={'moeda_lancamento_id':moeda_principal}
		elif acerto=='ms':
			moeda_secundaria=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas')
			logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria))
			value={'moeda_lancamento_id':moeda_secundaria}
		
		return {'value':value}
		
	
	def on_change_currency(self, cr, uid, ids, currency_id, context=None):
		if context is None:
			context = {}
		res = {}
		if currency_id:
			moeda = self.pool.get('res.currency').browse(cr, uid, currency_id)
			cambio = moeda.rate or 1
			res['cambio'] = cambio
			for documento in self.browse(cr,uid,ids):
				logger.info('MAIS DE 1 LANCAMENTO')
		return {'value':res}
	
	
	def on_change_moeda_secundaria(self,cr,uid,ids,moeda_secundaria_id, context=None):
		if context is None:
			context={}
		res={}
		if moeda_secundaria_id:
			moeda = self.pool.get('res.currency').browse(cr, uid, moeda_secundaria_id)
			logger.info('MOEDA SECUNDARIA ACHADA %s' %str(moeda))
			res['cambio_secundario']=moeda.rate or 1
		return {'value':res}
		
	
	def create(self,cr,uid,values,context=None):
		if context is None:
			context={}
		
		ano_fiscal_id=values['ano_fiscal_id']
		
		periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
		periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
		data_fecho=periodo_abertura.date_stop
		
		values['data']=data_fecho
		values['periodo']=periodo_abertura.id
		
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		logger.info('ANO ACTUAL %s' %str(ano_actual))
		ano_anterior=ano_actual-1
		logger.info('ANO ANTERIOR %s' %str(ano_anterior))
		
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
		logger.info('DATA INICIO ANO ANTERIOR %s' %str(data_inicio_novo_ano))
		
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			values['ano_fiscal_base_id']=ano_anterior_ids[0]
		else:
			raise osv.except_osv(_('Acção Invalida !'), _('Ano fiscal anterior a '+str(ano_actual)+' inesistente'))
		
		values['cambio']=1
		 
		periodo_id=super(dotcom_periodo_abertura, self).create(cr, uid, values, context=context)
		
		documento_object=self.browse(cr,uid,periodo_id)
		
		moeda_secundaria_id=documento_object.moeda_secundaria_id.id
		on_change_moeda_secundaria=self.on_change_moeda_secundaria(cr,uid,[periodo_id],moeda_secundaria_id)
		value=on_change_moeda_secundaria['value']
		cambio_secundario=value['cambio_secundario']
		
		conversao_moeda=values['conversao_moeda']
		on_change_acerto=self.on_change_acerto(cr,uid,[periodo_id],conversao_moeda)
		value=on_change_acerto['value']
		moeda_lancamento_id=value['moeda_lancamento_id']
		
		
		
		self.write(cr,uid,periodo_id,{'cambio_secundario':cambio_secundario,'moeda_lancamento_id':moeda_lancamento_id})
				
		return periodo_id
	
	
	
	def criar_periodo_abertura(self,cr,uid,ids,context=None):
		if context==None:
			context={}
			
		contador_contas=0
		
		retorno={}		
		poup_id=0
		
		lista_lancamentos=[]
		
		for documento in self.browse(cr,uid,ids):
			self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
			
			
			on_change_acerto=self.on_change_acerto(cr,uid,ids,documento.conversao_moeda)
			value=on_change_acerto['value']
			moeda_lancamento_id=value['moeda_lancamento_id']
			
			#self.write(cr,uid,documento.id,{'cambio':1})
			
			on_change_value=self.on_change_currency(cr,uid,ids,moeda_lancamento_id)
			value=on_change_value['value']
			cambio_primario=1
			
			on_change_moeda_secundaria=self.on_change_moeda_secundaria(cr,uid,ids,documento.moeda_secundaria_id.id)
			value=on_change_moeda_secundaria['value']
			cambio_secundario=value['cambio_secundario']
			
			
			data_inicio=self.on_change_ano_fiscal_id(cr,uid,ids,documento.ano_fiscal_id.id)
			data_inicio=data_inicio['value']
			data_inicio=data_inicio['data']
			logger.info('VALOR RETORNADO PELO ONCHANGE DA DATA %s' %str(data_inicio))
			
			movimento={
					'data':data_inicio,
					'ano_fiscal_id':documento.ano_fiscal_id.id,
					'diario_id':documento.diario_id.id,
					'documento_id':documento.documento_id.id,
					'periodo':documento.periodo.id,
					'moeda_lancamento_id':documento.moeda_lancamento_id.id,
					'cambio':cambio_primario,
					'cambio_secundario':cambio_secundario,
					'lancamento_abertura':True,
					'lancamento_fecho':False
				}
			#movimento_id=self.pool.get('dotcom.contabilidade.movimentos').create(cr,uid,movimento)
			
			ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,documento.ano_fiscal_id.id)
			data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
			ano_actual=data.year
			
			contas_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
										('ano_fiscal_id','=',documento.ano_fiscal_base_id.id),
										('tipo_interno','=','m')
								])
			for conta in contas_ids:
				
				conta= self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta)
				
				moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
				moeda_secundaria_id=moeda_secundaria_id[0]
				
				if conta.tipo_interno=='m':
					lancamento_ids=[]
					
					#if documento.conversao_moeda=='mp':
					#	#logger.info('ACERTO DA MOEDA PRIMARIA')
					#	lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
					#								('conta_id','=',conta.id),  
					#								('state','=','emitido'),
					#								('acerto','in',['mp','all'])
					#								])
					#						
					#elif documento.conversao_moeda=='ms':
					#	lancamento_ids=self.pool.get('dotcom.contabilidade.lancamentos.diarios').search(cr,uid,[
					#		('conta_id','=',conta.id),  
					#		('state','=','emitido'),
					#		('acerto','in',['all','ms'])
					#		])
					
					lancamento_ids=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').search(cr,uid,[
																									('conta_id','=',conta.id),  
																									])
					
					total_credito=0
					total_debito=0
					saldo=0
											
					for lancamento in lancamento_ids:
						lancamento=self.pool.get('dotcom.contabilidade.saldo.contas.periodo').browse(cr,uid,lancamento)
						
						if documento.conversao_moeda=='mp':
							total_debito=total_debito+lancamento.total_debito_primaria
							total_credito=total_credito+lancamento.total_credito_primaria
						
						elif documento.conversao_moeda=='ms':
							total_debito=total_debito+lancamento.total_debito_secundaria
							total_credito=total_credito+lancamento.total_credito_secundaria				
					
					if (total_credito-total_debito)!=0:
						conta_novo_ano_id=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[
										('ano_fiscal_id','=',documento.ano_fiscal_id.id),
										('ref','=',conta.ref)
									])
						
						if len(conta_novo_ano_id)>0:
							conta_nova=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_novo_ano_id[0])
							#logger.info('REFERENCIA DA CONTA NOVA %s' %str(conta_nova.ref))
							if conta_nova.tipo_interno=='m':
							
								if total_credito>total_debito:
									saldo=total_credito-total_debito
									saldo=round(saldo, 2)
									lancamento_novo={
													'conta_id':conta_nova.id,
													'ref':conta_nova.ref,
													'debito':0,
													'credito':saldo,
													#'movimento_id':movimento_id,
													'reflexao_iva':False,
													'reflexao_centro':False,
													#'acerto':'all',
													'periodo_id':documento.periodo.id,
													'moeda_documento':documento.moeda_lancamento_id.id,
													'moeda_secundaria_id':moeda_secundaria_id,
													'moeda_lancamento_id':documento.moeda_lancamento_id.id,
													'moeda_primaria_id':documento.moeda_lancamento_id.id,
													'cambio':cambio_primario,
													'cambio_secundario':cambio_secundario,
													'tipo_lancamento':'abertura',
													'data_lancamento':data_inicio,
													'acerto':documento.conversao_moeda,
													'ano_fiscal_id':documento.ano_fiscal_id.id,
												}
									if saldo>0:
										#logger.info('REFERENCIA DA CONTA NOVA %s' %str(conta_nova.ref))
										#logger.info('TIPO INTERNO DA CONTA NOVA %s' %str(conta_nova.tipo_interno))
										lista_lancamentos.append(lancamento_novo)
										#self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento_novo)
									
								elif total_credito<total_debito:
									saldo=total_debito-total_credito
									saldo=round(saldo, 2)
									lancamento_novo={
													'conta_id':conta_nova.id,
													'ref':conta_nova.ref,
													'debito':saldo,
													'credito':0,
													#'movimento_id':movimento_id,
													'reflexao_iva':False,
													'reflexao_centro':False,
													#'acerto':'all',
													'periodo_id':documento.periodo.id,
													'moeda_documento':documento.moeda_lancamento_id.id,
													'moeda_secundaria_id':moeda_secundaria_id,
													'moeda_lancamento_id':documento.moeda_lancamento_id.id,
													'moeda_primaria_id':documento.moeda_lancamento_id.id,
													'cambio':cambio_primario,
													'cambio_secundario':cambio_secundario,
													'tipo_lancamento':'abertura',
													'data_lancamento':data_inicio,
													'acerto':documento.conversao_moeda,
													'ano_fiscal_id':documento.ano_fiscal_id.id,
												}
									if saldo>0:
										
										logger.info('TIPO INTERNO DA CONTA NOVA %s' %str(conta_nova.tipo_interno))
										#self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento_novo)
										lista_lancamentos.append(lancamento_novo)
							else:
						
								credito=0
								debito=0
								if total_credito>total_debito:
									credito=total_credito-total_debito
								elif total_credito<total_debito:
									debito=total_debito-total_credito
								
								if poup_id==0:
									poup_up={ 
												#'movimento_id':movimento_id,
												'moeda_lancamento_id':documento.moeda_lancamento_id.id,
												'moeda_secundaria_id':moeda_secundaria_id,
												'cambio':documento.cambio,
												'cambio_secundario':cambio_secundario,
												'conversao_moeda':documento.conversao_moeda
											}
									poup_id=self.pool.get('dotcom.contabilidade.periodo.abertura.poup.up').create(cr,uid,poup_up)
								 
								linha={
										'ano_fiscal_id':documento.ano_fiscal_id.id,
										'conta_pai_id':conta.id,
										'credito':credito,
										'debito':debito,
										'poup_id':poup_id
										}
								self.pool.get('dotcom.contabilidade.periodo.abertura.poup.up.linhas').create(cr,uid,linha)
								#logger.info('VA %s' %str(poup_up))
								context['lista']=lista_lancamentos
								context['movimento']=movimento
								retorno={
											'type': 'ir.actions.act_window',
											'name': 'Seleccione a Conta de Movimento',
											'view_mode': 'form',
											'view_type': 'form',
											'res_model': 'dotcom.contabilidade.periodo.abertura.poup.up',
											'res_id':poup_id,
											'target': 'new',
											'context': context,
											'nodestroy': True,
										}
						else:
							credito=0
							debito=0
							if total_credito>total_debito:
								credito=total_credito-total_debito
							elif total_credito<total_debito:
								debito=total_debito-total_credito
							if poup_id==0:
								poup_up={
											
											#'movimento_id':movimento_id,
											'moeda_lancamento_id':documento.moeda_lancamento_id.id,
											'moeda_secundaria_id':moeda_secundaria_id,
											'cambio':cambio_primario,
											'cambio_secundario':cambio_secundario,
											'conversao_moeda':documento.conversao_moeda
										}
								poup_id=self.pool.get('dotcom.contabilidade.periodo.abertura.poup.up').create(cr,uid,poup_up)
							
							linha={
									'conta_pai_id':conta.id,
									'ano_fiscal_id':documento.ano_fiscal_id.id,
									'credito':credito,
									'debito':debito,
									'poup_id':poup_id
									}
							self.pool.get('dotcom.contabilidade.periodo.abertura.poup.up.linhas').create(cr,uid,linha)
							
							context['lista']=lista_lancamentos
							context['movimento']=movimento
							retorno={
											'type': 'ir.actions.act_window',
											'name': 'Seleccione a Conta de Movimento',
											'view_mode': 'form',
											'view_type': 'form',
											'res_model': 'dotcom.contabilidade.periodo.abertura.poup.up',
											'res_id':poup_id,
											'target': 'new',
											'context': context,
											'nodestroy': True,
										}
			
			if len (lista_lancamentos)<=0:
				raise osv.except_osv(_('Acção Invalida !'), _('Abertura de Ano sem Movimentos a Lançar')) 
			
			if bool(context.has_key('lista'))==False:
				movimento_id=self.pool.get('dotcom.contabilidade.movimentos').create(cr,uid,movimento)
				for lancamento in lista_lancamentos:
					#logger.info('LANCAMENTO A SER CRIADO PARA O MOVIMENTO %s' %str(lancamento))
					lancamento['movimento_id']=movimento_id
					self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento)
				
			self.write(cr,uid,documento.id,{'moeda_secundaria_id':moeda_secundaria_id,'cambio':1})		 
			self.unlink(cr,uid,documento.id)
			#logger.info('IDENTIFICADOR DO POUP UP %s' %str(retorno))	
		return retorno	 
	
	
	def on_change_ano_fiscal_id(self,cr,uid,ids,ano_fiscal_base_id,context=None):
		if context is None:
			context={}
		periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_base_id)  ,
							('special','=',True)
				])
		periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
		data_fecho=periodo_abertura.date_stop
		logger.info('DATA DE FECHO DO PERIODO %s' %str(data_fecho))
		#self.on_change_data(cr,uid,ids,data_fecho)
		
		return {'value':{'data':data_fecho}}
		
	
	#trazer o ano fiscal anterior
	def on_change_ano_id(self,cr,uid,ids,ano_fiscal_id,context=None):
		if context is None:
			context={}
			
		val={}
		ano_fiscal=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fiscal_id)
		logger.info('ANO ACTUAL %s' %str(ano_fiscal.date_start))
		data=datetime.strptime(ano_fiscal.date_start, '%Y-%m-%d')
		ano_actual=data.year
		logger.info('ANO ACTUAL %s' %str(ano_actual))
		ano_anterior=ano_actual-1
		logger.info('ANO ANTERIOR %s' %str(ano_anterior))
		
		data_inicio_horas_novo_ano=datetime(ano_anterior,01,01,0,0,0)
		data_inicio_novo_ano=datetime.strptime(str(data_inicio_horas_novo_ano), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
		logger.info('DATA INICIO ANO ANTERIOR %s' %str(data_inicio_novo_ano))
		
		ano_anterior_ids=self.pool.get('configuration.fiscalyear').search(cr,uid,[
							('date_start','=',data_inicio_novo_ano)		
			])
		if len(ano_anterior_ids)>0:
			#ano_anterior=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_anterior_ids[0])
			periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
							('fiscalyear_id','=',ano_fiscal_id)  ,
							('special','=',True)
				])
			periodo_abertura=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
			data_fecho=periodo_abertura.date_stop
			val={'data':data_fecho,'ano_fiscal_base_id':ano_anterior_ids[0]}
		else:
			raise osv.except_osv(_('Acção Invalida !'), _('Ano fiscal anterior a '+str(ano_actual)+' inesistente')) 
			
		return {'value':val}
		
	
	def on_change_data(self,cr,uid,ids,data,context=None):
		if context is None:
			context={}
		periodo=self.pool.get('dotcom.contabilidade.movimentos').get_period_id(cr,uid,ids,data)
		
		return{'value':{'periodo':periodo}}
		
		
	#def on_change_currency(self, cr, uid, ids, currency_id, context=None):
	#	if context is None:
	#		context = {}
	#	res = {}
	#	if currency_id:
	#		moeda = self.pool.get('res.currency').browse(cr, uid, currency_id)
	#		cambio = moeda.rate or 1
	#		res['cambio'] = cambio					
	#	return {'value':res}
	#
	
dotcom_periodo_abertura()



class dotcom_poup_up_contas(osv.osv):
	
	def _acerto(self,cr,uid,context=None):
		if context is None:
			context = {}
		moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
		logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
		
		moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
		moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
		logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
		
		ano_ids=self.search(cr,uid,[])
		result=()
		this=[]
				
		result=('mp',str(moeda_primaria.name))
		this.append(result)
		
		result=('ms',str(moeda_secundaria.name))
		this.append(result)
			
		return this
	
	_name='dotcom.contabilidade.periodo.abertura.poup.up'
	_columns={
		
		#'movimento_id':fields.many2one('dotcom.contabilidade.movimentos','Movimento',required=True),
		'conversao_moeda':fields.selection(_acerto,'Conv. Moeda', required=True),
		'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,),
		'moeda_secundaria_id': fields.many2one('res.currency','Moeda Secundária',),
		'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=False,),
		'cambio_secundario':fields.float('Câmbio MP/MS', help='Cámbio da moeda Principal(MP) para a moeda secundária(MS)',),
		'linhas_poup_ids':fields.one2many('dotcom.contabilidade.periodo.abertura.poup.up.linhas','poup_id','Linhas')
		
	}
	
	
	def processar_linhas(self,cr,uid,ids,context=None):
		if context is None:
			context={}
			
		lista=context['lista']
		movimento=context['movimento']
		
		
		movimento_id=self.pool.get('dotcom.contabilidade.movimentos').create(cr,uid,movimento)
		
		for documento in self.browse(cr,uid,ids):
			#movimento=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,documento.movimento_id.id)
			logger.info('CONTEXTO ACHADO NO PROCESSAMENTO %s' %str(documento.conversao_moeda))
			for linha in documento.linhas_poup_ids:
				if linha.conta_filho_id.tipo_interno!='m':
					raise osv.except_osv(_('Invalid action !'), _('A conta '+linha.conta_filho_id.ref+' nao permitido. Seleccione uma conta de Movimento!!'))
				lancamento_novo={
							'conta_id':linha.conta_filho_id.id,
							'ref':linha.conta_filho_id.ref,
							'debito':linha.debito,
							'credito':linha.credito,
							#'moeda_lancamento_id':documento.movimento_id.moeda_lancamento_id.id,
							'reflexao_iva':False,
							'reflexao_centro':False,
							#'acerto':'all',
							#'periodo_id':documento.movimento_id.periodo.id,
							'moeda_documento':documento.moeda_lancamento_id.id,
							'moeda_secundaria_id':documento.moeda_secundaria_id.id,
							'moeda_primaria_id':documento.moeda_lancamento_id.id,
							'cambio':1,
							'cambio_secundario':documento.cambio_secundario,
							'tipo_lancamento':'abertura',
							#'data_lancamento':movimento.data,
							'acerto':documento.conversao_moeda,
							#'ano_fiscal_id':documento.movimento_id.ano_fiscal_id.id,
						}
				lista.append(lancamento_novo)
			
			for lancamento in lista:
				lista= sorted(lista, key=lambda d: (d['ref']))
				
			for lancamento in lista:
				lancamento['movimento_id']=movimento_id
				lancamento['periodo_id']=movimento['periodo']
				lancamento['data_lancamento']=movimento['data']
				lancamento['ano_fiscal_id']=movimento['ano_fiscal_id']
				lancamento['moeda_lancamento_id']=movimento['moeda_lancamento_id']
				logger.info('LANCAMENTO A SER CRIADO %s' %str(lancamento))
				self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento)
				
			self.unlink(cr,uid,documento.id)
		return{}
	
	
dotcom_poup_up_contas()


class dotcom_poup_up_linhas(osv.osv):
	_name='dotcom.contabilidade.periodo.abertura.poup.up.linhas'
	_columns={
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True, ),
		'conta_pai_id':fields.many2one('dotcom.contabilidade.plano.contas','Contas Inválidas',readonly=True),
		'conta_filho_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Movimento',),
		'credito':fields.float('Credito'),
		'debito':fields.float('Debito'),
		'poup_id':fields.many2one('dotcom.contabilidade.periodo.abertura.poup.up','Poup Up')
	}
	
	def on_change_conta(self,cr,uid,ids,conta_id,context=None):
		if context is None:
			context={}
		
		conta_object=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_id)
		if conta_object.tipo_interno!='m':
			raise osv.except_osv(_('Invalid action !'), _('Tipo de conta nao permitido. Seleccione uma conta de Movimento!!'))
	
dotcom_poup_up_linhas()