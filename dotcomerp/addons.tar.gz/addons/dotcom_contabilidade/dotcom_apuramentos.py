# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator

class dotcom_apuramentos(osv.osv):
	_name='dotcom.contabilidade.apuramentos'
	_columns={
		
		'ref':fields.char('Ref',required=True,size=100),
		'nome':fields.char('Nome',required=True,size=100),
		'tipo_apuramento':fields.selection([('resultado','Resultado'),('iva','IVA'),('outro','Outro')],'Tipo de apuramento', required=True),
		'diario_id':fields.many2one('dotcom.contabilidade.diario','Diário',required=True),
		'documento_id':fields.many2one('dotcom.contabilidade.documento','Documento',required=True),
		'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True),
		'contra_partida_id':fields.many2one('dotcom.contabilidade.plano.contas','Contra Partida',required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'contas_ids':fields.one2many('dotcom.contabilidade.contas.apuramentos','apuramento_id','Contas'),
		'conta_iva_a_pagar_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta Iva a Pagar', domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'conta_de_reporte_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta de report',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'conta_de_reembolso_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta de reembolso',domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
		'resultados_id':fields.many2one('dotcom.contabilidade.resultados','Resultado'),
		'selecionar':fields.boolean('Seleccionar'),
		'acerto':fields.selection([('all','MP/MS'),('mp','MP'),('ms','MS')],'Conversão Moeda',help='*MP - Moeda Principal\n*MS - Moeda Secundária'),
		
	}
	
	_rec_name='ref'
	
	_defaults={
		'ano_fiscal_id':validator._get_default_year,
	}
	
	_sql_constraints = [
		('name_uniq', 'unique (ref,ano_fiscal_id)', 'Já foi criado o Apuramento para este Ano Fiscal!!'),
	]
	
	def on_change_contra_partida(self,cr,uid,ids,contra_partida_id,context=None):
		if context is None:
			context={}
		conta_partida=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,contra_partida_id)
		if conta_partida.tipo_interno!='m':
			raise osv.except_osv(_('Acção Invalida !'), _('Tipo de Conta não permitido'))
		return {}
	
dotcom_apuramentos()

class dotcom_contas_apuramento(osv.osv):
	_name='dotcom.contabilidade.contas.apuramentos'
	_columns={
		'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',required=True),
		'apuramento_id':fields.many2one('dotcom.contabilidade.apuramentos','Apuramento',readonly=True),
		'desc': fields.related('conta_id','nome',type="char",string="Nome", store=True, readonly=True), 
		#'tipo_apuramento': fields.related('apuramento_id','tipo_apuramento',type="selection", relation="dotcom.contabilidade.apuramentos",string="Tipo Apuramento", store=True, readonly=True),
		'periodo': fields.selection([
			('0-12','0-12'),
			('0-13','0-13'),
			('0-14','0-14'),
			('0-15','0-15'),
			('actual','Actual'),
			('anterior','Anterior')],'Período', required=True),
	}
	
	_defaults={
			'apuramento_id':lambda self, cr, uid, c: c.get('apuramento_id', False),
		}
	
dotcom_contas_apuramento()