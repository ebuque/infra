# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from osv import fields,osv
import logging
logger = logging.getLogger('CONSULTAS:MEDICO')

class medico(osv.osv):
    _name = 'dotcom.consultas.medico'
    _description = 'Médicos'
    _columns = {
                'ref': fields.char('Ref.', size=15, required=True),
                'name': fields.char('Nome', size=250, required=True),
                'honorarios': fields.float('Honorários'),
                'moeda_id': fields.many2one('res.currency', 'Moeda'),
                'especialidade_id': fields.many2one('dotcom.consultas.medico.especialidade', 'Especialidade'),
    }
    _sql_constraints = [('unique_ref', 'unique(ref)', 'Referência em uso!')]
    
    def copy(self, cr, uid, id, default=None, context=None):
        if context is None:
            context = {}
        ref = self.browse(cr, uid, id).ref or ''
        default['ref'] = '%s (Cópia)' % ref
        return super(medico, self).copy(cr, uid, id, default, context=context)