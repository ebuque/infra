# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from osv import fields,osv
import time
from tools.translate import _

class consultas(osv.osv):
    _name = 'dotcom.consultas.consulta'
    _description = 'Consultas'
    _columns = {
                'ref': fields.char('Ref.', size=20, readonly=True),
                'data_hora': fields.datetime('Data e Hora', required=True, readonly=True, states={'draft':[('readonly',False)]}),
                'medico_id': fields.many2one('dotcom.consultas.medico', 'Médico', required=True, readonly=True, states={'draft':[('readonly',False)]}),
                'honorario': fields.float('Honorários', readonly=True, states={'draft':[('readonly',False)]}),
                'moeda_id': fields.many2one('res.currency','Moeda', readonly=True, states={'draft':[('readonly',False)]}),
                'parceiro_id': fields.many2one('res.partner','Parceiro', readonly=True, states={'draft':[('readonly',False)]}),
                'paciente_id': fields.many2one('dotcom.consultas.paciente', 'Paciente', required=True, readonly=True, states={'draft':[('readonly',False)]}),
                'state': fields.selection([('draft','Rascunho'),('marcada','Marcada'),('facturada','Facturada'),('cancelada','Cancelada')],'Estados', readonly=True),
                
                'venda_id': fields.many2one('dotcom.venda','Venda', readonly=True),
    }
    _rec_name = 'ref'
    _defaults = {'state': 'draft'}
    
    def _check_data_hora(self, cr, uid, ids):
        for consulta in self.browse(cr, uid, ids):
            data_actual = time.strftime('%Y-%m-%d %H:%M:%S')
            data_consulta = consulta.data_hora
            if data_consulta < data_actual:
                return False
            else:
                return True
    
    _constraints = [(_check_data_hora, 'Data inferior a data actual', ['data_hora'])]
    
    def on_change_medico(self, cr, uid, ids, medico, context={}):
        res = {}
        if medico:
            medico_obj = self.pool.get('dotcom.consultas.medico').browse(cr, uid, medico)
            res['honorario'] = medico_obj.honorarios or 0.0
            res['moeda_id'] = medico_obj.moeda_id and medico_obj.moeda_id.id or False
        return {'value': res}
    
    def marcar_consulta(self, cr, uid, ids, context={}):
        consulta = self.browse(cr, uid, ids and ids[0])
       #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_consultas',context)
        values = {}
        
        if not consulta.ref:
            company_obj = self.pool.get('res.users').browse(cr, uid,uid).company_id
            prefixo = company_obj.consulta_prefix or ''
            sufixo = company_obj.consulta_sufix or ''
            padding = company_obj.consulta_padding or 3
            increment = company_obj.consulta_implementation or 1
            proximo = company_obj.consulta_next_number or 1
            
            consulta_numero = str(proximo).zfill(padding)
            consulta_numero = '%s%s%s' % (prefixo,consulta_numero,sufixo)
            
            proximo += increment
            values['ref'] = consulta_numero
            
            self.pool.get('res.company').write(cr, uid, company_obj.id, {'consulta_next_number': proximo})
            
        values['state'] = 'marcada'
        self.write(cr, uid, ids, values)
        
    def cancelar_consulta(self, cr, uid, ids, context={}):
        self.write(cr, uid, ids, {'state': 'draft'})
    
    def facturar_consulta(self, cr, uid, ids, context={}):
        
        res = False
        id = ids and ids[0]
        consulta = self.browse(cr,uid,id)
        
        if consulta.venda_id:
            raise osv.except_osv(_('Acção Inválida !'), _('Consulta já facturada!'))
        company_obj = self.pool.get('res.users').browse(cr, uid,uid).company_id
        
        # CRIAR VENDA
        doc_type_id = company_obj.consulta_doc_type_id and company_obj.consulta_doc_type_id.id
        doc_sequence_id = company_obj.consulta_doc_sequence_id and company_obj.consulta_doc_sequence_id.id
        payment_term_id = company_obj.consulta_payment_term_id and company_obj.consulta_payment_term_id.id
        partner_id = consulta and consulta.parceiro_id and consulta.parceiro_id.id
        
        
        values = {}
        values['partner_id'] = partner_id
        values['doc_type'] = doc_type_id
        values['sequence_id'] = doc_sequence_id
        values['payment_term_id'] = payment_term_id
        
        values['args'] = {'consulta_id': id}
        
        #res = self.pool.get('dotcom.venda').create_from_data(cr,uid,values=values, context=context)
        
        #CRIAR LINHAS DA VENDA
        linha_values = {}
        linha_values['venda'] = res
        produto = company_obj.consulta_product_id and company_obj.consulta_product_id.id or False
        linha_values['produto'] = produto
        linha_values['parceiro'] = partner_id
        
        linha = self.pool.get('dotcom.venda.linha').create_from_data(cr, uid, values=linha_values, context=context)
        
        # ACTUALIZA A CONSULTA
        self.write(cr,uid,ids,{'venda_id': res})
        # ABRE NOVA JANELA (VENDA CRIADA)
        janela = {
            'name':'Nova Venda',
            'view_type':'form',
            'view_mode':'form',
            'res_model':'dotcom.venda',
            'type':'ir.actions.act_window',
            'res_id': res,
            'target':'new',
            'context':context,
        }
        return janela