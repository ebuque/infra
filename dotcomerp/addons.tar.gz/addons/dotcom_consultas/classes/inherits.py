# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from osv import fields,osv
import time

class empresa(osv.osv):
    _name = 'res.company'
    _inherit = 'res.company'
    _columns = {
                'consulta_doc_type_id': fields.many2one('documento.tipo','Tipo de Documento', domain=[('tipo_doc','=','sales'),('automatic_doc','=',False)]),
                'consulta_doc_sequence_id': fields.many2one('dotcom.sequence','Sequência'),
                'consulta_product_id': fields.many2one('product.product','Produto'),
                'consulta_payment_term_id': fields.many2one('condicoes.pagamento','Prazo de Pagamento'),
                
                #Numerador das consultas
                'consulta_prefix': fields.char('Prefixo', size=10),
                'consulta_sufix': fields.char('Sufixo', size=10),
                'consulta_padding': fields.integer('Número de Dígitos'),
                'consulta_implementation': fields.integer('Valor a Incrementar'),
                'consulta_next_number': fields.integer('Próximo Número'),
    }
    _defaults = {'consulta_padding': 3,
                 'consulta_next_number': 1,
                 'consulta_implementation': 1,
                 'consulta_prefix': 'CON'}
    
empresa()

class venda(osv.osv):
    _name = 'dotcom.venda'
    _inherit = 'dotcom.venda'
    _columns = {'consulta_id': fields.many2one('dotcom.consultas.consulta','Consulta',readonly=True)}

    def post(self, cr, uid, ids, move_stock=True, context=None):
        if context is None:
            context = {}
        res = super(venda, self).post(cr, uid,ids, move_stock=move_stock,context=context)
        
        venda_obj = self.browse(cr, uid, ids and ids[0])
        consulta_id = venda_obj.consulta_id and venda_obj.consulta_id.id or False
        if consulta_id:
            self.pool.get('dotcom.consultas.consulta').write(cr,uid,consulta_id, {'state':'facturada'})
        return res
venda()

class parceiro(osv.osv):
    _name = 'res.partner'
    _inherit = 'res.partner'
    _columns = {'paciente_ids': fields.one2many('dotcom.consultas.paciente','parceiro_id', 'Pacientes')}
parceiro()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    