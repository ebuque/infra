# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
import os
import io
import base64
import csv
# import pandas as pd
import xlrd
import random
logger = logging.getLogger('jasper_print')


def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

TIPO_PROD = {
	'psicotropico': 'Psicotropico',
	'estupefaciente': 'Estupefaciente',
	'percursor': 'Percursor',
	}

OBJ = {
	'impo': 'Modelo - Importadores',
	'fabr': 'Modelo - Fabricantes',
	'prod': 'Modelo - Produtos Farmacêuticos',
	'noco': 'Modelo - Nomes Comerciais',
	'dirt': 'Modelo - Director Tecnico',
	# 'grtp': 'Modelo - Grupo Terapêutico',
}

COLUNAS = {
	'impo': ['NOME*','ALVARÁ Nº*','NUIT*','ENDEREÇO','CIDADE','PAÍS(ref/nome)*','PROVÍNCIA','TELEFONE','CELULAR','FAX','E-MAIL'],
	'fabr': ['NOME*','ENDEREÇO','CIDADE','PAÍS(ref)*','TELEFONE','CELULAR','FAX','E-MAIL'],
	'prod': [
		'NOME*',
		# 'GRUPO TERAPEUTICO(ref/nome)',
		'CATEGORIA(medic/prosa)*',
		# 'LISTA NACIONAL(s/n)',
		# 'CODIGO FNM','SUBSTANCIA CONTROLADA(sim/nao)',
		'TIPO DE SUBSTANCIA(Psicotropico,Estupefaciente,Percursor)'
		],
	'noco': ['PODUTO(ref/nome)*','NOME','Nº DE REGISTO','FORMA FARMACEUTICA','DOSAGEM','APRESENTACAO','FABRICANTE(ref/nome)','IMPORTADOR(ref/nome)'],
	'dirt': ['Nome','Função','CPF Nº','Endereço','C. Postal','Cidade','País','Província','Telefone','Celular','Fax','Email','Sujeito a notificações(sim/não)','1º Importador','Login 1º Usuário','Senha 1º Usuário','2º Importador','Login 2º Usuário','Senha 2º Usuário'],
}

MODEL = {
	'impo': 'dotcom.parceiro.importador',
	'fabr': 'dotcom.fabricante',
	'prod': 'dotcom.produto.farmaceutico',
	'noco': 'dotcom.prod.comercial_name',
	'dirt': 'dotcom.director.tecnico',
}

NOTA = u"""
	A planilha de Produtos Farmacêuticos deve obedecer as seguintes regras:\n\n
	1. Estrutura do cabeçalho\n
	EMPRESA,NOME COMERCIAL DO MEDICAMENTO,SUBSTÂNCIA ACTIVA,DOSAGEM,FORMA,APRESENTAÇÃO,FABRICANTE DO PRODUTO ACABADO,País de Origem\n\n
	2. Posição do cabeçalho\n
	Deve estar entre A2 e J2, assim serão 9 colunas.
"""
class excel_export(osv.osv_memory):
	_name='excel.export'
	_columns ={
		'anexo_name': fields.char('Nome', size=128, readonly=True),
		'anexo': fields.binary("Anexo", required=False, readonly=True,),
		'obj': fields.selection([
			('impo', 'Modelo - Importadores'),
			('fabr', 'Modelo - Fabricantes'),
			('prod', 'Modelo - Produtos Farmacêuticos'),
			('noco', 'Modelo - Nomes Comerciais'),
			('dirt', 'Modelo - Director Tecnico'),
			],'Objecto', required=True, readonly=False),
		'nota': fields.text('Nota', required=False, readonly=True,),
		}
	_defaults ={
		'obj': 'prod',
	}

	def _change(self, cr, uid, ids, vals, context=None):
		msg('_change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals} 

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('export_excel.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'obj':
			if not valor:
				vals = {'nota': False}			
			else:
				vals = {'nota': OBJ[valor]}
			return self._change(cr, uid, ids, vals)

	def processar(self,cr,uid,ids,context=None):
		if context is None:context = {}
		vals, obj  = [], False
		for document in self.browse(cr,uid,ids):
			csv_file="/opt/dotcomerp/server/openerp/addons/dotcom_importacoes/data/excel_export.csv"
			obj = document.obj
			model = self.pool.get(MODEL[obj])
			obj_ids = []
			for id in model.search(cr,uid,[]):
				if len(obj_ids) < 20: obj_ids.append(model.browse(cr,uid,id))
			with open(csv_file,mode='w') as writeFile:
				writer = csv.writer(writeFile,dialect='excel')
				spc ='	'
				colunas = COLUNAS[obj]
				writer.writerow(colunas)
				for linha_id in obj_ids:
					if obj == 'impo':
						vals = [
							linha_id.name or '', #'NOME*': linha_id.xxxx or '',
							linha_id.alvara or '', #'ALVARÁ Nº*': linha_id.xxxx or '',
							linha_id.nuit or '', #'NUIT*': linha_id.xxxx or '',
							linha_id.endereco or '', #'ENDEREÇO': linha_id.xxxx or '',
							linha_id.cidade or '', #'CIDADE': linha_id.xxxx or '',
							linha_id.pais_id.name or '', #'PAÍS(ref)*': linha_id.xxxx or '',
							linha_id.provincia_id.name or '', #'PROVÍNCIA': linha_id.xxxx or '',
							linha_id.telefone or '', #'TELEFONE': linha_id.xxxx or '',
							linha_id.celular or '', #'CELULAR': linha_id.xxxx or '',
							linha_id.fax or '', #'FAX': linha_id.xxxx or '',
							linha_id.email or '', #'E-MAIL': linha_id.xxxx or '',
							]
					elif obj == 'fabr':
						vals = [
							linha_id.name or '', #'NOME*': linha_id.xxxx or '',
							linha_id.endereco or '', #'ENDEREÇO': linha_id.xxxx or '',
							linha_id.cidade or '', #'CIDADE': linha_id.xxxx or '',
							linha_id.pais_id.name or '', #'PAÍS(ref)*': linha_id.xxxx or '',
							linha_id.telefone or '', #'TELEFONE': linha_id.xxxx or '',
							linha_id.celular or '', #'CELULAR': linha_id.xxxx or '',
							linha_id.fax or '', #'FAX': linha_id.xxxx or '',
							linha_id.email or '', #'E-MAIL': linha_id.xxxx or '',
							]
					elif obj == 'prod':
						vals = [
							linha_id.name or '', #'NOME*': linha_id.xxxx or '',
							# linha_id.grupo_terapeutico_id.name or '', #'GRUPO TERAPÊUTICO': linha_id.xxxx or '',
							linha_id.categoria or '', #'CATEGORIA*': linha_id.xxxx or '',
							# linha_id.is_nacional and 'Sim' or 'Nao', #'LISTA NACIONAL': linha_id.xxxx or '',
							# linha_id.fnm_code or '', #'CÓDIGO FNM': linha_id.xxxx or '',
							linha_id.subs_controlada and 'Sim' or '', #'É SUBSTÂNCIA CONTROLADA': linha_id.xxxx or '',
							linha_id.tipo_prod or '', #'TIPO DE SUBSTÂNCIA': linha_id.xxxx or '',
							]
					elif obj == 'noco':
						vals = [
							linha_id.prod_id.name or '', #'PRPDUTO',
							linha_id.name or '', #'NOME',
							linha_id.nr_registo or '', #'Nº DE REGISTO',
							linha_id.forma or '', #'FORMA FARMACEUTICA',
							linha_id.dosagem or '', #'DOSAGEM',
							linha_id.apresentacao or '', #'APRESENTACAO',
							linha_id.fabricante_id.name or '', #'FABRICANTE(ref/nome)',
							linha_id.importador_id.name or '', #'IMPORTADOR(ref/nome)'
							]
					elif obj == 'dirt':
						vals = [
							linha_id.name or '---',
							linha_id.funcao or '',
							linha_id.cpf or '',
							linha_id.endereco or '',
							linha_id.cx_postal or '',
							linha_id.cidade or '',
							linha_id.pais_id.name or '',
							linha_id.provincia_id.name or '',
							linha_id.telefone or '',
							linha_id.celular or '',
							linha_id.fax or '',
							linha_id.user_email or 'xyz@etc',

							linha_id.must_notify and 'sim' or 'nao',

							linha_id.importador_1_id.name or '',
							linha_id.login_1 or '',
							linha_id.new_password_1 or '',

							linha_id.importador_2_id.name or '',
							linha_id.login_2 or '',
							linha_id.new_password_2 or '',
							]
					writer.writerow(vals)
			writeFile.close()

			new_anexo=io.open(csv_file,mode='r',encoding='utf-8-sig')
			new_anexo = new_anexo.read()
			new_anexo = base64.b64encode(new_anexo)
			msg('new_anexo: %s'%new_anexo)
			file_excel={'anexo':new_anexo, 'anexo_name': ''+OBJ[obj]+'.csv', }#xlsx			
			# self.write(cr,uid,ids,file_excel)
			self._change(cr, uid, ids, file_excel)
		return {'value':file_excel}
excel_export()
