# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2014 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import decimal_precision as dp
from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

DICT = {
    'bief_submeter': 'Submeter',
    'bief_validar_1': 'Validar_1',
    'bief_validar_2': 'Validar_2',
    'bief_aprovar': 'Aprovar',
    'bief_rejeitar': 'Rejeitar',
    'bief_cancelar': 'Cancelar',
    'bief_rascunho_2': 'Voltar à Rascunho',
    'xxxxxxx': 'yyyyyyyyy',
    }
def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

def name_selection_groups(ids): return 'sel_groups_' + '_'.join(map(str, ids))
def name_boolean_group(id): return 'in_group_' + str(id)

class res_users(osv.osv):
	_inherit = 'res.users'
	_columns = {
		'is_director': fields.boolean('Director Técnico', readonly=True),
		# 'is_eliminavel': fields.boolean('Director Técnico', readonly=True),		
		'director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico',),
		'nr_importador': fields.selection([('1','1'),('2','2')],'Importador Nr',readonly=True),
		}
	_defaults = {'is_director': False,'director_id': False,}
res_users()

class res_groups(osv.osv):
	_inherit = 'res.groups'

	def update_user_groups_view(self, cr, uid, context=None):
		# the view with id 'base.user_groups_view' inherits the user form view,
		# and introduces the reified group fields
		view = self.get_user_groups_view(cr, uid, context)
		if view:
			xml = u"""<?xml version="1.0" encoding="utf-8"?>
<!-- GENERATED AUTOMATICALLY BY GROUPS -->
<field name="groups_id" position="replace">
<group col="12" colspan="12">
%s
%s
</group>
</field>
"""
			xml1, xml2 = [], []
			xml1.append('<separator string="%s" colspan="12"/>' % _('Applications'))
			for app, kind, gs in self.get_groups_by_application(cr, uid, context):
				if kind == 'selection':
					# application name with a selection field
					field_name = name_selection_groups(map(int, gs))
					xml1.append('<field name="%s" colspan="2"/>' % field_name)
					# xml1.append('<newline/>')
				else:
					# application separator with boolean fields
					app_name = app and app.name or _('Other')
					xml2.append('<separator string="%s" colspan="12"/>' % app_name)
					for g in gs:
						field_name = name_boolean_group(g.id)
						xml2.append('<field name="%s" colspan="2"/>' % field_name)
			arch = {'arch': xml % ('\n'.join(xml1), '\n'.join(xml2))}
			view.write(arch)
			# error('NADA',xml2)
		return True
res_groups()



class res_bank(osv.osv):
    _name = 'res.bank'
    _inherit = 'res.bank'
    _columns = {
                'nib': fields.char('Bank Identification Number (BIN)', size=21),
                'iban': fields.char('International Bank Account Number (IBAN)', size=34),
                }

res_bank()

class res_partner_bank(osv.osv):
    _name = 'res.partner.bank'
    _inherit = 'res.partner.bank'
    _columns = {
                'nib': fields.char('Bank Identification Number (BIN)', size=21),
                'iban': fields.char('SWIFT Code', size=34),
                'currency_id': fields.many2one('res.currency','Currency', required=True),
                }
    
    _defaults = {'partner_id': lambda self, cr, uid, c: c.get('partner_id', False)}

    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        if not vals.has_key('partner_id'):
            company_id = self.pool.get('res.company')._company_default_get(cr, uid, 'res.bank', context=context)
            company  = self.pool.get('res.company').browse(cr, uid, company_id)
            partner_id = company and company.partner_id and company.partner_id.id or False
            vals['partner_id'] = partner_id
        return super(res_partner_bank, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        if vals.has_key('partner_id'):
            company_id = self.pool.get('res.company')._company_default_get(cr, uid, 'res.bank', context=context)
            company  = self.pool.get('res.company').browse(cr, uid, company_id)
            partner_id = company and company.partner_id and company.partner_id.id or False
            if vals.get('partner_id', False) != partner_id:
                vals['partner_id'] = partner_id
        res = super(res_partner_bank, self).write(cr, uid, ids, vals, context=context)
        return True    
res_partner_bank()
