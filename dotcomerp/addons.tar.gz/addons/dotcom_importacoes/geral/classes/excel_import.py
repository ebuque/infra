# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
import os
import base64
# import pandas as pd
import xlrd
import random
# import unidecode
logger = logging.getLogger('excel_import')


def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

def _add_digitos(n_digitos,numero):
    str_nr = str(numero)
    while(len(str_nr) < n_digitos):
        str_nr = ('0'+str_nr)
    return str_nr


def _get(vals):
    res = False
    if 'tipo_prod' in vals and 'subs_controlada' in vals and vals['subs_controlada']:
        op = random.randint(1,3)
        if op == 1: res =  'psicotropico'
        if op == 2: res =  'estupefaciente'
        res =  'percursor'
    elif 'subs_controlada' in vals:
        if random.randint(0,1) == 1: res =  True
    elif 'is_nacional' in vals:
        if random.randint(0,1) == 1: res =  True
    elif 'nuit' in vals or 'alvara' in vals:
        res =  str(random.randint(4000000,9999999))
    if ('fnm_code' in vals and 'is_nacional' in vals and vals['is_nacional']) or 'nr_registo' in vals:
        res =  str(random.randint(100,9999))
    elif 'grupo_terapeutico_id' in vals:
        res =  "GR%s"%_add_digitos(3,random.randint(1,31))
    msg('vals: %s,   res: %s'%(vals,res))
    return res

mod_dirtec = ['Nome','Função','CPF Nº','Endereço','C. Postal','Cidade','País','Província','Telefone','Celular','Fax','Email','Sujeito a notificações(sim/não)','1º Importador','Login 1º Usuário','Senha 1º Usuário','2º Importador','Login 2º Usuário','Senha 2º Usuário']
mod_fabric = ['Nome','NUIT','Endereço','Complemento','C. Postal','Cidade','País','Província','Telefone','Celular','Fax','E-Mail']
mod_profar = ['Nome','Medicamento(sim/não)','É Subs Controlada(sim/não)','Tipo de Substância(Psicotrópico,Estupefaciente,Percursor)','NC-NOME','NC-Nº DE REGISTO','NC-GRUPO TERAPÊUTICO(ref)','NC-LISTA NACIONAL(sim/não)','NC-CÓDIGO FNM','NC-DATA DE REGISTO','NC-PRAZO(ANOS)','NC-FORMA FARMACEUTICA','NC-DOSAGEM','NC-APRESENTAÇÃO','NC-FABRICANTE','NC-IMPORTADOR']
mod_import = ['Nome','NUIT','Alvará nº','Endereço','Complemento','C. Postal','Cidade','País','Província','Telefone','Celular Fax E-Mail']
mod_sal = ['Nome','Factor de Conversão','Produto Farmacêuticos']

MODEL = {
    'profar': 'dotcom.produto.farmaceutico',
    'import': 'dotcom.parceiro.importador',
    'fabric': 'dotcom.fabricante',
    'dirtec': 'dotcom.director.tecnico',
    'nomcom': 'dotcom.prod.comercial_name',
    'gruter': 'dotcom.grupo.terapeutico',
    'pais_id': 'res.country',
    'provincia_id': 'res.country.state',
    'sal': 'dotcom.prod.sal',
    }
# def getShVal(sheet,row,col):
#     return sheet.cell_value(rowx=row, colx=col)
def getShVal(sheet,row,col):
    val = toStr(sheet.cell_value(rowx=row, colx=col))
    # msg('%s.type = %s'%(val,type(val)))
    return val

def getStrOf(lista):
    val = ''
    n, i = len(lista), 1
    for item in lista:
        if i < n: val += "%s, "%item
        if i == n: val += "%s"%item
        i += 1
    return val

def toStr(maybeFloat):
    return (type(maybeFloat) == float and "%s"%int(maybeFloat)) or maybeFloat

def get_row_1(sheet):
    row = 1
    for rx in range(sheet.nrows):
        if not getShVal(sheet,rx,0) and  not getShVal(sheet,rx,1):
            row += 1
        else:
            break
    return row

def getCateg(medicamento):
    if medicamento == 'sim': return 'medicamento'
    return 'saude'

def trem(arg):
    return arg.replace(' ', '')

#isupper(), islower(), lower(), upper()
def getTipoSubs(tipo):
    tipo = trem(tipo)
    if not tipo: return False
    if tipo in ['psicotropico','Psicotrópico',tipo.upper()]: return 'psicotropico'
    if tipo in ['estupefaciente','Estupefaciente',tipo.upper()]: return 'estupefaciente'
    return 'percursor'

def getBoll(boll):
    if boll == 'sim': return True
    return False

class excel_import(osv.osv_memory):
    _name='excel.import'
    _columns ={
        'anexo_name': fields.char('Nome', size=128, readonly=True),
        'anexo': fields.binary("Anexo", required=False, readonly=False,),
        'datetime': fields.datetime('Data e Hora', readonly=True),
        'linhas': fields.integer('Linhas', readonly=True),
        'colunas': fields.integer('Colunas', readonly=True),
        'objecto': fields.selection([
            ('profar','Produtos Farmacêuticos'),
            ('sal','Sais'),
            ('dirtec','Director Técnicos'),
            ('fabric','Fabricante'),
            ('import','Importador'),
            ],'Objecto', required=True, readonly=False),

        'nota': fields.text('Nota', required=False, readonly=True,),
        'state': fields.selection([
                ('rascunho','Rascunho'),
                ('importado','Importado'),
                ],'Estado', select=True, readonly=True,),
        }
    _defaults ={
        'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'objecto': 'profar',
        'state': 'rascunho',
    }

    def _change(self, cr, uid, ids, vals, context=None):
        self.write(cr,uid,ids,vals)
        return {'value': vals}  

    def on_ch(self, cr, uid, ids, valor, descricao, context=None):
        # msg('import_excel.on_ch_ %s valor: %s'%(descricao,valor))
        if context is None: context = {}
        vals = {}
        if valor and descricao == 'anexo':
            vals = {'state': 'rascunho','linhas': 0,'colunas': 0}
            return self._change(cr, uid, ids, vals)


    def getObjId(self,cr,uid,objecto,query, vals):
        model = self.pool.get(MODEL[objecto])
        obj_id = model.search(cr, uid, query)
        if not obj_id:
            obj_id = False
            if vals: obj_id = model.create(cr, uid, vals)
        else:
            obj_id = obj_id[0]
        # msg('getObjId.%s, query: %s,  obj_id: %s'%(objecto,query,obj_id))
        return obj_id

    def get_vals_dirtec(self,cr,uid,sheet):
        result = [] # query = [('name','=',fnm_code)]
        # unidecode.unidecode('não')
        for rx in range(get_row_1(sheet),sheet.nrows):
            pais_id = getShVal(sheet,rx,6) and self.getObjId(cr,uid,'pais_id',[('code','=',getShVal(sheet,rx,6))],False) or False
            provincia_id = getShVal(sheet,rx,7) and self.getObjId(cr,uid,'provincia_id',[('code','=',getShVal(sheet,rx,7))],False) or False
            importador_1_id = getShVal(sheet,rx,13) and self.getObjId(cr,uid,'import',[('name','=',getShVal(sheet,rx,13))],False) or False
            importador_2_id = getShVal(sheet,rx,16) and self.getObjId(cr,uid,'import',[('name','=',getShVal(sheet,rx,16))],False) or False
            vals = {
                'name': getShVal(sheet,rx,0) or '---',
                'funcao': getShVal(sheet,rx,1) or '',
                'cpf': getShVal(sheet,rx,2) or '',
                'endereco': getShVal(sheet,rx,3) or '',
                'cx_postal': getShVal(sheet,rx,4) or '',
                'cidade': getShVal(sheet,rx,5) or '',
                'pais_id': pais_id,
                'provincia_id': provincia_id,
                'telefone': getShVal(sheet,rx,8) or '',
                'celular': getShVal(sheet,rx,9) or '',
                'fax': getShVal(sheet,rx,10) or '',
                'user_email': getShVal(sheet,rx,11) or 'algo@etc.com',
                'must_notify': True,
                'importador_1_id': importador_1_id,
                'login_1': getShVal(sheet,rx,14) or '',
                'new_password_1': getShVal(sheet,rx,15) or '',
                'importador_2_id': importador_2_id,
                'login_2': getShVal(sheet,rx,17) or '',
                'new_password_2': getShVal(sheet,rx,18) or '',
            }
            result.append(vals)
        return result

    def get_vals_fabric(self,cr,uid,sheet):
        result = [] # query = [('name','=',fnm_code)]
        for rx in range(get_row_1(sheet),sheet.nrows):
            pais_id = getShVal(sheet,rx,6) and self.getObjId(cr,uid,'pais_id',[('code','=',getShVal(sheet,rx,6))],False) or False
            provincia_id = getShVal(sheet,rx,7) and self.getObjId(cr,uid,'provincia_id',[('code','=',getShVal(sheet,rx,7))],False) or False
            vals = {
                'name': getShVal(sheet,rx,0) or '',
                'nuit':  getShVal(sheet,rx,1) or '',
                'endereco':  getShVal(sheet,rx,2) or '',
                'complemento':  getShVal(sheet,rx,3) or '',
                'cx_postal':  getShVal(sheet,rx,4) or '',
                'cidade':  getShVal(sheet,rx,5) or '',
                'pais_id': pais_id,
                'provincia_id': provincia_id,
                'telefone':  getShVal(sheet,rx,8) or '',
                'celular':  getShVal(sheet,rx,9) or '',
                'fax':  getShVal(sheet,rx,10) or '',
                'email':  getShVal(sheet,rx,11) or '',                
            }
            result.append(vals)
        return result

    def get_vals_import(self,cr,uid,sheet):
        result = [] # query = [('name','=',fnm_code)]
        for rx in range(get_row_1(sheet),sheet.nrows):
            pais_id = getShVal(sheet,rx,7) and self.getObjId(cr,uid,'pais_id',[('code','=',getShVal(sheet,rx,7))],False) or False
            provincia_id = getShVal(sheet,rx,8) and self.getObjId(cr,uid,'provincia_id',[('code','=',getShVal(sheet,rx,8))],False) or False
            vals = {
                'name': getShVal(sheet,rx,0) or '',
                'nuit':  getShVal(sheet,rx,1) or '',
                'endereco':  getShVal(sheet,rx,2) or '',
                'alvara':  getShVal(sheet,rx,3) or '',
                'complemento':  getShVal(sheet,rx,4) or '',
                'cx_postal':  getShVal(sheet,rx,5) or '',
                'cidade':  getShVal(sheet,rx,6) or '',
                'pais_id': pais_id,
                'provincia_id': provincia_id,
                'telefone':  getShVal(sheet,rx,9) or '',
                'celular':  getShVal(sheet,rx,10) or '',
                'fax':  getShVal(sheet,rx,11) or '',
                'email':  getShVal(sheet,rx,12) or '',                
            }
            result.append(vals)
        return result

    def get_vals_profar(self,cr,uid,sheet):
        result = [] # query = [('name','=',fnm_code)]
        for rx in range(get_row_1(sheet),sheet.nrows):
            grupo_terapeutico_id = getShVal(sheet,rx,6) and self.getObjId(cr,uid,'gruter',[('ref','=',getShVal(sheet,rx,6))],False) or 1
            fabricante_id = getShVal(sheet,rx,14) and self.getObjId(cr,uid,'fabric',[('name','=',getShVal(sheet,rx,14))],False) or False
            importador_id = getShVal(sheet,rx,15) and self.getObjId(cr,uid,'import',[('name','=',getShVal(sheet,rx,15))],False) or False
            vals = {
                'name': getShVal(sheet,rx,0) or '',
                'categoria': getCateg(getShVal(sheet,rx,1) or ''),
                'subs_controlada': getBoll(getShVal(sheet,rx,2)),
                'tipo_prod': getTipoSubs(getShVal(sheet,rx,3) or ''),

                'cn_name': getShVal(sheet,rx,4) or '',
                'nr_registo': getShVal(sheet,rx,5) or '',
                'grupo_terapeutico_id': grupo_terapeutico_id,

                'is_nacional': getBoll(getShVal(sheet,rx,7)),
                'fnm_code': getShVal(sheet,rx,8) or '',
                'data_registo': getShVal(sheet,rx,9) or '',

                'prazo': getShVal(sheet,rx,10) or '',
                'forma': getShVal(sheet,rx,11) or '',
                'dosagem': getShVal(sheet,rx,12) or '',
                'apresentacao': getShVal(sheet,rx,13) or '',

                'fabricante_id': fabricante_id,
                'importador_id': importador_id,
            }
            result.append(vals)
        return result

    def get_vals_sal(self,cr,uid,sheet):
        result = [] # query = [('name','=',fnm_code)]
        for rx in range(get_row_1(sheet),sheet.nrows):
            prod_id = getShVal(sheet,rx,2) and self.getObjId(cr,uid,'profar',[('name','=',getShVal(sheet,rx,2))],False) or False
            vals = {
                'name': getShVal(sheet,rx,0) or '',
                'fact_conv':  float(getShVal(sheet,rx,1)) or 0.01,
                'prod_id':  prod_id,              
            }
            result.append(vals)
        return result
# mod_sal = ['Nome','Factor de Conversão','Produto Farmacêuticos']

    def import_excel(self,cr,uid,ids,context=None):
        if context is None: context = {}
        msg('import_excel ids: %s' % ids)
        prod_model = self.pool.get('dotcom.produto.farmaceutico')
        importador_model = self.pool.get('dotcom.parceiro.importador')
        fabricante_model = self.pool.get('dotcom.fabricante')
        comercial_name_model = self.pool.get('dotcom.prod.comercial_name')
        grupo_terapeutico_model = self.pool.get('dotcom.grupo.terapeutico')

        objecto = ''
        for document in self.browse(cr,uid,ids):
            objecto = document.objecto
            if not document.anexo: error(action,'Anexo Inexistente!')
            file_anexo = document.anexo
            file_resource="/opt/dotcomerp/server/openerp/addons/dotcom_importacoes/data/xxxx.py"
            if os.path.exists(file_resource): os.remove(file_resource)
            f = open(file_resource, "wb")
            f.write(file_anexo.decode('base64'))
            # f.read()
            f.close()

        book = xlrd.open_workbook(file_resource)
        sheet = book.sheet_by_index(0)
        self._change(cr, uid, ids, {'linhas': sheet.nrows, 'colunas': sheet.ncols })
        msg('book.nsheets: %s, sheet.name: %s, sheet.nrows: %s, sheet.ncols: %s,' % (book.nsheets,sheet.name, sheet.nrows, sheet.ncols))
        
        # if objecto == 'profar': self.import_excel_antigo(cr,uid,sheet,context)
        # msg('_________________________________________________________________________________')
        # return True
        result = []
        if objecto == 'dirtec': result = self.get_vals_dirtec(cr,uid,sheet)
        elif objecto == 'fabric': result = self.get_vals_fabric(cr,uid,sheet)
        elif objecto == 'import': result = self.get_vals_import(cr,uid,sheet)
        elif objecto == 'profar': result = self.get_vals_profar(cr,uid,sheet)
        elif objecto == 'sal': result = self.get_vals_sal(cr,uid,sheet)
        # msg('result.%s: %s'%(objecto,result))

         # =  #'ERROS ENCONTRADOS\n'
        model = self.pool.get(MODEL[objecto])
        nota, aux_nota, barra = '', '', '_________________________________________________________________________________'
        for vals in result:
            aux_nota = ''
            linha = []
            # if True:
            try:
                if objecto == 'dirtec':
                    linha = getStrOf([vals['name'],vals['funcao'],vals['cpf'],vals['endereco'],vals['cx_postal'],vals['cidade'],vals['pais_id'],vals['provincia_id'],vals['telefone'],vals['celular'],vals['fax'],vals['user_email'],vals['must_notify'],vals['importador_1_id'],vals['login_1'],vals['new_password_1'],vals['importador_2_id'],vals['login_2'],vals['new_password_2']])
                    if not vals['name']: aux_nota = '\nNome não definido. '
                    if not vals['user_email']: aux_nota += '\nEmail não definido. '
                    if len(aux_nota) == 0:
                        oid = model.search(cr, uid,  [('name','=',vals['name'])])
                        if not oid: model.create(cr, uid, vals)
                        if oid: aux_nota += '\nDirector ja existe!\n%s'%linha
                    else:
                        aux_nota +='\nLinha: %s'%(linha)

                elif objecto == 'import':
                    linha = getStrOf([vals['name'],vals['nuit'],vals['endereco'],vals['alvara'],vals['complemento'],vals['cx_postal'],vals['cidade'],vals['pais_id'],vals['provincia_id'],vals['telefone'],vals['celular'],vals['fax'],vals['email']])
                    if not vals['name']: aux_nota = '\nNome não definido. '
                    if not vals['nuit']: aux_nota += '\nNuit não definido. '
                    if not vals['alvara']: aux_nota += '\nAlvará não definido. '
                    if not vals['pais_id']: aux_nota += '\nPaís não definido. '
                    if len(aux_nota) == 0:
                        oid = model.search(cr, uid,  [('name','=',vals['name'])])
                        if not oid: model.create(cr, uid, vals)
                        if oid: aux_nota += '\nImportador ja existe!\n%s'%linha
                    else:
                        aux_nota +='\nLinha: %s'%(linha)

                elif objecto == 'fabric':
                    linha = getStrOf([vals['name'],vals['nuit'],vals['endereco'],vals['complemento'],vals['cx_postal'],vals['cidade'],vals['pais_id'],vals['provincia_id'],vals['telefone'],vals['celular'],vals['fax'],vals['email']])
                    if not vals['name']: aux_nota = '\nNome não definido. '
                    if not vals['nuit']: aux_nota += '\nNuit não definido. '
                    if len(aux_nota) == 0:
                        oid = model.search(cr, uid,  [('name','=',vals['name'])])
                        if not oid: model.create(cr, uid, vals)
                        if oid: aux_nota += '\nFabricante ja existe!\n%s'%linha
                    else:
                        aux_nota +='\nLinha: %s'%(linha)

                elif objecto == 'sal':
                    linha = getStrOf([vals['name'],vals['fact_conv'],vals['prod_id']])
                    if not vals['name']: aux_nota = '\nNome não definido. '
                    if not vals['fact_conv']: aux_nota += '\nNuit não definido. '
                    if not vals['prod_id']: aux_nota += '\nProduto não definido. '
                    if len(aux_nota) == 0:
                        oid = model.search(cr, uid,  [('name','=',vals['name'])])
                        if not oid: model.create(cr, uid, vals)
                        if oid: aux_nota += '\nSal ja existe!\n%s'%linha
                    else:
                        aux_nota +='\nLinha: %s'%(linha)

                elif objecto == 'profar':
                    cn_model = self.pool.get(MODEL['nomcom'])
                    if not vals['name']: aux_nota += '\nNome não definido. '
                    if not vals['categoria']: aux_nota += '\nCategoria não definida. '
                    if vals['subs_controlada'] and not vals['tipo_prod']: aux_nota += '\nTipo de Substância não definido. '
                    
                    linha = getStrOf([vals['name'],vals['categoria'],vals['subs_controlada'],vals['tipo_prod']])
                    if len(aux_nota) == 0:
                        oid = model.search(cr, uid,  [('name','=',vals['name'])])
                        if oid: oid = oid[0] 
                        if not oid: oid = model.create(cr, uid, vals)   

                        prod_name = vals['name']
                        vals['prod_id'] = oid
                        vals['name'] = vals['cn_name']
                        if not vals['importador_id']: aux_nota += '\nImportador não definido. '
                        if not vals['grupo_terapeutico_id']: aux_nota += '\nGrupo Terapêuticos não definido. '
                        if not vals['fabricante_id']: aux_nota += '\nFabricante não definido. '
                        if vals['is_nacional'] and not vals['fnm_code']: aux_nota += '\nCódigo FNM não definido. '

                        linha = getStrOf([vals['name'],vals['nr_registo'],vals['grupo_terapeutico_id'],vals['is_nacional'],vals['fnm_code'],vals['data_registo'],vals['prazo'],vals['forma'],vals['dosagem'],vals['apresentacao'],vals['fabricante_id'],vals['importador_id']])
                        if len(aux_nota) == 0:
                            oid = cn_model.search(cr, uid,  [('name','=',vals['name'])])
                            if not oid: model.create(cr, uid, vals)
                            if oid: aux_nota += '\nNome Comercial ja existe!\n%s'%linha
                        else:
                            aux_nota +='\nNomes  Comerciais do Produto "%s"\nLinha: %s'%(prod_name,linha)
                    else:
                        aux_nota +='\nProduto Farmacêutico\nLinha: %s'%(linha)
                if len(aux_nota) > 0:  nota += '\n%s\n%s'%(aux_nota,barra)
            except Exception as e:#e.message
                aux_nota += '\nException: %s'%e
        if len(aux_nota) > 0:  nota += '\n%s'%(aux_nota)
        self._change(cr, uid, ids, {'anexo': False, 'state': 'importado', 'nota': nota})
        return True 





    def import_excel_antigo(self,cr,uid,sh,context=None):
        if context is None:context = {}
        msg('import_excel_antigo')
        prod_model = self.pool.get('dotcom.produto.farmaceutico')
        importador_model = self.pool.get('dotcom.parceiro.importador')
        fabricante_model = self.pool.get('dotcom.fabricante')
        comercial_name_model = self.pool.get('dotcom.prod.comercial_name')
        grupo_terapeutico_model = self.pool.get('dotcom.grupo.terapeutico')

        result = []
        for rx in range(sh.nrows):
            if rx > 1:
                vals = {
                    'EMPRESA': sh.cell_value(rowx=rx, colx=0),
                    'NOME_COMERCIAL': sh.cell_value(rowx=rx, colx=1),
                    'SUBSTÂNCIA_ACTIVA': sh.cell_value(rowx=rx, colx=2),
                    'DOSAGEM': sh.cell_value(rowx=rx, colx=3),
                    'FORMA': sh.cell_value(rowx=rx, colx=4),
                    'APRESENTACAO': sh.cell_value(rowx=rx, colx=5),
                    'FABRICANTE': sh.cell_value(rowx=rx, colx=6),
                    'Pais': sh.cell_value(rowx=rx, colx=7),
                    'N_REGISTO': sh.cell_value(rowx=rx, colx=8),
                }
                result.append(vals)

        for vals in result: 
            importador_id = importador_model.search(cr, uid,  [('name','=',vals['EMPRESA'])])
            if not importador_id:
                nuit = _get(['nuit'])
                alvara = _get(['alvara'])
                importador_id = importador_model.create(cr, uid, {'name': vals['EMPRESA'], 'nuit':  nuit[0], 'alvara':  alvara[0], 'pais_id': 159})
            else:
                importador_id = importador_id[0]
            
            prod_name = vals['SUBSTÂNCIA_ACTIVA'] and vals['SUBSTÂNCIA_ACTIVA']
            prod_id = prod_model.search(cr, uid,  [('name','=',prod_name)])
            if not prod_id:
                subs_controlada = _get(['subs_controlada']),
                tipo_prod = _get({'subs_controlada': subs_controlada,'tipo_prod': True,}),
                msg('type(tipo_prod): %s,   type(subs_controlada): %s'%(type(tipo_prod),type(subs_controlada)))
                prod_vals = {
                    'name': prod_name, 
                    'categoria': 'medicamento',
                    'in_use': True,
                    'from_excel': True,
                    'subs_controlada': subs_controlada[0],
                    'tipo_prod': tipo_prod[0],
                    }
                prod_id = prod_model.create(cr,uid,prod_vals)
            else:
                prod_id = prod_id[0]  

            
            fabricante_id = fabricante_model.search(cr, uid,  [('name','=',vals['FABRICANTE'])])
            if not fabricante_id:
                nuit = _get(['nuit'])
                fabricante_id = fabricante_model.create(cr, uid, {'name': vals['FABRICANTE'], 'pais_id': 159, 'nuit': nuit[0]})
            else:
                fabricante_id = fabricante_id[0]

            grupo_terapeutico_id = _get(['grupo_terapeutico_id'])
            grupo_terapeutico_id = grupo_terapeutico_model.search(cr, uid,  [('ref','=',grupo_terapeutico_id[0])])
            if not grupo_terapeutico_id:
                grupo_terapeutico_id = 1
            else:
                grupo_terapeutico_id = grupo_terapeutico_id[0]

            
            
            is_nacional = _get(['is_nacional']),
            fnm_code = _get({'is_nacional': is_nacional,'fnm_code': True,}),
            cn_vals = {       
                'name': vals['NOME_COMERCIAL'] and vals['NOME_COMERCIAL'],
                'nr_registo': vals['N_REGISTO'] and vals['N_REGISTO'] or '',
                'data_criacao': time.strftime('%Y-%m-%d'),
                'prod_id': prod_id,
                'is_nacional': is_nacional[0],
                'fnm_code': fnm_code[0],
                'grupo_terapeutico_id': grupo_terapeutico_id,
                'importador_id': importador_id,
                'forma': vals['FORMA'] and vals['FORMA'] or '',
                'dosagem': vals['DOSAGEM'] and vals['DOSAGEM'] or '',
                'apresentacao': vals['APRESENTACAO'] and vals['APRESENTACAO'],
                'fabricante_id': fabricante_id,
                }
            if not comercial_name_model.search(cr, uid,  [('name','=',cn_vals['name'])]):
                try:
                    comercial_name_model.create(cr, uid,cn_vals)
                except Exception as e:
                    pass
        return True 
excel_import()

