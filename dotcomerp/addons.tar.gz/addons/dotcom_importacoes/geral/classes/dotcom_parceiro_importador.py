# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_parceiro_importador(osv.osv):
	def _lang_get(self, cr, uid, context=None):
		obj = self.pool.get('res.lang')
		ids = obj.search(cr, uid, [], context=context)
		res = obj.read(cr, uid, ids, ['code', 'name'], context)
		return [(r['code'], r['name']) for r in res] + [('','')]

	_name = 'dotcom.parceiro.importador'
	_description = 'Importadores'
	_columns = {
		'ref': fields.char('Ref.', size=16, required=True,readonly=True),
		'name': fields.char('Nome', size=120, required=True),
		'activo': fields.boolean('Activo'),
		'lang': fields.selection(_lang_get, 'Idioma', help="If the selected language is loaded in the system, all documents related to this partner will be printed in this language. If not, it will be english."),
		'nuit': fields.char('NUIT', size=120, required=True),#Número Único de Indentificação Tributária
		'alvara': fields.char('Alvará nº', size=120, required=True, readonly=False),

		'endereco': fields.char('Endereço', size=120, required=False),
		'complemento': fields.char('Complemento', size=120, required=False),
		'cx_postal': fields.char('C. Postal', size=120, required=False),
		'cidade': fields.char('Cidade', size=120, required=False),
		'pais_id': fields.many2one('res.country', 'País',required=True,),
		'provincia_id': fields.many2one("res.country.state", 'Província', domain="[('country_id','=',pais_id)]"),

		'telefone': fields.char('Telefone', size=64),
		'celular': fields.char('Celular ', size=64),
		'fax': fields.char('Fax', size=64),
		'email': fields.char('E-Mail', size=240),
		'must_notify': fields.boolean('Sujeito a notificações'),

		'nota': fields.text('Notes'),
		'director_1_ids': fields.one2many('dotcom.director.tecnico','importador_1_id','Directores Tecnicos', readonly=True,),#domain="[('activo','=',True)]",
		'director_2_ids': fields.one2many('dotcom.director.tecnico','importador_2_id','Directores Tecnicos', readonly=True,),#domain="[('activo','=',True)]",
		'comercial_name_ids': fields.one2many('dotcom.prod.comercial_name','importador_id','Nomes Comerciais',readonly=True),
		# 'comercial_name_ids': fields.many2many('dotcom.prod.comercial_name', 'transferencia_comercial_name_rel', 'importador_id', 'comercial_name_id', 'Nomes Comerciais', readonly=False,),
	}
	_defaults = {
		'activo': True,
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 6, 'IMP', 'dotcom.parceiro.importador', context=c),
	}
	
	#_rec_name = 'name'	
	_sql_constraints = [('ref_nuit_alvara_unique', 'unique(ref,nuit,alvara)', 'Já existe um importador com esta referência/Nuit/Alvará!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 6, 'IMP', 'dotcom.parceiro.importador', context,True)
		id = super(dotcom_parceiro_importador, self).create(cr, uid, vals, context=context)
		return id
dotcom_parceiro_importador()
