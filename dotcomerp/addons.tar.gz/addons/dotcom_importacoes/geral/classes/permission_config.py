# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2009 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import osv, fields
import tools
import pooler
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)

# class groups_view(osv.osv):
#     _inherit = 'res.groups'
#     def get_application_groups(self, cr, uid, domain=None, context=None):
#         data_model = self.pool.get('ir.model.data')
#         config_model = self.pool.get('permission.config')

#         gids = self.search(cr, uid, domain or [])
#         data_ids = data_model.search(cr,uid,[('model','=','res.groups'),('module','=','dotcom_base')])

#         # gids = gids - [data_id.res_id for data_id in data_model.browse(cr,uid,gids)]
#         ids, data_ids = [], [data_id.res_id for data_id in data_model.browse(cr,uid,data_ids)]
#         for gid in gids:
#             if gid not in data_ids: ids.append(gid)

#         msg('get_application_groups: ids: %s, len(ids): %s, len(gids): %s, data_ids: %s'%(ids,len(ids),len(gids),data_ids))
#         # self.pool.get('permission.config').hide_menus(cr,uid)
#         return ids
# groups_view()

class permission_config(osv.osv):
    _name = 'permission.config'
    _columns = {'name': fields.char('Nome', size=50),}

    # def _auto_init(self, cr, context=None):
    #     super(permission_config, self)._auto_init(cr, context)
    #     return True

    def hide_menus(self, cr,uid,ids,context=None):
        # msg('get_doc_menus')
        data_model, mids, gids, vals, vals_name = self.pool.get('ir.model.data'), [], [], {}, {}
        grupo_model = self.pool.get('res.groups')
        menu_model = self.pool.get('ir.ui.menu')

        # mids.append(data_model.search(cr,uid,[('name','=','menu_administration')]))# Configuracoes
        mids.append(data_model.search(cr,uid,[('model','=','ir.ui.menu'),('name','=','cmanagement_main')])[0])#Gestao Comercial
        mids.append(data_model.search(cr,uid,[('model','=','ir.ui.menu'),('name','=','menu_base_partner')])[0])# Geral
        # msg('permission_config: mids:%s'%mids)
        vals_name['menu_names'] = [menu_model.browse(cr,uid,data_id.res_id).complete_name for data_id in data_model.browse(cr,uid,mids)]
        vals['menu_access'] = [(3, data_id.res_id) for data_id in data_model.browse(cr,uid,mids)] # data_id.res_id = menu_id
        msg('permission_config: vals: %s, vals_name: %s'%(vals,vals_name))
        gids = data_model.search(cr,uid,[('model','=','res.groups'),('module','=','base')])
        gids = [data_id.res_id for data_id in data_model.browse(cr,uid,gids)]
        grupo_model.write(cr,uid,gids,vals)
permission_config()