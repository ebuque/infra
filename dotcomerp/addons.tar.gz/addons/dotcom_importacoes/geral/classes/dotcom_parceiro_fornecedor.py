# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_parceiro_fornecedor(osv.osv):
	def _lang_get(self, cr, uid, context=None):
		obj = self.pool.get('res.lang')
		ids = obj.search(cr, uid, [], context=context)
		res = obj.read(cr, uid, ids, ['code', 'name'], context)
		return [(r['code'], r['name']) for r in res] + [('','')]
		
	_name = 'dotcom.parceiro.fornecedor'
	_description = 'fornecedores'
	_columns = {
		'ref': fields.char('Ref', size=32, required=True,readonly=True),
		'name': fields.char('Nome', size=120, required=True),
		'activo': fields.boolean('Activo'),
		'lang': fields.selection(_lang_get, 'Idioma', help="If the selected language is loaded in the system, all documents related to this partner will be printed in this language. If not, it will be english."),
		'nuit': fields.char('NUIT', size=120, required=True),#Número Único de Indentificação Tributária

		'endereco': fields.char('Endereço', size=120, required=True),
		'complemento': fields.char('Complemento', size=120, required=False),
		'cx_postal': fields.char('C. Postal', size=120, required=False),
		'cidade': fields.char('Cidade', size=120, required=True),
		'pais_id': fields.many2one('res.country', 'País', required=True),
		'provincia_id': fields.many2one("res.country.state", 'Província', domain="[('country_id','=',pais_id)]"),

		'telefone': fields.char('Telefone', size=64),
		'celular': fields.char('Celular ', size=64),
		'fax': fields.char('Fax', size=64),
		'email': fields.char('E-Mail', size=240),
		'must_notify': fields.boolean('Sujeito a notificações'),

		'nota': fields.text('Notes'),
	}
	_defaults = {
		'activo': True,
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 6, 'FOR', 'dotcom.parceiro.fornecedor', context=c),
	}
	
	#_rec_name = 'name'	
	_sql_constraints = [('ref_nuit_unique', 'unique(ref,nuit)', 'Já existe um fornecedor com esta referência ou NUIT!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 6, 'FOR', 'dotcom.parceiro.fornecedor', context,True)
		id = super(dotcom_parceiro_fornecedor, self).create(cr, uid, vals, context=context)
		return id
dotcom_parceiro_fornecedor()