
# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

class dotcom_transf_titularidades(osv.osv):
	_name = 'dotcom.transf.titularidades'
	_description = 'Historico de Transferência de Titularidades'
	_columns = {
		'ref': fields.char('Referência', size=128, required=False, readonly=True),
		'data': fields.date('Data da transferência', required=False, readonly=True),
		'importador_origem_id': fields.many2one('dotcom.parceiro.importador', 'Importador Origem', required=True, readonly=False),
		'importador_destino_id': fields.many2one('dotcom.parceiro.importador', 'Importador Destino', required=True, readonly=False),
		'linha_ids': fields.many2many('dotcom.prod.comercial_name', 'transf_titularidade_comercial_name_rel', 'transf_titularidade_id', 'comercial_name_id', 'Nomes Comerciais', readonly=False, domain="[('importador_id','=',importador_origem_id)]"),
		'state': fields.selection([
			('rascunho','Rascunho'),
			('emitido','Emitido'),
			],'Estado', select=True, readonly=True,),
		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

	}
	_rec_name = 'ref'
	_defaults = {
		'state': 'rascunho',
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'TTI', 'dotcom.transf.titularidades', context=c),
		'data': lambda *a: time.strftime('%Y-%m-%d'),
	}
	# _sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma comercial_name com esta referência!')]


	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('trans_titularidade.on_ch_ %s valor: %s'%(descricao,valor))
		if descricao == 'importador_origem_id':
			return self._change(cr, uid, ids, {'linha_ids': False,})

	def validar(self, cr, uid,ids, context=None):
		msg('trans_titularidade.validar: %s'%(ids))
		err_imp = ''
		for document in self.browse(cr,uid,ids):
			if document.importador_origem_id.id == document.importador_destino_id.id: error(action,'O importador Origem deve ser diferente do importador Destino.')
			if not document.linha_ids: error(action,'Documento sem linhas.')
			for linha_id in document.linha_ids:
				if linha_id.importador_id.id != document.importador_origem_id.id:
					err_imp +=  ('%s, '%linha_id.ref)
			if len(err_imp) > 0: error(action,'Os nomes Comerciais %s não pertencem ao importador "%s".'%(err_imp,document.importador_origem_id.name))
			

	def emitir(self, cr, uid,ids,context=None):
		msg('trans_titularidade.aprovar ids: %s'%ids)
		comercial_name_model = self.pool.get('dotcom.prod.comercial_name')
		for document in self.browse(cr,uid,ids):
			self.validar(cr,uid,ids,context)
			for linha_id in document.linha_ids:
				comercial_name_model.write(cr,uid,[linha_id.id],{'importador_id': document.importador_destino_id.id})
			self.write(cr,uid,ids,{'state':'emitido'})

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'TTI', 'dotcom.transf.titularidades', context,True)
		id = super(dotcom_transf_titularidades, self).create(cr, uid, vals, context=context)
		
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_transf_titularidades, self).unlink(cr, uid, ids, context=context)
		return id
dotcom_transf_titularidades()
