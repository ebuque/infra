# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2014 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import dotcom_director_tecnico
import dotcom_parceiro_importador
import dotcom_parceiro_fornecedor
import dotcom_produto_farmaceutico
import decimal_precision
import res_inherits
import dotcom_transf_titularidades
import excel_import
import excel_export


# id
# create_uid
# create_date
# write_date
# write_uid
# alvara
# fax
# provincia_id
# nuit
# activo
# celular
# cx_postal
# lang
# complemento
# name
# must_notify
# cidade
# pais_id
# nota
# telefone
# endereco
# ref
# email

# 1
# 1
# 2021-03-02 07:38:15.014536


# 87

# 56
# 40515416
# t
# +258 55454515



# MEDIMPORT LDA
# f
# Maputo
# 159

# +258 21 626262
# Av. Dos bla bla bla, 98
# IMP/000001
# info@info