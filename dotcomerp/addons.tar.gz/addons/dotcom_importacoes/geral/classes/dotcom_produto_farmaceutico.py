# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
from dateutil.relativedelta import relativedelta
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

class dotcom_produto_farmaceutico(osv.osv):#Farmacêutico
	_name = 'dotcom.produto.farmaceutico'
	_description = 'Produto Farmacêutico'
	_columns = {
		'ref': fields.char('Ref', size=64, required=True, readonly=True),
		'name': fields.char('Nome', size=120, required=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, readonly=True),
		
		'comercial_name_ids': fields.one2many('dotcom.prod.comercial_name','prod_id','Nomes Comerciais', states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, readonly=True),
		'sal_ids': fields.one2many('dotcom.prod.sal','prod_id','Formas', states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, readonly=True),
		
		'movimento_ids': fields.one2many('reg.mov','prod_id','Movimentos', readonly=True,),

		'subs_controlada': fields.boolean('É Substância Controlada', states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, readonly=True),
		'tipo_prod': fields.selection([
				('psicotropico','Psicotrópico'),
				('estupefaciente','Estupefaciente'),
				('percursor','Percursor'),],'Tipo de Substância', readonly=False),# states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]},
		'categoria': fields.selection([('medicamento','Medicamento'),('saude','Produto de Saúde'),],'Categoria', required=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, readonly=True),

		'in_use': fields.boolean('Em Uso', readonly=True),
		'from_excel': fields.boolean('Vem do Excel', readonly=True),
		'editado': fields.boolean('Já foi Editado', readonly=True),
		
		'state': fields.selection([
			('rascunho','Rascunho'),
			('emitido','Emitido'),
			('cancelado','Cancelado'),
			('rascunho_2','Rascunho'),
			],'Estado', select=True, readonly=True,),
		# 'fact_conv': fields.float('Factor de Conversão', digits=(1,2),  required=True, readonly=False,),
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','prod_id','Cancelamentos', readonly=True,),
	}	 
	_sql_constraints = [('ref_name_unique', 'unique(ref,name)', 'Já existe um Produto Farmacêutico com mesma referência/nome!')]

	_defaults = {		
		'state': 'rascunho',
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 10, 'PRF', 'dotcom.produto.farmaceutico', context=c),
		'subs_controlada': False,
		'from_excel': False,
		'tipo_prod': '',
		'categoria': 'medicamento',
		}

	def start_report(self, cr, uid,ids, context={}):
		msg('prod.start_report ids: %s'%ids)
		data = self.read(cr,uid,ids,)[-1]
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_prod',
			'datas':{
					'model':'dotcom.produto.farmaceutico',
					'id':ids[0],
					'ids':ids,
					'report_type':'pdf',
					'form':data
			},
			'nodestroy':False,
		}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('liberação.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		bief_model = self.pool.get('dotcom.importacao.bief')
		nr_model = self.pool.get('dotcom.sequence')

		vals = {}
		if descricao == 'subs_controlada':
			if not valor: vals = {'tipo_prod': False,}
		if descricao == 'categoria':
			if valor != 'medicamento': vals = {'subs_controlada': False}
		msg('vals: %s'%vals)
		return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}


	def set_numerador(self, cr, uid, ids, context=None):
		cn_model = self.pool.get('dotcom.prod.comercial_name')
		if context is None: context = {}
		numerador = 1
		for document in self.browse(cr,uid,ids):
			for linha_id in document.comercial_name_ids:
				cn_model._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def validar(self, cr, uid,ids, context=None):
		msg('produto.validar: %s'%(ids))
		cn_model = self.pool.get('dotcom.prod.comercial_name')
		for document in self.browse(cr,uid,ids):
			err_cn = ''
			for cnid in document.comercial_name_ids:
				if cnid.is_nacional and not cnid.fnm_code: err_cn += ('#:%s, '%cnid.numerador)
				if cnid.is_nacional and cnid.fnm_code: cn_model._change(cr, uid, [cnid.id], {'fnm_code':False})
			if len(err_cn) > 0: error(action,'O pisco "Lista Nacional" está activo. Informe o "Código FNM" nas linhas %s.'%(err_cn))
			
			if document.subs_controlada and not document.tipo_prod: error(action,'Informe o "Tipo de Substância" ou desactive o pisco "Substância Controlada"!')
			if document.subs_controlada and document.editado and not document.from_excel and not document.sal_ids:
				error(action,'Informe os "Sais da Substância" ou desactive o pisco "Substância Controlada"!')
			
			if not document.subs_controlada and document.tipo_prod: self._change(cr, uid, ids, {'tipo_prod': False})

	def emitir(self, cr, uid,ids,context=None):
		msg('produto.aprovar ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'emitido'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'prod_id': ids[0]},context)

	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': None,
			'certificad_id': None,
			'prod_id': ids and ids[0] or None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_cancelar(self, cr, uid,ids,context=None):
		msg('produto.cancelar ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'prod_id': ids[0]},context)

	def run_voltar_rascunho(self, cr, uid,ids,context=None):
		msg('produto.voltar_rascunho ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'rascunho_2'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'prod_id': ids[0]},context)	

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 10, 'PRF', 'dotcom.produto.farmaceutico', context,True)
		id = super(dotcom_produto_farmaceutico, self).create(cr, uid, vals, context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'prod_id': id},context)
		self.validar(cr, uid,[id],context)
		self.set_numerador(cr, uid,[id],context)
		self._change(cr, uid, [id], {'editado':True})
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		id = super(dotcom_produto_farmaceutico, self).write(cr, uid, ids, vals, context=context)
		self.set_numerador(cr, uid,ids,context)
		return id

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_produto_farmaceutico, self).unlink(cr, uid, ids, context=context)
		
dotcom_produto_farmaceutico()

class dotcom_prod_comercial_name(osv.osv):

	def get_activo(self, cr, uid, ids, name, arg, context=None):
		msg('comercial_name.get_activo ids: %s'%ids)
		res, activo, now= {}, False, date.today()
		for oid in self.browse(cr, uid, ids, context):
			self.on_ch_2(cr, uid, [oid.id], oid.data_registo,oid.prazo,'data_registo_prazo')
		for oid in self.browse(cr, uid, ids, context):
			data_vencimento = datetime.strptime(oid.data_vencimento, '%Y-%m-%d').date()
			if now < data_vencimento: activo = True
			res[oid.id] = activo
			msg('id: %s #  now: %s < date_venc: %s =  activo: %s'%(oid.id, now,data_vencimento,activo))
		return res

	_name = 'dotcom.prod.comercial_name'
	_description = 'Nomes Comerciais das Substâncias'
	_columns = {
		'numerador': fields.integer('#', readonly=True),
		'ref': fields.char('Ref', size=32, required=False,readonly=True),		
		'name': fields.char('Nome', size=120, required=False),
		'nr_registo': fields.char('Nº de registo', size=32, required=False,),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico', 'Produto Farmacêutico', required=False, readonly=False),
		'importador_id': fields.many2one('dotcom.parceiro.importador', 'Importador', required=True, readonly=False, domain="[('activo','=',True),]",),

		'is_nacional': fields.boolean('Lista Nacional', readonly=False),
		'fnm_code': fields.char('Código FNM', size=16,  readonly=True, help='Formulário Nacional de Medicamentos'),

		'grupo_terapeutico_id': fields.many2one('dotcom.grupo.terapeutico','Grupo Terapêutico', required=True,readonly=False),

		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=False),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=False),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=False),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=True,readonly=False),
		# 'activo': fields.boolean('Activo', readonly=False),
		'activo': fields.function(get_activo, method=True, string='Activo', type='boolean', readonly=False),

		'data_registo': fields.date('Data de Registo', readonly=False),
		'prazo': fields.integer('Prazo(Anos)', readonly=False),
		'data_vencimento': fields.date('Vencimento', required=False, readonly=True),
	}
	_defaults = {
		'prazo': 5,
		'activo': True,
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 10, 'NCS', 'dotcom.prod.comercial_name', context=c),
		'data_registo': lambda *a: time.strftime('%Y-%m-%d'),
	}	 
	_sql_constraints = [('ref_nr_registo_unique', 'unique(ref,nr_registo)', 'Já existe um Nome Comercial com referência/Código FNM informado/Nome!')]


	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch_2(self, cr, uid, ids, valor_a, valor_b, descricao, context=None):
		# msg('comercial_name.on_ch_2 %s, %s , %s'%(descricao,valor_a,valor_b))
		if context is None: context = {}

		vals = {}
		if descricao == 'data_registo_prazo':
			if valor_b <= 0: error(action,'Prazo Inválido!')
			if not valor_a:
				valor_a = date.today()
				vals['data_registo'] = valor_a
			valor_a = datetime.strptime(str(valor_a), '%Y-%m-%d')
			# data_vencimento = str((valor_a + timedelta(years=valor_b)).strftime('%Y-%m-%d'))
			data_vencimento = str((valor_a + relativedelta(years=valor_b)).strftime('%Y-%m-%d'))
			vals['data_vencimento'] = data_vencimento
		# if descricao == 'is_nacional':
		# 	if not valor: vals = {'fnm_code': False,}
		return self._change(cr, uid, ids, vals)

	def is_unique_fnm_code(self, cr, uid,ids,fnm_code, context=None):
		msg('produto.is_unique_fnm_code = %s, ids[%s]'%(fnm_code,ids))
		if context is None: context = {}
		if not fnm_code: return True		
		existe = self.search(cr, uid, [('fnm_code','=',fnm_code)])
		if existe and (not ids or (ids and ids[0] != existe[0])): error('Acção Inválida!','Já existe um Produto Farmacêutico com este Código FNM: "%s".'%fnm_code)
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		msg('comercial_name.create %s'%vals)
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 10, 'NCS', 'dotcom.prod.comercial_name', context,True)
		id = super(dotcom_prod_comercial_name, self).create(cr, uid, vals, context=context)
		# if 'fnm_code' in vals: self.is_unique_fnm_code(cr, uid,[id],vals['fnm_code'],context)
		oid = self.browse(cr,uid,id)
		self.is_unique_fnm_code(cr, uid,[id],oid.fnm_code,context)
		self.on_ch_2(cr, uid, [id], oid.data_registo,oid.prazo,'data_registo_prazo')
		self._change(cr, uid, [id], vals)
		return id

	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		for oid in self.browse(cr,uid,ids,context):
			self.is_unique_fnm_code(cr, uid,ids,oid.fnm_code,context)
		msg('comercial_name.write %s'%vals)
		return super(dotcom_prod_comercial_name, self).write(cr, uid, ids, vals, context=context)
dotcom_prod_comercial_name()


class dotcom_grupo_terapeutico(osv.osv):
	_name = 'dotcom.grupo.terapeutico'
	_description = 'Grupo Terapêutico'
	_columns = {
		'ref': fields.char('Ref', size=32, required=True, readonly=False),
		'name': fields.char('Nome', size=120, required=True, readonly=False),
	}
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma Grupo Terapêutico com esta referência!')]
dotcom_grupo_terapeutico()

class dotcom_prod_sal(osv.osv):
	_name = 'dotcom.prod.sal'
	_description = 'Sal das substâncias'
	_columns = {
		'name': fields.char('Sal', size=120, required=True),
		'fact_conv': fields.float('Factor de Conversão', digits=(1,2),  required=True, readonly=False,),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico', 'Produto Farmacêutico', required=False, readonly=False),
	}
	# _defaults = {
	# 	# 'state': 'rascunho',
	# 	'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 10, 'NCS', 'dotcom.prod.comercial_name', context=c),
	# 	'data_registo': lambda *a: time.strftime('%Y-%m-%d'),
	# }
	# _sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma comercial_name com esta referência!')]
dotcom_prod_sal()

class dotcom_fabricante(osv.osv):
	_name = 'dotcom.fabricante'
	_description = 'Fabricante'
	_columns = {

		'ref': fields.char('Ref', size=32, required=True,readonly=True),
		
		'name': fields.char('Nome', size=120, required=True, select=True,),
		'nuit': fields.char('NUIT', size=16, required=True, select=True,),
		'full_name': fields.char('Full Nome', size=255,),

		'endereco': fields.char('Endereço', size=120, required=False),
		'complemento': fields.char('Complemento', size=255, required=False),
		'cx_postal': fields.char('C. Postal', size=120, required=False),
		'cidade': fields.char('Cidade', size=120, required=False),
		'pais_id': fields.many2one('res.country', 'País'),
		'provincia_id': fields.many2one("res.country.state", 'Província', domain="[('country_id','=',pais_id)]"),

		'telefone': fields.char('Telefone', size=64),
		'celular': fields.char('Celular ', size=64),
		'fax': fields.char('Fax', size=64),
		'email': fields.char('Email', size=64),

		'nota': fields.text('Notes'),
	}
	_defaults = {
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 5, 'FAB', 'dotcom.fabricante', context=c),
	}
	_rec_name = 'full_name'	
	_sql_constraints = [('ref_nuit_unique', 'unique(ref,nuit)', 'Já existe um Fabricante com esta referência/Nuit!')]

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('fabricante.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao and valor:
			if descricao == 'new_password':
				return {'value': {'password': valor,}}
		return False

	def get_full_name(self, cr, uid, name, pais_id, context=None):
		pais_id = self.pool.get('res.country').browse(cr,uid,pais_id)
		full_name = name
		if pais_id and pais_id.id > 0: full_name = full_name+' - '+pais_id.name
		return full_name

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 5, 'FAB', 'dotcom.fabricante', context,True)
		vals['full_name'] = self.get_full_name(cr,uid,vals['name'],vals['pais_id'])
		id = super(dotcom_fabricante, self).create(cr, uid, vals, context=context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		model = self.pool.get('res.users')
		for oid in self.browse(cr,uid,ids,context):
			vals['full_name'] = self.get_full_name(cr,uid,oid.name,(oid.pais_id and oid.pais_id.id) or False)
		return super(dotcom_fabricante, self).write(cr, uid, ids, vals, context=context)
dotcom_fabricante()




import jasper_reports
from dotcom_doc_reports import JasperDataParser
import pooler
from datetime import datetime, timedelta
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

class prod_farmaceutico_parser(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(prod_farmaceutico_parser, self).__init__(cr, uid, ids, data, context)
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
		return {}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	# def add_days_to_licence(self,cr,uid,context=None):   
	# 	res = {}			
	# 	licence_model = self.pool.get('dotcom.licence')  
	# 	mm = licence_model.search(cr,uid,[])
	# 	logger.info('\n  ________________   =========   ________________')
	# 	logger.info('\n  ________________   =========   ________________')
	# 	logger.info('\n  ________________   mm   ________________  %s' %mm)
	# 	logger.info('\n  ________________   =========   ________________')
	# 	for _id in licence_model.search(cr,uid,[]):
	# 		l = licence_model.browse(cr,uid,_id) 
	# 		# if l.ref == 'DERP/2017/216':
	# 		res = {
	# 			'start': l.end,
	# 			'end': (datetime.now() + timedelta(days=400)).strftime('%Y-%m-01'),
	# 			'remaining_days': 400,
	# 		}
	# 		msg('res: %s'%res)

	def generate_records(self, cr, uid, ids, data, context): 
		msg('prod.farmac.generate_records ids: %s, data: %s'%(ids,data))
		result=[]		
		model = self.pool.get('dotcom.produto.farmaceutico') 
		for oid in model.browse(cr,uid,model.search(cr,uid,[])):
			for linha_id in oid.comercial_name_ids:
				data = {'nome': '%s:%s/%s, %s, %s, %s'%(oid.ref,oid.name,linha_id.name,linha_id.forma,linha_id.dosagem,linha_id.apresentacao)} 
				result.append(data)
		result.append({'company_name': 'Felix Marondo'})
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_prod_farmac','dotcom.produto.farmaceutico',parser=prod_farmaceutico_parser)





# {'name': 'PRF/0000000001:Rituximabe/INTAMAB 500mg/50ml, Solu\xe7\xe3o para infus\xe3o, 500mg/50ml, frasco de 50ml'}, 
# {'name': 'PRF/0000000001:Rituximabe/INTAMAB 100mg/10ml, Solu\xe7\xe3o para infus\xe3o, 100mg/10ml, frasco de 10ml'}, 
# {'name': 'PRF/0000000002:Estearato de eritromicina/RYTHRO 250, Comprimidos revestidos, 250mg, Embalagem de 10 blisters de 10 comprimidos'},

# {'name': 'PRF/0000000003:Vitamina A + Clolecalciferol (Vit. D3)/MAXIVIT A-D, Pomada, False, Bisnaga de 45g'}, 
# {'name': 'PRF/0000000004:Fosfomicina trometasol/UROFAST 3G, Po para solucao oral, 3g, 1 Saqueta contendo 3g'}, 
# {'name': 'PRF/0000000005:Morfina/Morfinax 1000MG, Comprimidos, 1000mg, Embalagem de 10 blisters de 10 comprimidos'}, 
# {'name': 'PRF/0000000005:Morfina/Morfinax 500MG, Comprimidos, 500mg, Embalagem de 10 blisters de 10 comprimidos'}