
# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_director_tecnico(osv.osv):
	_name = 'dotcom.director.tecnico'
	_description = 'Director Técnicos do Importador'
	_columns = {
		'id': fields.integer('ID'),
		'name': fields.char('Nome', size=64, required=True, select=True,
							help="The new user's real name, used for searching"
								 " and most listings"),
		'login_1': fields.char('Login', size=64, required=False,
							 help="Used to log into the system"),
		'login_2': fields.char('Login', size=64, required=False,
							 help="Used to log into the system"),
		'password_1': fields.char('Password', size=64, invisible=True, help="Keep empty if you don't want the user to be able to connect on the system."),
		'new_password_1': fields.char('Senha', size=64, help="Specify a value only when creating a user or if you're changing the user's password, "
															"otherwise leave empty. After a change of password, the user has to login again."),
		'password_2': fields.char('Password', size=64, invisible=True, help="Keep empty if you don't want the user to be able to connect on the system."),
		'new_password_2': fields.char('Senha', size=64, help="Specify a value only when creating a user or if you're changing the user's password, "
															"otherwise leave empty. After a change of password, the user has to login again."),
		
		'saved_1': fields.boolean('Salvo', help="Valida se campos de usuario foram preenchidos"),
		'saved_2': fields.boolean('Salvo'),

		'user_email': fields.char('Email', size=64, required=True),
		'active': fields.boolean('Activo'),

		'funcao': fields.char('Função', size=120, required=False),

		'endereco': fields.char('Endereço', size=120, required=False),
		'cx_postal': fields.char('C. Postal', size=120, required=False),
		'cidade': fields.char('Cidade', size=120, required=False),
		'pais_id': fields.many2one('res.country', 'País'),
		'provincia_id': fields.many2one("res.country.state", 'Província', domain="[('country_id','=',pais_id)]"),

		'telefone': fields.char('Telefone', size=64),
		'celular': fields.char('Celular ', size=64),
		'fax': fields.char('Fax', size=64),
		'must_notify': fields.boolean('Sujeito a notificações'),

		'cpf': fields.char('CPF Nº', size=120, required=False, readonly=False),
		'is_director': fields.boolean('Director Técnico'),

		'importador_1_id':fields.many2one('dotcom.parceiro.importador','1º Importador',),
		'user_importador_1_id': fields.many2one('res.users','Usuário', readonly=True,),
		'importador_2_id':fields.many2one('dotcom.parceiro.importador','2º Importador',),
		'user_importador_2_id': fields.many2one('res.users','Usuário', readonly=True,),
	}
	_defaults = {
		'active': True,
		'saved_1': False,
		'saved_2': False,
		'is_director': True,
		}
	_sql_constraints = [('login_cpf_key', 'UNIQUE (login_1,login_2,cpf)',  'You can not have two users with the same login or cpf!')]

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('director.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao and valor:
			if descricao == 'new_password_1':
				return {'value': {'password_1': valor,}}
			if descricao == 'new_password_2':
				return {'value': {'password_2': valor,}}
		return False

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch_2(self, cr, uid, ids, valor_a, valor_b, descricao, context=None):
		msg('director_write.on_ch_2: %s  valor_a: %s valor_b: %s'%(descricao,valor_a,valor_b))
		if context is None: context = {}
		vals = {}
		# on_change="on_ch_2(importador_1_id,importador_2_id,'importador_1_id')"/>
		if descricao in ['importador_1_id','importador_2_id']:
			if valor_a and valor_b and valor_a == valor_b:
				# self._change(cr, uid, ids, vals)
				error(action,'Os importadores devem ser diferentes!')
		return {'value': vals}

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		model = self.pool.get('res.users')	
		if 'importador_1_id' in vals and 'importador_2_id' in vals and vals['importador_1_id'] == ['importador_2_id']:		
			error(action,'Os importadores devem ser diferentes!')

		if vals['login_1'] and vals['new_password_1']:
			vals['saved_1'] = True
		if vals['login_2'] and vals['new_password_2']:
			vals['saved_2'] = True

		id = super(dotcom_director_tecnico, self).create(cr, uid, vals, context=context)
		vals['director_id'] = id
		vals['is_director'] = True

		if vals['login_1'] and vals['new_password_1']:
			vals['login'] = vals['login_1']
			vals['password'] = vals['password_1']
			vals['new_password'] = vals['new_password_1']
			vals['nr_importador'] = '1'
			self._change(cr, uid, [id], {'user_importador_1_id': model.create(cr, uid, vals, context=context)})

		if vals['login_2'] and vals['new_password_2']:
			vals['login'] = vals['login_2']
			vals['password'] = vals['password_2']
			vals['new_password'] = vals['new_password_2']
			vals['nr_importador'] = '2'
			vals['saved_2'] = True
			self._change(cr, uid, [id], {'user_importador_2_id': model.create(cr, uid, vals, context=context)})
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		model = self.pool.get('res.users')

		for oid in self.browse(cr,uid,ids):
			vals['director_id'] = ids[0]
			vals['is_director'] = True
			vals['name'] = oid.name
			vals['active'] = oid.active
			if oid.importador_1_id and oid.importador_2_id and oid.importador_1_id == oid.importador_2_id:		
				error(action,'Os importadores devem ser diferentes!')

			oid_1 = model.search(cr, uid,  [('director_id','=',oid.id),('nr_importador','=','1')])
			oid_2 = model.search(cr, uid,  [('director_id','=',oid.id),('nr_importador','=','2')])
			if not oid.user_importador_1_id and 'login_1' in vals and 'new_password_1' in vals:
				vals['login'] = vals['login_1']
				vals['password'] = oid.password_1
				vals['new_password'] = vals['new_password_1']
				vals['nr_importador'] = '1'
				vals['saved_1'] = True
				vals['user_importador_1_id'] = model.create(cr, uid, vals, context=context)

			if not oid.user_importador_2_id and  'login_2' in vals and 'new_password_2' in vals:
				vals['login'] = vals['login_2']
				vals['password'] = oid.password_2
				vals['new_password'] = vals['new_password_2']
				vals['nr_importador'] = '2'
				vals['saved_2'] = True
				vals['user_importador_2_id'] = model.create(cr, uid, vals, context=context)

			uids = model.search(cr,uid,[('director_id','=',ids[0])])
			model.write(cr, uid, uids, {'name': oid.name,'active': oid.active}, context=context)
		return super(dotcom_director_tecnico, self).write(cr, uid, ids, vals, context=context)

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {} 
		model = self.pool.get('res.users')
		if model.search(cr,uid,[('director_id','=',ids[0])]):
			error(action,'Não é possível eliminar. Este director possue usuarios.')
		return super(dotcom_director_tecnico, self).unlink(cr, uid, ids, context=context)
dotcom_director_tecnico()	