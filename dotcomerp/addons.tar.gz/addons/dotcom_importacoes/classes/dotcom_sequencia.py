# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
import decimal_precision as dp
logger = logging.getLogger('DOTCOM_LOGGS') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)


def _codigo_get(self, cr, uid, context=None):
	cr.execute('select codigo, name from dotcom_sequencia_tipo')
	return cr.fetchall()

class dotcom_sequencia_tipo(osv.osv):
	_name = 'dotcom.sequencia.tipo'
	_order = 'name'
	_columns = {
		'name': fields.char('Nome', size=64, required=True,readonly=True,),
		'codigo': fields.char('codigo', size=32, required=True,readonly=True,),
		'activo': fields.boolean('Activo',readonly=True,),
	}
	_defaults = {'activo': True,}
	_sql_constraints = [('codigo_unique', 'unique(codigo)', '`codigo` must be unique.'),]

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		if True:
			error('Acção Inválida!','Não é possível eliminar esta linha.')
		return super(dotcom_sequencia_tipo, self).unlink(cr, uid, [], context=context)
dotcom_sequencia_tipo()

class dotcom_sequencia_serie(osv.osv):
	_name = "dotcom.sequencia.serie"
	_description = "Séries para sequencias"
	_columns = {
				'ref':fields.char('Reference',size=32,required=True,readonly=True,),
				'name':fields.char('Name',size=250,required=True,readonly=False,),
				'editavel': fields.boolean('Activo',readonly=True,),
				}
	_defaults = {
		'editavel': True,
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'SES', 'dotcom.sequencia.serie', context=c),
		}
	_order = 'ref desc'
	_rec_name = 'ref'
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma Series com esta referência!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'SES', 'dotcom.sequencia.serie', context,True)
		id = super(dotcom_sequencia_serie, self).create(cr, uid, vals, context=context)
		return id
	
	# def get_serie_id(self, cr, uid, serie_id, context=None):
	# 	if context is None: context = {}
	# 	if serie_id:
	# 		serie_id = self.browse(cr,uid,serie_id, context=context)
	# 	return serie_id

	def get_name(self, cr, uid, serie_id, context=None):
		if context is None:
			context = {}
		if serie_id:
			ano = self.browse(cr,uid,serie_id, context=context).ref
			return ano
		else:
			return False
	
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			if document.editavel == False:
				error('Acção Inválida!','Não é possível eliminar esta Séries.')

		# to_delete = []
		# for id in ids:
		# 	vals = self.pool.get('dotcom.sequencia').search(cr,uid,[('serie_id','=',id)])
		# 	if vals and len(vals)>0:
		# 		raise osv.except_osv(_('Invalid action !'), _('The selected serie is already referenced by a sequencia! '))
		# 	else:
		# 		to_delete.append(id)
		return super(dotcom_sequencia_serie, self).unlink(cr, uid, ids, context=context)
	
dotcom_sequencia_serie()

def _add_digitos(digitos,numero):
	str_nr = str(numero)
	while(len(str_nr) < digitos):
		str_nr = ('0'+str_nr)
	return str_nr

class dotcom_sequencia_gerar_linha(osv.osv):
	_name = 'dotcom.sequencia.gerar.linha'
	_columns = {
		'name': fields.char('Nome', size=64, required=True,readonly=True,),
		'parent_id': fields.many2one('dotcom.sequencia.gerar', 'parent_id', readonly=True,),
		'codigo': fields.char('codigo', size=32, required=True,readonly=True,),
		'activo': fields.boolean('Activo',readonly=True,),
	}
dotcom_sequencia_gerar_linha()

class dotcom_sequencia_gerar(osv.osv):

	def _company_get(self, cr, uid, context=None):
		u_id = self.pool.get('res.users').browse(cr, uid, uid, context=context)
		return (u_id.company_id and u_id.company_id.id) or False

	_name = 'dotcom.sequencia.gerar'
	_order = 'ano_id'
	_columns = {
		'ano_id': fields.many2one('configuration.fiscalyear', 'Ano Fiscal', readonly=False,),
		'tipo_ids': fields.one2many('dotcom.sequencia.gerar.linha','parent_id','Linhas', readonly=True),
		'state': fields.selection([('rascunho','Rascunho'),('emitido','Emitido'),],'Estado', select=True, readonly=True,),
	}
	_rec_name = 'ano_id'
	_defaults = {'state':'rascunho','ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),}
	# _sql_constraints = [('codigo_unique', 'unique(codigo)', '`codigo` must be unique.'),]
	
	def processar(self, cr, uid, ids, context=None):
		if context is None: context = {}
		seq_model = self.pool.get('dotcom.sequencia')
		linha_model = self.pool.get('dotcom.sequencia.gerar.linha')
		tipo_model = self.pool.get('dotcom.sequencia.tipo')
		
		res = []		
		for oid in self.browse(cr,uid,ids):
			seq_ids = seq_model.search(cr, uid, [('ano_id','=',oid.ano_id.id)])
			tipo_ids = tipo_model.search(cr, uid, [])
			msg('len(seq_ids): %s,    len(tipo_ids): %s,    '%(len(seq_ids),len(tipo_ids)))
			if seq_ids and len(seq_ids) == len(tipo_ids):
				error('Acção Inválida!','Já existem Sequenências para o Ano Fiscal de %s.'%oid.ano_id.name)

			tipo_ids = tipo_model.browse(cr,uid,tipo_ids)
			for tipo_id in tipo_ids:
				vals = {
					'codigo': tipo_id.codigo,
					'objecto': tipo_id.codigo,
					'activo': True,
					'em_uso': True,
					'digitos': 6,
					'proximo_nr': 0,
					'incremento_nr': 1,
					'company_id': self._company_get(cr,uid,None),
					'ano_id': oid.ano_id.id,
					'serie': 'DNF',
					'name': seq_model._name_get(cr,uid, [], tipo_id.codigo, 'DNF', oid.ano_id.id,None),
				}
				seq_id = seq_model.create(cr,uid,vals)
				vals['parent_id'] = ids[0]
				linha_model.create(cr,uid,vals)
				res.append(seq_id)
			if res: self.write(cr,uid,ids,{'state':'emitido'})
		return res

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_sequencia_gerar, self).unlink(cr, uid, ids, context=context)
		
	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		id = super(dotcom_sequencia_gerar, self).create(cr, uid, vals, context=context)
		# self.processar(cr, uid,[id],context)
		return id
dotcom_sequencia_gerar()

class dotcom_sequencia(osv.osv):

	# def get_company_id(self, cr, uid, context=None):
	# 	user_id = self.pool.get('res.users').browse(cr, uid, uid)
	# 	if user_id.company_id: return user_id.company_id.id
	# 	return False



	def _company_get(self, cr, uid, context=None):
		u_id = self.pool.get('res.users').browse(cr, uid, uid, context=context)
		return (u_id.company_id and u_id.company_id.id) or False

	def _proximo_nr_get(self, cr, uid, ids, context=None):
		msg('sequencia._proximo_nr_get: %s)'%ids)
		if context is None: context = {}
		proximo_nr = 1
		for oid in self.browse(cr,uid,ids):
			proximo_nr = oid.proximo_nr + 1
		return proximo_nr

	def _proximo_codigo_get(self, cr, uid, ids, digitos, context=None):
		if context is None: context = {}
		proximo_nr = self._proximo_nr_get(cr,uid,ids,context)
		return _add_digitos(digitos,proximo_nr)

	_name = 'dotcom.sequencia'
	_description = 'Sequência'
	_columns = {
		'name': fields.char('Nome', size=120, required=True, readonly=True,),
		'codigo': fields.char('Código', size=120, readonly=True, required=False),
		'serie': fields.char('Série', size=16, readonly=True, required=True),
		'proximo_codigo': fields.char('Próximo Código', size=120, readonly=True, required=False),
		'objecto': fields.selection(_codigo_get, 'Objecto', size=64),
		'activo': fields.boolean('Activo', readonly=True,),
		'em_uso': fields.boolean('Em Uso', readonly=True,),
		'digitos' : fields.integer('Nº de Digitos', required=True, help="OpenERP will automatically adds some '0' on the left of the 'Next Number' to get the required padding size."),
		'proximo_nr': fields.integer('Próximo  Número',readonly=True, required=True, help="Next number of this sequencia"),
		'incremento_nr': fields.integer('Incremento', readonly=True, help="The next number of the sequencia will be incremented by this number"),
		'company_id': fields.many2one('res.company', 'Empresa', readonly=True,),
		'ano_id': fields.many2one('configuration.fiscalyear', 'Ano Fiscal',readonly=True, states={'rascunho':[('readonly',False)]}),
		# 'serie_id': fields.many2one('dotcom.sequencia.serie','Série',required=True),
	}
	_rec_name = 'proximo_codigo'
	_defaults = {
		# 'state': 'rascunho',
		'serie': 'DNF',
		'em_uso': True,
		'activo': True,
		'incremento_nr': 1,
		'proximo_nr': lambda self, cr, uid, c: self.pool.get('dotcom.sequencia')._proximo_nr_get(cr, uid,[],c),
		'proximo_codigo': lambda self, cr, uid, c: self.pool.get('dotcom.sequencia')._proximo_codigo_get(cr, uid,[],5,c),
		'digitos': 5,
		'company_id': _company_get,
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
	 }

	_sql_constraints = [('name_unique', 'unique(name)', 'Já existe uma Sequenência com este nome!')]

	def _nr_get(self, cr, uid, codigo, campo, context=None,save=False):
		seq_model = self.pool.get('dotcom.sequencia')
		ano_model = self.pool.get('configuration.fiscalyear')
		# campo = ['name','full','proximo_codigo']
		ano_id = ano_model.find(cr, uid),
		query =  [('codigo','=',codigo),('ano_id','=',ano_id)]
		oid = seq_model.search(cr, uid,query)
		nr = False
		msg('sequencia._nr_get(cod: %s, query: %s, oid: %s)'%(codigo,query,oid))
		res = {'name': False,'full': False,'proximo_codigo': False,}
		if oid:
			oid = seq_model.browse(cr, uid, oid[0], context=None)
			nr = seq_model._get_full_next_cod(cr,uid,[oid.id],oid.digitos,oid.name,context) or False
			res = {'name': oid.name or False, 'full': nr, 'proximo_codigo': oid.proximo_codigo or False,}
			if save:
				vals = {
					'proximo_nr': self._proximo_nr_get(cr, uid,[oid.id],context),
					'proximo_codigo': self._proximo_codigo_get(cr,uid,[oid.id],oid.digitos,context),
				}
				msg('sequencia._nr_get.vals: %s'%vals)
				seq_model.write(cr,uid,[oid.id],vals)
		if not res[campo]: error(action,'Configure a Sequenência para este Documento.')
		return res[campo]

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('sequencia.on_ch_%s: %s'%(descricao,valor))
		if context is None: context = {}
		if descricao:
			if descricao == 'objecto':
				return {'value': {'codigo': valor,}}

	def on_ch_nexcod(self, cr, uid, ids, digitos, name, context=None):
		msg('sequencia.on_ch_nexcod(digitos: %s, name: %s)'%( digitos, name,))
		if context is None: context = {}
		next_cod = self._proximo_codigo_get(cr,uid,ids,digitos,context)
		if name and next_cod:
			next_cod = (name+'/'+next_cod)
		return {'value': {'proximo_codigo': next_cod,}}

	def _get_full_next_cod(self, cr, uid, ids, digitos, name, context=None):
		if context is None: context = {}
		next_cod = self._proximo_codigo_get(cr,uid,ids,digitos,context)
		next_cod = (name+'/'+next_cod)
		return next_cod

	def on_ch_name(self, cr, uid, ids, codigo, serie, ano_id, context=None):
		msg('sequencia.on_ch_name(codigo: %s, serie: %s, ano_id: %s)'%(codigo, serie, ano_id))
		if context is None: context = {}
		ano_model = self.pool.get('configuration.fiscalyear')
		serie_model = self.pool.get('dotcom.sequencia.serie')

		if codigo and serie and ano_id:
			ano = ano_model.get_ano(cr,uid, ano_id)
			# serie_id = serie_model.get_serie_id(cr,uid, serie_id)
			name = codigo + '/' + serie + '/' +ano
			return {'value': {'name': name,}}
		return {'value': {'name': False,}}

	def _name_get(self, cr, uid, ids, codigo, serie, ano_id, context=None):
		msg('sequencia._name_get(codigo: %s, serie: %s, ano_id: %s)'%(codigo, serie, ano_id))
		if context is None: context = {}
		ano_model = self.pool.get('configuration.fiscalyear')
		serie_model = self.pool.get('dotcom.sequencia.serie')
		name = ''
		if codigo and serie and ano_id:
			ano = ano_model.get_ano(cr,uid, ano_id)
			# serie_id = serie_model.get_serie_id(cr,uid, serie_id)
			# name = codigo + '/' + serie + '/' +ano
			name = codigo + '/' +ano
		return name

	# def copy(self, cr, uid, id, default=None, context=None):
	# 	if default is None: default = {}
	# 	vals = {}
	# 	for oid in self.browse(cr,uid,ids):
	# 		vals = {
	# 			'name': (oid.xxxx+' - copy'),
	# 			'codigo': (oid.xxxx+' - copy'),
	# 			'objecto': oid.xxxxxx,
	# 			'activo': oid.xxxxxx,
	# 			'em_uso': oid.xxxxxx,
	# 			'digitos': oid.xxxxxx,
	# 			'proximo_nr': oid.xxxxxx,
	# 			'incremento_nr': oid.xxxxxx,
	# 			'company_id': oid.xxxxxx,
	# 			'ano_id': oid.xxxxxx,
	# 			'serie': oid.xxxxxx,
	# 		}
	# 	return super(dotcom_sequencia, self).copy(cr, uid, id, vals, context)

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}

		codigo = vals['objecto'] or False
		msg('sequencia.create 1: %s'%vals)
		ano_id = vals['ano_id'] or False
		if  vals and 'name' not in vals:
			vals['serie'] = 'DNF'
			vals['name'] = self._name_get(cr,uid, [], codigo, vals['serie'], ano_id,context)
			vals['codigo'] = codigo
			# vals['proximo_codigo'] = self._proximo_codigo_get(cr,uid,[],vals['digitos'],context)
			# vals['proximo_codigo'] = self._get_full_next_cod(cr,uid,[],vals['digitos'],vals['name'],context)
		msg('sequencia.create 2: %s'%vals)
		
		id = self.search(cr, uid, [('name','=',vals['name'])])
		if not id:
			id = [super(dotcom_sequencia, self).create(cr, uid, vals, context=context)]
		return id[0]
	
	def write(self, cr, uid, ids, vals, context=None):
		msg('sequencia.write: %s'%vals)
		if context is None: context = {}
		return super(dotcom_sequencia, self).write(cr, uid, ids, vals, context=context)
dotcom_sequencia()	












class gen_ref(osv.osv):
	_name = 'gen.ref'
	_order = 'name'
	_columns = {
			'ref': fields.char('Ref', size=64, readonly=True),
			'name': fields.char('Classe Name', size=256, readonly=True),
			'numero': fields.integer('Nº', readonly=True),
			}

	def next_ref(self, cr, uid, digitos, prefix, class_name, context=None, save=False):
		ids = self.search(cr,uid,[('name','=',class_name)])
		numero = 1
		ref = ('%s/%s'%(prefix,_add_digitos(digitos, numero)))
		vals = {'ref': ref, 'name': class_name, 'numero': numero}
		for oid in self.browse(cr,uid,ids):
			ref = ('%s/%s'%(prefix,_add_digitos(digitos, oid.numero+1)))
			vals = {'ref': ref, 'name': class_name, 'numero': oid.numero+1}

		model = self.pool.get(class_name)
		# model_ids = model.browse(cr,uid,model.search(cr,uid,[('ref','=',ref)]))
		model_ids = model.search(cr,uid,[('ref','=',ref)])
		model_all_ids = model.search(cr,uid,[])
		if model_ids:
			numero = ((model_all_ids and max(model_all_ids)) or 0) + 1
			ref = ('%s/%s'%(prefix,_add_digitos(digitos, numero)))
			vals = {'ref': ref, 'name': class_name, 'numero': numero}
		if save:
			msg('[%s].next_ref: %s'% (class_name,ref))
			if not ids:
				self.create(cr, uid, vals, context)
			else:
				self.write(cr, uid, ids, vals, context)
		return ref
gen_ref()
