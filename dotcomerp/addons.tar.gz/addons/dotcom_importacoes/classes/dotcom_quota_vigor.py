# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

REF = ''
class dotcom_quotas_vigor(osv.osv):

	def get_diferenca(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for oid in self.browse(cr, uid, ids, context):
			res[oid.id] = oid.quota - oid.quota_importada
		return res

	def get_quota_importada_perc(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for oid in self.browse(cr, uid, ids, context):
			perc = 0
			if oid.quota_importada == 0:
				perc = 0
			else:
				perc = (100*oid.quota_importada)/oid.quota
			res[oid.id] = perc
		return res

	def _get_full_name(self, cr, uid, ids, name, args, context):
		res = {}
		for oid in self.browse(cr, uid, ids, context):
			prefix = 'QVIG/%s'%(oid.ano_id.name)
			self.REF = self.pool.get('gen.ref').next_ref(cr, uid, 6, prefix, 'dotcom.quotas.vigor', context,True)
			res[oid.id] = self.REF
		return self.REF #res

	def _get_ref(self, cr, uid, ids, context):
		for oid in self.browse(cr, uid, ids, context):
			prefix = 'QVIG/%s'%(oid.ano_id.name)
		return self.pool.get('gen.ref').next_ref(cr, uid, 6, prefix, 'dotcom.quotas.vigor', context,True)

	_name = 'dotcom.quotas.vigor'
	_description = 'Quotas em Vigor'
	_columns = {	
		# 'ref': fields.function(_get_full_name, string='Nome', type='char', size=128, readonly=True),
		'ref': fields.char('Nome', size=120, required=False, readonly=True),
		'ref_prod': fields.char('Ref Prod', size=120, required=True, readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=False, readonly=True, domain="[('subs_controlada','=',True)]"),
		'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo', readonly=True,),
		
		'quota': fields.float('Quota Total', required=False, readonly=True),
		'quota_importada': fields.float('Quota Importada', required=False, readonly=True),
		'quota_importada_perc': fields.function(get_quota_importada_perc, method=True, string='Importado', type='float'),
		'diferenca': fields.function(get_diferenca, method=True, string='Quota Actual', type='float', help='Quota Actual = "Quota Total" - "Quotas Libertadas"'),
		'quota_bief_aprovadas': fields.float('Quota BIEFs Aprovados', required=False, readonly=True),

		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False,readonly=True,),
		# 'period_id': fields.many2one('configuration.period','Período', required=False, readonly=True,),
		# 'data': fields.date('Data da Emissão', required=False, readonly=True),
		'em_vigor': fields.boolean('Em Vigor', readonly=True),

		'data_bief': fields.date('Ultima Data do Movimento do BIEF',help="Ultima Data do Movimento do BIEF"),
		'data_actualizacao': fields.date('Ultima Data do Movimento da Actualização',help="Ultima Data do Movimento da Actualização"),

		'historico_ids': fields.one2many('dotcom.quotas.historico','parent_id','Histórico', readonly=True,),
	}
	_rec_name = 'ref'
	_defaults = {
		# 'data': lambda *a: time.strftime('%Y-%m-%d'),
		'data_bief': False,
		'data_actualizacao': False,
		'quota_importada': 0,
		'quota_bief_aprovadas': 0,
	 }	
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma Quota em Vigor com a referência "%s"!'%REF)]


	def _change(self, cr, uid, ids, vals, context=None):
		msg('vigor._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}
		
	def on_ch_2(self, cr, uid, ids, valor_a, descricao_a, valor_b, descricao_b, context=None):
		msg('bief.on_ch_2(%s=%s), (%s=%s)'%(descricao_a,valor_a,descricao_b,valor_b))
		if context is None: context = {}
		vals = {}
		if descricao_a == 'quota' and descricao_b == 'diferenca':
			vals = {'quota':valor_a,'diferenca':valor_b,'quota_importada_perc':valor_b,}
		return self._change(cr, uid, ids, vals)

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		msg('vigor.create: %s'%(vals))
		id = super(dotcom_quotas_vigor, self).create(cr, uid, vals, context)
		vals = {'ref': self._get_ref(cr, uid, [id], context)}
		self.write(cr, uid,[id],vals)
		return id
	
	# def write(self, cr, uid, ids, vals, context=None):
	# 	if context is None: context = {}
	# 	if not isinstance(ids, (list, tuple)): ids = [ids]
	# 	for document in self.browse(cr,uid,ids):
	# 		vals['diferenca'] = 
	# 	return super(dotcom_quotas_vigor, self).write(cr, uid, ids, vals, context=context)

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.quota_bief_aprovadas > 0 or document.quota_importada > 0 or document.diferenca != document.quota:
				error('Acção Inválida!','Esta quota ja tem movimentos')
		error('Acção Inválida!','Impossivel eliminar!')
		return super(dotcom_quotas_vigor, self).unlink(cr, uid, ids, context=context)
dotcom_quotas_vigor()	


class dotcom_quotas_historico(osv.osv):
	_name = 'dotcom.quotas.historico'
	_description = 'Histórico das quotas'
	#_rec_name = 'name'
	_columns = {
		'name': fields.char('Nome', size=9, required=False, readonly=True),
		'parent_id': fields.many2one('dotcom.quotas.vigor','Parente', readonly=True),
		'act_linha_id': fields.many2one('dotcom.quotas.linha','Linha da Actualização', readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Produto', readonly=True),
		'processo': fields.selection([('adenda','Adenda'),('renovacao','Renovação')],'Processo', readonly=True,),

		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True,readonly=False,),
		'period_id': fields.many2one('configuration.period','Período', required=True, readonly=False,),
		'data': fields.date('Data da Emissão', required=False, readonly=True),

		'quota': fields.float('Quota', required=True, readonly=True),
		'em_vigor': fields.boolean('Em Vigor', readonly=True),
	}
	_rec_name = 'data'
	_defaults = {
		'quota': 0,
		# 'data': lambda *a: time.strftime('%Y-%m-%d'),
	}
dotcom_quotas_historico()