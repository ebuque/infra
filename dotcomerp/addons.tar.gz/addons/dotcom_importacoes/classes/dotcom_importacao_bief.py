# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
# from dotcom_importacoes import dotcom_registo_movimentos as rm
logger = logging.getLogger('DOTCOM') 

# Timedelta aceita os seguintes parâmetros:
# days
# seconds
# microseconds
# milliseconds
# minutes
# hours
# weeks


action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_importacao_bief(osv.osv): 

	def pattern(self,cr,uid,valor):
		return self.pool.get('decimal.precision').get_decimal_precision(cr,uid,valor)

	def get_director_id_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id:
			res = u_id.director_id.id
		msg('get_director_id_bay_uid: %s'%res)
		return res

	def get_is_director_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id: res = True
		msg('get_is_director_bay_uid: %s'%res)
		return res

	def get_importador_id_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id: res = u_id.director_id.importador_id.id
		msg('get_importador_id_bay_uid: %s'%res)
		return res

	def get_perc_libertado(self, cr, uid, ids, name, arg, context=None):
		res = {}
		linha_model = self.pool.get('dotcom.bief.linha')
		for oid in self.browse(cr, uid, ids, context=context):
			progress = 0
			total_linhas = len(oid.linha_ids)
			libertado_ids = len(linha_model.search(cr,uid,[('libertado','=',True),('parent_id','=',ids[0])]))
			if libertado_ids == 0:
				progress = 0
			else:
				progress = (libertado_ids*100)/total_linhas
			res[oid.id] = progress
		return res

	_name = 'dotcom.importacao.bief'
	_description = 'Registo de BIEFs'
	#_rec_name = 'name'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, readonly=True),
		'vref': fields.char('V/Ref', size=120, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, help='Vossa Referência.'),
		'data_emissao': fields.date('Data da Emissão', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'period_id': fields.many2one('configuration.period','Período', readonly=True,),
		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True),
		'prazo': fields.selection([('anual','Anual'),('semestral','Semestral'),('mensal','Mensal'),],'Prazo', required=True,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data_vencimento': fields.date('Data de Vencimento', required=False, readonly=True),
		# 'data_libertacao': fields.date('Data de Libertação', required=False, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True,readonly=True, ),
		
		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=True, domain="[('activo','=',True),]",readonly=False,),
		'endereco_import': fields.char('Endereço', size=120, required=False, readonly=True),
		'nuit_import': fields.char('NUIT', size=120, required=False, readonly=True),

		'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', required=True, domain="[('activo','=',True),]",readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'pro_forma': fields.char('Pro-Forma', size=120, required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),	
		
		'director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico',domain="['|',('importador_1_id','=',importador_id),('importador_2_id','=',importador_id),('active','=',True),]",readonly=False,),
		'director_cpf': fields.char('CPF Nº', size=120, required=False,readonly=True,),
		'is_director': fields.boolean('Is Director', readonly=True,),
		'user_id': fields.many2one('res.users','User',readonly=True,),
		
		'concurso_id': fields.many2one('dotcom.lancamento.concurso','Concurso', required=False, readonly=True, domain="[('importador_id','=',importador_id),('state','=','aprovado'),('ano_id','=',ano_id)]", states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'tipo_bief': fields.selection([
			('imes','Importação Especial'),
			('snsc','Serviço Nacional de Saúde - Concurso'),
			('snsd','Serviço Nacional de Saúde - Doação'),
			('lnme','Lista Nacional de Medicamentos Essenciais'),
			('extra','Extra Lista'),
			('prosa','Produtos de Saúde'),
			],'Tipo BIEF', required=True,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'state': fields.selection([
			('rascunho','Rascunho'),
			('submetido','Submetido'),
			('validar','Validar'),
			('validado','Validado'),
			('aprovado','Aprovado'),
			('rejeitado','Rejeitado'),
			('cancelado','Cancelado'),
			('rascunho_2','Rascunho'),
			],'Estado', select=True, readonly=True,
			help=' * \'Rascunho\' indica que o documento não foi confirmado. \
			\n* \'Submetido\' Submetido... \
			\n* \'Validar\' Validar... \
			\n* \'Validado\' Validado... \
			\n* \'Aprovado\' Aprovado... \
			\n* \'Cancelado\' Cancelado...'),

		'moeda_id': fields.many2one('res.currency','Moeda',readonly=True, required=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'moeda_str' : fields.char('Moeda',size=60,readonly=True),
		'cambio': fields.float('Câmbio do Processo', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_moeda': fields.float('Total Moeda', readonly=True,),

		'moeda_principal_id': fields.many2one('res.currency', 'Moeda Principal', readonly=True),
		'cambio_principal': fields.float('Câmbio Principal',required=False,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_principal': fields.float('Total Principal', readonly=True,),

		'moeda_secundaria_id': fields.many2one('res.currency', 'Moeda Secundária', readonly=True),
		'cambio_secundario': fields.float('Cambio Secundário', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_secundario': fields.float('Total Secundário', readonly=True,),
		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'linha_ids': fields.one2many('dotcom.bief.linha','parent_id','Linhas', readonly=False,),
		'libertacao_ids': fields.one2many('dotcom.importacao.liberacao','bief_id','Libertações', readonly=True,),
		'bief_cambio_ids': fields.one2many('dotcom.bief.cambio','parent_id','Cambios', readonly=True,),
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','bief_id','Cancelamentos', readonly=True,),
		'movimento_ids': fields.one2many('reg.mov','bief_id','Movimentos', readonly=True,),

		'quant': fields.float('Total(QTD)', readonly=True),
		'preco': fields.float('Total(Preço)', readonly=True), 
		'total': fields.float('Total(Linhas)', readonly=True),
		'perc_libertada': fields.function(get_perc_libertado, method=True, string='Percentagem Libertada', type='float'),
		'libertado': fields.boolean('Libertado', readonly=True,),
		'from_historico': fields.boolean('Histórico', readonly=True,help="Vem do Histórico"),
		'historico_id': fields.many2one('dotcom.historico.bief','Histórico',readonly=True,),

		'from_certif': fields.boolean('Carregar Do Certificado', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, help="Carregar Substancias Controladas do Certificado"),
		'certificado_id': fields.many2one('dotcom.quotas.certificado','Certificado',readonly=True, domain="[('importador_id','=',importador_id),('activo','=',True),('libertado','=',False)]",),

		'por_terc': fields.boolean('BIEF por terceirização', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, help="Ao activar esta função, possibilita que um importador consigua importar nomes comerciais de outro importador."),
		'importador_terc_id': fields.many2one('dotcom.parceiro.importador','Importador Terceirizado', required=False, domain="[('activo','=',True),]", readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]},),

		'anexo_1': fields.binary('1º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_1_name' : fields.char('1º Anexo Name',size=255),
		'anexo_2': fields.binary('2º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_2_name' : fields.char('2º Anexo Name',size=255),
		'anexo_3': fields.binary('3º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_3_name' : fields.char('3º Anexo Name',size=255),
	}
	_rec_name = 'doc_numero'
	# Configuração Contas Bancárias Notificações Contracto de Adesão Contabilidade
	_defaults = {
		'cambio': 1,
		'libertado': False,
		'director_id': get_director_id_bay_uid,		
		'is_director': get_is_director_bay_uid,
		'importador_id': get_importador_id_bay_uid,
		'cambio_principal': 1,
		'state': 'rascunho',
		# 'tipo_bief': 'snsd',
		'prazo': 'anual',
		# 'doc_numero':  lambda self, cr, uid, c: self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'BIEF','full',c),
		'data_emissao': lambda *a: time.strftime('%Y-%m-%d'),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
		'moeda_str': 'MT',
		'moeda_principal_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.importacao.bief', context=c),
		'moeda_secundaria_id': lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.importacao.bief', context=c),
	}
	
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já foi criado uma BIEF com esta referência!')]

	def start_report(self, cr, uid,ids, context={}):
		msg('bief.start_report ids: %s'%ids)
		data = self.read(cr,uid,ids,)[-1]
		msg('data: %s'%data)
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_bief',
			'datas':{
					'model':'dotcom.importacao.bief',
					'id':ids[0],
					'ids':ids,
					'report_type':'pdf',
					'form':data
			},
			'nodestroy':False,
		}

	def on_change_cambio(self, cr, uid, ids, moeda_secundaria, cambio_secundario, contravalor, contravalor_moeda, contravalor_cambio, moeda2=False, cambio2=False, moeda1=False, cambio1=False,context=None):
		vals = {}
		if context is None:
			context = {}
			
		if moeda1 == moeda_secundaria:
			vals['cambio_secundario'] = cambio1
		if moeda1 == moeda2:
			vals['cambio'] = cambio2
		if contravalor:
			if moeda_secundaria == contravalor_moeda:
				vals['alternative_currency_value'] = cambio_secundario
			elif moeda2 == contravalor_moeda:
				vals['alternative_currency_value'] = cambio2
			elif moeda1 == contravalor_moeda:
				vals['alternative_currency_value'] = cambio1
			# else:
				# vals['alternative_currency_value'] = self.pool.get('res.currency').browse(cr, uid, contravalor_moeda).rate or 0.0
		return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('bief._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('bief.on_ch_ %s valor: %s'%(descricao,valor))
		import_model = self.pool.get('dotcom.parceiro.importador')
		dir_model = self.pool.get('dotcom.director.tecnico')
		if context is None: context = {}

		vals = {}
		if descricao in ['moeda_id','moeda_principal_id','moeda_secundaria_id',]:
			oid = self.pool.get('res.currency').browse(cr,uid,valor)
			cambio, name, vals = 1, '', {}
			name = oid.name			
			if oid and oid.base is not True: cambio = self.pattern(cr,uid,oid.rate)
			if descricao == 'moeda_id':
				if oid: vals = {'moeda_str': name,'cambio': cambio}
				else: vals = {'moeda_str': name,'cambio': cambio}
			if descricao == 'moeda_principal_id': 
				if oid: vals = {'cambio_principal': cambio}
				else: vals = {'cambio_principal': 0}
			if descricao == 'moeda_secundaria_id': 
				if oid: vals = {'cambio_secundario': cambio}
				else: vals = {'cambio_secundario': 0}
			return self._change(cr, uid, ids, vals)
		elif descricao == 'tipo_bief' and not valor:
			return self._change(cr, uid, ids, {'tipo_bief': 'snsd',})

		elif descricao == 'importador_id':
			if not valor: vals = {'nuit_import': '','endereco_import': '','director_id': False,}
			if valor:
				oid = import_model.browse(cr,uid,valor)
				vals = {'nuit_import': oid.nuit,'endereco_import': oid.endereco,}	#'director_id': False,		
			return self._change(cr, uid, ids, vals)

		elif descricao == 'director_id':
			if not valor: vals = {'director_cpf': '',}
			if valor:
				oid = dir_model.browse(cr,uid,valor)
				vals = {'director_cpf': oid.cpf,}	
		elif descricao == 'data_emissao':
			vals = {
				'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
				'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
				}
		elif descricao == 'from_certif' and not valor:
			vals = {'certificado_id': False}
		return self._change(cr, uid, ids, vals)

	def on_ch_2(self, cr, uid, ids, valor_a, descricao_a, valor_b, descricao_b, context=None):
		msg('bief.on_ch_2(%s=%s), (%s=%s)'%(descricao_a,valor_a,descricao_b,valor_b))
		if context is None: context = {}

		vals = {}
		if descricao_a == 'data_emissao' and descricao_b == 'prazo':
			if not valor_a:
				valor_a = datetime.datetime.now().strftime('%Y-%m-%d')#datetime.strptime(data, '%Y-%m-%d')
				vals['data_emissao'] = valor_a
			valor_a = datetime.strptime(valor_a, '%Y-%m-%d')
			vals['period_id'] = self.pool.get('get.aux').get_period_id(cr, uid,valor_a)
			vals['ano_id'] = self.pool.get('get.aux').get_ano_id(cr, uid,valor_a)
			data_vencimento = False
			if valor_b == 'anual': data_vencimento = str((valor_a + timedelta(365)).strftime('%Y-%m-%d'))
			if valor_b == 'semestral': data_vencimento = str((valor_a + timedelta(182)).strftime('%Y-%m-%d'))
			if valor_b == 'mensal': data_vencimento = str((valor_a + timedelta(30)).strftime('%Y-%m-%d'))
			if not valor_b: data_vencimento = False
			vals['data_vencimento'] = data_vencimento
			msg('data_vencimento: %s'%(data_vencimento))
		return self._change(cr, uid, ids, vals)

	def validar_certificado(self, cr, uid,ids,context=None):
		if context is None: context = {}
		certificado_model = self.pool.get('dotcom.quotas.certificado')
		certificado_linha_model = self.pool.get('dotcom.certificado.linha')
		for document in self.browse(cr,uid,ids):
			if document.from_certif and not document.certificado_id: error(action,'Seleccione um Certificado!')
			if document.certificado_id:
				if not document.certificado_id.activo: error(action,'O Certificado Expirou!')
				
				err_subs_controlada, err_src, err_qtd = '','',''
				for linha_id in document.linha_ids:
					if not linha_id.prod_id.subs_controlada: err_subs_controlada += ('#:%s, '%linha_id.numerador)
					query = [('prod_id','=',linha_id.prod_id.id),('comercial_name_id','=',linha_id.comercial_name_id.id),('parent_id','=',document.certificado_id.id)]
					src = certificado_linha_model.search(cr,uid,query)
					if not src: err_src += ('#:%s, '%linha_id.numerador)
					if src:
						src = certificado_linha_model.browse(cr,uid,src[0])
						if src.quant != linha_id.quant: err_qtd += ('#:%s x #:%s, '%(linha_id.numerador,src.numerador))
				if len(err_subs_controlada) > 0: error(action,'O/s produto/s %s não é/são Substancias Controladas.'%(err_subs_controlada))
				if len(err_src) > 0: error(action,'Produtos %s não encontrados no Certificado informado.'%(err_src))
				if len(err_qtd) > 0: error(action,'Quantidade incompactivel nos produtos(BIEF x Certificado)\n%s'%(err_qtd))
			else:
				err_certificado = ''
				for linha_id in document.linha_ids:
					if linha_id.prod_id.subs_controlada: err_certificado += ('#:%s, '%linha_id.numerador)
				if len(err_certificado) > 0: error(action,'Informe o Certificado para os produtos %s'%(err_certificado))

	def carregar_certificado(self, cr, uid,ids,context=None):
		if context is None: context = {}
		linha_model = self.pool.get('dotcom.bief.linha')
		for document in self.browse(cr,uid,ids):
			if not document.certificado_id: error(action,'Seleccione um Certificado')
			for linha_id in document.linha_ids:
				linha_model.unlink(cr,uid,[linha_id.id])
			for linha_id in document.certificado_id.linha_ids:
				vals = {
					'parent_id': ids[0],
					'prod_id': linha_id.prod_id.id,
					'comercial_name_id': linha_id.comercial_name_id.id,
					'quant': linha_id.quant,
					}
				linha_model.create(cr,uid,vals)

	def calcular(self, cr, uid,ids,context=None):
		msg('bief.calcular ids: %s'%ids)
		linha_model = self.pool.get('dotcom.bief.linha')

		self.validar(cr,uid,ids,context)
		quant,preco,total = 0,0,0
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model.on_ch_a_b(cr,uid,[linha_id.id], linha_id.quant, linha_id.preco, 'quant', 'quant_preco')
				quant += linha_id.quant
				preco += linha_id.preco
				total += (linha_id.quant * linha_id.preco)
			vals = {'quant':quant, 'preco':preco, 'total':total}
			return self._change(cr, uid, ids, vals)

	def get_query(self, cr, uid,linha_id,parent_id):
		query = []
		if linha_id:
			query = [ 
				('parent_id','=', parent_id),
				('prod_id','=', linha_id.prod_id.id),
				('comercial_name_id','=', linha_id.comercial_name_id and linha_id.comercial_name_id.id or False),
				# ('forma','=',linha_id.forma),
				# ('dosagem','=',linha_id.dosagem or False),
				# ('apresentacao','=',linha_id.apresentacao and linha_id.apresentacao.id or False),
			]
		return query

	def get_quota_vigor_id(self, cr, uid,prod_id,context=None):
		if context is None: context = {}
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		ano_id = self.pool.get('configuration.fiscalyear').find(cr, uid)
		vigor_ids = vigor_model.search(cr,uid,[('prod_id','=',prod_id),('ano_id','=',ano_id),('em_vigor','=',True)])
		if vigor_ids:
			return vigor_model.browse(cr,uid,vigor_ids[0]) or False
		return False

	def validar(self, cr, uid,ids,context=None):
		if context is None: context = {}
		concurso_linha_model = self.pool.get('dotcom.lancamento.concurso.linha')
		dir_model = self.pool.get('dotcom.director.tecnico')
		certificado_model = self.pool.get('dotcom.quotas.certificado')

		for document in self.browse(cr,uid,ids):
			# if document.from_certif or document.certificado_id:
			self.validar_certificado(cr,uid,ids,context)
			# if not document.doc_numero: 
			# 	doc_numero = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'BIEF','full',context)
			# 	if not doc_numero: error(action,'Defina Sequenência para este Documento.')
			# 	self._change(cr, uid, ids, {'doc_numero': doc_numero})

			if len(document.linha_ids) > 10: error(action,'O BIEF deve ter no máximo 10 linhas.')
			if not document.linha_ids: error(action,'O BIEF tem que ter pelo menos uma linha.')
			if document.tipo_bief == 'snsc' and not document.concurso_id:  error(action,'Informe o nº do concurso.')
			if document.tipo_bief == 'snsc' and document.concurso_id and document.concurso_id.importador_id.id != document.importador_id.id:
				error(action,'O importador do concurso é diferente do selecionado no BIEF.')
			
			if document.director_id:
				import_dir_ids = dir_model.search(cr,uid,['|',('importador_1_id','=',document.importador_id.id),('importador_2_id','=',document.importador_id.id)])
				if document.director_id.id not in import_dir_ids:
					error(action,'O Dir. Técnico não pertence ao Importador selecionado.')

			err_prod_import, err_imes, err_snsc = '','',''
			err_prosa, err_extra, err_lnme, err_snsd = '','','',''
			
			nr_registo, nr_registo_in, err_nr_registo = 000, 000, 000
			fnm_code, fnm_code_id, err_fnm_code = 000, 000, 000 #Validar que nao haja produtos repetidos no BIEF

			err_snsc_not_in, err_snsc_qtd, err_medicamento = '','',''
			err_qty, err_preco = '',''

			err_vigor_id, err_vigor_id_quota = '',''
			for linha_id in document.linha_ids:
				if linha_id.quant <= 0: err_qty += ('#:%s, '%linha_id.numerador)
				if linha_id.preco <= 0: err_preco += ('#:%s, '%linha_id.numerador)

				if document.importador_id.id != linha_id.comercial_name_id.importador_id.id: err_prod_import += ('#:%s, '%linha_id.numerador)
				if document.tipo_bief == 'imes' and linha_id.comercial_name_id.nr_registo:#Importação Especial
					err_imes +=  ('#:%s, '%linha_id.numerador)
				
				if document.tipo_bief == 'snsc':#Serviço Nacional de Saúde - Concurso
					if not document.concurso_id.linha_ids: error(action,'O Concurso deve ter pelo menos uma linha.')
					
					query = self.get_query(cr, uid, linha_id,document.concurso_id.id)
					conc_lin_ids = concurso_linha_model.search(cr,uid,query)
					if len(conc_lin_ids) > 1:
						linhas = [('#:'+clid.numerador) for clid in concurso_linha_model.browse(cr,uid,conc_lin_ids)]
						error(action,'As linhas %s têm dados iguais.'%len(linhas))
					if len(conc_lin_ids) == 0: err_snsc_not_in += ('#:%s, '%linha_id.numerador)
					if len(conc_lin_ids) == 1:
						conc_lin_id = concurso_linha_model.browse(cr,uid,conc_lin_ids[0])
						if conc_lin_id.diferenca < linha_id.quant: err_snsc_qtd += ('#:%s, '%linha_id.numerador)
 
				if document.tipo_bief == 'lnme' and not linha_id.comercial_name_id.fnm_code:#Lista Nacional de Medicamentos Essenciais
					err_lnme +=  ('#:%s, '%linha_id.numerador)
				
				if document.tipo_bief == 'extra':#Extra Lista
					if not (linha_id.comercial_name_id.nr_registo and not linha_id.comercial_name_id.fnm_code):
						err_extra +=  ('#:%s, '%linha_id.numerador)

				if document.tipo_bief == 'prosa' and linha_id.prod_id.categoria == 'medicamento':#Lista Nacional de Medicamentos Essenciais
					err_prosa +=  ('#:%s, '%linha_id.numerador)

				if document.tipo_bief != 'prosa' and linha_id.prod_id.categoria != 'medicamento':#Produtos de Saúde
					err_medicamento +=  ('#:%s, '%linha_id.numerador)

				if linha_id.prod_id.subs_controlada:
					vigor_id = self.get_quota_vigor_id(cr,uid,linha_id.prod_id.id)
					if not vigor_id: err_vigor_id += ('#:%s, '%linha_id.numerador)
					if vigor_id.diferenca < linha_id.quant: err_vigor_id_quota += ('#:%s, '%linha_id.numerador)

			if len(err_qty) > 0: error(action,'Quantidade inválida no/s produto/s %s.'%(err_qty))
			if len(err_preco) > 0: error(action,'Preço inválido no/s produto/s %s.'%(err_preco))

			if len(err_prod_import) > 0: error(action,'Os produtos %s não pertencem ao importador "%s".'%(err_prod_import,document.importador_id.name))
			if len(err_imes) > 0: error(action,'Os produtos %s não pode ser de Importação Especial.'%(err_imes))
			
			if len(err_snsc) > 0: error(action,'Os produtos %s não pode ser de Serviço Nacional de Saúde - Concurso.'%(err_snsc))
			if len(err_snsc_not_in) > 0: error(action,'Os produtos %s não pertencem ao Concurso selecionado.'%(err_snsc_not_in))
			if len(err_snsc_qtd) > 0: error(action,'A quantidade de produtos %s superam a quantidade por importar no Concurso.'%(err_snsc_qtd))
			
			# if len(err_snsd) > 0: error(action,'Os produtos %s não pode ser de Serviço Nacional de Saúde - Doação.'%(err_snsd))
			if len(err_lnme) > 0: error(action,'Os produtos %s não possuem o Código FNM portanto, não pertencem a Lista Nacional de Medicamentos Essenciais.'%(err_lnme))
			if len(err_extra) > 0: error(action,'Os produtos %s não pode ser de Extra Lista.'%(err_extra))
			if len(err_prosa) > 0: error(action,'Os produtos %s não são Produtos de Saúde.'%(err_prosa))
			if len(err_medicamento) > 0: error(action,'Os produtos %s não são Medicamentos.'%(err_medicamento))

			if len(err_vigor_id) > 0: error(action,'Não encontramos quota em vigor para o/s produto/s %s.'%(err_vigor_id))
			if len(err_vigor_id_quota) > 0: error(action,' Já não há quota em vigor para o/s produto/s %s.'%(err_vigor_id_quota))

			# error(action,'O nome comercial do produto "%s" não pertence ao importador "%s"'%(linha_id.prod_id.name,document.importador_id.name))

	# imes = Importação Especial
	# snsc = Serviço Nacional de Saúde - Concurso
	# snsd = Serviço Nacional de Saúde - Doação
	# lnme = Lista Nacional de Medicamentos Essenciais
	# extra = Extra Lista = Sao todos medicamentos que tem nr_registo e sem o fnm_code
	# prosa = Produtos de Saúde

	def submeter(self, cr, uid,ids,context=None):
		msg('bief.submeter ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			self.validar(cr,uid,ids,context)
			self.calcular(cr, uid,ids,context)
			if document.certificado_id and not document.certificado_id.bief_id:
				self.pool.get('dotcom.quotas.certificado').write(cr,uid,[document.certificado_id.id],{'bief_id': ids[0]})
			vals = {'state': 'submetido', 'user_id': uid}

			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'BIEF','full',context,True)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def validar_1(self, cr, uid, ids, context=None):
		msg('bief.validar_1 ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'validar','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			self.validar(cr,uid,ids,context)
			self.write(cr,uid,ids,{'state':'validar'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def validar_2(self, cr, uid,ids,context=None):
		msg('bief.validar_2 ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'validado','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			self.validar(cr,uid,ids,context)
			self.write(cr,uid,ids,{'state':'validado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def aprovar(self, cr, uid,ids,context=None):
		msg('bief.aprovar ids: %s'%ids)
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		certificado_model = self.pool.get('dotcom.quotas.certificado')
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			data_aprovacao = date.today()
			for linha_id in document.linha_ids:
				if linha_id.prod_id.subs_controlada:
					vigor_id = self.get_quota_vigor_id(cr,uid,linha_id.prod_id.id)
					quota_bief_aprovadas = vigor_id.quota_bief_aprovadas+linha_id.quant
					if vigor_id.diferenca < quota_bief_aprovadas:
						error(action,'Quota Actual "%s" menor que quotas aprovadas em BIEFs "%s".'%(vigor_id.diferenca,quota_bief_aprovadas))
					vigor_model.write(cr,uid,vigor_id.id,{'quota_bief_aprovadas': quota_bief_aprovadas,'data_bief': date.today(),})
			# data_aprovacao = (date.today()+relativedelta(hours=2)).strftime('%%Y/%%m/%%d')
			self.write(cr,uid,ids,{'state':'aprovado','data_aprovacao':data_aprovacao})
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		cancel_model = self.pool.get('dotcom.import.cancel')
		self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','bief')#['bief','hibi','libe','capr','conc','quat','quce']
		# self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		resets = {}
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'type': _type,			
			'required': True,

			'bief_id': ids and ids[0] or None,
			'liberacao_id': None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': None,
			'certificad_id': None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)

	def rejeitar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rejeitar',context)
		
	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_rejeitar(self, cr, uid,ids,context=None):
		msg('bief.rejeitar ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			if document.certificado_id:
				self.pool.get('dotcom.quotas.certificado').write(cr,uid,[document.certificado_id.id],{'bief_id': False})
			self.pool.get('get.aux').check_act_doc(cr,uid,'rejeitado','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'rejeitado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def run_cancelar(self, cr, uid,ids,context=None):
		msg('bief.cancelar ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			if document.certificado_id:
				self.pool.get('dotcom.quotas.certificado').write(cr,uid,[document.certificado_id.id],{'bief_id': False})
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)

	def run_voltar_rascunho(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids,context):
			if document.certificado_id:
				self.pool.get('dotcom.quotas.certificado').write(cr,uid,[document.certificado_id.id],{'bief_id': False})
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','bief')#['bief','hibi','libe','capr','conc','quat','quce']
			vals = {'quant':0, 'preco':0, 'total':0, 'state':'rascunho_2'}
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)
		return True

	def imprimir(self, cr, uid,ids,context=None):
		msg('bief.imprimir ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'submetido'})

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error(action,'Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_importacao_bief, self).unlink(cr, uid, ids, context=context)

	def all_changes(self, cr, uid,ids,context=None):
		msg('bief.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.importador_id.id,'importador_id',context)
			self.on_ch_2(cr,uid,ids,oid.data_emissao,'data_emissao',oid.prazo,'prazo')
		return True

	def set_numerador(self, cr, uid, ids, context=None):
		msg('bief.set_numerador.ids:%s'%(ids))
		linha_model = self.pool.get('dotcom.bief.linha')
		if context is None: context = {}
		numerador = 1
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}

		id = super(dotcom_importacao_bief, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': id},context)
		self.set_numerador(cr, uid,[id],context)
		self.all_changes(cr, uid,[id],context)		
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		val = super(dotcom_importacao_bief, self).write(cr, uid, ids, vals, context=context)
		self.set_numerador(cr, uid,ids,context)

		# if ids:
		# 	self.pool.get(RM_MODEL).rm_run(cr,uid,{'bief_id': ids[0], 'operacao': 'write', 'processo': 'BIEF'},context)	
		return val
dotcom_importacao_bief()	



class dotcom_bief_linha(osv.osv):

	def print_context(self,cr,uid,ids, context=None):
		msg('print_context: %s'%context)
		return 0

	_name = 'dotcom.bief.linha'
	_description = 'Linhas de BIEFs'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True),
		'importador_id':fields.related('parent_id','importador_id',type='many2one',relation='dotcom.parceiro.importador',string='Importador',readonly=True),
		'importador_terc_id':fields.related('parent_id','importador_terc_id',type='many2one',relation='dotcom.parceiro.importador',string='Importador Terceirizado',readonly=True),
		
		'numerador': fields.integer('#', readonly=True),
		'fnm_code': fields.char('Código FNM', size=9,  readonly=True,help='Formulário Nacional de Medicamentos'),
		'nr_registo': fields.char('Nº registo', size=9, required=False, readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True,),		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=True, domain="[('prod_id','=',prod_id),('activo','=',True),('importador_id','in',[importador_id,importador_terc_id])]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=True),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=True),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=True),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=False, readonly=True),

		'quant': fields.float('QTD', required=False), 
		'preco': fields.float('Preço', required=False), 
		'total': fields.float('Total', readonly=True), 
		'libertado': fields.boolean('Libertado', readonly=True,),
	}
	
	_defaults = {
		'quant': 0,
		'numerador': print_context,
		'importador_id':lambda self, cr, uid, c: c.get('importador_id', False),
		'importador_terc_id':lambda self, cr, uid, c: c.get('importador_terc_id', False),
	}
# dotcom.tesouraria.lancamento.movimentos
	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('bief_linha.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'prod_id':
			if not valor: vals = {'comercial_name_id': False,}			
			# if valor:
			# 	oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
			# 	# cnid = (oid.comercial_name_id and oid.comercial_name_id.id)
			# 	vals = {'fnm_code': oid.fnm_code}
			return self._change(cr, uid, ids, vals)
		if descricao == 'comercial_name_id':
			if not valor: vals = {'fnm_code': False,'nr_registo': False, 'forma': False, 'dosagem': False, 'apresentacao': False, 'fabricante_id': False, }
			if valor:
				oid = self.pool.get('dotcom.prod.comercial_name').browse(cr,uid,valor)
				vals = {
					'nr_registo': oid.nr_registo,
					'fnm_code': oid.fnm_code,
					'forma': oid.forma,
					'dosagem': oid.dosagem,
					'apresentacao': oid.apresentacao,
					'fabricante_id': oid.fabricante_id.id,
					}
			return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('bief_linha._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch_a_b(self, cr, uid, ids, a, b, campo, descricao, context=None):
		msg('bief_linha.on_ch_a_b:%s, descricao: %s, a: %s,  b: %s'%(campo, descricao,a,b))
		if context is None: context = {}
		if descricao in ['quant_preco','preco_quant']:
			total = a * b
			self.write(cr,uid,ids,{'total':total})
			return self._change(cr, uid, ids, {'total':total})


	def all_changes(self, cr, uid,ids,context=None):
		msg('bief.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.prod_id.id,'prod_id',context)
			self.on_ch(cr,uid,ids,oid.comercial_name_id.id,'comercial_name_id',context)
			self.on_ch_a_b(cr,uid,ids,oid.quant,oid.preco,'preco_quant',context)			
			# self.on_ch(cr,uid,ids,oid.bief_id.id,'bief_id',context)
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		query = [
			('parent_id','=',vals['parent_id']),
			('prod_id','=',vals['prod_id']),
			('comercial_name_id','=',vals['comercial_name_id']),
			# ('forma','=',vals['forma']),
			# ('dosagem','=',vals['dosagem']),
			# ('apresentacao','=',vals['apresentacao']),
			]
		ids = self.search(cr,uid,query)
		if ids: error(action,'Linha[#:%s] duplicada.\nNão se permite mais de uma linha com mesmas características.'%(self.browse(cr,uid,ids[0]).numerador))
		id = super(dotcom_bief_linha, self).create(cr, uid, vals, context=context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	# def write(self, cr, uid, ids, vals, context=None):
	# 	if context is None: context = {}		
	# 	return super(dotcom_bief_linha, self).write(cr, uid, ids, vals, context=context)


	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.parent_id and not document.parent_id.from_historico and document.parent_id.state not in ['rascunho',]:
				error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_bief_linha, self).unlink(cr, uid, ids, context=context)

dotcom_bief_linha()		



class dotcom_bief_cambio(osv.osv):
	_name = 'dotcom.bief.cambio'
	_description = 'Cambios de BIEFs'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True),

		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', readonly=True,),


		'moeda_id': fields.many2one('res.currency','Moeda',readonly=True,),
		'total_moeda': fields.float('Total Moeda', readonly=True,),

		'moeda_principal_id': fields.many2one('res.currency', 'MP', readonly=True),
		'total_principal': fields.float('Total MP', readonly=True,),

		'moeda_secundaria_id': fields.many2one('res.currency', 'MS', readonly=True),
		'total_secundario': fields.float('Total MS', readonly=True,),
	}
	
	_defaults = {
		'total_secundario': 0,
	}

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.parent_id and document.parent_id.state not in ['rascunho',]: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_bief_cambio, self).unlink(cr, uid, ids, context=context)
dotcom_bief_cambio()	



	# def add_days_to_licence(self,cr,uid,context=None):  
	# 	msg('bief.add_days_to_licence')
	# 	licence_model = self.pool.get('dotcom.licence')  
	# 	lic_mod_model = self.pool.get('dotcom.licence.module') 
	# 	for licence_id in licence_model.browse(cr,uid,licence_model.search(cr,uid,[])):
	# 		res = {
	# 			'start': (datetime.now()).strftime('%Y-%m-01'),
	# 			'end': (datetime.now() + timedelta(days=400)).strftime('%Y-%m-01'),
	# 			'remaining_days': 400,
	# 		}
	# 		msg('res: %s licence_id.modulos_ids: %s'%(res,licence_id.modulos_ids))
	# 		licence_model.write(cr,uid,[licence_id.id],res)
	# 		for mod in licence_id.modulos_ids:
	# 			lic_mod_model.write(cr,uid,[mod.id],res)