# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
import logging 
import decimal_precision as dp
logger = logging.getLogger('DOTCOM_LOGGS') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_sequencia(osv.osv):

	def get_proximo_nr(self, cr, uid, ids, context=None):
		msg('sequencia.get_proximo_nr: %s)'%ids)
		proximo_nr = 1
		for seq_id in self.browse(cr,uid,ids):
			proximo_nr = seq_id.proximo_nr + 1
		return proximo_nr

	def _proximo_codigo_get(self, cr, uid, ids, digitos, context=None):
		if context is None: context = {}
		proximo_nr = self._proximo_nr_get(cr,uid,ids,context)
		return _add_digitos(digitos,proximo_nr)

	_name = 'dotcom.sequencia'
	_description = 'Sequência'
	_columns = {
		'proximo_nr': fields.integer('Próximo  Número',readonly=True, required=True, help="Next number of this sequencia"),
		'ano_id': fields.many2one('configuration.fiscalyear', 'Ano Fiscal',readonly=True,),
		'tipo_doc': fields.char('Tipo Documento', size=128, required=False, readonly=False),
		}
	_rec_name = 'ano_id'
	_defaults = {
		'proximo_nr': lambda self, cr, uid, c: self.pool.get('dotcom.sequencia').get_proximo_nr(cr, uid,[],c),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
	 }

	def get_name(self, cr, uid,tipo_doc, can_save,context=None):
		# msg('sequencia.get_name: %s)'%ids)
		name = ''
		seq_ids = self.search(cr,uid,[('tipo_doc': tipo_doc)])
		id = (seq_ids and max(seq_ids)) or False

		if not id:
			ano_id = self.pool.get('configuration.fiscalyear').find(cr, uid)
			id = self.create(cr, uid, {'proximo_nr': 0, 'tipo_doc': tipo_doc, 'ano_id': ano_id.id })

		for seq_id in self.browse(cr,uid,[id]):
			proximo_nr = self.get_proximo_nr(cr, uid,[id],context)
			name = '%s/%S'%(seq_id.ano_id.name,proximo_nr)

			if can_save:
				self.write(cr, uid, [id], {'proximo_nr': proximo_nr})
		return name
dotcom_sequencia()	












class gen_ref(osv.osv):
	_name = 'gen.ref'
	_order = 'name'
	_columns = {
			'ref': fields.char('Ref', size=64, readonly=True),
			'name': fields.char('Classe Name', size=256, readonly=True),
			'numero': fields.integer('Nº', readonly=True),
			}

	def get_next_nr(self, cr, uid,class_name, context=None):
		model = self.pool.get(class_name)
		ids, res_1, res_2 = model.search(cr,uid,[]), '', ''
		res_1 = ids
		if not ids:
			ids = self.search(cr,uid,[('name','=',class_name)])
			res_2 = ids
		# msg('get_next_nr. res_1: %s, res_2: %s'% (res_1,res_2))
		ids = (ids and max(ids)) or 0
		return( ids + 1)

	def if_exist(self, cr, uid,prefix,digitos,next_nr,class_name, context=None):
		model = self.pool.get(class_name)
		ref = ('%s/%s'%(prefix,_add_digitos(digitos,next_nr)))
		ids = model.search(cr,uid,[('ref','=',ref)])
		msg('if_exist: [%s].ref: %s, ids: %s'% (class_name,ref,ids))
		if ids:
			next_nr += 1
			return self.if_exist(cr,uid,prefix,digitos,next_nr,class_name,context)
		return ref

	def next_ref(self, cr, uid, digitos, prefix, class_name, context=None, save=False):
		model = self.pool.get(class_name)
		next_nr = self.get_next_nr(cr,uid,class_name,context)
		ref = self.if_exist(cr,uid,prefix,digitos,next_nr,class_name,context) #('%s/%s'%(prefix,_add_digitos(digitos,next_nr)))
		msg('[%s].next_ref: %s, salvar: %s'% (class_name,ref,save))

		if save:
			self.create(cr, uid, {'ref':ref,'name':class_name,'numero':next_nr,}, context=context)
		return ref
gen_ref()