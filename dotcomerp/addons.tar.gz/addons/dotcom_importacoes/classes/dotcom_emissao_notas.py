# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'emitido': 'Emitido',
    }
class dotcom_emissao_notas(osv.osv):
	def pattern(self,cr,uid,valor):
		return self.pool.get('decimal.precision').get_decimal_precision(cr,uid,valor)
		
	_name = 'dotcom.emissao.notas'
	_description = 'Emissão de Notas'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True,),
		'data': fields.date('Data', required=True, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True, readonly=True,),
		'period_id': fields.many2one('configuration.period','Período', required=True, readonly=True, states={'rascunho':[('readonly',False)]},),
		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=True, domain="[('activo','=',True),]", readonly=True, states={'rascunho':[('readonly',False)]},),		
		'linha_ids': fields.one2many('dotcom.notas.linha','parent_id','Linhas', readonly=True, states={'rascunho':[('readonly',False)]},),
		'movimento_ids': fields.one2many('reg.mov','eminota_id','Movimentos', readonly=True,),

		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)]},),
		'state': fields.selection([
			('rascunho','Rascunho'),
			('emitido','Emitido'),
			],'Estado', select=True, readonly=True,),	
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'state': 'rascunho',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
	}
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já foi criado uma notas com esta referência!')]

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('notas.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		if descricao in ['moeda_id','moeda_principal_id','moeda_secundaria_id',]:
			oid = self.pool.get('res.currency').browse(cr,uid,valor)
			cambio, name, vals = 1, '', {}
			name = oid.name			
			if oid and oid.base is not True: cambio = self.pattern(cr,uid,oid.rate)
			if descricao == 'moeda_id':
				if oid: vals = {'moeda_str': name,'cambio': cambio}
				else: vals = {'moeda_str': name,'cambio': cambio}
			if descricao == 'moeda_principal_id': 
				if oid: vals = {'cambio_principal': cambio}
				else: vals = {'cambio_principal': 0}
			if descricao == 'moeda_secundaria_id': 
				if oid: vals = {'cambio_secundario': cambio}
				else: vals = {'cambio_secundario': 0}
			elif descricao == 'data':
				vals = {
					'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
					'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
					}
			return {'value': vals}


	def get_bief(self, cr, uid,campo,valor,context=None):
		msg('notas.get_bief:where %s = %s'%(campo,valor))
		if context is None: context = {}
		bief_model = self.pool.get('dotcom.importacao.bief')
		if not valor: return False
		bief_ids = bief_model.search(cr, uid, [(campo,'=',valor),('state','=','aprovado')])
		if bief_ids: return bief_model.browse(cr,uid,bief_ids)
		return False

	def validar(self, cr, uid,ids,context=None):
		msg('notas.validar. ids: %s'%ids)
		if context is None: context = {}
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')

	def processar(self, cr, uid,ids,context=None):
		msg('notas.processar. ids: %s'%ids)
		if context is None: context = {}
		lin_model = self.pool.get('dotcom.notas.linha')
		lin_model = self.pool.get('dotcom.notas.linha')

		for document in self.browse(cr,uid,ids):
			bief_ids = self.get_bief(cr,uid,'importador_id',document.importador_id.id,context)
			if not bief_ids:error('Acção Inválida!','Não encontramos BIEFs.')

			for linha in document.linha_ids:
				lin_model.unlink(cr, uid, linha.id)

			for linha in bief_ids:
				vals = {
					'parent_id': document.id,
					'bief_id': linha.id,
					'data_aprovacao': linha.data_aprovacao,				
					}
				lin_model.create(cr,uid,vals)

	def emitir(self, cr, uid,ids,context=None):
		msg('notas.emitir. ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			vals = {'state': 'emitido'}
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'EMNO','full',context,True)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'eminota_id': ids[0]},context)

	def start_report(self, cr, uid,ids, context={}):
		msg('notas.start_report ids: %s'%ids)
		data = self.read(cr,uid,ids,)[-1]
		msg('data: %s'%data)
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_eminota',
			'datas':{
					'model':'dotcom.emissao.notas',
					'id':ids[0],
					'ids':ids,
					'report_type':'pdf',
					'form':data
			},
			'nodestroy':False,
		}

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		# seq_model = self.pool.get('dotcom.sequencia')
		# vals['doc_numero'] = seq_model._nr_get(cr,uid,'EMNO','full',context,True)
		id = super(dotcom_emissao_notas, self).create(cr, uid, vals, context=context)
		# self.all_changes(cr, uid,[id],context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'eminota_id': id},context)
		return id
dotcom_emissao_notas()


class dotcom_notas_linha(osv.osv):
	_name = 'dotcom.notas.linha'
	_description = 'Linhas de Emissão de Notas'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.emissao.notas','Parente', readonly=True),
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF', required=True, readonly=True),
		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True),
	}
	
	# _defaults = {
	# 	'total': 0,
	# }
dotcom_notas_linha()