# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

class dotcom_lancamento_concurso(osv.osv):

	_name = 'dotcom.lancamento.concurso'
	_description = 'Lançamento de Concursos'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True),

		'nr_concur': fields.char('Nº Concurso', size=120, required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'tipo': fields.selection([('nacional','Nacional'),('internacional','Internacional'),],'Tipo', select=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'nota': fields.char('Nota', size=512, required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', domain="[('activo','=',True),]",readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data': fields.date('Data da Emissão', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data_vencimento': fields.date('Data de Vencimento', required=False, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True,readonly=True,),
		'period_id': fields.many2one('configuration.period','Período', required=True, readonly=True,),

		'linha_ids': fields.one2many('dotcom.lancamento.concurso.linha','parent_id','Linhas', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'movimento_ids': fields.one2many('reg.mov','concurso_id','Movimentos', readonly=True,),

		# 'in_use': fields.char('Em uso no BIEF', readonly=True),
		'state': fields.selection([
				('rascunho','Rascunho'),
				('submetido','Submetido'),
				('aprovado','Aprovado'),
				('cancelado','Cancelado'),
				('rascunho_2','Rascunho'),
				],'Estado', select=True, readonly=True,),
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','concurso_id','Cancelamentos', readonly=True,),
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'state': 'rascunho',
		# 'in_use': False,
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
	 }	
	_sql_constraints = [('doc_numero_nr_concur_unique', 'unique(nr_concur,doc_numero)', 'Já existe um Lançamento de Concursos com este Nº!')]

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('lancamento_concurso.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao and valor:
			if descricao == 'director_id':
				oid = self.pool.get('dotcom.director.tecnico').browse(cr, uid, valor)
				return {'value': {'director_funcao': oid.funcao,'importador_id': (oid.importador_id and oid.importador_id.id) or False,}}
			# if descricao == 'importador_id':
			# 	oid = self.pool.get('dotcom.parceiro.importador').browse(cr, uid, valor)
			# 	return {'value': {'import_endereco': oid.endereco,'dir_cpf': oid.cpf,}}
			if descricao == 'fornecedor_id':
				oid = self.pool.get('dotcom.parceiro.fornecedor').browse(cr, uid, valor)
				return {'value': {'forn_pais_id': (oid.pais_id and oid.pais_id.id) or False,'forn_endereco': oid.endereco,}}
		elif descricao == 'data':
			vals = {
				'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
				'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
				}
			return self._change(cr, uid, ids, vals)
		return False

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def all_changes(self, cr, uid,ids,context=None):
		msg('concurso.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.importador_id.id,'importador_id',context)
		return True

	def validar(self, cr, uid,ids,context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			a = 0
			# error(action,'O nome comercial do produto "%s" não pertence ao importador "%s"'%(linha_id.prod_id.name,document.importador_id.name))

	def submeter(self, cr, uid,ids,context=None):
		msg('concurso.submeter ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			vals = {'state': 'submetido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','conc')#['bief','hibi','libe','capr','conc','quat','quce']
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'CONC','full',context,True)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': ids[0]},context)

	def aprovar(self, cr, uid,ids,context=None):
		msg('concurso.aprovar ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		vals = {}
		for document in self.browse(cr,uid,ids):
			vals['data_aprovacao'] = datetime.now().strftime('%Y-%m-%d')
			vals['state'] = 'aprovado'
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','conc')#['bief','hibi','libe','capr','conc','quat','quce']
			msg('concurso.vals: %s'%vals)
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': ids[0]},context)


	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': ids and ids[0] or None,
			'quota_act_id': None,
			'certificad_id': None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_cancelar(self, cr, uid,ids,context=None):
		msg('concurso.cancelar ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','conc')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': ids[0]},context)

	def run_voltar_rascunho(self, cr, uid,ids,context=None):
		msg('concurso.voltar_rascunho ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.validar_unlink(cr,uid,ids,'Voltar à Rascunho')
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','conc')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'rascunho_2'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': ids[0]},context)

	def imprimir(self, cr, uid,ids,context=None):
		msg('concurso.imprimir ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		# for document in self.browse(cr,uid,ids):
			# self.write(cr,uid,ids,{'state':'submetido'})

	def validar_unlink(self, cr, uid, ids, operacao, context=None):
		if context is None: context = {}
		bief_model = self.pool.get('dotcom.importacao.bief')
		for document in self.browse(cr,uid,ids): 
			src_ids = bief_model.search(cr,uid,[('concurso_id','=',ids[0]),('state','not in',['rascunho','cancelado','rejeitado']),])
			if src_ids: error('Acção Inválida!','Não é possível %s!\nEste documento já foi mencionado em BIEFs.'%operacao)
		
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		self.validar_unlink(cr,uid,ids,'eliminar')
		return super(dotcom_lancamento_concurso, self).unlink(cr, uid, ids, context=context)

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		# seq_model = self.pool.get('dotcom.sequencia')
		# vals['doc_numero'] = seq_model._nr_get(cr,uid,'CONC','full',context,True)

		id = super(dotcom_lancamento_concurso, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': id},context)
		self.all_changes(cr, uid,[id],context)
		return id
dotcom_lancamento_concurso()	



class dotcom_lancamento_concurso_linha(osv.osv):

	def _calcula_progress(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for sale in self.browse(cr, uid, ids, context=context):
			return 0
			
	_name = 'dotcom.lancamento.concurso.linha'
	_description = 'Linhas do Lançamento de Concursos'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.lancamento.concurso','Concurso', readonly=True),
		'numerador': fields.integer('#', readonly=True),
		'name': fields.char('Ref. Prod', size=120, required=False),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True,),
		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=False, domain="[('prod_id','=',prod_id),('activo','=',True),('importador_id','=',importador_id)]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=False),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=False),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=False),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=True,readonly=False),

		'quant': fields.float('QTD'), 
		'quant_acumulada': fields.float('QTD acumulada', help="QTD acumulada Já submetida e/ou emitida"), 
		'quant_emitida': fields.float('QTD Emitida'), 
		'diferenca': fields.float('Diferença'), # = quant - quant_emitida
		# 'quota_importada_perc': fields.float('Progresso', required=False, readonly=True),
		'quota_importada_perc': fields.function(_calcula_progress, method=True, string='Progresso', type='float'),
	}
	# _rec_name = 'name'
	_defaults = {
		'numerador': 0,
		'quant': 0,
		'quant_acumulada': 0,
		'quant_emitida': 0,
		'diferenca': 0,
		'quota_importada_perc': 0,
	}
		
	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('concurso_linha.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'tiposs' and not valor:
			return {'value': {'tipo': 'adenda',}}
		if descricao == 'prod_id':
			if not valor: vals = {'name': oid.ref,'comercial_name_id': False,} 
			if valor:
				oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
				vals = {'name': oid.ref,'comercial_name_id': False,}
			return self._change(cr, uid, ids, vals)
		if descricao == 'comercial_name_id':
			if not valor: vals = {'nr_registo': False,}
			oid = self.pool.get('dotcom.prod.comercial_name').browse(cr,uid,valor)
			vals = {
				'forma': oid.forma,
				'dosagem': oid.dosagem,
				'apresentacao': oid.apresentacao,
				'fabricante_id': oid.fabricante_id.id,
				}
			return self._change(cr, uid, ids, vals)
		return False

	def set_numerador(self, cr, uid, ids, vals, context=None):
		msg('concurso_linha.set_numerador.ids:%s, vals: %s'%(ids, vals))
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			numerador = 1
			for linha_id in document.parent_id.linha_ids:
				if linha_id.numerador != numerador:
					self._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		query = [
			('parent_id','=',vals['parent_id']),
			('prod_id','=',vals['prod_id']),
			('comercial_name_id','=',vals['comercial_name_id']),
			# ('forma','=',vals['forma']),
			# ('dosagem','=',vals['dosagem']),
			# ('apresentacao','=',vals['apresentacao']),
			]
		ids = self.search(cr,uid,query)
		if ids: error(action,'Linha[#:%s] duplicada.\nNão se permite mais de uma linha com mesmas características.'%(self.browse(cr,uid,ids[0]).numerador))
		
		vals['diferenca'] = vals['quant']
		id = super(dotcom_lancamento_concurso_linha, self).create(cr, uid, vals, context=context)
		self.set_numerador(cr, uid,[id],vals,context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}		
		return super(dotcom_lancamento_concurso_linha, self).write(cr, uid, ids, vals, context=context)

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}

		concurso_model = self.pool.get('dotcom.lancamento.concurso')
		for document in self.browse(cr,uid,ids): 
			if document.parent_id:
				if document.parent_id.state not in ['rascunho','cancelado']: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
				concurso_model.validar_unlink(cr,uid,[document.parent_id.id])
		return super(dotcom_lancamento_concurso_linha, self).unlink(cr, uid, ids, context=context)
		
dotcom_lancamento_concurso_linha()	