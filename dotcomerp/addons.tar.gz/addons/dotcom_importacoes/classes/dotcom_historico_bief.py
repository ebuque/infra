# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
# from dotcom_importacoes import dotcom_registo_movimentos as rm
logger = logging.getLogger('DOTCOM') 

# Timedelta aceita os seguintes parâmetros:
# days
# seconds
# microseconds
# milliseconds
# minutes
# hours
# weeks


action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_historico_bief(osv.osv): 

	def pattern(self,cr,uid,valor):
		return self.pool.get('decimal.precision').get_decimal_precision(cr,uid,valor)

	def get_director_id_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id:
			res = u_id.director_id.id
		msg('get_director_id_bay_uid: %s'%res)
		return res

	def get_is_director_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id: res = True
		msg('get_is_director_bay_uid: %s'%res)
		return res

	def get_importador_id_bay_uid(self,cr,uid,ids):
		user_model = self.pool.get('res.users')
		u_id = user_model.browse(cr,uid,uid)
		res = False
		if u_id and u_id.is_director and u_id.director_id: res = u_id.director_id.importador_id.id
		msg('get_importador_id_bay_uid: %s'%res)
		return res

	def get_perc_libertado(self, cr, uid, ids, name, arg, context=None):
		res = {}
		linha_model = self.pool.get('dotcom.historico.bief.linha')
		for oid in self.browse(cr, uid, ids, context=context):
			progress = 0
			total_linhas = len(oid.linha_ids)
			libertado_ids = len(linha_model.search(cr,uid,[('libertado','=',True),('parent_id','=',ids[0])]))
			if libertado_ids == 0:
				progress = 0
			else:
				progress = (libertado_ids*100)/total_linhas
			res[oid.id] = progress
		return res

	_name = 'dotcom.historico.bief'
	_description = 'Registo de Histórico de BIEFs'
	#_rec_name = 'name'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, readonly=True),
		'vref': fields.char('V/Ref', size=120, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, help='Vossa Referência.'),
		'data_emissao': fields.date('Data da Emissão', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'period_id': fields.many2one('configuration.period','Período', readonly=True,),
		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True),
		'prazo': fields.selection([('anual','Anual'),('semestral','Semestral'),('mensal','Mensal'),],'Prazo', required=True,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data_vencimento': fields.date('Data de Vencimento', required=False, readonly=True),
		# 'data_libertacao': fields.date('Data de Libertação', required=False, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True,readonly=True,),
		
		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=True, domain="[('activo','=',True),]",readonly=False,),
		'endereco_import': fields.char('Endereço', size=120, required=False, readonly=True),
		'nuit_import': fields.char('NUIT', size=120, required=False, readonly=True),

		'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', required=True, domain="[('activo','=',True),]",readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'pro_forma': fields.char('Pro-Forma', size=120, required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),	
		
		'director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico',domain="[('importador_id','=',importador_id),('active','=',True),]",readonly=False,),
		'director_cpf': fields.char('CPF Nº', size=120, required=False,readonly=True,),
		'is_director': fields.boolean('Is Director', readonly=True,),
		'user_id': fields.many2one('res.users','User',readonly=True,),
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF',readonly=True,),
		
		'concurso_id': fields.many2one('dotcom.lancamento.concurso','Concurso', required=False, readonly=True, domain="[('importador_id','=',importador_id),('state','=','aprovado'),('ano_id','=',ano_id)]", states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'tipo_bief': fields.selection([
			('imes','Importação Especial'),
			('snsc','Serviço Nacional de Saúde - Concurso'),
			('snsd','Serviço Nacional de Saúde - Doação'),
			('lnme','Lista Nacional de Medicamentos Essenciais'),
			('extra','Extra Lista'),
			('prosa','Produtos de Saúde'),
			],'Tipo BIEF', required=True,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'state': fields.selection([
			('rascunho','Rascunho'),
			('aprovado','Aprovado'),
			('cancelado','Cancelado'),
			('rascunho_2','Rascunho'),
			],'Estado', select=True, readonly=True,),

		'moeda_id': fields.many2one('res.currency','Moeda',readonly=True, required=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'moeda_str' : fields.char('Moeda',size=60,readonly=True),
		'cambio': fields.float('Câmbio do Processo', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_moeda': fields.float('Total Moeda', readonly=True,),

		'moeda_principal_id': fields.many2one('res.currency', 'Moeda Principal', readonly=True),
		'cambio_principal': fields.float('Câmbio Principal',required=False,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_principal': fields.float('Total Principal', readonly=True,),

		'moeda_secundaria_id': fields.many2one('res.currency', 'Moeda Secundária', readonly=True),
		'cambio_secundario': fields.float('Cambio Secundário', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_secundario': fields.float('Total Secundário', readonly=True,),
		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'linha_ids': fields.one2many('dotcom.historico.bief.linha','parent_id','Linhas', readonly=False,),
		
		'quant': fields.float('Total(QTD)', readonly=True),
		'preco': fields.float('Total(Preço)', readonly=True), 
		'total': fields.float('Total(Linhas)', readonly=True),
		# 'perc_libertada': fields.function(get_perc_libertado, method=True, string='Percentagem Libertada', type='float'),
		'libertado': fields.boolean('Libertado', readonly=True,),
		'from_historico': fields.boolean('Histórico', readonly=True,help="Vem do Histórico"),

		'anexo_1': fields.binary('1º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_1_name' : fields.char('1º Anexo Name',size=255),
		'anexo_2': fields.binary('2º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_2_name' : fields.char('2º Anexo Name',size=255),
		'anexo_3': fields.binary('3º Anexo',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_3_name' : fields.char('3º Anexo Name',size=255),
	}
	_rec_name = 'doc_numero'
	# Configuração Contas Bancárias Notificações Contracto de Adesão Contabilidade
	_defaults = {
		'cambio': 1,
		'director_id': get_director_id_bay_uid,		
		'is_director': get_is_director_bay_uid,
		'importador_id': get_importador_id_bay_uid,
		'cambio_principal': 1,
		'state': 'rascunho',
		# 'tipo_bief': 'snsd',
		'prazo': 'anual',
		'libertado': True,
		'from_historico': True,
		# 'doc_numero':  lambda self, cr, uid, c: self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'BIEF','full',c),
		'data_emissao': lambda *a: time.strftime('%Y-%m-%d'),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
		'moeda_str': 'MT',
		'moeda_principal_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.historico.bief', context=c),
		'moeda_secundaria_id': lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.historico.bief', context=c),
	}
	
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já foi criado um Histórico BIEF com esta referência!')]

	def on_change_cambio(self, cr, uid, ids, moeda_secundaria, cambio_secundario, contravalor, contravalor_moeda, contravalor_cambio, moeda2=False, cambio2=False, moeda1=False, cambio1=False,context=None):
		vals = {}
		if context is None:
			context = {}
			
		if moeda1 == moeda_secundaria:
			vals['cambio_secundario'] = cambio1
		if moeda1 == moeda2:
			vals['cambio'] = cambio2
		if contravalor:
			if moeda_secundaria == contravalor_moeda:
				vals['alternative_currency_value'] = cambio_secundario
			elif moeda2 == contravalor_moeda:
				vals['alternative_currency_value'] = cambio2
			elif moeda1 == contravalor_moeda:
				vals['alternative_currency_value'] = cambio1
			# else:
				# vals['alternative_currency_value'] = self.pool.get('res.currency').browse(cr, uid, contravalor_moeda).rate or 0.0
		return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('bief._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('bief.on_ch_ %s valor: %s'%(descricao,valor))
		import_model = self.pool.get('dotcom.parceiro.importador')
		dir_model = self.pool.get('dotcom.director.tecnico')
		if context is None: context = {}

		vals = {}
		if descricao in ['moeda_id','moeda_principal_id','moeda_secundaria_id',]:
			oid = self.pool.get('res.currency').browse(cr,uid,valor)
			cambio, name, vals = 1, '', {}
			name = oid.name			
			if oid and oid.base is not True: cambio = self.pattern(cr,uid,oid.rate)
			if descricao == 'moeda_id':
				if oid: vals = {'moeda_str': name,'cambio': cambio}
				else: vals = {'moeda_str': name,'cambio': cambio}
			if descricao == 'moeda_principal_id': 
				if oid: vals = {'cambio_principal': cambio}
				else: vals = {'cambio_principal': 0}
			if descricao == 'moeda_secundaria_id': 
				if oid: vals = {'cambio_secundario': cambio}
				else: vals = {'cambio_secundario': 0}
			return self._change(cr, uid, ids, vals)
		elif descricao == 'tipo_bief' and not valor:
			return self._change(cr, uid, ids, {'tipo_bief': 'snsd',})

		elif descricao == 'importador_id':
			if not valor: vals = {'nuit_import': '','endereco_import': '','director_id': False,}
			if valor:
				oid = import_model.browse(cr,uid,valor)
				vals = {'nuit_import': oid.nuit,'endereco_import': oid.endereco,}	#'director_id': False,		
			return self._change(cr, uid, ids, vals)

		elif descricao == 'director_id':
			if not valor: vals = {'director_cpf': '',}
			if valor:
				oid = dir_model.browse(cr,uid,valor)
				vals = vals = {'director_cpf': oid.cpf,}	
		return self._change(cr, uid, ids, vals)

	def on_ch_2(self, cr, uid, ids, valor_a, descricao_a, valor_b, descricao_b, context=None):
		msg('bief.on_ch_2(%s=%s), (%s=%s)'%(descricao_a,valor_a,descricao_b,valor_b))
		if context is None: context = {}

		vals = {}
		if descricao_a == 'data_emissao' and descricao_b == 'prazo':
			if not valor_a:
				valor_a = datetime.datetime.now().strftime('%Y-%m-%d')#datetime.strptime(data, '%Y-%m-%d')
				vals['data_emissao'] = valor_a
				
			valor_a = datetime.strptime(valor_a, '%Y-%m-%d')
			vals['period_id'] = self.pool.get('get.aux').get_period_id(cr, uid,valor_a)
			vals['ano_id'] = self.pool.get('get.aux').get_ano_id(cr, uid,valor_a)
			data_vencimento = False
			if valor_b == 'anual': data_vencimento = str((valor_a + timedelta(365)).strftime('%Y-%m-%d'))
			if valor_b == 'semestral': data_vencimento = str((valor_a + timedelta(182)).strftime('%Y-%m-%d'))
			if valor_b == 'mensal': data_vencimento = str((valor_a + timedelta(30)).strftime('%Y-%m-%d'))
			if not valor_b: data_vencimento = False
			vals['data_vencimento'] = data_vencimento
			msg('data_vencimento: %s'%(data_vencimento))
		return self._change(cr, uid, ids, vals)
	def get_cabec_vals(self, cr, uid,oid):
		return {
			'vref': oid.vref,
			'data_emissao': oid.data_emissao,
			'period_id': oid.period_id and oid.period_id.id or False,
			'data_aprovacao': oid.data_aprovacao,
			'prazo': oid.prazo,
			'data_vencimento': oid.data_vencimento,
			'ano_id': oid.ano_id and oid.ano_id.id or False,
			
			'importador_id': oid.importador_id and oid.importador_id.id or False,
			'endereco_import': oid.endereco_import,
			'nuit_import': oid.nuit_import,
			
			'fornecedor_id': oid.fornecedor_id and oid.fornecedor_id.id or False,
			'pro_forma': oid.pro_forma,
			
			'director_id': oid.director_id and oid.director_id.id or False,
			'director_cpf': oid.director_cpf,
			'is_director': oid.is_director,
			'user_id': uid,
			
			'concurso_id': oid.concurso_id and oid.concurso_id.id or False,
			'tipo_bief': oid.tipo_bief,
			
			'state': oid.state,
			
			'moeda_id': oid.moeda_id and oid.moeda_id.id or False,
			'moeda_str': oid.moeda_str,
			'cambio': oid.cambio,
			'total_moeda': oid.total_moeda,
			
			'moeda_principal_id': oid.moeda_principal_id and oid.moeda_principal_id.id or False,
			'cambio_principal': oid.cambio_principal,
			'total_principal': oid.total_principal,
			
			'moeda_secundaria_id': oid.moeda_secundaria_id and oid.moeda_secundaria_id.id or False,
			'cambio_secundario': oid.cambio_secundario,
			'total_secundario': oid.total_secundario,
			'nota': oid.nota,
			
			# 'linha_ids': oid.xxxxxxxxxx,
			
			'quant': oid.quant,
			'preco': oid.preco,
			'total': oid.total,
			'libertado': oid.libertado,
			'from_historico': oid.from_historico,
			
			'anexo_1': oid.anexo_1,
			'anexo_1_name' : oid.anexo_1_name,
			'anexo_2': oid.anexo_2,
			'anexo_2_name' : oid.anexo_2_name,
			'anexo_3': oid.anexo_3,
			'anexo_3_name': oid.anexo_3_name,
			}

	def get_line_vals(self, cr, uid,oid):
		return {
			'parent_id': oid.parent_id and oid.parent_id.id or False,
			'importador_id': oid.importador_id and oid.importador_id.id or False,
			
			'numerador': oid.numerador,
			'fnm_code': oid.fnm_code,
			'nr_registo': oid.nr_registo,
			'prod_id': oid.prod_id and oid.prod_id.id or False,
			'comercial_name_id': oid.comercial_name_id and oid.comercial_name_id.id or False,
			
			'forma': oid.forma,
			'dosagem': oid.dosagem,
			'apresentacao': oid.apresentacao,
			'fabricante_id': oid.fabricante_id and oid.fabricante_id.id or False,
			
			'quant': oid.quant,
			'preco': oid.preco,
			'total': oid.total,
			'libertado': oid.libertado,
			}

	def save_bief(self, cr, uid,ids,context=None):
		bief_model = self.pool.get('dotcom.importacao.bief')
		linha_model = self.pool.get('dotcom.bief.linha')
		for document in self.browse(cr,uid,ids):
			if not document.linha_ids: error(action,'Documento sem Linhas')

			bief_id = bief_model.search(cr,uid,[('historico_id','=',ids[0])])
			cabec_vals =  self.get_cabec_vals(cr,uid,document)
			cabec_vals['historico_id'] = ids[0]
			cabec_vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'BIEF','full',context,True)
			
			if bief_id:
				bief_id = bief_id[0]
				for linha_id in bief_model.browse(cr,uid,bief_id).linha_ids:
					linha_model.unlink(cr,uid,[linha_id.id])
			if not bief_id:
				bief_id = bief_model.create(cr,uid,cabec_vals)

			for linha_id in document.linha_ids:
				line_vals =  self.get_line_vals(cr,uid,linha_id)
				line_vals['parent_id'] = bief_id
				linha_model.create(cr,uid,line_vals)
			self.write(cr,uid,ids,{'bief_id': bief_id})

	def calcular(self, cr, uid,ids,context=None):
		linha_model = self.pool.get('dotcom.historico.bief.linha')
		quant,preco,total = 0,0,0
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model.on_ch_a_b(cr,uid,[linha_id.id], linha_id.quant, linha_id.preco, 'quant', 'quant_preco')
				quant += linha_id.quant
				preco += linha_id.preco
				total += (linha_id.quant * linha_id.preco)
			vals = {'quant':quant, 'preco':preco, 'total':total}
			return self._change(cr, uid, ids, vals)

	def aprovar(self, cr, uid,ids,context=None):
		for document in self.browse(cr,uid,ids):
			self.calcular(cr, uid,ids,context)
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','hibi')#['bief','hibi','libe','capr','conc','quat','quce']
			data_aprovacao = date.today()
			vals = {'state':'aprovado','data_aprovacao':data_aprovacao}			
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'HIBI','full',context,True)
			# self.write(cr,uid,ids,vals)
			self._change(cr, uid, ids, vals)
			self.save_bief(cr,uid,ids,context)

	def cancelar(self, cr, uid,ids,context=None):
		bief_model = self.pool.get('dotcom.importacao.bief')
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','hibi')#['bief','hibi','libe','capr','conc','quat','quce']
			bief_model.write(cr,uid,[oid.bief_id.id],{'state':'cancelado'})
			self.write(cr,uid,ids,{'state':'cancelado'})

	def voltar_rascunho(self, cr, uid, ids, context=None):
		bief_model = self.pool.get('dotcom.importacao.bief')
		if context is None: context = {}
		for oid in self.browse(cr,uid,ids,context):
			vals = {'quant':0, 'preco':0, 'total':0, 'state':'rascunho_2'}
			self._change(cr, uid, ids, vals)
			bief_model.voltar_rascunho(cr,uid,[oid.bief_id.id],context)
			bief_model.write(cr,uid,[oid.bief_id.id],vals)
		return True

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_historico_bief, self).unlink(cr, uid, ids, context=context)

	def all_changes(self, cr, uid,ids,context=None):
		msg('bief.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.importador_id.id,'importador_id',context)
			self.on_ch_2(cr,uid,ids,oid.data_emissao,'data_emissao',oid.prazo,'prazo')
		return True

	def set_numerador(self, cr, uid, ids, context=None):
		msg('bief.set_numerador.ids:%s'%(ids))
		linha_model = self.pool.get('dotcom.historico.bief.linha')
		if context is None: context = {}
		numerador = 1
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}

		id = super(dotcom_historico_bief, self).create(cr, uid, vals, context=context)
		self.set_numerador(cr, uid,[id],context)
		self.all_changes(cr, uid,[id],context)		
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		val = super(dotcom_historico_bief, self).write(cr, uid, ids, vals, context=context)
		self.set_numerador(cr, uid,ids,context)
		return val
dotcom_historico_bief()	



class dotcom_historico_bief_linha(osv.osv):

	def print_context(self,cr,uid,ids, context=None):
		msg('print_context: %s'%context)
		return 0

	_name = 'dotcom.historico.bief.linha'
	_description = 'Linhas de BIEFs'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.historico.bief','BIEF', readonly=True),
		'importador_id':fields.related('parent_id','importador_id',type='many2one',relation='dotcom.parceiro.importador',string='Importador',readonly=True),

		'numerador': fields.integer('#', readonly=True),
		'fnm_code': fields.char('Código FNM', size=9,  readonly=True,help='Formulário Nacional de Medicamentos'),
		'nr_registo': fields.char('Nº registo', size=9, required=False, readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True,),		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=True, domain="[('prod_id','=',prod_id),('activo','=',True),('importador_id','=',importador_id)]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=True),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=True),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=True),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=False, readonly=True),

		'quant': fields.float('QTD', required=True), 
		'preco': fields.float('Preço', required=True), 
		'total': fields.float('Total', readonly=True), 
		'libertado': fields.boolean('Libertado', readonly=True,),
	}
	
	_defaults = {
		'quant': 0,
		'numerador': print_context,
		'importador_id':lambda self, cr, uid, c: c.get('importador_id', False),
	}
# dotcom.tesouraria.lancamento.movimentos
	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('hist_bief_linha.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'prod_id':
			if not valor: vals = {'comercial_name_id': False,}			
			# if valor:
			# 	oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
			# 	# cnid = (oid.comercial_name_id and oid.comercial_name_id.id)
			# 	vals = {'fnm_code': oid.fnm_code}
			return self._change(cr, uid, ids, vals)
		if descricao == 'comercial_name_id':
			if not valor: vals = {'fnm_code': False,'nr_registo': False, 'forma': False, 'dosagem': False, 'apresentacao': False, 'fabricante_id': False, }
			if valor:
				oid = self.pool.get('dotcom.prod.comercial_name').browse(cr,uid,valor)
				vals = {
					'nr_registo': oid.nr_registo,
					'fnm_code': oid.fnm_code,
					'forma': oid.forma,
					'dosagem': oid.dosagem,
					'apresentacao': oid.apresentacao,
					'fabricante_id': oid.fabricante_id.id,
					}
			return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('hist_bief_linha._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch_a_b(self, cr, uid, ids, a, b, campo, descricao, context=None):
		msg('hist_bief_linha.on_ch_a_b:%s, descricao: %s, a: %s,  b: %s'%(campo, descricao,a,b))
		if context is None: context = {}
		if descricao in ['quant_preco','preco_quant']:
			total = a * b
			self.write(cr,uid,ids,{'total':total})
			return self._change(cr, uid, ids, {'total':total})


	def all_changes(self, cr, uid,ids,context=None):
		msg('bief.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.prod_id.id,'prod_id',context)
			self.on_ch(cr,uid,ids,oid.comercial_name_id.id,'comercial_name_id',context)
			self.on_ch_a_b(cr,uid,ids,oid.quant,oid.preco,'preco_quant',context)			
			# self.on_ch(cr,uid,ids,oid.bief_id.id,'historico_bief_id',context)
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		query = [
			('parent_id','=',vals['parent_id']),
			('prod_id','=',vals['prod_id']),
			('comercial_name_id','=',vals['comercial_name_id']),
			# ('forma','=',vals['forma']),
			# ('dosagem','=',vals['dosagem']),
			# ('apresentacao','=',vals['apresentacao']),
			]
		ids = self.search(cr,uid,query)
		if ids: error(action,'Linha[#:%s] duplicada.\nNão se permite mais de uma linha com mesmas características.'%(self.browse(cr,uid,ids[0]).numerador))
		id = super(dotcom_historico_bief_linha, self).create(cr, uid, vals, context=context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	# def write(self, cr, uid, ids, vals, context=None):
	# 	if context is None: context = {}		
	# 	return super(dotcom_historico_bief_linha, self).write(cr, uid, ids, vals, context=context)


	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.parent_id and document.parent_id.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_historico_bief_linha, self).unlink(cr, uid, ids, context=context)

dotcom_historico_bief_linha()		

