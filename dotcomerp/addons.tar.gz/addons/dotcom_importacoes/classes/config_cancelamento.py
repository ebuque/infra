
# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)


MODEL = {
	'bief_id': 'dotcom.importacao.bief',
	'liberacao_id': 'dotcom.importacao.liberacao',
	'calc_preco_id': 'dotcom.calculo.precos',
	'eminota_id': 'dotcom.emissao.notas',
	'concurso_id': 'dotcom.lancamento.concurso',
	'quota_act_id': 'dotcom.quotas.actualizacao',
	'certificad_id': 'dotcom.quotas.certificado',
	'prod_id': 'dotcom.produto.farmaceutico',
	# 'quota_vig_id': 'dotcom.quotas.vigor',
	# 'transtitu_id': 'dotcom.transf.titularidades',
}

class dotcom_import_cancel(osv.osv):
	_name = 'dotcom.import.cancel'
	_description = 'Motivos de Cancelamento'
	_columns = {
		'user_id': fields.many2one('res.users', 'Usuário', readonly=True, required=True),
		'datetime': fields.datetime('Data e Hora', readonly=True, required=True),
		'motivo': fields.text('Motivo', required=True),
		'type': fields.selection([('rascunho_2','Voltar para Rascunho'),('cancelar','Cancelar'),('rejeitar','Rejeitar')],'Tipo de Movimento',required=True),
		
		'bief_id': fields.many2one('dotcom.importacao.bief', 'BIEF', readonly=True, required=False, ondelete='cascade'),
		'liberacao_id': fields.many2one('dotcom.importacao.liberacao', 'Libertação', readonly=True, required=False, ondelete='cascade'),
		'calc_preco_id': fields.many2one('dotcom.calculo.precos', 'Cálculo de Preços', readonly=True,ondelete='cascade'),
		# 'eminota_id': fields.many2one('dotcom.emissao.notas', 'Emissão de Notas', readonly=True,ondelete='cascade'),
		'concurso_id': fields.many2one('dotcom.lancamento.concurso', 'Concursos', readonly=True,ondelete='cascade'),
		'quota_act_id': fields.many2one('dotcom.quotas.actualizacao', 'Actualização de quotas', readonly=True,ondelete='cascade'),
		'certificad_id': fields.many2one('dotcom.quotas.certificado', 'Certificado', readonly=True,ondelete='cascade'),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico', 'Produto Farmacêutico', readonly=True,ondelete='cascade'),
		}
	_defaults = {#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'bief_id': lambda s, cr, u, c: c.get('bief_id',None),
		'liberacao_id': lambda s, cr, u, c: c.get('liberacao_id',None),
		'calc_preco_id': lambda s, cr, u, c: c.get('calc_preco_id',None),
		# 'eminota_id': lambda s, cr, u, c: c.get('eminota_id',None),
		'concurso_id': lambda s, cr, u, c: c.get('concurso_id',None),
		'quota_act_id': lambda s, cr, u, c: c.get('quota_act_id',None),
		'certificad_id': lambda s, cr, u, c: c.get('certificad_id',None),
		'prod_id': lambda s, cr, u, c: c.get('prod_id',None),

		'user_id': lambda s, cr, u, c: u,
		'motivo': lambda s, cr, u, c: c.get('motivo',None),
		'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
		'type': lambda s, cr, u, c: c.get('type','rascunho_2'),
		}
	_rec_name = 'user_id'
	_order = 'datetime DESC'
  
	def getVals(self, cr, uid, oid):
		vals = {}
		if oid.bief_id: 
			vals = {'model': MODEL['bief_id'], 'ids': oid.bief_id and [oid.bief_id.id] or []}
		elif oid.liberacao_id:
			vals = {'model': MODEL['liberacao_id'], 'ids': oid.liberacao_id and [oid.liberacao_id.id] or []}
		if oid.calc_preco_id:
			vals = {'model': MODEL['calc_preco_id'], 'ids': oid.calc_preco_id and [oid.calc_preco_id.id] or []}
		# if oid.eminota_id:
		# 	vals = {'model': MODEL['eminota_id'], 'ids': oid.eminota_id and [oid.eminota_id.id] or []}
		if oid.concurso_id:
			vals = {'model': MODEL['concurso_id'], 'ids': oid.concurso_id and [oid.concurso_id.id] or []}
		if oid.quota_act_id:
			vals = {'model': MODEL['quota_act_id'], 'ids': oid.quota_act_id and [oid.quota_act_id.id] or []}
		if oid.certificad_id:
			vals = {'model': MODEL['certificad_id'], 'ids': oid.certificad_id and [oid.certificad_id.id] or []}
		if oid.prod_id:
			vals = {'model': MODEL['prod_id'], 'ids': oid.prod_id and [oid.prod_id.id] or []}
		return vals

	def save(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for oid in self.browse(cr, uid, ids):
			motivo = oid.motivo or ''
			stripped = str(motivo).strip()
			tipo = oid.type or 'rascunho_2'
			required = context.get('required', False)
			if not stripped and required: raise osv.except_osv(_('Acção Inválida !'), _('Campo motivo não foi devidamente preenchido!'))
			if len(motivo) < 20 and required: osv.except_osv(_('Acção Inválida !'), _('Campo motivo deve ter no minimo 20 caracteres!'))

			vals = self.getVals(cr,uid,oid)
			msg('save ids: %s,      vals: %s,      motivo: %s'%(ids,vals,motivo))
			if tipo == 'rascunho_2': self.pool.get(vals['model']).run_voltar_rascunho(cr, uid, vals['ids'] , context=context)
			elif tipo == 'cancelar': self.pool.get(vals['model']).run_cancelar(cr, uid, vals['ids'] , context=context)
			elif tipo == 'rejeitar': self.pool.get(vals['model']).run_rejeitar(cr, uid, vals['ids'] , context=context)
		return {'type': 'ir.actions.act_window_close'}
	
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		if context.get('delete', False):
			super(dotcom_import_cancel, self).unlink(cr,uid,ids, context=context)
		else:
			raise osv.except_osv(_('Acção Inválida !'), _('Não é possivel eliminar logs!'))
		return True
	
	def cancel(self, cr, uid, ids,context=None):
		context.update({'delete': True})
		self.unlink(cr, uid, ids, context=context)
		return {'type': 'ir.actions.act_window_close'}
	
	def copy(self, cr, uid, id, default=None, context=None):
		if context is None: context = {}
		raise osv.except_osv(_('Acção Inválida !'), _('Não é possivel duplicar logs!'))
		return False
dotcom_import_cancel()