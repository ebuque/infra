# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_via_transporte(osv.osv):
	_name = 'dotcom.via.transporte'
	_description = 'Via de Transporte'
	_columns = {
		'ref': fields.char('Ref.', size=9, required=True, readonly=True),
		'name': fields.char('Nome', size=120, required=True),
		'prazo': fields.integer('Prazo(Dias)'), 
	}	
	_defaults = {
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'VTR', 'dotcom.via.transporte', context=c),
	}
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma Via de Transporte com esta referência!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'VTR', 'dotcom.via.transporte', context,True)
		id = super(dotcom_via_transporte, self).create(cr, uid, vals, context=context)
		return id
dotcom_via_transporte()	

class dotcom_quota_certificado(osv.osv):

	def get_activo(self, cr, uid, ids, name, arg, context=None):
		# msg('quotas_certificado.get_activo ids: %s'%(ids))
		res = {}
		for oid in self.browse(cr, uid, ids, context):
			activo = False
			now = date.today()
			vals = {'libertado': False}
			if oid.bief_id and oid.bief_id.libertado:
				msg('get_activo: %s bief_id: %s'%(oid.id,oid.bief_id.id))
				vals = {'libertado': True}
			if oid.state in ['aprovado'] and not oid.bief_id and not oid.libertado and oid.certificado_data and oid.data_vencimento:
				data_a = datetime.strptime(oid.data_aprovacao, '%Y-%m-%d').date() <= now
				data_v = datetime.strptime(oid.data_vencimento, '%Y-%m-%d').date() >= now
				# msg('data_a: %s,    data_v: %s'%(data_a,data_v))
				activo = data_a and data_v or False
			vals['activo'] = activo
			self._change(cr, uid, [oid.id], vals)
			res[oid.id] = activo
		return res

	_name = 'dotcom.quotas.certificado'
	_description = 'Certificados de Substâncias Controladas'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True),
		
		'data': fields.date('Data da Emissão', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True),
		'certificado_data': fields.date('Data Certificado', required=False, readonly=True, states={'validado':[('readonly',False)],}),
		'data_vencimento': fields.date('Data de Vencimento', required=False, readonly=True),
		
		'execute_method': fields.function(get_activo, method=True, string='Metodo Auxiliat', type='boolean'),
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True),
		# 'libertado':fields.related('bief_id','libertado',type='boolean',relation='dotcom.importacao.bief',string='Libertado', readonly=True),
		'libertado': fields.boolean('Libertado', readonly=True,),
		'activo': fields.boolean('Activo', readonly=True,),
		
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True, readonly=True),
		'period_id': fields.many2one('configuration.period','Período', required=True, readonly=True),
		
		'director_id': fields.many2one('dotcom.director.tecnico','Director', required=True, domain="['|',('importador_1_id','=',importador_id),('importador_2_id','=',importador_id),('active','=',True)]", readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'director_funcao': fields.char('Função', size=9, required=False, readonly=True),
		'dir_cpf': fields.char('CPF Nº', size=120, required=False, help='Inspecção Central do Exercicio Farmacêutico', readonly=True), #cpf=Inspecção Central do Exercicio Farmacêutico

		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', domain="[('activo','=',True),]", readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'import_endereco': fields.char('Endereço', size=120, required=False, readonly=True),	
		
		'via_id': fields.many2one('dotcom.via.transporte','Via', required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'prazo':fields.related('via_id','prazo',type='integer',relation='dotcom.via.transporte',string='Prazo(Dias)', readonly=True),
		'prazo_aux':fields.related('via_id','prazo',type='integer',relation='dotcom.via.transporte',string='Prazo(Dias)', readonly=True),
		'alfandega_id': fields.many2one('dotcom.terminal.alfandega','Terminal Alfandegário', required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'destinado': fields.char('Destinado á', size=120, required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'como': fields.char('Como', size=120, required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', domain="[('activo','=',True),]", readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'forn_pais_id': fields.many2one('res.country', 'País', readonly=True),
		'forn_endereco': fields.char('Endereço', size=120, required=False, readonly=True),

		'linha_ids': fields.one2many('dotcom.certificado.linha','parent_id','Linhas', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'movimento_ids': fields.one2many('reg.mov','certificad_id','Movimentos', readonly=True,),

		'state': fields.selection([
				('rascunho','Rascunho'),
				('submetido','Submetido'),
				('validado','Validado'),
				('aprovado','Aprovado'),
				('cancelado','Cancelado'),
				('rascunho_2','Rascunho'),
				],'Estado', select=True, readonly=True,),

		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','certificad_id','Cancelamentos', readonly=True,),
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'state': 'rascunho',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
	 }	
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já existe um Certificados de Substâncias Controladas com esta referência!')]


	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('quotas_certificado.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao and valor:
			if descricao == 'via_id':
				oid = self.pool.get('dotcom.via.transporte').browse(cr, uid, valor)
				return {'value': {'prazo': oid.prazo,'prazo_aux': oid.prazo,}}
			if descricao == 'director_id':
				oid = self.pool.get('dotcom.director.tecnico').browse(cr, uid, valor)
				return {'value': {'director_funcao': oid.funcao,'importador_id': (oid.importador_id and oid.importador_id.id) or False,'dir_cpf': oid.cpf,}}
			if descricao == 'importador_id':
				oid = self.pool.get('dotcom.parceiro.importador').browse(cr, uid, valor)
				return {'value': {'import_endereco': oid.endereco,}}
			if descricao == 'fornecedor_id':
				oid = self.pool.get('dotcom.parceiro.fornecedor').browse(cr, uid, valor)
				return {'value': {'forn_pais_id': (oid.pais_id and oid.pais_id.id) or False,'forn_endereco': oid.endereco,}}
			# elif descricao == 'data':
			# 	vals = {
			# 		'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
			# 		'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
			# 		}		
		return self._change(cr, uid, ids, vals)


	def on_ch_2(self, cr, uid, ids, valor_a, valor_b, descricao, context=None):
		msg('quotas_certificado.on_ch_2(%s), (%s_%s)'%(descricao,valor_a,valor_b))
		if context is None: context = {}

		vals = {}
		if descricao == 'certificado_data_prazo':
			if not valor_a:
				valor_a = date.today() #datetime.datetime.now().strftime('%Y-%m-%d')#datetime.strptime(data, '%Y-%m-%d')
				vals['certificado_data'] = valor_a
			valor_a = datetime.strptime(str(valor_a), '%Y-%m-%d')
			vals['period_id'] = self.pool.get('get.aux').get_period_id(cr, uid,valor_a)
			vals['ano_id'] = self.pool.get('get.aux').get_ano_id(cr, uid,valor_a)
			data_vencimento = str((valor_a + timedelta(valor_b)).strftime('%Y-%m-%d'))
			vals['data_vencimento'] = data_vencimento
		return self._change(cr, uid, ids, vals)

	def get_query(self, cr, uid,linha_id,parent_id):
		query = []
		if linha_id:
			query = [ 
				('parent_id','=', parent_id),
				('prod_id','=', linha_id.prod_id.id),
				('comercial_name_id','=', linha_id.comercial_name_id and linha_id.comercial_name_id.id or False),
			]
		return query

	def check_if(self, cr, uid,ids,context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			
			# if len(document.linha_ids) > 10: error(action,'O Certificado deve ter no máximo 10 linhas.')
			if not document.linha_ids: error(action,'O Certificado tem que ter pelo menos uma linha.')
			if document.director_id.importador_id.id != document.importador_id.id:
				error(action,'O Dir. Técnico não pertencem ao importador selecionado.')

			err_prod_import, err_medicamento = '',''
			for linha_id in document.linha_ids:
				if document.importador_id.id != linha_id.comercial_name_id.importador_id.id:
					err_prod_import += ('#:%s, '%linha_id.numerador)				
				if linha_id.prod_id.categoria != 'medicamento':#Produtos de Saúde
					err_medicamento +=  ('#:%s, '%linha_id.numerador)

			if len(err_prod_import) > 0: error(action,'Os produtos %s não pertencem ao importador "%s".'%(err_prod_import,document.importador_id.name))
			if len(err_medicamento) > 0: error(action,'Os produtos %s não são Medicamentos.'%(err_medicamento))

	def submeter(self, cr, uid,ids,context=None):
		msg('certificado.submeter ids: %s'%ids)
		linha_model = self.pool.get('dotcom.certificado.linha')
		self.check_if(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			vals = {'state': 'submetido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','quce')#['bief','hibi','libe','capr','conc','quat','quce']
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'CERT','full',context,True)
			for linha_id in document.linha_ids:
				linha_model.all_changes(cr, uid,[linha_id.id],context)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)

	def validar(self, cr, uid,ids,context=None):
		msg('certificado.validar ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.check_if(cr,uid,ids,context)
			self.pool.get('get.aux').check_act_doc(cr,uid,'validado','quce')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'validado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)

	def aprovar(self, cr, uid,ids,context=None):
		msg('certificado.aprovar ids: %s'%ids)
		self.check_if(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			data_aprovacao = date.today()
			if datetime.strptime(document.certificado_data, '%Y-%m-%d').date() < data_aprovacao:
				error(action,'Data da Aprovação não deve ser maior que a do Certificado')
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','quce')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'aprovado','data_aprovacao': data_aprovacao,})
			self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)

	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': None,
			'certificad_id': ids and ids[0] or None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_cancelar(self, cr, uid,ids,context=None):
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','quce')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)
		
	def run_voltar_rascunho(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for oid in self.browse(cr,uid,ids,context):
			vals = {'state': 'rascunho_2'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','quce')#['bief','hibi','libe','capr','conc','quat','quce']
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)
		return True

	def all_changes(self, cr, uid,ids,context=None):
		msg('certificado.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.importador_id.id,'importador_id',context)
			self.on_ch(cr,uid,ids,oid.director_id.id,'director_id')
			self.on_ch(cr,uid,ids,oid.via_id.id,'via_id')
			self.on_ch(cr,uid,ids,oid.fornecedor_id.id,'fornecedor_id')
			self.on_ch_2(cr,uid,ids,oid.data,oid.prazo,'certificado_data_prazo')
		return True

	def set_numerador(self, cr, uid, ids, context=None):
		msg('certificado.set_numerador.ids:%s'%(ids))
		linha_model = self.pool.get('dotcom.certificado.linha')
		if context is None: context = {}
		numerador = 1
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		# seq_model = self.pool.get('dotcom.sequencia')
		# vals['doc_numero'] =  seq_model._nr_get(cr,uid,'CERT','full',context,True)

		id = super(dotcom_quota_certificado, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': id},context)
		self.set_numerador(cr, uid,[id],context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		val = super(dotcom_quota_certificado, self).write(cr, uid, ids, vals, context=context)
		self.set_numerador(cr, uid,ids,context)	
		return val

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_quota_certificado, self).unlink(cr, uid, ids, context=context)
		
dotcom_quota_certificado()	



class dotcom_certificado_linha(osv.osv):
	_name = 'dotcom.certificado.linha'
	_description = 'Linhas de certificados'
	#_rec_name = 'name'
	_columns = {

		'parent_id': fields.many2one('dotcom.quotas.certificado','Certificado', readonly=True),	
		'importador_id':fields.related('parent_id','importador_id',type='many2one',relation='dotcom.parceiro.importador',string='Importador',readonly=True),

		'numerador': fields.integer('#', readonly=True),
		'fnm_code': fields.char('Código FNM', size=9,  readonly=True,help='Formulário Nacional de Medicamentos'),
		'nr_registo': fields.char('Nº registo', size=9, required=False, readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True,domain="[('subs_controlada','=',True),]",),
		'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo de Subs.', readonly=True,),		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=True, domain="[('prod_id','=',prod_id),('activo','=',True),('importador_id','=',importador_id)]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=True),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=True),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=True),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=False, readonly=True),

		'sal_id': fields.many2one('dotcom.prod.sal', 'Sal', required=True, domain="[('prod_id','=',prod_id)]"),
		'fact_conv': fields.float('Factor de Conversão', digits=(1,2),  required=False, readonly=True,),
		'subs_pura': fields.float('Subs. Pura(g)', digits=(1,6), required=True, readonly=False,), 
		'qtd_total': fields.float('QTD Total', digits=(1,6),  required=False, readonly=False,), 
		'quant': fields.float('QTD', digits=(1,6),  required=True, readonly=True,), 
	}
	# _rec_name = 'name'
	_defaults = {
		'quant': 0,
		'numerador': 0,
	}
	
	def on_ch_conv(self, cr, uid, ids, fact_conv, subs_pura, qtd_total, context=None):
		msg('certificado_linha.on_ch_conv(fact_conv: %s, subs_pura: %s, qtd_total: %s)'%(fact_conv, subs_pura, qtd_total))
		if context is None: context = {}
		qtd = (subs_pura*qtd_total*fact_conv*0.01) # msg('res: %s quant: %s'%(res,quant))
		return self._change(cr, uid, ids, {'quant': qtd,})

	def on_ch_quant(self, cr, uid, ids, fact_conv, subs_pura, qtd_total, quant, context=None):
		msg('certificado_linha.on_ch_quant: %s'%quant)
		if context is None: context = {}
		qtd = (subs_pura*qtd_total*fact_conv*0.01) # msg('res: %s quant: %s'%(res,quant))
		return self._change(cr, uid, ids, {'quant': qtd,})

	def save(self, cr, uid, ids, context=None):
		if context is None: context = {}
		msg('certificado_linha.save: %s'%ids)
		for d in self.browse(cr, uid, ids):
			self.on_ch_conv(cr,uid,ids, d.fact_conv, d.subs_pura, d.qtd_total)
		return {'type': 'ir.actions.act_window_close'}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('bief_linha.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'prod_id':
			if not valor: vals = {'tipo_prod': False,'comercial_name_id': False,}			
			if valor:
				oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
				# cnid = (oid.comercial_name_id and oid.comercial_name_id.id)
				vals = {'tipo_prod': oid.tipo_prod}
			return self._change(cr, uid, ids, vals)
		if descricao == 'comercial_name_id':
			if not valor: vals = {'fnm_code': False,'nr_registo': False, 'forma': False, 'dosagem': False, 'apresentacao': False, 'fabricante_id': False, }
			if valor:
				oid = self.pool.get('dotcom.prod.comercial_name').browse(cr,uid,valor)
				vals = {
					'nr_registo': oid.nr_registo,
					'fnm_code': oid.fnm_code,
					'forma': oid.forma,
					'dosagem': oid.dosagem,
					'apresentacao': oid.apresentacao,
					'fabricante_id': oid.fabricante_id.id,
					}
			return self._change(cr, uid, ids, vals)
		if descricao == 'sal_id':
			if not valor: vals = {'fact_conv': 0}			
			if valor:
				vals = {'fact_conv': self.pool.get('dotcom.prod.sal').browse(cr,uid,valor).fact_conv}
			return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('bief._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}	 

	def all_changes(self, cr, uid,ids,context=None):
		msg('bief.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.prod_id.id,'prod_id',context)
			self.on_ch(cr,uid,ids,oid.comercial_name_id.id,'comercial_name_id',context)
			self.on_ch(cr,uid,ids,oid.sal_id.id,'sal_id',context)
			self.on_ch_quant(cr,uid,ids,oid.fact_conv,oid.subs_pura,oid.qtd_total,oid.quant)
			self.on_ch_conv(cr,uid,ids,oid.fact_conv,oid.subs_pura,oid.qtd_total)
			# self.on_ch(cr,uid,ids,oid.bief_id.id,'bief_id',context)
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		query = [
			('parent_id','=',vals['parent_id']),
			('prod_id','=',vals['prod_id']),
			('comercial_name_id','=',vals['comercial_name_id']),
			]
		ids = self.search(cr,uid,query)
		if ids: error(action,'Linha[#:%s] duplicada.\nNão se permite mais de uma linha com mesmas características.'%(self.browse(cr,uid,ids[0]).numerador))
		id = super(dotcom_certificado_linha, self).create(cr, uid, vals, context=context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}		
		return super(dotcom_certificado_linha, self).write(cr, uid, ids, vals, context=context)


	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.parent_id and document.parent_id.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_certificado_linha, self).unlink(cr, uid, ids, context=context)

dotcom_certificado_linha()	