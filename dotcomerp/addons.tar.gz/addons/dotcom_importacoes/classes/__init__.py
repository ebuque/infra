# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2014 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import dotcom_importacao_bief
import dotcom_historico_bief
import dotcom_importacao_liberacao
import dotcom_quota_vigor
import dotcom_quota_certificado
import dotcom_quota_actualizacao
import dotcom_sequencia
import validacoes
import dotcom_num_registo
import dotcom_calculo_precos
import dotcom_lancamento_concurso
# import dotcom_unidade_medida
import dotcom_emissao_notas
import config_cancelamento
import dotcom_registo_movimentos