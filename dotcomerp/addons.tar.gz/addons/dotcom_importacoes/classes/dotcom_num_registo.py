# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_num_registo(osv.osv):
	_name = 'dotcom.num.registo'
	_description = 'Numero de registo'
	_columns = {
		'ref': fields.char('Ref.', size=9, required=True, readonly=True),
		'name': fields.char('Nome', size=120, required=True),
	}
	_defaults = {
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'NRE', 'dotcom.num.registo', context=c),
	}	
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe um Numero de registo com esta referência!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'NRE', 'dotcom.num.registo', context,True)
		id = super(dotcom_num_registo, self).create(cr, uid, vals, context=context)
		return id
dotcom_num_registo()	