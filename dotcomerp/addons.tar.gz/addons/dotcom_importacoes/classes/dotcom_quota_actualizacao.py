# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class dotcom_quotas_actualizacao(osv.osv):

	_name = 'dotcom.quotas.actualizacao'
	_description = 'Actualização de quotas'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True, readonly=True,),
		'ano_vigor_id': fields.many2one('configuration.fiscalyear','Ano Fiscal a Vigorar', required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'period_id': fields.many2one('configuration.period','Período', required=True, readonly=True),
		'data': fields.date('Data da Emissão', required=False, readonly=True),
		'tipo': fields.selection([('adenda','Adenda'),('renovacao','Renovação'),],'Tipo', required=True, readonly=True, states={'rascunho':[('readonly',False)],}),
		'linha_ids': fields.one2many('dotcom.quotas.linha','parent_id','Linhas', readonly=False, states={'submetido':[('readonly',True)],'aprovado':[('readonly',True)]}),
		'movimento_ids': fields.one2many('reg.mov','quota_act_id','Movimentos', readonly=True,),
		# 'ano_base_renovacao_ids': fields.one2many('dotcom.anos.base.renovacao','parent_id','Anos Base Renovação', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'ano_base_renovacao_ids': fields.many2many('dotcom.anos.base.renovacao','anos_base_renovacao_rel','parent_id','ano_id','Anos Base Renovação', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'state': fields.selection([
				('rascunho','Rascunho'),
				('submetido','Submetido'),
				('autorizar','Autorizar'),
				('aprovado','Aprovado'),
				('cancelado','Cancelado'),
				('rascunho_2','Rascunho'),
				],'Estado', select=True, readonly=True,),
		# 'em_vigor': fields.boolean('Em Vigor', readonly=True),
		'data_aprovacao': fields.date('Data da aprovação', required=False, readonly=True),
		'fact_conv': fields.float('Factor de Conversão', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','quota_act_id','Cancelamentos', readonly=True,),
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'state': 'rascunho',
		'ano_id': lambda self, cr, uid, c: self.pool.get('configuration.fiscalyear').find(cr, uid),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
		'tipo': 'adenda',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
	 }	
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já existe uma Actualização de Quota com esta referência!')]

	# def unlink(self, cr, uid, ids, context=None):
	# 	if context is None: context = {}
	# 	for document in self.browse(cr,uid,ids): 
	# 		if document.state not in ['rascunho',]:error(action,'Não é possível eliminar documentos no estado "%s".'%document.state)
	# 	return super(dotcom_quotas_actualizacao, self).unlink(cr, uid, ids, context=context)
		
	def open_wiz(self, cr, uid, ids , context=False):
		anos_model = self.pool.get('dotcom.anos.base.renovacao')
		ano_base_renovacao_ids = False
		fact_conv = 0

		for oid in self.browse(cr,uid,ids):
			ano_base_renovacao_ids = [linha_id.id for linha_id in oid.ano_base_renovacao_ids] or []
			fact_conv = oid.fact_conv
		msg('quota.open_wiz: (ano_base_renovacao_ids: %s, fact_conv: %s)'%(ano_base_renovacao_ids,fact_conv))
		return {
			'name': 'Introdução de Produto Farmacêutico',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.quo.act.get.prods',
			'type': 'ir.actions.act_window',
			'context': {
				'quo_act_id': ids and ids[0],
				'ano_base_renovacao_ids': ano_base_renovacao_ids,
				'fact_conv': fact_conv,
				},
			'target':'new',
			}


	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('quota.actualizacao.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'fact_conv':
			if (valor > 100 or valor < 0): self._change(cr, uid, ids, {'fact_conv': 0,})
		if descricao == 'tipo': 
			linha_model = self.pool.get('dotcom.quotas.linha')
			for document in self.browse(cr,uid,ids):
				for linha_id in document.linha_ids:
					linha_model.unlink(cr,uid,[linha_id.id])
			vals = {'linha_ids': False}
			if valor == 'adenda':
				vals['fact_conv'] = 0
			return self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('quota.actualizacao._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def all_changes(self, cr, uid,ids,context=None):
		msg('quota.actualizacao.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.fact_conv,'fact_conv',context)
			self.on_ch(cr,uid,ids,oid.tipo,'tipo',context)
		return True

	def validar(self, cr, uid,ids,context=None):
		if context is None: context = {}
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		quota_autorizada_err, quota_err, quota_vs_err = '','',''
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids: 
				if linha_id.quota <= 0: quota_err += ('#:%s, '%linha_id.numerador)
				msg('state: %s   quota_autorizada: %s'%(document.state,linha_id.quota_autorizada))
				if linha_id.quota_autorizada <= 0 and document.state == 'autorizar': quota_autorizada_err += ('#:%s, '%linha_id.numerador)
				if linha_id.quota_autorizada > linha_id.quota: quota_vs_err += ('#:%s, '%linha_id.numerador)
			
			vigor_ids = vigor_model.search(cr,uid,[('ano_id','=',document.ano_vigor_id.id),('em_vigor','=',True)])
			# if len(vigor_ids) > 1:
			# 	 error(action,'Existem %s quota em vigor para o ano de %s.'%(len(vigor_ids),document.ano_vigor_id.name))
			if document.tipo == 'adenda' and not vigor_ids:
				 error(action,'Adenda negada!\nNão existe quota em vigor para o ano de %s.'%document.ano_vigor_id.name)
			if document.tipo == 'renovacao' and vigor_ids:
				 error(action,'Renovação negada!\Já existe Renovação em vigor para o ano de %s.'%document.ano_vigor_id.name)
			if len(quota_err) > 0: error(action,'A quota solicitada da/s linha/s %s são inválidas.'%(quota_err))
			if len(quota_autorizada_err) > 0: error(action,'A quota autorizada da/s linha/s %s são inválidas ao aprovar.'%(quota_autorizada_err))
			if len(quota_vs_err) > 0: error(action,'Quota autorizada superior que solicitada na/s linha/s %s.'%(quota_vs_err))


	# def processar(self, cr, uid,ids,context=None):
	# 	msg('actualizacao.processar. ids: %s'%ids)
	# 	if context is None: context = {}
	# 	linha_model = self.pool.get('dotcom.quotas.linha')
	# 	prod_model = self.pool.get('dotcom.produto.farmaceutico')

	# 	for document in self.browse(cr,uid,ids):
	# 		for linha in document.linha_ids:
	# 			linha_model.unlink(cr, uid, linha.id)

	# 		prod_ids = prod_model.search(cr,uid,[('categoria','=','medicamento'),('subs_controlada','=',True)])
	# 		for linha in prod_model.browse(cr,uid,prod_ids):
	# 			vals = {'parent_id': ids[0],'prod_id': linha.id,'tipo_prod': linha.tipo_prod,}
	# 			qlid = linha_model.create(cr,uid,vals)
	# 			linha_model.on_ch(cr,uid,[qlid],linha.id,'prod_id')
	# 	return True

	def submeter(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.submeter ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		tipo = 'QREN'
		for document in self.browse(cr,uid,ids):
			if document.tipo == 'adenda': tipo = 'QADE'
			vals = {'state': 'submetido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','quat')#['bief','hibi','libe','capr','conc','quat','quce']
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,tipo,'full',context,True)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)

	def autorizar(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.autorizar ids: %s'%ids)
		linha_model = self.pool.get('dotcom.quotas.linha')
		self.validar(cr,uid,ids,context)
		vals = {}
		for document in self.browse(cr,uid,ids):
			vals['state'] = 'autorizar'
			self.pool.get('get.aux').check_act_doc(cr,uid,'autorizar','quat')#['bief','hibi','libe','capr','conc','quat','quce']
			for linha_id in document.linha_ids:
				msg('%s) quota: %s'%(linha_id.numerador,linha_id.quota))
				linha_model._change(cr, uid, [linha_id.id], {'quota_autorizada': linha_id.quota})
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)

	def aprovar(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.aprovar ids: %s'%ids)
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		historico_model = self.pool.get('dotcom.quotas.historico')		
		anos_model = self.pool.get('dotcom.anos.base.renovacao')
		self.validar(cr,uid,ids,context)
		vals = {}
		for document in self.browse(cr,uid,ids):
			vals['data_aprovacao'] = datetime.now().strftime('%Y-%m-%d')
			vals['state'] = 'aprovado'
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','quat')#['bief','hibi','libe','capr','conc','quat','quce']
			msg('quotas.actualizacao.vals: %s'%vals)
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)
 
			vigor_ids = vigor_model.search(cr,uid,[('ano_id','=',document.ano_vigor_id.id),('em_vigor','=',True)])

			vals_vigor, vals_hist = {}, {}
			for linha_id in document.linha_ids:
				vals_vigor = {
					'ref_prod': linha_id.prod_id.ref,
					'prod_id': linha_id.prod_id.id,
					'tipo_prod': linha_id.prod_id.tipo_prod,
					'quota': linha_id.quota,
					'ano_id': document.ano_vigor_id.id,
					# 'diferenca': 0,
					'data_actualizacao': datetime.now().strftime('%Y-%m-%d'),
					# 'quota_importada_perc': 0,
					'em_vigor': True,
					# 'historico_ids': document.xxxxxxx,
					}
				vals_hist = {
					'name': '[%s]%s/%s/%s'%(linha_id.prod_id.ref,linha_id.prod_id.name,document.ano_vigor_id.name,document.tipo),
					'parent_id': False,
					'act_linha_id': linha_id.id,
					'prod_id': linha_id.prod_id.id,
					'processo': document.tipo,
					'ano_id': document.ano_vigor_id.id,
					'period_id': document.period_id.id,
					'data': document.data,
					'quota': linha_id.quota,
					'em_vigor': True,
					}

				if document.tipo == 'renovacao' and not vigor_ids:
					vigor_id = vigor_model.create(cr,uid,vals_vigor)
					vals_hist['parent_id'] = vigor_id
					msg('  1. vals_hist: %s'%vals_hist)
					historico_model.create(cr,uid,vals_hist)
					msg('  2. vals_hist: %s'%vals_hist)
					if not anos_model.search(cr,uid,[('ano_id','=',document.ano_vigor_id.id)]):
						anos_model.create(cr,uid,{'parent_id': ids[0],'vigor_id': vigor_id,'ano_id': document.ano_vigor_id.id})

				if document.tipo == 'adenda' and vigor_ids:
					vigor_id = vigor_model.search(cr,uid,[('ano_id','=',document.ano_vigor_id.id),('em_vigor','=',True),('prod_id','=',linha_id.prod_id.id)])
					if not vigor_id:
						vigor_id = [vigor_model.create(cr,uid,vals_vigor)]
						vals_hist['parent_id'] = vigor_id[0]
						historico_model.create(cr,uid,vals_hist)
					else:
						oid = vigor_model.browse(cr,uid,vigor_id[0])
						vals_vigor = {'quota': (oid.quota + linha_id.quota),}
						vigor_model.write(cr,uid,vigor_id,vals_vigor)

						vals_hist['parent_id'] = vigor_id[0]
						historico_model.create(cr,uid,vals_hist)
		return True

	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': ids and ids[0] or None,
			'certificad_id': None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_cancelar(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.cancelar ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','quat')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)

	def run_voltar_rascunho(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.voltar_rascunho ids: %s'%ids)
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		historico_model = self.pool.get('dotcom.quotas.historico')
		vals = {}
		# return self._change(cr, uid, ids, {'state':'submetido'})
		for document in self.browse(cr,uid,ids):

			vals_vigor, vals_hist = {}, {}
			for linha_id in document.linha_ids:
				query = [('ano_id','=',document.ano_vigor_id.id),('em_vigor','=',True),('prod_id','=',linha_id.prod_id.id)]
				vigor_ids = vigor_model.search(cr,uid,query)
				msg('vigor_ids: %s'%vigor_ids)
				if not vigor_ids: error(action,'Quota em vigor não encontrada!')
				if len(vigor_ids) > 1: error(action,'Tem mais de uma quota em vigor para este produto!')

				vigor_id = vigor_model.browse(cr,uid,vigor_ids[0])
				data_actualizacao = datetime.strptime(str(vigor_id.data_actualizacao), '%Y-%m-%d')
				data_bief = False
				if vigor_id.data_bief:
					data_bief = datetime.strptime(str(vigor_id.data_bief), '%Y-%m-%d')
				act_linha_ids = [hid.act_linha_id for hid in vigor_id.historico_ids]

				msg('data_actualizacao: %s, data_bief: %s, act_linha_ids: %s'%(data_actualizacao,data_bief,act_linha_ids))
				if data_bief and data_bief > data_actualizacao: error('Acção Inválida!','Esta quota já possui movimentos!')

				if document.tipo == 'renovacao':
					for hid in vigor_id.historico_ids:
						historico_model.unlink(cr, uid, [hid.id])
					vigor_model.unlink(cr, uid, [vigor_id.id])

				if document.tipo == 'adenda':
					if linha_id.id in act_linha_ids:
						vigor_model.write(cr,uid,vigor_id.id,{'quota': (vigor_id.quota - linha_id.quota),})
						historico_model.unlink(cr, uid, act_linha_ids)
						
			vals['data_aprovacao'] = False
			vals['state'] = 'rascunho_2'
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','quat')#['bief','hibi','libe','capr','conc','quat','quce']
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)

	def imprimir(self, cr, uid,ids,context=None):
		msg('quotas.actualizacao.imprimir ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'submetido'})

	def validar_unlink(self, cr, uid, ids, operacao, context=None):
		if context is None: context = {}
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		for document in self.browse(cr,uid,ids): 
			src_ids = vigor_model.search(cr,uid,[('state','not in',['rascunho','cancelado']),])
			if src_ids: error(action,'Não é possível %s!\nEste documento já foi mencionado em outro.'%operacao)
		
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error(action,'Não é possível eliminar documentos no estado "%s".'%document.state)
		# self.validar_unlink(cr,uid,ids,'eliminar')
		return super(dotcom_quotas_actualizacao, self).unlink(cr,uid,ids,context=context)

	def set_numerador(self, cr, uid, ids, context=None):
		msg('quota.set_numerador.ids:%s'%(ids))
		linha_model = self.pool.get('dotcom.quotas.linha')
		if context is None: context = {}
		numerador = 1
		for document in self.browse(cr,uid,ids):
			for linha_id in document.linha_ids:
				linha_model._change(cr, uid, [linha_id.id], {'numerador': numerador}, context)
				numerador += 1
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		anos_model = self.pool.get('dotcom.anos.base.renovacao')
		id = super(dotcom_quotas_actualizacao, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': id},context)
		self.set_numerador(cr, uid,[id],context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		val = super(dotcom_quotas_actualizacao, self).write(cr, uid, ids, vals, context=context)
		self.set_numerador(cr, uid,ids,context)	
		return val
dotcom_quotas_actualizacao()	

act_states=[
	('rascunho','Rascunho'),
	('submetido','Submetido'),
	('autorizar','Autorizar'),
	('aprovado','Aprovado'),
	('cancelado','Cancelado'),
	('rascunho_2','Rascunho'),
]

class dotcom_quotas_linha(osv.osv):
	def get_max_id(self, cr, uid, context=None):
		model = self.pool.get('dotcom.quotas.linha')
		ids = model.search(cr,uid,[])
		return (ids and max(ids)) or 0

	_name = 'dotcom.quotas.linha'
	_description = 'Linhas das quotas'
	#_rec_name = 'name'
	_columns = {
		'numerador': fields.integer('#', readonly=True),
		'parent_id': fields.many2one('dotcom.quotas.actualizacao','Quota', readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True, readonly=True, domain="[('subs_controlada','=',True),]",),
		'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo de Substância', readonly=True,),
		'state':fields.related('parent_id','state',type='selection',selection=act_states,relation='dotcom.quotas.actualizacao',string='Estado', store=True, readonly=True),
		'quota': fields.float('Quota Solicitada', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'quota_autorizada': fields.float('Quota Autorizada', required=False, readonly=True, states={'autorizar':[('readonly',False)]}),
		'ano_vigor_id':fields.related('parent_id','ano_vigor_id',type='many2one',relation='configuration.fiscalyear',string='Ano Fiscal a Vigorar',readonly=True),
		'tipo': fields.selection([('adenda','Adenda'),('renovacao','Renovação'),],'Tipo', readonly=True,),
		'anos_base_ren_hist_ids': fields.one2many('quo.act.get.prods.hist','parent_id','Linhas', readonly=True,),
	}
	_defaults = {
		'quota': 0,
	}


	# def open_details(self, cr, uid, ids , context=False):
	# 	anos_model = self.pool.get('dotcom.anos.base.renovacao')
	# 	ano_base_renovacao_ids = False
	# 	fact_conv = 0

	# 	for oid in self.browse(cr,uid,ids):
	# 		ano_base_renovacao_ids = [linha_id.id for linha_id in oid.ano_base_renovacao_ids] or []
	# 		fact_conv = oid.fact_conv
	# 	msg('quota.open_wiz: (ano_base_renovacao_ids: %s, fact_conv: %s)'%(ano_base_renovacao_ids,fact_conv))
	# 	return {
	# 		'name': 'Anos Base da Renovação',
	# 		'view_type': 'form',
	# 		'view_mode': 'form',
	# 		'res_model': 'dotcom.quotas.linha',
	# 		'type': 'ir.actions.act_window',
	# 		'context': {
	# 			'quo_act_id': ids and ids[0],
	# 			'ano_base_renovacao_ids': ano_base_renovacao_ids,
	# 			'fact_conv': fact_conv,
	# 			},
	# 		'target':'new',
	# 		}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('quota.actualizacao.linha.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'prod_id':
			if not valor: vals = {'tipo_prod': False,}
			if valor:
				ob_id = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
				vals = {'tipo_prod': ob_id.tipo_prod,}
			self._change(cr, uid, ids, vals)

	def _change(self, cr, uid, ids, vals, context=None):
		msg('quota.actualizacao.linha._change: %s'%vals)
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def all_changes(self, cr, uid,ids,context=None):
		msg('quota.actualizacao.linha.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.prod_id.id,'prod_id',context)
		return True

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		id = super(dotcom_quotas_linha, self).create(cr, uid, vals, context=context)
		self.all_changes(cr, uid,[id],context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}		
		return super(dotcom_quotas_linha, self).write(cr, uid, ids, vals, context=context)
		
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.parent_id and document.parent_id.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_quotas_linha, self).unlink(cr, uid, ids, context=context)
dotcom_quotas_linha()


class dotcom_anos_base_renovacao(osv.osv):
	_name = 'dotcom.anos.base.renovacao'
	_description = 'Anos Base Renovação'
	_columns = {
		'parent_id': fields.many2one('dotcom.quotas.actualizacao','Quota', readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,),
		'vigor_id': fields.many2one('dotcom.quotas.vigor', 'Quota', readonly=True),
	}
	_rec_name = 'ano_id'
	# _sql_constraints = [('ano_id_unique', 'unique(ano_id)', 'Já existe um "Ano Base de Renovação" com este ano!')]
dotcom_anos_base_renovacao()


class dotcom_quo_act_get_prods(osv.osv_memory):
	_name = 'dotcom.quo.act.get.prods'
	_columns = {
		'prod_ids': fields.many2many('dotcom.produto.farmaceutico','quo_act_prods_rel','quo_act_id','prod_id','Produtos', domain="[('subs_controlada','=',True)]"),
		'quo_act_id': fields.many2one('dotcom.quotas.actualizacao', 'Actualização', readonly=True),
		# 'ano_base_renovacao_ids': fields.one2many('dotcom.anos.base.renovacao','linha_id','Anos Base Renovação', readonly=False,),
		'fact_conv': fields.float('Factor de Conversão', required=False, readonly=True),
		'ano_base_renovacao_ids': fields.many2many('dotcom.anos.base.renovacao','base_ren_get_prod_rel','get_prod','ano_base_id','Ano Base Renovacao'),
	}
	_rec_name = 'quo_act_id'
	_defaults = {
		'quo_act_id': lambda self, cr, uid, c: c.get('quo_act_id',False),
		'ano_base_renovacao_ids': lambda self, cr, uid, c: c.get('ano_base_renovacao_ids',False),
		'fact_conv': lambda self, cr, uid, c: c.get('fact_conv',False),
		}
	
	def update_prods(self, cr, uid, ids, context=None):
		if context is None: context = {}
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		quo_act_model = self.pool.get('dotcom.quotas.actualizacao')
		linha_model = self.pool.get('dotcom.quotas.linha')
		anos_base_model = self.pool.get('dotcom.anos.base.renovacao')
		get_prod_hist_model = self.pool.get('quo.act.get.prods.hist')
		for oid in self.browse(cr,uid,ids):
			if not oid.quo_act_id: break
			if oid.quo_act_id.state not in ['rascunho','rascunho_2']:
				error(action,'Não é possível actualizar documentos no estado "%s".'% oid.quo_act_id.state)
			linha_ids = [linha_id.id for linha_id in oid.quo_act_id.linha_ids]
			linha_model.unlink(cr,uid,linha_ids)
			# ano_base_renovacao_ids = anos_base_model.browse(cr,uid,context.get('ano_base_renovacao_ids',False))

			msg('unlink_linha_ids: %s,   ano_base_renovacao_ids: %s'%(linha_ids,oid.ano_base_renovacao_ids))
			ano_ids = [linha_id.ano_id.id for linha_id in oid.ano_base_renovacao_ids] or []
			numerador = 1
			for prod_id in oid.prod_ids:
				soma, media, quota, fact_conv = 0,0,0,oid.fact_conv
				if oid.ano_base_renovacao_ids and fact_conv <= 0: error(action,'Informe o Factor de Conversão.')
				if fact_conv >= 1: fact_conv = fact_conv/100
				hist_list = []
				if oid.ano_base_renovacao_ids and fact_conv > 0:
					query = [('ano_id','in',ano_ids),('prod_id','=',prod_id.id),]
					linha_ids = vigor_model.search(cr,uid,query)
					if not linha_ids: error(action,'Não houve quotas em vigor nos anos seleccionados para o produto "[%s]%s".'%(prod_id.ref,prod_id.name))
					for vigor_id in vigor_model.browse(cr,uid,linha_ids):
						soma += vigor_id.quota						
						vals_hist = {
							'parent_id': False,
							'get_prods_id': ids[0],
							'act_id': oid.quo_act_id.id,
							'prod_id': prod_id.id,
							'vigor_id': vigor_id.id,
							'ano_id': vigor_id.ano_id.id,
							'quota': vigor_id.quota,
						}
						hist_list.append(vals_hist)
					media = soma/len(linha_ids)
					quota = soma + (soma * fact_conv)

				vals = {
					'numerador': numerador,
					'prod_id': prod_id.id,
					'parent_id': oid.quo_act_id.id,
					'tipo': oid.quo_act_id.tipo,
					'quota': quota,
					}
				numerador += 1
				linha_id = linha_model.create(cr,uid,vals)
				for vals_hist in hist_list:
					vals_hist['parent_id'] = linha_id
					get_prod_hist_model.create(cr,uid,vals_hist)
		return {'type': 'ir.actions.act_window_close'}
dotcom_quo_act_get_prods()


class quo_act_get_prods_hist(osv.osv_memory):
	_name = 'quo.act.get.prods.hist'
	_columns = {
		'parent_id': fields.many2one('dotcom.quotas.linha', 'Linha Parente', readonly=True),
		'get_prods_id': fields.many2one('dotcom.quo.act.get.prods', 'Gerador de Produtos', readonly=True),
		'act_id': fields.many2one('dotcom.quotas.actualizacao', 'Actualização', readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico', 'Produto', readonly=True),
		'vigor_id': fields.many2one('dotcom.quotas.vigor', 'Quota', readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False, readonly=True,),
		'quota': fields.float('Quota', required=False, readonly=True),
		'quota': fields.float('Quota', required=False, readonly=True),
	}
quo_act_get_prods_hist()