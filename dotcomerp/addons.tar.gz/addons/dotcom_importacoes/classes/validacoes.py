# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

action = 'Acção Inválida!'

STATE = {
	'rascunho': 'Rascunho',
	'submetido': 'Submeter',
	'validar': 'Validar',
	'validado': 'Validado',
	'aprovado': 'Aprovar',
	'rejeitado': 'Rejeitar',
	'cancelado': 'Cancelar',
	'rascunho_2': 'Voltar à Rascunho',
	'autorizar': 'Autorizar',
	'emitido': 'Emitir',
	'definido': 'Agendamento',
	}

OBJ = {
	'bief': 'BIEF',
	'hibi': 'Hist. BIEF',
	'libe': 'Libertação',
	'capr': 'Cálc. Preços',
	'conc': 'Concursos',
	'quat': 'Act. Quotas',
	'quce': 'Cert. Quotas',
	}

SPC = '►'

DOC = {
	'bief': 'BIEF',
	'hibi': 'Histórico de BIEF',
	'libe': 'Libertação',
	'capr': 'Cálculo de Preços',
	'conc': 'Concursos',
	'quat': 'Actualização de Quotas',
	'quce': 'Certificados de Quotas',
	}

class get_aux(osv.osv):
	_name = 'get.aux'
	_description = 'Metodos Auxiliares'

	def validar(self, cr, uid, ids, name, arg, context=None):
		msg('validar: %s'%ids)
		res_model = self.pool.get('res.groups')
		ir_model = self.pool.get('ir.module.category')
		vals = {}

		s_bief = ['rascunho','submetido','validar','validado','aprovado','rejeitado','cancelado','rascunho_2']
		s_hst_bief = ['rascunho','submetido','validar','validado','aprovado','rejeitado','cancelado','rascunho_2']
		s_liberacao = ['rascunho','submetido','validado','aprovado','rejeitado','cancelado','rascunho_2','definido']
		s_calculopreco = ['rascunho','submetido','aprovado','cancelado','rascunho_2']
		s_concurso = ['rascunho','submetido','aprovado','cancelado','rascunho_2']
		s_quo_actualizacao = ['rascunho','submetido','autorizar','aprovado','cancelado','rascunho_2']
		s_quo_certificado = ['rascunho','submetido','validado','aprovado','cancelado','rascunho_2']

		bief_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de BIEFs','visible': True,'sequence': 10}, {})
		hibi_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Histórico de BIEFs','visible': True,'sequence': 11}, {})
		libe_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Libertações','visible': True,'sequence': 12}, {})
		capr_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Cálculo de Preços','visible': True,'sequence': 13}, {})
		conc_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Concursos','visible': True,'sequence': 14}, {})
		quat_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Actualização de Quotas','visible': True,'sequence': 15}, {})
		quce_categ_id = self.get_category_id(cr,uid, {'name': 'Estados de Certificados de Subs. Controladas','visible': True,'sequence': 16}, {})

		for state in s_bief:
			vals = {'name': OBJ['bief']+SPC+STATE[state],'category_id': bief_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['bief'], STATE[state],context)
		for state in s_hst_bief:
			vals = {'name': OBJ['hibi']+SPC+STATE[state],'category_id': hibi_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['hibi'], STATE[state],context)
		for state in s_liberacao:
			vals = {'name': OBJ['libe']+SPC+STATE[state],'category_id': libe_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['libe'], STATE[state],context)
		for state in s_calculopreco:
			vals = {'name': OBJ['capr']+SPC+STATE[state],'category_id': capr_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['capr'], STATE[state],context)
		for state in s_concurso:
			vals = {'name': OBJ['conc']+SPC+STATE[state],'category_id': conc_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['conc'], STATE[state],context)
		for state in s_quo_actualizacao:
			vals = {'name': OBJ['quat']+SPC+STATE[state],'category_id': quat_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['quat'], STATE[state],context)
		for state in s_quo_certificado:
			vals = {'name': OBJ['quce']+SPC+STATE[state],'category_id': quce_categ_id}
			self.get_group_id(cr,uid, vals, OBJ['quce'], STATE[state],context)
		return str(date.today())

	_columns = {
		'name': fields.char('Name', size=64, required=False, translate=False),
		'validar': fields.function(validar, type='char', string='Validar a'),
	}
	# _default = {'name': validar}

	def check_act_doc(self, cr, uid,state,obj):
		#OBJ = ['bief','hibi','libe','capr','conc','quat','quce']
		g_model = self.pool.get('res.groups')
		u_model = self.pool.get('res.users')

		user_id = u_model.browse(cr,uid,uid)
		gid = g_model.search(cr,uid,[('name','=',OBJ[obj]+SPC+STATE[state])])
		if gid: gid = gid[0]
		if not gid: error(action,'Grupo %s não encontrado.'%(OBJ[obj]+SPC+STATE[state]))
		uids = [usid.id for usid in g_model.browse(cr,uid,gid).users]
		if not uids or uid not in uids:
			error(action,'O usuário "%s" não tem permissão para executar esta operação.\nuid=[%s], uids%s'%(user_id.name,uid,uids))

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		msg('validacoes.create: %s'%vals)
		id = super(get_aux, self).create(cr, uid, vals, context=context)	
		self.validar(cr,uid,[id],False,False,context)
		return id
	
	def write(self, cr, uid, ids, vals, context=None):
		msg('validacoes.write: %s'%ids)
		if context is None: context = {}
		self.validar(cr,uid,ids,False,False,context)
		id = super(get_aux, self).write(cr, uid, ids, vals, context=context)
		return id

	def get_category_id(self, cr,uid,vals,context=None):
		ir_model = self.pool.get('ir.module.category')
		category_id = ir_model.search(cr,uid,[('name','=',vals['name']),('visible','=',vals['visible'])]) or False
		if category_id:
			category_id = category_id[0]
		else:
			category_id = ir_model.create(cr,uid,vals)
		return category_id

	def get_group_id(self, cr,uid,vals,obj, state,context=None):
		g_model = self.pool.get('res.groups')
		data_model = self.pool.get('ir.model.data')
		gid = g_model.search(cr,uid,[('name','=',vals['name']),('category_id','=',vals['category_id'])]) or False
		if gid:
			gid = gid[0]
		else:
			names = [obj+'/'+state, obj+'-'+state, obj+'/'+state]
			res_id = data_model.search(cr,uid,[('name','in',names),('module','=','dotcom_importacoes')])
			if res_id:
				gid = data_model.browse(cr,uid,res_id[0]).res_id
				g_model.write(cr,uid,gid,vals)
				data_model.write(cr,uid,res_id,{'name': vals['name']})
			if not gid:
				gid = g_model.create(cr,uid,vals)
				data_vals = {
					'name': vals['name'],
					'model': 'res.groups',
					'module': 'dotcom_importacoes',
					'res_id': gid,
					'noupdate': False,
					'date_update': date.today(),
					'date_init': date.today(),
				}
				data_model.create(cr,uid,data_vals)
		return gid

	def get_category_id_1(self, cr,uid,name,context=None):
		# msg('get_doc_menus') #cat_estados_bief
		category_id = False
		res_id = self.pool.get('ir.model.data').search(cr,uid,[('name','=',name),('model','=','ir.module.category')])		
		for data_id in self.pool.get('ir.model.data').browse(cr,uid,res_id): category_id = data_id.res_id
		return category_id
	
	def get_period_id(self, cr, uid,date):
		model = self.pool.get('configuration.period')
		period_id = None		
		# given_date = datetime(*(time.strptime(str(date), '%Y-%m-%d')[0:6]))
		
		query = [('closing','=',False),('special','=',False),('date_start','<=',date),('date_stop','>=',date)]
		fiscal = model.search(cr,uid,query,limit=1)
		if fiscal and len(fiscal)>0:
			period_id = fiscal[0]
		return period_id
	
	def get_ano_id(self, cr, uid,date):
		model = self.pool.get('configuration.fiscalyear')
		ano_id = None		
		# given_date = datetime(*(time.strptime(date, '%Y-%m-%d')[0:6]))
		
		query = [('date_start','<=',date),('date_stop','>=',date)]
		fiscal = model.search(cr,uid,query,limit=1)
		if fiscal and len(fiscal)>0:
			ano_id = fiscal[0]
		return ano_id
get_aux()	