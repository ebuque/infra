# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

CFG_MODEL = 'dotcom.taxas.impostos.config'
	# CIF = 163.64
	# DAI = 186.55
	# PVF = 225.01
	# PVP = 333.5
	# PVP_Farmac = 310.16
def perc(valor,percent):
	return (valor*percent*0.01)

def _res_get(campo,vals):
	res = 0
	if campo == 'fob':# FOB = FOB_OR*cambio
		res = vals['fob_origem']*vals['cambio'] # 
	elif campo == 'cif':# CIF = FOB*fact_conv
		res = vals['fob']*vals['fact_conv']
	elif campo == 'dai':# DAI = CIF+(DAI=14%)
		res = vals['cif']+perc(vals['cif'],vals['dai'])
	elif campo == 'pvf':# PVF = CIF+DAI+LI 	{'cif':cif,'dai':oid.dai,'li':oid.li,   'iva':0,'da':0,'ice':0,'oc':0,}
		res = vals['cif']+perc(vals['cif'],vals['dai'])+perc(vals['cif'],vals['li'])  +perc(vals['cif'],vals['iva'])+perc(vals['cif'],vals['da'])+perc(vals['cif'],vals['ice'])+perc(vals['cif'],vals['oc'])
	elif campo == 'pvp':# PVP = PVF+(LF*CIF)
		res = vals['pvf']+perc(vals['cif'],vals['lf'])
	elif campo == 'pvp_farmac':# PVP_Farmac = PVP - (LFE = 7%)
		res = vals['pvp']-perc(vals['pvp'],vals['lfe'])
	return res

class dotcom_taxas_impostos_config(osv.osv):
	_name = 'dotcom.taxas.impostos.config'
	_description = 'Configuração de Taxas e Impostos'
	_columns = {
		'ref': fields.char('Referência', size=120, required=True, readonly=True),
		'name': fields.char('Nome', size=120, required=True, readonly=False),
		'data_hora': fields.datetime('Data', required=False, readonly=False),
		'em_vigor': fields.boolean('Em Vigor', readonly=False),

		'dai': fields.float('DAI', required=True, readonly=False, help='Dispesas Administrativa da Importadora'),
		'li': fields.float('LI', required=True, readonly=False, help='Lucro da Importadora'),
		'lf': fields.float('LF', required=True, readonly=False, help='Lucro da Farmácia'),
		'lfe': fields.float('LFE', required=True, readonly=False, help='Lucro da Farmácia do Estado'),
		
		'iva': fields.float('Iva', required=False, readonly=False,),
		'da': fields.float('DA', required=False, readonly=False, help='Direitos Aduaneiros'),
		'ice': fields.float('ICE', required=False, readonly=False, help='Imposto de Consumo Especial'),
		'oc': fields.float('OC', required=False, readonly=False, help='Outros Custos'),
	}
	# _rec_name = 'data_hora'
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe uma Configuração de Taxas e Impostos com esta Referência!')]
	_defaults = {
		'data_hora': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'CTI', 'dotcom.taxas.impostos.config', context=c),

		'dai': 14,
		'li': 23.5,
		'lf': 66.3,
		'lfe': 7,

		'iva': 17,
		'da': 0,
		'ice': 0,
		'oc': 0,
	 }

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def _get_tax(self, cr, uid, tax, context=None):
		if context is None: context = {}
		ids = self.search(cr, uid, [('em_vigor','=',True)])
		vals, res = {}, 0
		for oid in self.browse(cr,uid,ids):
			vals = {
				'dai': oid.dai, 'li': oid.li, 'lf': oid.lf, 'lfe': oid.lfe,
				'iva': oid.iva, 'da': oid.da, 'ice': oid.ice, 'oc': oid.oc,
		 	}
		if tax in vals: return vals[tax]
		return 0
		
	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('config.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'em_vigor':
			active_ids = self.search(cr, uid, [('em_vigor','=',True)])
			if len(active_ids) == 1 and len(ids) == 1 and active_ids[0] == ids[0] and not valor:
				vals = {'em_vigor': True}
				return self._change(cr, uid, ids, vals)
	
	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		rem_ids = self.search(cr, uid, [('em_vigor','=',True)])
		if vals['em_vigor']:
			# msg('create # rem_ids: %s'%rem_ids)
			self.write(cr,uid,rem_ids,{'em_vigor':False})
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'CTI', 'dotcom.taxas.impostos.config', context,True)
		return super(dotcom_taxas_impostos_config, self).create(cr, uid, vals, context=context)
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None: context = {}
		if 'em_vigor' in vals and vals['em_vigor']:
			active_ids, rem_ids = self.search(cr, uid, [('em_vigor','=',True)]), []
			for sid in active_ids:
				if sid != ids[0]: rem_ids.append(sid)
				# msg('write # active_ids: %s, rem_ids:%s'%(active_ids,rem_ids))			
			self.write(cr,uid,rem_ids,{'em_vigor':False})
		return super(dotcom_taxas_impostos_config, self).write(cr, uid, ids, vals, context=context)
dotcom_taxas_impostos_config()	

class dotcom_calculo_precos(osv.osv):

	def pattern(self,cr,uid,valor):
		return self.pool.get('decimal.precision').get_decimal_precision(cr,uid,valor)

	_name = 'dotcom.calculo.precos'
	_description = 'Cálculo de Preços de Substâncias'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True),	
		'factura': fields.char('Nº Factura', size=120, required=False ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'liberacao_id': fields.many2one('dotcom.importacao.liberacao','Libertação de Encomenda', required=False ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		# 'importador_id': fields.many2one('dotcom.parceiro.importador','Importador' ,readonly=True, domain="[('activo','=',True),]",),	
		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=True, domain="[('activo','=',True),]" ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'data_factura': fields.date('Data Factura', required=False ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),#Vem da Liberacao
		
		'moeda_id': fields.many2one('res.currency','Moeda', required=True,help='Moeda do Cálculo' ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'moeda_factura_id': fields.many2one('res.currency','Moeda Origem', required=True ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'cambio_factura': fields.float('Câmbio', required=True ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_fob': fields.float('Total FOB', required=False, readonly=True,),
		'total_cif': fields.float('Total CIF', required=False ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'seguro': fields.float('Seguro', required=True ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'frete': fields.float('Frete', required=True ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'fact_conv': fields.float('Factor Conv.', required=False, readonly=True,),

		'dai': fields.float('DAI', required=True, help='Dispesas Administrativa da Importadora', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'li': fields.float('LI', required=True, help='Lucro da Importadora', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'lf': fields.float('LF', required=True, help='Lucro da Farmácia', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'lfe': fields.float('LFE', required=True, help='Lucro da Farmácia do Estado', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		
		'iva': fields.float('Iva', required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'da': fields.float('DA', required=True, help='Direitos Aduaneiros', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'ice': fields.float('ICE', required=True, help='Imposto de Consumo Especial', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'oc': fields.float('OC', required=True, help='Outros Custos', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'data': fields.date('Data da Emissão', required=False ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'period_id': fields.many2one('configuration.period','Período', readonly=True,),
		'data_aprovacao': fields.date('Aprovação', required=False, readonly=True),
		# 'data_vencimento': fields.date('Vencimento', required=False, readonly=True),
		'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False ,readonly=True,),
		
		'linha_ids': fields.one2many('dotcom.calculo.precos.linha','parent_id','Linhas' ,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'movimento_ids': fields.one2many('reg.mov','calc_preco_id','Movimentos', readonly=True,),
		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'state': fields.selection([
				('rascunho','Rascunho'),
				('submetido','Submetido'),
				('aprovado','Aprovado'),
				('cancelado','Cancelado'),
				('rascunho_2','Rascunho'),
				],'Estado', select=True, readonly=True,),
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','calc_preco_id','Cancelamentos', readonly=True,),
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'state': 'rascunho',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),

		'dai': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'dai', context=c),
		'li': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'li', context=c),
		'lf': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'lf', context=c),
		'lfe': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'lfe', context=c),

		'iva': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'iva', context=c),
		'da': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'da', context=c),
		'ice': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'ice', context=c),
		'oc': lambda self,cr,uid,c: self.pool.get(CFG_MODEL)._get_tax(cr, uid, 'oc', context=c),
	 }	
	_sql_constraints = [('doc_numero_unique', 'unique(doc_numero)', 'Já existe um Cálculo Preços com esta referência!')]

	def start_report(self, cr, uid,ids, context={}):
		msg('precos.start_report ids: %s'%ids)
		data = self.read(cr,uid,ids,)[-1]
		msg('data: %s'%data)
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_calculopreco',
			'datas':{
					'model': 'dotcom.calculo.precos',
					'id': ids[0],
					'ids': ids,
					'report_type': 'pdf',
					'form': data
			},
			'nodestroy':False,
		}
		
	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('calculo_precos.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'moeda_factura_id':
			oid = self.pool.get('res.currency').browse(cr,uid,valor)
			rate, name = 1, ''
			if oid:
				name = oid.name
				if oid.base is not True: rate = self.pattern(cr,uid,oid.rate)
				vals = {'moeda_str': name,'cambio_factura': rate}
		elif descricao == 'data':
			vals = {
				'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
				'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
				}
			return self._change(cr, uid, ids, vals)
		return self._change(cr, uid, ids, vals)

	def on_ch_fact(self, cr, uid, ids, liberacao_id, factura, descricao, context=None):
		msg('calculo_precoson_ch_fact_%s: liberacao_id: %s factura: %s'%(descricao,liberacao_id,factura))
		if context is None: context = {}
		model = self.pool.get('dotcom.importacao.liberacao')
		vals = {}
		li = liberacao_id
		if descricao == 'factura':
			li = model.search(cr, uid, [('factura','=',factura)])
			if li: li = li[0]
		oid = model.browse(cr,uid,li)
		if not liberacao_id and not oid.id:
			oid = False
		# msg('oid: %s, liberacao_id: %s'%(oid,liberacao_id))
		if oid and oid.id != liberacao_id: vals['liberacao_id'] = oid.id
		if oid and oid.factura != factura: vals['factura'] = oid.factura
		if not oid and descricao == 'factura': vals['liberacao_id'] = False
		if not oid and not factura and descricao == 'liberacao_id': vals['factura'] = ''
		if oid:
			vals['moeda_factura_id'] = oid.moeda_id.id
			vals['importador_id'] = oid.importador_id.id
			vals['data_factura'] = oid.data
		else:
			vals['moeda_factura_id'] = False
			vals['importador_id'] = False
			vals['data_factura'] = False
		self.write(cr,uid,ids,{'moeda_factura_id':vals['moeda_factura_id']})
		return self._change(cr, uid, ids, vals)

	def validar(self, cr, uid,ids,context=None):
		msg('calculo_precos.validar. ids: %s'%ids)
		if context is None: context = {}
		# for oid in self.browse(cr,uid,ids):
		
	def processar(self, cr, uid,ids,context=None):
		msg('calculo_precos.processar. ids: %s'%ids)
		if context is None: context = {}
		lin_model = self.pool.get('dotcom.calculo.precos.linha')
		self.validar(cr,uid,ids,context)
		# total_fob = 0
		for oid in self.browse(cr,uid,ids):
			if not oid.liberacao_id:
				error('Acção Inválida!','Seleccione a Libertação de Encomenda.')
			for linha in oid.linha_ids:
				lin_model.unlink(cr, uid, linha.id)

			for linha in oid.liberacao_id.linha_ids:
				fob = linha.preco * oid.cambio_factura
				# total_fob += linha.quant_autorizada*fob
				vals = {
					'parent_id': oid.id,
					'lib_linha_id': linha.id,
					'lote_nr': linha.nr_lote,
					'prod_id': linha.prod_id.id,
					# 'tipo_prod': linha.zzz,
					'comercial_name_id': linha.comercial_name_id.id,
					'forma': linha.forma,
					'dosagem': linha.dosagem,
					'apresentacao': linha.apresentacao,
					'fabricante_id': linha.fabricante_id.id,
					'quant': linha.quant_autorizada,
					'fob_origem': linha.preco,
					'fob': fob,
					'cif': 0,
					'dai': 0,
					'pvf': 0,
					'pvp': 0,
					'pvp_farmac': 0,
				}
				lin_model.create(cr,uid,vals)
			self.on_ch_fact(cr,uid,ids,oid.liberacao_id.id,oid.factura,'liberacao_id',None)
		return True	

	def run_calcular(self, cr, uid,ids,context=None):
		msg('calculo_precos.run_calcular. ids: %s'%ids)
		if context is None: context = {}
		lin_model = self.pool.get('dotcom.calculo.precos.linha')

		total_fob, total_cif, fact_conv, seguro, frete = 0,0,0,0,0
		for oid in self.browse(cr,uid,ids):
			if not oid.linha_ids: error('Acção Inválida!','Não encontramos linhas por calcular.')
			seguro, frete = oid.seguro, oid.frete
			for linha in oid.linha_ids:
				# fob = linha.fob_origem * oid.cambio_factura
				total_fob += linha.quant*linha.fob_origem
			total_cif = total_fob+seguro+frete
			fact_conv = total_cif/total_fob
			vals = {
				'total_fob': total_fob,
				'total_cif': total_cif,
				'fact_conv': fact_conv,
				'seguro': seguro,
				'frete': frete,
				}
			self._change(cr, uid, ids, vals)

			for linha in oid.linha_ids:
				# fop = vals['fob_origem']*vals['cambio']
				# cif = vals['fob']*vals['fact_conv']
				# dai = vals['cif']+perc(vals['cif'],vals['dai'])
				# pvf = vals['cif']+perc(vals['cif'],vals['dai'])+perc(vals['cif'],vals['li'])
				# pvp = vals['pvf']+perc(vals['cif'],vals['lf'])
				# pvp_farmac = vals['pvp']-perc(vals['pvp'],vals['lfe'])

				fob = _res_get('fob',{'fob_origem':linha.fob_origem,'cambio':oid.cambio_factura,})
				cif = _res_get('cif',{'fob':fob,'fact_conv':oid.fact_conv,})
				dai = _res_get('dai',{'cif':cif,'dai':oid.dai,})

				pvf_vals = {'cif':cif,'dai':oid.dai,'li':oid.li,'iva':0,'da':0,'ice':0,'oc':0,}
				if linha.prod_id.categoria == 'saude':
					pvf_vals = {'cif':cif,'dai':oid.dai,'li':oid.li,'iva':oid.iva,'da':oid.da,'ice':oid.ice,'oc':oid.oc,}
				pvf = _res_get('pvf',pvf_vals)
				pvp = _res_get('pvp',{'pvf':pvf,'cif':cif,'lf':oid.lf,})
				pvp_farmac = _res_get('pvp_farmac',{'pvp':pvp,'lfe':oid.lfe,})
				# Total FOB = Somatorio de (QTD*FOB) nas linhas.
				# Total CIF = (Total FOB + Seguro + Frete).
				# Factor Conv = Total CIF / Total FOB.	
				vals = {
					'fob': fob,
					'cif': cif,
					'dai': dai,
					'pvf': pvf,
					'pvp': pvp,
					'pvp_farmac':pvp_farmac,
					}
				lin_model.write(cr,uid,linha.id,vals)
				lin_model.on_ch_calc(cr,uid,linha.id,vals,None)
			
			self.on_ch_fact(cr,uid,ids,oid.liberacao_id.id,oid.factura,'liberacao_id',None)
		return True
		
	def calcular(self, cr, uid,ids,context=None):
		msg('calculo_precos.calcular. ids: %s'%ids)
		self.run_calcular(cr,uid,ids,context)
		return self.run_calcular(cr,uid,ids,context)	

	def submeter(self, cr, uid,ids,context=None):
		msg('calculo_precos.submeter ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for oid in self.browse(cr,uid,ids):
			vals = {'state': 'submetido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','capr')#['bief','hibi','libe','capr','conc','quat','quce']
			if not oid.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'CAPR','full',context,True)
			self.write(cr,uid,ids,vals)
			self.on_ch(oid.moeda_factura_id,'moeda_factura_id')
			self.on_ch(oid.data,'data')
			self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': ids[0]},context)

	def aprovar(self, cr, uid,ids,context=None):
		msg('calculo_precos.aprovar ids: %s'%ids)
		self.validar(cr,uid,ids,context)
		vals = {}
		for document in self.browse(cr,uid,ids):
			vals['data_aprovacao'] = datetime.now().strftime('%Y-%m-%d')
			vals['state'] = 'aprovado'
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','capr')#['bief','hibi','libe','capr','conc','quat','quce']
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': ids[0]},context)


	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': None,
			'calc_preco_id': ids and ids[0] or None,
			'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': None,
			'certificad_id': None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)	

	# def rejeitar(self, cr, uid,ids,context=None):
	# 	return self.run_motivo_cancelamento(cr,uid,ids,'rejeitar',context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_cancelar(self, cr, uid,ids,context=None):
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','capr')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': ids[0]},context)

	def run_voltar_rascunho(self, cr, uid,ids,context=None):
		for document in self.browse(cr,uid,ids):
			self.write(cr,uid,ids,{'state':'rascunho_2'})
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','capr')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': ids[0]},context)

	# def validar_unlink(self, cr, uid, ids, operacao, context=None):
	# 	if context is None: context = {}
	# 	bief_model = self.pool.get('dotcom.importacao.bief')
	# 	for document in self.browse(cr,uid,ids): 
	# 		src_ids = bief_model.search(cr,uid,[('concurso_id','=',ids[0]),('state','not in',['rascunho','cancelado','rejeitado']),])
	# 		if src_ids: error('Acção Inválida!','Não é possível %s!\nEste documento já foi mencionado em BIEFs.'%operacao)
		
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]: error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		# self.validar_unlink(cr,uid,ids,'eliminar')
		return super(dotcom_calculo_precos, self).unlink(cr, uid, ids, context=context)

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		# seq_model = self.pool.get('dotcom.sequencia')
		# vals['doc_numero'] = seq_model._nr_get(cr,uid,'CAPR','full',context,True)

		id = super(dotcom_calculo_precos, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': id},context)
		# self.all_changes(cr, uid,[id],context)
		return id
dotcom_calculo_precos()	



class dotcom_calculo_precos_linha(osv.osv):
	_name = 'dotcom.calculo.precos.linha'
	_description = 'Linhas de Cálculo Preços'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.calculo.precos','Cálculo de Preços', readonly=True),
		'lib_linha_id': fields.many2one('dotcom.liberacao.linha','Linha da Libertação de Encomenda', readonly=True),
		# 'name': fields.char('Nome', size=120, required=False),
		'lote_nr': fields.integer('Nº Lote', required=False),

		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True,),
		# 'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo de Prod.', readonly=True,),	
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=True, domain="[('prod_id','=',prod_id),('activo','=',True)]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=False),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=False),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=False),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=True, readonly=False),

		'quant': fields.float('QTD'), 
		'fob_origem': fields.float('FOB Origem'), 
		'fob': fields.float('FOB UNIT.'), 
		'cif': fields.float('CIF UNIT.'), 
		'dai': fields.float('DAI'), 
		'pvf': fields.float('PVF'), 
		'pvp': fields.float('PVP'), 
		'pvp_farmac': fields.float('PVP Farmac'), 
	}
	_rec_name = 'prod_id'
	_defaults = {
		'quant': 0,
	}

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('qutas_calculo_precos_linha.on_ch_%s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao == 'tiposs' and not valor:
			vals = {'tipo': 'adenda',}
			return self._change(cr, uid, ids, vals)
		if valor:
			if descricao == 'prod_id':
				oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
				vals = {'tipo_prod': oid.tipo_prod,}
				return self._change(cr, uid, ids, vals)
		return False

	def on_ch_calc(self, cr, uid, ids, vals, context=None):
		# fob, cif, dai, pvf, pvp, pvp_farmac,
		msg('calculo_linha.on_ch_calc: vals: %s'%vals)
		return self._change(cr, uid, ids, vals)

dotcom_calculo_precos_linha()	