# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
# from validators import validator
# from validators import group_validator
import logging 
# import pooler
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

vals = {}

class dotcom_terminal_alfandega(osv.osv):
	_name = 'dotcom.terminal.alfandega'
	_description = 'Terminal Alfandegário'
	_columns = {
		'ref': fields.char('Ref.', size=9, required=True, readonly='True'),
		'name': fields.char('Nome', size=120, required=True),
	}
	_defaults = {
		'ref': lambda self,cr,uid,c: self.pool.get('gen.ref').next_ref(cr, uid, 3, 'TEA', 'dotcom.terminal.alfandega', context=c),
	}
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já existe um Terminal Alfandegário com esta referência!')]

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}# 
		vals['ref'] = self.pool.get('gen.ref').next_ref(cr, uid, 3, 'TEA', 'dotcom.terminal.alfandega', context,True)
		id = super(dotcom_terminal_alfandega, self).create(cr, uid, vals, context=context)
		return id
dotcom_terminal_alfandega()	

class dotcom_importacao_liberacao(osv.osv):
	def pattern(self,cr,uid,valor):
		return self.pool.get('decimal.precision').get_decimal_precision(cr,uid,valor)
		
	_name = 'dotcom.importacao.liberacao'
	_description = 'Libertação de Encomenda de Importações'
	_columns = {
		'doc_numero': fields.char('Nº', size=120, required=False, readonly=True),
		'data': fields.date('Data', required=True, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'period_id': fields.many2one('configuration.period','Período', readonly=True,),

		'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', readonly=True, domain="[('activo','=',True),]",),
		'import_nuit': fields.char('NUIT', size=120, required=False, readonly=True),
		'import_alvara': fields.char('Alvará nº', size=120, required=False, readonly=True),
		'import_contacto': fields.char('Contacto', size=120, required=False, readonly=True),
		'import_endereco': fields.char('Endereço', size=120, required=False, readonly=True),
		'import_director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico', readonly=True,domain="[('importador_id','=',importador_id),('active','=',True),]",),

		'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', readonly=True, domain="[('activo','=',True),]",),	
		'forn_nuit': fields.char('NUIT', size=120, required=False, readonly=True),
		'forn_endereco': fields.char('Endereço', size=120, required=False, readonly=True),
		'factura': fields.char('Factura Nº', size=120, required=True, readonly=False),

		'bief_tipo': fields.selection([
			('imes','Importação Especial'),
			('snsc','Serviço Nacional de Saúde - Concurso'),
			('snsd','Serviço Nacional de Saúde - Doação'),
			('lnme','Lista Nacional de Medicamentos Essenciais'),
			('extra','Extra Lista'),
			('prosa','Produtos de Saúde'),
			],'Tipo BIEF', readonly=True,),

		# 'bief_doc_numero': fields.char('BIEF Nº', size=120, required=True, readonly=False),
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF Nº', domain="[('libertado','=',False),('state','=','aprovado')]", required=True, readonly=False,),
		'data_aprovacao_bief': fields.date('Aprovação BIEF', required=False, readonly=True),
		'data_aprovacao': fields.date('Data da Aprovação', required=False, readonly=True),
		'proforma': fields.char('Factura Proforma Nº', size=120, required=False, readonly=True),
		'data_hora_chegada': fields.datetime('Data e Hora Chegada', readonly=False, required=True),
		'nr_items': fields.integer('Nº de Items', readonly=True),
		'alfandega_id': fields.many2one('dotcom.terminal.alfandega','Terminal Alfandegário', required=True,readonly=False,),

		'agendar': fields.boolean('Agendar', readonly=True, required=False, states={'validado':[('readonly',False)]}),
		'data_agenda': fields.datetime('Data e Hora Agendada', readonly=False, required=False),
		'state_agenda': fields.selection([('n_definido','Não Definido'),('definido','Definido')],'Agenda', readonly=True,),

		'linha_get_ids': fields.one2many('dotcom.bief.linha.get','parent_id','Linhas Get', readonly=True,),
		'linha_ids': fields.one2many('dotcom.liberacao.linha','parent_id','Linhas', readonly=False,),
		'liberacao_cambio_ids': fields.one2many('dotcom.liberacao.cambio','parent_id','Cambios', readonly=True,),
		'cancelamento_ids': fields.one2many('dotcom.import.cancel','liberacao_id','Cancelamentos', readonly=True,),
		'movimento_ids': fields.one2many('reg.mov','liberacao_id','Movimentos', readonly=True,),

		'moeda_id': fields.many2one('res.currency','Moeda',readonly=True, required=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'cambio': fields.float('Câmbio do Processo', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_moeda': fields.float('Total Moeda', readonly=True,),

		'moeda_principal_id': fields.many2one('res.currency', 'MP', readonly=True),
		'cambio_principal': fields.float('Câmbio MP',required=False,readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_principal': fields.float('Total MP', readonly=True,),

		'moeda_secundaria_id': fields.many2one('res.currency', 'MS', readonly=True),
		'cambio_secundario': fields.float('Cambio MS', readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'total_secundario': fields.float('Total MS', readonly=True,),
		'nota': fields.text('Nota', required=False, readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),

		'anexo_lst_emb': fields.binary('Lista de Emabalagem',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_lst_emb_name' : fields.char('LE Name',size=255),
		'anexo_du': fields.binary('Documento Unico',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_du_name' : fields.char('DU Name',size=255),
		'anexo_ca': fields.binary('Certificados de Analises',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}),
		'anexo_ca_name' : fields.char('CA Name',size=255),
		'anexo_cria': fields.binary('CRIA',readonly=True, states={'rascunho':[('readonly',False)],'rascunho_2':[('readonly',False)]}, help="Produtos Importados da India"),
		'anexo_cria_name' : fields.char('CRIA Name',size=255),
		
		'state': fields.selection([
			('rascunho','Rascunho'),
			('submetido','Submetido'),
			('validado','Validado'),
			('aprovado','Aprovado'),
			('rejeitado','Rejeitado'),
			('cancelado','Cancelado'),
			('rascunho_2','Rascunho'),
			],'Estado', select=True, readonly=True,),

		'quant': fields.float('Total(Q.Aut)', readonly=True),
		'preco': fields.float('Total(Preço)', readonly=True), 
		'total': fields.float('Total(Linhas)', readonly=True),
	}
	_rec_name = 'doc_numero'
	_defaults = {
		'nota': 'Este processo calcula automaticamente os preços de revenda e os preços de venda ao público. Visto que os preços de custo de uma determinada substância activa vêm da factura do fornecedor e esta por sua vez consta no processo de liberação, o sistema deste modo irá fazer um rastreamento automático das facturas/liberações que ainda não forma atribuído preços. Assim a qualquer momento será possível verificar quais substâncias activas têm preço estipulados e quais ainda não. Para o cálculo dos preços é necessário adicionar outros custos ao processo, tais como, o preço FOB, seguros, frete, etc.',
		'state': 'rascunho',
		'state_agenda': 'n_definido',
		'data': lambda *a: time.strftime('%Y-%m-%d'),
		'moeda_principal_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.importacao.bief', context=c),
		'moeda_secundaria_id': lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.importacao.bief', context=c),
		# 'alfandega': '',
		# 'data_aprovacao': lambda *a: time.strftime('%Y-%m-%d'),
		# 'data_hora_chegada': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
	}
	_sql_constraints = [('ref_unique', 'unique(ref)', 'Já foi criado uma Liberacao com esta referência!')]

	def start_report(self, cr, uid,ids, context={}):
		msg('liberacao.start_report ids: %s'%ids)
		data = self.read(cr,uid,ids,)[-1]
		msg('data: %s'%data)
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_liberacao',
			'datas':{
					'model':'dotcom.importacao.liberacao',
					'id':ids[0],
					'ids':ids,
					'report_type':'pdf',
					'form':data
			},
			'nodestroy':False,
		}


	def get_bief(self, cr, uid, ids,doc_numero,context=None):
		msg('liberacao.get_bief. doc_numero: %s'%doc_numero)
		if context is None: context = {}
		bief_model = self.pool.get('dotcom.importacao.bief')
		if not doc_numero: return False
		bief_ids = bief_model.search(cr, uid, [('doc_numero','=',doc_numero)])
		if bief_ids:
			return bief_model.browse(cr,uid,bief_ids[0])
		return False

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch(self, cr, uid, ids, valor, descricao, context=None):
		msg('liberacao.on_ch_ %s valor: %s'%(descricao,valor))
		if context is None: context = {}
		vals = {}
		if descricao in ['moeda_id','moeda_principal_id','moeda_secundaria_id',]:
			oid = self.pool.get('res.currency').browse(cr,uid,valor)
			cambio, name, vals = 1, '', {}
			name = oid.name			
			if oid and oid.base is not True: cambio = self.pattern(cr,uid,oid.rate)
			if descricao == 'moeda_id':
				if oid: vals = {'moeda_str': name,'cambio': cambio}
				else: vals = {'moeda_str': name,'cambio': cambio}
			if descricao == 'moeda_principal_id': 
				if oid: vals = {'cambio_principal': cambio}
				else: vals = {'cambio_principal': 0}
			if descricao == 'moeda_secundaria_id': 
				if oid: vals = {'cambio_secundario': cambio}
				else: vals = {'cambio_secundario': 0}
			return self._change(cr, uid, ids, vals) 

		elif descricao == 'importador_id':
			model = self.pool.get('dotcom.parceiro.importador')
			if not valor: vals = {'import_alvara': '','import_endereco': '','import_nuit': '','import_contacto': '',}
			if valor:
				oid = model.browse(cr,uid,valor)
				vals = {
					'import_alvara': oid.alvara,
					'import_endereco': oid.endereco,
					'import_nuit': oid.nuit,
					'import_contacto': oid.telefone,
					}		
			return self._change(cr, uid, ids, vals)

		elif descricao == 'fornecedor_id':
			model = self.pool.get('dotcom.parceiro.fornecedor')
			if not valor: vals = {'forn_endereco': '','forn_nuit': '',}
			if valor:
				oid = model.browse(cr,uid,valor)
				vals = {'forn_endereco': oid.endereco,'forn_nuit': oid.nuit,}		
			return self._change(cr, uid, ids, vals)

		elif descricao == 'bief_id':
			model = self.pool.get('dotcom.importacao.bief')
			if not valor: vals = {'bief_tipo': False,}
			if valor:
				oid = model.browse(cr,uid,valor)
				vals = {
					'bief_tipo': oid.tipo_bief,
					'proforma': oid.pro_forma,
					'data_aprovacao_bief': oid.data_aprovacao,
					'importador_id': oid.importador_id.id,
					'import_director_id': oid.director_id.id,
					'fornecedor_id': oid.fornecedor_id.id,
					}
		elif descricao == 'data':
			vals = {
				'period_id': self.pool.get('get.aux').get_period_id(cr, uid,valor),
				'ano_id': self.pool.get('get.aux').get_ano_id(cr, uid,valor),
				}
		elif descricao == 'agendar' and not valor:
			vals = {'data_agenda': False,'state_agenda': 'n_definido'}
		return self._change(cr, uid, ids, vals)

	def all_changes(self, cr, uid,ids,context=None):
		msg('liberacao.all_changes ids: %s'%ids)
		vals = {}
		for oid in self.browse(cr,uid,ids):
			self.on_ch(cr,uid,ids,oid.importador_id.id,'importador_id',context)
			self.on_ch(cr,uid,ids,oid.fornecedor_id.id,'fornecedor_id',context)
			self.on_ch(cr,uid,ids,oid.bief_id.id,'bief_id',context)
		return True

	def processar(self, cr, uid,ids,context=None):
		msg('liberacao.processar. ids: %s'%ids)
		if context is None: context = {}
		lin_model = self.pool.get('dotcom.liberacao.linha')
		lin_get_model = self.pool.get('dotcom.bief.linha.get')

		for document in self.browse(cr,uid,ids):
			# bief_id = self.get_bief(cr,uid,ids,document.doc_numero,context)
			bief_id = document.bief_id
			if not bief_id: error('Acção Inválida!','Não encontramos a BIEF.')

			for linha in document.linha_ids:
				lin_model.unlink(cr, uid, linha.id)
			for linha in document.linha_get_ids:
				lin_get_model.unlink(cr, uid, linha.id)

			for linha in bief_id.linha_ids:
				# if not linha.libertado:
				vals = {
					# dotcom.bief.linha.get
					'parent_id': document.id,
					'bief_id': bief_id.id,
					'bief_linha_id': linha.id,
					'numerador': linha.numerador,

					'fnm_code': linha.fnm_code,
					'nr_registo': linha.nr_registo,
					'prod_id': linha.prod_id.id,
					'comercial_name_id': linha.comercial_name_id.id,
					'forma': linha.forma,
					'dosagem': linha.dosagem,
					'apresentacao': linha.apresentacao,
					'fabricante_id': linha.fabricante_id.id,
					
					'quant': linha.quant,
					'preco': linha.preco,
					'total': linha.total,

					#dotcom.liberacao.linha
					'quant_bief': linha.quant,
					'quant_autorizada': linha.quant,
					'quant_diferenca': 0,
					# 'prazo': '',
					'nr_lote': '',
					'valor': 0,					
					}
				lin_model.create(cr,uid,vals)
				lin_get_model.create(cr,uid,vals)
		return True

	def guardar(self, cr, uid,ids,context=None):
		msg('liberacao.guardar ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			vals = {'state_agenda': 'definido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'definido','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0],'state_agenda': 'definido'},context)
		return self.write(cr,uid,ids,vals)

	def remarcar(self, cr, uid,ids,context=None):
		msg('liberacao.remarcar ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			vals = {'state_agenda': 'n_definido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'definido','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0],'state_agenda': 'n_definido'},context)
		return self.write(cr,uid,ids,vals)

	def get_query(self, cr, uid,linha_id,parent_id):
		query = []
		if linha_id:
			query = [ 
				('parent_id','=', parent_id),
				('prod_id','=', linha_id.prod_id.id),
				('comercial_name_id','=', linha_id.comercial_name_id and linha_id.comercial_name_id.id or False),
				# ('forma','=',linha_id.forma),
				# ('dosagem','=',linha_id.dosagem or False),
				# ('apresentacao','=',linha_id.apresentacao and linha_id.apresentacao.id or False),
			]
		return query

	def validar(self, cr, uid,ids,context=None):
		msg('liberacao.validar. ids: %s'%ids)
		if context is None: context = {}
		for document in self.browse(cr,uid,ids):
			if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')
			
			now = date.today()
			err_prazo, err_prazo_menor, err_nr_lote= '','',''
			err_quant_autorizada = ''
			for linha_id in document.linha_ids:
				msg('now: %s, prazo: %s'%(now,linha_id.prazo))
				if linha_id.prazo and datetime.strptime(linha_id.prazo, '%Y-%m-%d').date() < now: err_prazo_menor +=  ('#:%s, '%linha_id.numerador)
				if not linha_id.prazo: err_prazo +=  ('#:%s, '%linha_id.numerador)
				if not linha_id.nr_lote: err_nr_lote +=  ('#:%s, '%linha_id.numerador)
				if linha_id.quant_autorizada == 0: err_quant_autorizada +=  ('#:%s, '%linha_id.numerador)
				# if linha_id.quant_autorizada == 0 or linha_id.quant_autorizada > linha_id.quant_bief:
			if len(err_prazo_menor) > 0: error(action,'Os produtos %s possuem prazos Inválidos.'%(err_prazo_menor))
			if len(err_prazo) > 0: error(action,'Os produtos %s não possuem prazos definidos.'%(err_prazo))
			if len(err_nr_lote) > 0: error(action,'Os produtos %s não possuem Nº de Lote definido.'%(err_nr_lote))
			if len(err_quant_autorizada) > 0: error(action,'A quantidade Autotizada dos produtos %s não deve ser igual a ZERO.'%(err_quant_autorizada))

	def calcular(self, cr, uid,ids,context=None):
		msg('liberacao.calcular ids: %s'%ids)
		self.validar(cr,uid,ids,context)		
		lin_model = self.pool.get('dotcom.liberacao.linha')
		quant_autorizada,preco,total = 0,0,0
		nr_items = 0
		for document in self.browse(cr,uid,ids):
			nr_items = len(document.linha_ids)
			for linha_id in document.linha_ids:
				quant_autorizada += linha_id.quant_autorizada
				preco += linha_id.preco
				total += (linha_id.quant_autorizada * linha_id.preco)
				vals = {
					'quant_diferenca': linha_id.quant_bief - linha_id.quant_autorizada,
					'total': linha_id.quant_autorizada * linha_id.preco,
				}
				lin_model._change(cr, uid, [linha_id.id], vals)

			vals = {'quant': quant_autorizada, 'preco': preco, 'total': total, 'nr_items': nr_items}
			return self._change(cr, uid, ids, vals)


	def submeter(self, cr, uid,ids,context=None):
		msg('liberacao.submeter ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.calcular(cr, uid,ids,context)
			
			vals = {'state': 'submetido'}
			self.pool.get('get.aux').check_act_doc(cr,uid,'submetido','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			if not document.doc_numero:
				vals['doc_numero'] = self.pool.get('dotcom.sequencia')._nr_get(cr,uid,'LIBE','full',context,True)
			self.write(cr,uid,ids,vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)

	def validar_state(self, cr, uid,ids,context=None):
		msg('liberacao.validar_state ids: %s'%ids)
		for document in self.browse(cr,uid,ids):
			self.validar(cr,uid,ids,context)
			self.write(cr,uid,ids,{'state':'validado'})
			self.pool.get('get.aux').check_act_doc(cr,uid,'validado','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)


	def get_quota_vigor_id(self, cr, uid,prod_id,context=None):
		if context is None: context = {}
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		ano_id = self.pool.get('configuration.fiscalyear').find(cr, uid)
		vigor_ids = vigor_model.search(cr,uid,[('prod_id','=',prod_id),('ano_id','=',ano_id),('em_vigor','=',True)])
		if vigor_ids:
			return vigor_model.browse(cr,uid,vigor_ids[0]) or False
			# vigor_model.write(cr,uid,vigor_id,{'quota_bief_aprovadas': xxxx,'data_bief': date.today(),})
		return False

	def aprovar(self, cr, uid,ids,context=None):
		msg('liberacao.aprovar ids: %s'%ids)
		bief_linha_model = self.pool.get('dotcom.bief.linha')
		bief_model = self.pool.get('dotcom.importacao.bief')
		vigor_model = self.pool.get('dotcom.quotas.vigor')
		self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):#+ timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
			data_aprovacao = date.today()
			if document.bief_id.certificado_id:
				self.pool.get('dotcom.quotas.certificado').write(cr,uid,[document.bief_id.certificado_id.id],{'libertado': True})
			for linha_id in document.linha_ids:
				bief_linha_model.write(cr,uid,[linha_id.bief_linha_id.id],{'libertado':True})
				if linha_id.prod_id.subs_controlada:
					vigor_id = self.get_quota_vigor_id(cr,uid,linha_id.prod_id.id)
					vals = {
						'quota_importada': vigor_id.quota_importada+linha_id.quant_autorizada,
						'quota_bief_aprovadas': vigor_id.quota_bief_aprovadas-(linha_id.quant_autorizada+linha_id.quant_diferenca),
						}
					vigor_model.write(cr,uid,vigor_id.id,vals)
			self.pool.get('get.aux').check_act_doc(cr,uid,'aprovado','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'aprovado','data_aprovacao':data_aprovacao})
			bief_model.write(cr,uid,[document.bief_id.id],{'libertado':True})
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)


	def run_motivo_cancelamento(self, cr, uid,ids,_type,context=None):
		if context is None: context = {}
		cancel_model = self.pool.get('dotcom.import.cancel')
		#bief_id,liberacao_id,calc_preco_id,eminota_id,concurso_id,quota_act_id,certificad_id,prod_id
		vals = {
			'user_id': uid,
			'motivo': context.get('motivo_cancelamento',' '),
			'required': True,
			'type': _type,	

			'bief_id': None,
			'liberacao_id': ids and ids[0] or None,
			'calc_preco_id': None,
			# 'eminota_id': None,
			'concurso_id': None,
			'quota_act_id': None,
			'certificad_id': None,
			'prod_id': None,
		}
		if True:
			return {
				'name': _("Motivos de Cancelamento"),
				'type': 'ir.actions.act_window',
				'view_type': 'form',
				'view_mode': 'form',
				'res_model': 'dotcom.import.cancel',
				'res_id': False,
				'target' : 'new',
				'nodestroy': True,
				'context': vals,
			}
		else:
			cancel_id = cancel_model.create(cr, uid, vals)
			return cancel_model.save(cr, uid, [cancel_id], context=context)	

	def rejeitar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rejeitar',context)

	def cancelar(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'cancelar',context)

	def voltar_rascunho(self, cr, uid,ids,context=None):
		return self.run_motivo_cancelamento(cr,uid,ids,'rascunho_2',context)

	def run_rejeitar(self, cr, uid,ids,context=None):
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'rejeitado','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'rejeitado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)

	def run_cancelar(self, cr, uid,ids,context=None):
		msg('liberacao.cancelar ids: %s'%ids)
		# self.validar(cr,uid,ids,context)
		for document in self.browse(cr,uid,ids):
			self.pool.get('get.aux').check_act_doc(cr,uid,'cancelado','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			self.write(cr,uid,ids,{'state':'cancelado'})
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)		
		
	def run_voltar_rascunho(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for oid in self.browse(cr,uid,ids,context):
			self.pool.get('get.aux').check_act_doc(cr,uid,'rascunho_2','libe')#['bief','hibi','libe','capr','conc','quat','quce']
			vals = {'quant':0, 'preco':0, 'total':0, 'state':'rascunho_2'}
			self._change(cr, uid, ids, vals)
			self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)
		return True

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,ids): 
			if document.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.state)
		return super(dotcom_importacao_liberacao, self).unlink(cr, uid, ids, context=context)

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		id = super(dotcom_importacao_liberacao, self).create(cr, uid, vals, context=context)
		self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': id},context)
		self.all_changes(cr, uid,[id],context)
		return id
dotcom_importacao_liberacao()


class dotcom_liberacao_linha(osv.osv):
	_name = 'dotcom.liberacao.linha'
	_description = 'Linhas de Libertação de Encomenda'
	_order = 'numerador'
	_columns = {
		'parent_id': fields.many2one('dotcom.importacao.liberacao','Libertação de Encomenda', readonly=True),
		'bief_linha_id': fields.many2one('dotcom.bief.linha','Linha Bief', readonly=True),
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True),

		'numerador': fields.integer('#', readonly=True),
		'nr_lote': fields.integer('Nº Lote'),
		'nr_registo': fields.char('Nº registo', size=9, required=False, readonly=True),
		'fnm_code': fields.char('Código FNM', size=9,  readonly=True,help='Formulário Nacional de Medicamentos'),

		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', required=True, readonly=True),		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', required=True, readonly=True, domain="[('prod_id','=',prod_id),('activo','=',True)]"),
		
		'prazo': fields.date('Prazo', required=False, readonly=False),# do Medicamento
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=True),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=True),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=True),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=False, readonly=True),

		'quant_bief': fields.integer('QTD BIEF', readonly=True),
		'quant_autorizada': fields.integer('QTD Autotizada'),
		'quant_diferenca': fields.integer('Diferença', readonly=True),
		'total': fields.float('Total', readonly=True),
		'preco': fields.float('Preço'),  
	}
	_rec_name = 'parent_id'
	
	_defaults = {
		'total': 0,
	}

	def do_noting(self, cr, uid, ids, context=None):
		return {}

	def _change(self, cr, uid, ids, vals, context=None):
		self.write(cr,uid,ids,vals)
		return {'value': vals}	

	def on_ch_qtd_prec(self, cr, uid, ids, quant_bief, quant_autorizada, preco, context=None):
		msg('lib.linha.on_ch_qtd_prec(quant_bief: %s, quant_autorizada: %s, preco: %s)'%(quant_bief, quant_autorizada, preco))
		if context is None: context = {}		
		vals = {}
		vals['quant_diferenca'] = quant_bief - quant_autorizada
		vals['total'] = quant_autorizada * preco
		#on_change="on_ch_qtd_prec(quant_bief, quant_autorizada, preco)"
		return self._change(cr, uid, ids, vals)

	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		if isinstance(ids, (list, tuple)):
			ids = ids[0]
		document = self.browse(cr,uid,ids)
		if document.parent_id and document.parent_id.state not in ['rascunho']:
			error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_liberacao_linha, self).unlink(cr, uid, ids, context=context)
dotcom_liberacao_linha()


class dotcom_bief_linha_get(osv.osv):
	_name = 'dotcom.bief.linha.get'
	_description = 'Linhas de BIEFs na Libertação de Encomenda'
	_order = 'numerador'
	_columns = {
		'parent_id': fields.many2one('dotcom.importacao.liberacao','Libertação de Encomenda', readonly=True),
		'bief_linha_id': fields.many2one('dotcom.bief.linha','Linha Bief', readonly=True),

		'numerador': fields.integer('#', readonly=True),
		'fnm_code': fields.char('Código FNM', size=9,  readonly=True,help='Formulário Nacional de Medicamentos'),
		'nr_registo': fields.char('Nº registo', size=9,  readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', ),		
		'comercial_name_id': fields.many2one('dotcom.prod.comercial_name', 'Nome Comercial', domain="[('prod_id','=',prod_id),('activo','=',True)]"),
		
		'forma': fields.char('Forma Farmaceutica', size=128, required=False, readonly=False),
		'dosagem': fields.char('Dosagem', size=128, required=False, readonly=False),
		'apresentacao': fields.char('Apresentação', size=128, required=False, readonly=False),
		'fabricante_id': fields.many2one('dotcom.fabricante','Fabricante', required=True,readonly=False),

		'quant': fields.float('QTD'), 
		'preco': fields.float('Preço'), 
		'total': fields.float('Total', readonly=True), 
		'bief_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True),
	}
	_rec_name = 'parent_id'
	
	_defaults = {
		'quant': 0,
	}
	
	def unlink(self, cr, uid, ids, context=None):
		if context is None: context = {}
		for document in self.browse(cr,uid,[ids]): 
			if document.parent_id and document.parent_id.state not in ['rascunho',]:error('Acção Inválida!','Não é possível eliminar documentos no estado "%s".'%document.parent_id.state)
		return super(dotcom_bief_linha_get, self).unlink(cr, uid, ids, context=context)
		
dotcom_bief_linha_get()	


class dotcom_liberacao_cambio(osv.osv):
	_name = 'dotcom.liberacao.cambio'
	_description = 'Cambios de Libertação de Encomenda'
	#_rec_name = 'name'
	_columns = {
		'parent_id': fields.many2one('dotcom.importacao.liberacao','Parente', readonly=True),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico','Prod. Farmacêutico', readonly=True,),
		'moeda_id': fields.many2one('res.currency','Moeda',readonly=True,),
		'total_moeda': fields.float('Total Moeda', readonly=True,),

		'moeda_principal_id': fields.many2one('res.currency', 'MP', readonly=True),
		'total_principal': fields.float('Total MP', readonly=True,),

		'moeda_secundaria_id': fields.many2one('res.currency', 'MS', readonly=True),
		'total_secundario': fields.float('Total MS', readonly=True,),
	}
	_rec_name = 'parent_id'
	_defaults = {
		'total_secundario': 0,
	}
dotcom_liberacao_cambio()