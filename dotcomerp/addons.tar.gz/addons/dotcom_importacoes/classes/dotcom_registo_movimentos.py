# -*- coding: utf-8 -*-

from osv import fields,osv
import time
import netsvc
import string
from tools.translate import _
from lxml import etree
from datetime import date,datetime, timedelta
import logging 
logger = logging.getLogger('DOTCOM') 

action = 'Acção Inválida!'

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

def _add_digitos(maxLen,valor):
	str_nr = str(valor)
	while(len(str_nr) < maxLen):
		str_nr = ('0'+str_nr)
	return str_nr

PROCESSO = {
	'bief_id': 'BIEF',
	'liberacao_id': 'Libertação',
	'calc_preco_id': 'Cálculo de Preços',
	'eminota_id': 'Emissão de Notas',
	'concurso_id': 'Concursos',
	'quota_act_id': 'Actualização de quotas',
	'certificad_id': 'Certificado',
	# 'quota_vig_id': 'Quotas em Vigor',
	# 'transtitu_id': 'Transferência',
	'prod_id': 'Produto Farmacêutico',
}

CODE = {
	'bief_id': 'BIEF',
	'liberacao_id': 'LIBE',
	'calc_preco_id': 'CALP',
	'eminota_id': 'EMNO',
	'concurso_id': 'CONC',
	'quota_act_id': 'ACTQ',
	'certificad_id': 'CERT',
	# 'quota_vig_id': 'Quotas em Vigor',
	# 'transtitu_id': 'Transferência',
	'prod_id': 'PRFA',
}

MODEL = {
	'bief_id': 'dotcom.importacao.bief',
	'liberacao_id': 'dotcom.importacao.liberacao',
	'calc_preco_id': 'dotcom.calculo.precos',
	'eminota_id': 'dotcom.emissao.notas',
	'concurso_id': 'dotcom.lancamento.concurso',
	'quota_act_id': 'dotcom.quotas.actualizacao',
	'certificad_id': 'dotcom.quotas.certificado',
	'prod_id': 'dotcom.produto.farmaceutico',
	# 'quota_vig_id': 'dotcom.quotas.vigor',
	# 'transtitu_id': 'dotcom.transf.titularidades',
}

LISTA = ['bief_id','liberacao_id','calc_preco_id',
		'eminota_id','concurso_id','quota_act_id','certificad_id'
		,'prod_id',
		# 'quota_vig_id','transtitu_id'
		]
# self.pool.get('reg.mov').rm_run(cr,uid,{'bief_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','bief_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'calc_preco_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','calc_preco_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'eminota_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','eminota_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'liberacao_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','liberacao_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'concurso_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','concurso_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'quota_act_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','quota_act_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'certificad_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','certificad_id','Movimentos', readonly=True,),

# self.pool.get('reg.mov').rm_run(cr,uid,{'prod_id': ids[0]},context)
# 'movimento_ids': fields.one2many('reg.mov','prod_id','Movimentos', readonly=True,),
STATE = {
    'rascunho': 'Rascunho',
    'submetido': 'Submeter',
    'validar': 'Validar',
    'validado': 'Validado',
    'aprovado': 'Aprovar',
    'rejeitado': 'Rejeitar',
    'cancelado': 'Cancelar',
    'rascunho_2': 'Voltar à Rascunho',
    'autorizar': 'Autorizar',
    'emitido': 'Emitir',

    'n_definido': 'Remarcar Agenda',
    'definido': 'Marcar Agenda',
    }

# def format_name(name):
# 	texto = name
# 	if "'" in 
# 		for t in texto:
# 			if t != simbolo:
# 				ch += t
# 			elif t == simbolo and ch != '' and ch not in lista:
# 				lista.append(ch.replace(' ', '')+'\n')
# 				msg('ch: %s'%ch)
# 				res[i] = ch
# 				ch = ''
# 				i += 1
# 	return texto
class dotcom_registo_movimentos(osv.osv):

	def rm_run(self, cr, uid,rm_vals,context):
		# msg('RM.rm_run, rm_vals: %s'% (rm_vals))
		if context is None: context = {}
		processo, oid, operacao = False, False, False
		for item in LISTA:
			if item in rm_vals:
				processo = PROCESSO[item]
				oid = self.pool.get(MODEL[item]).browse(cr,uid,rm_vals[item],context)
				rm_vals['code'] = CODE[item]
				if oid:
					operacao = STATE[oid.state]
					if item == 'liberacao_id' and 'state_agenda' in rm_vals:
						operacao = STATE[rm_vals['state_agenda']]
					if item == 'prod_id':
						rm_vals['nr_processo'] = oid.ref
					else:
						rm_vals['nr_processo'] = oid.doc_numero
				break
		rm_vals['operacao'] = operacao
		rm_vals['processo'] = processo
		if not processo or not operacao: 
			error(action,'Lista Inválida: %s.'%rm_vals)
		context.update(rm_vals)
		# msg('rm_vals: %s'%(rm_vals))
		self.create(cr,uid,rm_vals,context)	

	_name = 'reg.mov'
	_description = 'Registos movimento processos de um estado para outro'
	_columns = {
		# 'name': fields.function(_get_full_name, string='Nome', type='char', size=128, readonly=True),
		'name': fields.char('Ref', size=120,readonly=True),
		'code': fields.char('Codigo', size=120,readonly=True),
		'nr_processo': fields.char('Processo Nº/Ref', size=120, required=False, readonly=True),
		'processo': fields.char('Processo', size=120, required=True, readonly=True),
		'operacao': fields.char('Operação', size=120, readonly=True),
		'datetime': fields.datetime('Data e Hora', readonly=True),
		'period_id': fields.many2one('configuration.period','Período', readonly=True),
		'user_id': fields.many2one('res.users', 'Usuário', readonly=True, required=True),
	
		'bief_id': fields.many2one('dotcom.importacao.bief', 'BIEF', readonly=True,ondelete='cascade'),
		'liberacao_id': fields.many2one('dotcom.importacao.liberacao', 'Libertação', readonly=True,ondelete='cascade'),
		'calc_preco_id': fields.many2one('dotcom.calculo.precos', 'Cálculo de Preços', readonly=True,ondelete='cascade'),
		'eminota_id': fields.many2one('dotcom.emissao.notas', 'Emissão de Notas', readonly=True,ondelete='cascade'),
		'concurso_id': fields.many2one('dotcom.lancamento.concurso', 'Concursos', readonly=True,ondelete='cascade'),
		'quota_act_id': fields.many2one('dotcom.quotas.actualizacao', 'Actualização de quotas', readonly=True,ondelete='cascade'),
		'certificad_id': fields.many2one('dotcom.quotas.certificado', 'Certificado', readonly=True,ondelete='cascade'),
		# 'quota_vig_id': fields.many2one('dotcom.quotas.vigor', 'Quotas em Vigor', readonly=True,ondelete='cascade'),
		# 'transtitu_id': fields.many2one('dotcom.transf.titularidades', 'Transferência', readonly=True,ondelete='cascade'),
		'prod_id': fields.many2one('dotcom.produto.farmaceutico', 'Produto Farmacêutico', readonly=True,ondelete='cascade'),
		# 'xxxxx_id': fields.many2one('xxxxx_xxxxxx', 'xxxxxx', readonly=True,ondelete='cascade'),
		}	
	_defaults = {
		# 'name': lambda self, cr, uid, c: self.pool.get('reg.mov')._get_full_name(cr, uid,context=c),
		'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
		'period_id': lambda self, cr, uid, c: self.pool.get('configuration.period').find_one(cr, uid),
		'user_id': lambda s, cr, u, c: u,

		'processo': lambda s, cr, u, c: c.get('processo',None),
		'operacao': lambda s, cr, u, c: c.get('operacao',None),
		'bief_id': lambda s, cr, u, c: c.get('bief_id',None),
		'liberacao_id': lambda s, cr, u, c: c.get('liberacao_id',None),
	}


	def _get_full_name(self, cr, uid, code):
		res = {}
		if not code: code = '---',
		all_ids = self.search(cr,uid,[('code','=',code)])
		max_id = (((all_ids and max(all_ids)) or 0) + 1)
		sufix = _add_digitos(8, max_id)
		return ('RM/%s/%s'%(code,sufix))

	def create(self, cr, uid, vals, context=None):
		if context is None: context = {}
		vals['name'] = self._get_full_name(cr, uid,vals['code']) #x[2:-2]
		return super(dotcom_registo_movimentos, self).create(cr, uid, vals, context=context)
dotcom_registo_movimentos()	