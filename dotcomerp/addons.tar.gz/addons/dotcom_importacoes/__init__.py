import JasperDataParser
import classes
import geral
import report




import logging 
from osv import osv
logger = logging.getLogger('DOTCOM') 

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

def __init__(self, cr, uid, ids, data, context):
	error('__init__ ========================================')