# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)


DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class modelo_rel_liberacao_all_linha(osv.osv_memory):
    _name='modelo.rel.liberacao.all.linha' 
    _columns = {
        'parent_id': fields.many2one('modelo.rel.liberacao.all','Parente', readonly=True,),
        'liberacao_id': fields.many2one('dotcom.importacao.liberacao','liberacao', readonly=True, required=True,),
        
        'state': fields.char('Estado', size=120, readonly=True),

        'quant': fields.float('Total(QTD)', readonly=True),
        'preco': fields.float('Total(Preço)', readonly=True), 
        'total': fields.float('Total(Linhas)', readonly=True),
        }
modelo_rel_liberacao_all_linha()

class modelo_rel_liberacao_all(osv.osv_memory):
    _name='modelo.rel.liberacao.all' 
    _columns = {
        'state': fields.selection([('rascunho','Rascunho'),('submetido','Submetido'),('validar','Validar'),('validado','Validado'),('aprovado','Aprovado'),('rejeitado','Rejeitado'),('cancelado','Cancelado'),('rascunho_2','Rascunho'),],'Estado', select=True,),
        
        'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False),
        # 'period_id': fields.many2one('configuration.period','Período'),
        
        'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=False, domain="[('activo','=',True),]",),
        'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', required=False, domain="[('activo','=',True),]",),
        'director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico',domain="[('active','=',True),]",),

        'linha_ids': fields.one2many('modelo.rel.liberacao.all.linha','parent_id','Linhas', readonly=False,),

        'report_type':fields.selection([("pdf","PDF"), ("xls","Excel"), ("html","HTML")],'Type'),
        'from' : fields.date('Início', required=False),
        'to' : fields.date('Término', required=False),
        'group_by':fields.selection([("subs", "Substância Activa"),("gter", "Grupo Terapêutico"),("data", "Por Datas"),],'Agrupar por'),
        # 'currency':fields.selection([("main","Principal"),
        #                             ("secondary","Secundária")],'Moeda'),
        # 'nota': fields.char('Nota', size=512, required=False,),
        }
    _defaults ={
        # 'state': 'submetido',
        'report_type': lambda *a: 'pdf',
        'group_by': lambda *a: 'subs',
        'to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'from': lambda *a: (datetime.now() - timedelta(days=30)).strftime('%Y-%m-01'),
        # 'currency': lambda *a: 'main',
        }

    def processar(self, cr, uid,ids, context={}):
        msg('liberacao_all.processar ids: %s'%ids)
        liberacao_model = self.pool.get('dotcom.importacao.liberacao')
        linha_model = self.pool.get('modelo.rel.liberacao.all.linha')

        query = []
        for document in self.browse(cr,uid,ids):
            for linha_id in document.linha_ids:
                linha_model.unlink(cr, uid, [linha_id.id])
            for liberacao_id in liberacao_model.browse(cr,uid,liberacao_model.search(cr,uid,query)):
                vals = {
                    'parent_id': ids[0],
                    'liberacao_id': liberacao_id.id,                    
                    'state': DICT[liberacao_id.state],
                    'quant': liberacao_id.quant,
                    'preco': liberacao_id.preco,
                    'total': liberacao_id.total,
                    }
                linha_model.create(cr, uid,vals)

                # seq_model = self.pool.get('dotcom.sequencia')
                # lib_model = self.pool.get('dotcom.importacao.liberacao')
                # lib_model.write(cr,uid,[liberacao_id.id],{'doc_numero': seq_model._nr_get(cr,uid,'LIBE','full',context,True)})


    def validar(self, cr, uid,ids,context=None):
        msg('validar. ids: %s'%ids)
        if context is None: context = {}
        # self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')

    def start_report(self, cr, uid,ids, context={}): 
        msg('liberacao_all.start_report ids: %s'%ids)
        data = self.read(cr,uid,ids,)[-1] 
        msg('data: %s'%data)
        liberacao_ids, group_by= [], ''
        self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            group_by = document.group_by or ''
            for linha_id in document.linha_ids:
                # vals = {'doc_numero':linha_id.liberacao_id.doc_numero, 'tipo_liberacao':linha_id.liberacao_id.tipo_liberacao, 'liberacao_id':linha_id.liberacao_id,}
                liberacao_ids.append(linha_id.liberacao_id.id)
            msg('liberacao_ids: %s'%liberacao_ids)
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'report_liberacao_all',
            'datas':{
                    'model': 'modelo.rel.liberacao.all',
                    'id': ids[0] or False,
                    'ids': ids or [],
                    'report_type': data['report_type'],
                    'form': data,
                    'liberacao_ids': liberacao_ids,
            },
            'nodestroy': False,
        }

modelo_rel_liberacao_all()


# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

class liberacao_all_parser(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(liberacao_all_parser, self).__init__(cr, uid, ids, data, context)
        #self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}#{'SELLER':_('Vendedor')}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        msg('generate_records ids: %s, data[from]: %s'%(ids,data))
        pool= pooler.get_pool(cr.dbname)
        result = []
        liberacao_model = pool.get('dotcom.importacao.liberacao')
        licence_model = pool.get('dotcom.licence')
        user_model = pool.get('res.users')  

        print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        form = data['form'] or False
        liberacao_ids = data['liberacao_ids'] or []
        group_by = form['group_by']
        report_type = form['report_type']
        inicio = form['from'] or datetime.strptime(print_date, '%Y-%m-%d')
        termino = form['to'] or datetime.strptime(print_date, '%Y-%m-%d')
        grupo = ''
        
        
        # error('Parre ja!','Parre ja!')
        licenca = 'Não Licenciado'
        # licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
        # if licenca_id:
        #   licenca = licence_model.browse(cr,uid,licenca_id).partner_name

        company_id = user_model.browse(cr,uid,uid).company_id
        company_name = 'Ministério da Saúde - DNF'
        company_logo = company_id.logo or ''
        if company_id:
            company_name = company_id.name or '' 
            company_logo = company_id.logo or ''

            # company_id_street = company_id.street or ''
            # company_id_phone = company_id.phone or ''
            # company_id_tin = company_id.partner_id.nuit or ''
        
        msg('company_name: %s'%company_name)
        for oid in liberacao_model.browse(cr,uid,liberacao_ids): 
            grupo = '%s%ss'%(grupo,DICT[oid.state])
            msg('grupo: %s'%grupo)
            for linha_id in oid.linha_ids:
                grupo = '%s-%s'%(linha_id.prod_id.ref, linha_id.prod_id.name or '' or '')
                if group_by == 'gter': grupo = 'Grupo Terapêutico'
                if group_by == 'data': grupo = '%s'%oid.data or ''
                lista = {
                    'grupo': grupo or '',
                    'inicio': inicio or '',
                    'termino': termino or '',
                    'liberacao_id': oid.doc_numero or '',

                    'licenca': licenca or '',
                    'company_name': company_name or '',
                    'company_logo': company_logo or '',
                    'print_date': print_date or '',

                    'doc_numero': oid.doc_numero or '',
                    'data': oid.data or '',
                    
                    'importador_id': oid.importador_id.name or '',
                    'endereco_import': oid.importador_id.endereco or '',
                    'nuit_import': oid.importador_id.nuit or '',
                    'alvara_import': oid.importador_id.alvara or '',
                    'contacto_import': oid.importador_id.telefone or oid.importador_id.celular or '',

                    'import_director_id': oid.import_director_id.name or '',
                    'fornecedor_id': oid.fornecedor_id.name or '',
                    'forn_nuit': oid.forn_nuit or '',
                    'forn_endereco': oid.fornecedor_id.endereco or '',

                    'tipo_bief': oid.bief_tipo and DICT[oid.bief_tipo] or '',
                    'bief_id': oid.bief_id.doc_numero or '',
                    'data_aprovacao_bief': oid.bief_id.data_aprovacao or '',
                    'data_aprovacao': (oid.data_aprovacao and str('%s'%oid.data_aprovacao)) or '',
                    'proforma': oid.proforma or '',
                    'data_hora_chegada': oid.data_hora_chegada or '',
                    'nr_items': oid.nr_items or '',
                    'alfandega_id': oid.alfandega_id and ('[%s] %s'%(oid.alfandega_id.ref,oid.alfandega_id.name)) or '',
                    'moeda_id': oid.moeda_id.name or '',
                    'nota': oid.nota or '',
                    'oid_quant': oid.quant or '',
                    'oid_preco': oid.preco or '',
                    'oid_total': oid.total or '',
                                
                    'linha_nr_lote': linha_id.nr_lote or '',
                    'linha_prazo': linha_id.prazo or '',
                    'linha_parent_id': linha_id.parent_id.doc_numero or '',
                    'linha_numerador': linha_id.numerador or '',
                    'linha_fnm_code': linha_id.fnm_code or '',
                    'linha_nr_registo': linha_id.nr_registo or '',
                    'linha_prod_id': linha_id.prod_id.name or '',
                    'linha_comercial_name_id': linha_id.comercial_name_id.name or '',
                    'linha_forma': linha_id.forma or '',
                    'linha_dosagem': linha_id.dosagem or '',
                    'linha_apresentacao': linha_id.apresentacao or '',
                    'linha_fabricante_id': linha_id.fabricante_id.name or '',
                    
                    'linha_quant_autorizada': linha_id.quant_autorizada or '',
                    'linha_quant_diferenca': linha_id.quant_diferenca or '',
                    'linha_quant_bief': linha_id.quant_bief or '',
                    'linha_preco': linha_id.preco or '',
                    'linha_total': linha_id.total or '',
                    }
                result.append(lista)

        msg('result: %s'%result)
        result = sorted(result, key=lambda d: (d['liberacao_id'], d['grupo']))
        return result
jasper_reports.report_jasper('report.report_liberacao_all','modelo.rel.liberacao.all',parser=liberacao_all_parser)







# [{
#     'fornecedor_id': u'BioTch SA',
#     'concurso_id': '',
#     'ano_id': u'2020',
#     'qtd': '',
#     'company_logo': 'xxxxxxxxx',
#     'director_id': '',
#     'state': 'Rascunho',
#     'print_date': '11/01/2021 11:46:16',
#     'doc_numero': u'liberacao/DNF/2021/00001',
#     'licenca': 'N\xc3\xa3o Licenciado',
#     'importador_id': u'BBC, LDA',
#     'termino': u'2021-01-10',
#     'tipo_liberacao': 'Servi\xc3\xa7o Nacional de Sa\xc3\xbade - Concurso',
#     'inicio': u'2020-12-01',
#     'data_emissao': '2021-01-07',
#     'preco': '',
#     'grupo': 'liberacao: Servi\xc3\xa7o Nacional de Sa\xc3\xbade - Concurso - Rascunhos',
#     'total': '',
#     'company_name': u'MISAU - Direcc\xe3o Nacional de Farm\xe1cia'
# }] 


