# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class liberacao(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(liberacao, self).__init__(cr, uid, ids, data, context)
		#self.sheet_names = []
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
	   return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		msg('generate_records ids: %s, data: %s'%(ids,data))
		pool= pooler.get_pool(cr.dbname)
		result = []
		liberacao_model = pool.get('dotcom.importacao.liberacao')
		licence_model = pool.get('dotcom.licence')
		user_model = pool.get('res.users')  

		oid = liberacao_model.browse(cr,uid,ids[0])
		
		licenca = 'Não Licenciado'
		# licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
		# if licenca_id:
		# 	licenca = licence_model.browse(cr,uid,licenca_id).partner_name
 
		company_id = user_model.browse(cr,uid,uid).company_id
		company_name = 'Ministério da Saúde - DNF'
		company_logo = company_id.logo or ''
		if company_id:
			company_name = company_id.name or '' 
			company_logo = company_id.logo or ''

			# company_id_street = company_id.street or ''
			# company_id_phone = company_id.phone or ''
			# company_id_tin = company_id.partner_id.nuit or ''
		
		print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
		msg('company_name: %s'%company_name)
		for linha_id in oid.linha_ids: 
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',

				'doc_numero': oid.doc_numero or '',
				'data': oid.data or '',
				
				'importador_id': oid.importador_id.name or '',
				# 'endereco_import': oid.importador_id.endereco or '',
				'nuit_import': oid.importador_id.nuit or '',
				'alvara_import': oid.importador_id.alvara or '',
				'contacto_import': oid.importador_id.telefone or oid.importador_id.celular or '',

				'import_director_id': oid.import_director_id.name or '',
				'fornecedor_id': oid.fornecedor_id.name or '',
				'forn_nuit': oid.forn_nuit or '',
				# 'forn_endereco': oid.fornecedor_id.endereco or '',

				'tipo_bief': oid.bief_tipo and DICT[oid.bief_tipo] or '',
				'bief_id': oid.bief_id.doc_numero or '',
				'data_aprovacao_bief': oid.bief_id.data_aprovacao or '',
				'data_aprovacao': (oid.data_aprovacao and str('Data Aprovação: %s'%oid.data_aprovacao)) or '',
				'proforma': oid.proforma or '',
				'data_hora_chegada': oid.data_hora_chegada or '',
				'nr_items': oid.nr_items or '',
				'alfandega_id': oid.alfandega_id and ('[%s] %s'%(oid.alfandega_id.ref,oid.alfandega_id.name)) or '',
				'moeda_id': oid.moeda_id.name or '',
				'nota': oid.nota or '',
				'oid_quant': oid.quant or '',
				'oid_preco': oid.preco or '',
				'oid_total': oid.total or '',
							
				'linha_nr_lote': linha_id.nr_lote or '',
				'linha_prazo': linha_id.prazo or '',
				'linha_parent_id': linha_id.parent_id.doc_numero or '',
				'linha_numerador': linha_id.numerador or '',
				'linha_fnm_code': linha_id.fnm_code or '',
				'linha_nr_registo': linha_id.nr_registo or '',
				'linha_prod_id': linha_id.prod_id.name or '',
				'linha_comercial_name_id': linha_id.comercial_name_id.name or '',
				'linha_forma': linha_id.forma or '',
				'linha_dosagem': linha_id.dosagem or '',
				'linha_apresentacao': linha_id.apresentacao or '',
				'linha_fabricante_id': linha_id.fabricante_id.name or '',
				
				'linha_quant_autorizada': linha_id.quant_autorizada or '',
				'linha_quant_diferenca': linha_id.quant_diferenca or '',
				'linha_quant_bief': linha_id.quant_bief or '',
				'linha_preco': linha_id.preco or '',
				'linha_total': linha_id.total or '',
				}
			result.append(lista)
		# print(result)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_liberacao','dotcom.importacao.liberacao',parser=liberacao)
