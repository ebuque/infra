# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

def _is(op):#⦿⨱⌧⎂╳🔴🔵
	if op: return 'Sim'#Azul=🔵 
	return 'Não'#'Vermelho=🔴 

def join_it(txt_bool,ms):
	if txt_bool and len(txt_bool) > 0: return ('%s: %s'%(ms,txt_bool))
	return''

def set_label(txt_bool,ms):
	if txt_bool and len(txt_bool) > 0: return ('%s:'%(ms))
	return''

DICT = {
	'psicotropico': 'Psicotrópico',
	'estupefaciente': 'Estupefaciente',
	'percursor': 'Percursor',

	'medicamento': 'Medicamento',
	'saude': 'Prod. de Saúde',
	}

class prod_parser(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(prod_parser, self).__init__(cr, uid, ids, data, context)
		#self.sheet_names = []
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
		return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		msg('generate_records ids: %s, data: %s'%(ids,data))
		pool= pooler.get_pool(cr.dbname)
		result = []
		prod_model = pool.get('dotcom.produto.farmaceutico')
		licence_model = pool.get('dotcom.licence')
		seq_model = pool.get('dotcom.sequencia')
		user_model = pool.get('res.users')  

		oid = prod_model.browse(cr,uid,ids[0])
		
		licenca = 'Não Licenciado'
		# licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
		# if licenca_id:
		# 	licenca = licence_model.browse(cr,uid,licenca_id).partner_name
 
		company_id = user_model.browse(cr,uid,uid).company_id
		company_name = 'Ministério da Saúde - DNF'
		company_logo = company_id.logo or ''
		if company_id:
			company_name = company_id.name or '' 
			company_logo = company_id.logo or ''

			# company_id_street = company_id.street or ''
			# company_id_phone = company_id.phone or ''
			# company_id_tin = company_id.partner_id.nuit or ''
		
		print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
		msg('company_name: %s'%company_name)
		for linha_id in oid.comercial_name_ids: 

			msg('tipo_prod: %s'%oid.tipo_prod)
			msg('categoria: %s'%oid.categoria)
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',

				'grupo': 'Detail 1',
				'ref': oid.ref,
				'name': oid.name,
				# 'is_nacional': _is(oid.is_nacional),
				'subs_controlada': _is(oid.subs_controlada),
				'categoria': oid.categoria, #DICT[oid.categoria],

				'tipo_prod': oid.tipo_prod,
				'fnm_code': linha_id.fnm_code,
				'fnm_code_str': set_label(linha_id.fnm_code,'Código FNM'),
				'tipo_prod_str': set_label(oid.tipo_prod,'Tipo'),

				'nc_ref': linha_id.ref or '',
				'nc_name': linha_id.name or '',
				'nr_registo': linha_id.nr_registo or '',
				'data_criacao': linha_id.data_criacao or '',
				'prod_id': oid.id or '',
				'importador_id': linha_id.importador_id.name or '',
				'forma': linha_id.forma or '',
				'dosagem': linha_id.dosagem or '',
				'apresentacao': linha_id.apresentacao or '',
				'fabricante_id': linha_id.fabricante_id.name or '',
				}
			result.append(lista)

		for linha_id in oid.sal_ids:
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',
				
				'grupo': 'Detail 2',
				'ref': oid.ref,
				'name': oid.name,
				# 'is_nacional': _is(oid.is_nacional),
				'subs_controlada': _is(oid.subs_controlada),
				'categoria': oid.categoria, #DICT[oid.categoria],

				# 'tipo_prod': oid.tipo_prod,
				# 'fnm_code': oid.fnm_code,
				# 'fnm_code_str': set_label(oid.fnm_code,'Código FNM'),
				# 'tipo_prod_str': set_label(oid.tipo_prod,'Tipo'),

				'sal_name_1': linha_id.name or '',
				'fact_conv_1': linha_id.fact_conv or '',
				}
			result.append(lista)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_prod','dotcom.produto.farmaceutico',parser=prod_parser)