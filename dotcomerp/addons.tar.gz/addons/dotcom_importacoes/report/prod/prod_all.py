# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)

def join_it(txt_bool,ms):
    if ms == 'is_nacional':
        if txt_bool and len(txt_bool) > 0: return ('L.Nacional: Sim,      Código FNM: %s'%(txt_bool)) 
        return ('L.Nacional: Não') 
    if ms == 'tipo_prod':
        if txt_bool and len(txt_bool) > 0: return ('Subs Controlada: Sim,      Tipo: %s'%(txt_bool)) 
        return ('Subs Controlada: Não')    
    return''

DICT = {
        'psicotropico': 'Psicotrópico',
        'estupefaciente': 'Estupefaciente',
        'percursor': 'Percursor',

        'medicamento': 'Medicamento',
        'saude': 'Produto de Saúde',
        
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class modelo_rel_prod_all_linha(osv.osv_memory):
    _name='modelo.rel.prod.all.linha' 
    _columns = {
        'parent_id': fields.many2one('modelo.rel.prod.all','Parente', readonly=True,),
        'prod_id': fields.many2one('dotcom.produto.farmaceutico','Produto', readonly=True, required=True,),
        
        'in_use': fields.boolean('Em Uso', readonly=True),
        # 'is_nacional': fields.boolean('Lista Nacional', readonly=True),
        
        'subs_controlada': fields.boolean('Subs. Controlada', readonly=True),
        'tipo_prod': fields.selection([
                ('psicotropico','Psicotrópico'),
                ('estupefaciente','Estupefaciente'),
                ('percursor','Percursor'),],'Tipo de Substância', readonly=True),
        'categoria': fields.selection([('medicamento','Medicamento'),('saude','Produto de Saúde'),],'Categoria', readonly=True),
        }
modelo_rel_prod_all_linha()

class modelo_rel_prod_all(osv.osv_memory):
    _name='modelo.rel.prod.all' 
    _columns = {
        'in_use': fields.boolean('Em Uso', readonly=False),
        # 'is_nacional': fields.boolean('Lista Nacional',),
        
        'subs_controlada': fields.boolean('Subs. Controlada'),
        'tipo_prod': fields.selection([
                ('psicotropico','Psicotrópico'),
                ('estupefaciente','Estupefaciente'),
                ('percursor','Percursor'),],'Tipo de Substância', readonly=False),
        'categoria': fields.selection([('medicamento','Medicamento'),('saude','Produto de Saúde'),],'Categoria',),

        'linha_ids': fields.one2many('modelo.rel.prod.all.linha','parent_id','Linhas', readonly=False,),

        'report_type':fields.selection([("pdf","PDF"), ("xls","Excel"), ("html","HTML")],'Type'),
        'from' : fields.date('Início', required=False),
        'to' : fields.date('Término', required=False),
        'group_by':fields.selection([("tipo_prod","Tipo de Produto"),("categoria", "Categoria"),("nacional", "Nacional"),],'Agrupar por'),
        }

    _defaults ={
        'report_type': lambda *a: 'pdf',
        'group_by': lambda *a: 'tipo_prod',
        'to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'from': lambda *a: (datetime.now() - timedelta(days=30)).strftime('%Y-%m-01'),
        }

    def _change(self, cr, uid, ids, vals, context=None):
        self.write(cr,uid,ids,vals)
        return {'value': vals}

    def on_ch(self, cr, uid, ids, valor, descricao, context=None):
        msg('prod.all.on_ch(%s = %s)'%(descricao,valor))
        if context is None: context = {}
        vals = {}
        if descricao == 'subs_controlada':
            if not valor:  self._change(cr, uid, ids, {'tipo_prod': '',})

    def processar(self, cr, uid,ids, context={}):
        msg('prod_all.processar ids: %s'%ids)
        prod_model = self.pool.get('dotcom.produto.farmaceutico')
        linha_model = self.pool.get('modelo.rel.prod.all.linha')

        query = []
        for document in self.browse(cr,uid,ids):
            for linha_id in document.linha_ids:
                linha_model.unlink(cr, uid, [linha_id.id])
            for prod_id in prod_model.browse(cr,uid,prod_model.search(cr,uid,query)):
                vals = {
                    'parent_id': ids[0],
                    'prod_id': prod_id.id,
                    
                    'in_use': prod_id.in_use,
                    # 'is_nacional': prod_id.is_nacional,
                    
                    'subs_controlada': prod_id.subs_controlada,
                    'tipo_prod': prod_id.tipo_prod,
                    'categoria': prod_id.categoria,
                    }
                linha_model.create(cr, uid,vals)

    def validar(self, cr, uid,ids,context=None):
        msg('validar. ids: %s'%ids)
        if context is None: context = {}
        # self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')

    def start_report(self, cr, uid,ids, context={}): 
        msg('prod_all.start_report ids: %s'%ids)
        data = self.read(cr,uid,ids,)[-1] 
        msg('data: %s'%data)
        prod_ids, group_by= [], ''
        self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            group_by = document.group_by or ''
            for linha_id in document.linha_ids:
                prod_ids.append(linha_id.prod_id.id)
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'report_prod_all',
            'datas':{
                    'model': 'modelo.rel.prod.all',
                    'id': ids[0] or False,
                    'ids': ids or [],
                    'report_type': data['report_type'],
                    'form': data,
                    'prod_ids': prod_ids,
            },
            'nodestroy': False,
        }

modelo_rel_prod_all()


# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

class prod_all_parser(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(prod_all_parser, self).__init__(cr, uid, ids, data, context)
        #self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}#{'SELLER':_('Vendedor')}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        msg('generate_records ids: %s, data[from]: %s'%(ids,data))
        pool= pooler.get_pool(cr.dbname)
        result = []
        prod_model = pool.get('dotcom.produto.farmaceutico')
        licence_model = pool.get('dotcom.licence')
        user_model = pool.get('res.users')  

        print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        form = data['form'] or False
        prod_ids = data['prod_ids'] or []
        group_by = form['group_by']
        report_type = form['report_type']
        inicio = form['from'] or datetime.strptime(print_date, '%Y-%m-%d')
        termino = form['to'] or datetime.strptime(print_date, '%Y-%m-%d')
        grupo = ''
        
        
        # error('Parre ja!','Parre ja!')
        licenca = 'Não Licenciado'
        # licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
        # if licenca_id:
        #   licenca = licence_model.browse(cr,uid,licenca_id).partner_name

        company_id = user_model.browse(cr,uid,uid).company_id
        company_name = 'Ministério da Saúde - DNF'
        company_logo = company_id.logo or ''
        if company_id:
            company_name = company_id.name or '' 
            company_logo = company_id.logo or ''

            # company_id_street = company_id.street or ''
            # company_id_phone = company_id.phone or ''
            # company_id_tin = company_id.partner_id.nuit or ''
        
        msg('company_name: %s'%company_name)
        for oid in prod_model.browse(cr,uid,prod_ids): 
            if group_by == 'tipo_prod':
                grupo = '%s'%(oid.tipo_prod and DICT[oid.tipo_prod] or '')
                if len(grupo) > 0: grupo = '%s%s'%(',   -   Tipo: ',grupo)
            if group_by == 'categoria': grupo = ',   -   %s'%(oid.categoria and DICT[oid.categoria] or '')
            # if group_by == 'nacional': grupo = ',   -   Nacional: %s'%(oid.is_nacional and "Sim" or 'Não')
            for linha_id in oid.comercial_name_ids:
                lista = {
                    'licenca': licenca or '',
                    'company_name': company_name or '',
                    'company_logo': company_logo or '',
                    'print_date': print_date or '',

                    'grupo': '%s%s'%(oid.name, grupo),
                    # 'produto': '[%s] %s,   Categoria: %s'%(oid.ref, oid.name, (oid.categoria and DICT[oid.categoria] or '')),
                    'descricao': 'Categoria: %s,      %s'%((oid.categoria and DICT[oid.categoria] or ''),join_it(oid.tipo_prod,'tipo_prod')),

                    'nc_ref': linha_id.ref or '',
                    'nc_name': linha_id.name or '',
                    'nr_registo': linha_id.nr_registo or '',
                    'data_criacao': linha_id.data_criacao or '',
                    'prod_id': oid.id or '',
                    'importador_id': linha_id.importador_id.name or '',
                    'forma': linha_id.forma or '',
                    'dosagem': linha_id.dosagem or '',
                    'apresentacao': linha_id.apresentacao or '',
                    'fabricante_id': linha_id.fabricante_id.name or '',
                    }
                result.append(lista)
        msg('result: %s'%result)
        result = sorted(result, key=lambda d: (d['grupo']))# d['ref'], d['name']
        return result
jasper_reports.report_jasper('report.report_prod_all','modelo.rel.prod.all',parser=prod_all_parser)


