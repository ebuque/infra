# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class bief(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(bief, self).__init__(cr, uid, ids, data, context)
		#self.sheet_names = []
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
	   return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		msg('generate_records ids: %s, data: %s'%(ids,data))
		pool= pooler.get_pool(cr.dbname)
		result = []
		bief_model = pool.get('dotcom.importacao.bief')
		licence_model = pool.get('dotcom.licence')
		seq_model = pool.get('dotcom.sequencia')
		user_model = pool.get('res.users')  

		oid = bief_model.browse(cr,uid,ids[0])
		
		licenca = 'Não Licenciado'
		# licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
		# if licenca_id:
		# 	licenca = licence_model.browse(cr,uid,licenca_id).partner_name
 
		company_id = user_model.browse(cr,uid,uid).company_id
		company_name = 'Ministério da Saúde - DNF'
		company_logo = company_id.logo or ''
		if company_id:
			company_name = company_id.name or '' 
			company_logo = company_id.logo or ''

			# company_id_street = company_id.street or ''
			# company_id_phone = company_id.phone or ''
			# company_id_tin = company_id.partner_id.nuit or ''
		
		print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
		msg('company_name: %s'%company_name)
		for linha_id in oid.linha_ids: 
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',

				'importador_id': oid.importador_id.name or '',
				'endereco_import': oid.endereco_import or '',
				'nuit_import': oid.nuit_import or '',
				'fornecedor_id': oid.fornecedor_id.name or '',
				'pro_forma': oid.pro_forma or '',
				'director_id': oid.director_id and oid.director_id.name or '',
				'director_cpf': oid.director_id and oid.director_id.cpf,


				'doc_numero': oid.doc_numero or '',
				'data_emissao': oid.data_emissao or '',
				'data_aprovacao': str('Data Aprovação: %s'%oid.data_aprovacao) or '',
				'prazo': oid.prazo or '',
				'data_vencimento': oid.data_vencimento or '',
				'period_id': oid.period_id.name or '',
				'ano_id': oid.ano_id.name or '',

                # 'tipo': DICT[oid.tipo_bief],
                # 'state': DICT[oid.state],
				'tipo_bief': DICT[oid.tipo_bief] or '',
				'concurso_id': oid.concurso_id and str('Concurso: %s'%oid.concurso_id.name) or '',
				'nota': oid.nota or '',
				

				'linha_parent_id': linha_id.parent_id.doc_numero or '',
				'linha_numerador': linha_id.numerador or '',
				'linha_fnm_code': linha_id.fnm_code or '',
				'linha_nr_registo': linha_id.nr_registo or '',
				'linha_prod_id': linha_id.prod_id.name or '',
				'linha_comercial_name_id': linha_id.comercial_name_id.name or '',
				'linha_forma': linha_id.forma or '',
				'linha_dosagem': linha_id.dosagem or '',
				'linha_apresentacao': linha_id.apresentacao or '',
				'linha_fabricante_id': linha_id.fabricante_id.name or '',
				'linha_quant': linha_id.quant or '',
				'linha_preco': linha_id.preco or '',
				'linha_total': linha_id.total or '',
				
				'oid_quant': oid.quant or '',
				'oid_preco': oid.preco or '',
				'oid_total': oid.total or '',

				'state': str('Estado: %s'%DICT[oid.state]) or '',
				'moeda_id': oid.moeda_id.name or '',
				'moeda_str': oid.moeda_str or '',
				'cambio': oid.cambio or '',
				'total_moeda': oid.total_moeda or '',
				'moeda_principal_id': oid.moeda_principal_id.name or '',
				'cambio_principal': oid.cambio_principal or '',
				'total_principal': oid.total_principal or '',
				'moeda_secundaria_id': oid.moeda_secundaria_id.name or '',
				'cambio_secundario': oid.cambio_secundario or '',
				'total_secundario': oid.total_secundario or '',
				}
			result.append(lista)
		# print(result)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_bief','dotcom.importacao.bief',parser=bief)

# $F{linha_quant}==""?BigDecimal.ZERO:BigDecimal.valueOf(new Double($F{linha_quant}))
# $F{linha_preco}==""?BigDecimal.ZERO:BigDecimal.valueOf(new Double($F{linha_preco}))
# $F{linha_total}==""?BigDecimal.ZERO:BigDecimal.valueOf(new Double($F{linha_total}))
# {'moeda_principal_id': u'MT',
# 'moeda_id': u'EUR',
# 'endereco_import': u'Av. dos Importadores, 99875',
# 'oid_quant': 1000.0, 'linha_fabricante_id': u'Global Pharma Healthcare Private Limited-India',
# 'importador_id': u'ORANE PHARMA, Lda',
# 'ano_id': u'2020',
# 'linha_quant': 1000, 'prazo': u'anual',
# 'linha_dosagem': u'250mg',
# 'doc_numero': u'BIEF/DNF/2020/00001',
# 'linha_apresentacao': u'Embalagem de 10 blisters de 10 comprimidos',
# 'linha_forma': u'Comprimidos revestidos',
# 'concurso_id': '',
# 'linha_total': 150000.0, 'cambio_principal': 1.0, 'data_aprovacao': '',
# 'linha_fnm_code': '',
# 'period_id': u'December/2020',
# 'total_principal': '',
# 'data_vencimento': '2021-12-28',
# 'moeda_secundaria_id': u'USD',
# 'data_emissao': '2020-12-28',
# 'fornecedor_id': u'BioTch SA',
# 'linha_numerador': 1, 'total_secundario': '',
# 'nuit_import': u'9845123',
# 'moeda_str': u'MT',
# 'cambio_secundario': 27.44, 'pro_forma': u'8484',
# 'linha_parent_id': u'BIEF/DNF/2020/00001',
# 'linha_preco': 150.0, 'print_date': '05/01/2021 18:52:58',
# 'state': u'submetido',
# 'nota': u'345678',
# 'company_name': 'Minist\xc3\xa9rio da Sa\xc3\xbade - DNF',
# 'licenca': 'N\xc3\xa3o Licenciado',
# 'oid_total': 150000.0, 'linha_comercial_name_id': u'RYTHRO 250',
# 'linha_nr_registo': u'J6170',
# 'total_moeda': '',
# 'linha_prod_id': u'Estearato de eritromicina',
# 'cambio': 90.0, 'tipo_bief': u'extra',
# 'oid_preco': 150.0}