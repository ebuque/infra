# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)


DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class modelo_rel_bief_all_linha(osv.osv_memory):
    _name='modelo.rel.bief.all.linha' 
    _columns = {
        'parent_id': fields.many2one('modelo.rel.bief.all','Parente', readonly=True,),
        'bief_id': fields.many2one('dotcom.importacao.bief','BIEF', readonly=True, required=True,),
        
        'tipo_bief': fields.char('Tipo', size=120, readonly=True,),
        'state': fields.char('Estado', size=120, readonly=True),

        'concurso': fields.char('Concurso', size=120, readonly=True),
        'ano': fields.char('Ano Fiscal', size=120, readonly=True),
        'periodo': fields.char('Período', size=120, readonly=True),
        'importador': fields.char('Importador', size=120, readonly=True),
        'fornecedor': fields.char('Fornecedor', size=120, readonly=True),
        'director': fields.char('Dir. Técnico', size=120, readonly=True),

        'quant': fields.float('Total(QTD)', readonly=True),
        'preco': fields.float('Total(Preço)', readonly=True), 
        'total': fields.float('Total(Linhas)', readonly=True),
        }
modelo_rel_bief_all_linha()

class modelo_rel_bief_all(osv.osv_memory):
    _name='modelo.rel.bief.all' 
    _columns = {
        # 'state': fields.selection([('rascunho','Rascunho'),('submetido','Submetido'),('validar','Validar'),('validado','Validado'),('aprovado','Aprovado'),('rejeitado','Rejeitado'),('cancelado','Cancelado'),('rascunho_2','Rascunho'),],'Estado', select=True,),
        'tipo_bief': fields.selection([('imes','Importação Especial'),('snsc','Serviço Nacional de Saúde - Concurso'),('snsd','Serviço Nacional de Saúde - Doação'),('lnme','Lista Nacional de Medicamentos Essenciais'),('extra','Extra Lista'),('prosa','Produtos de Saúde'),],'Tipo BIEF', required=False,readonly=False,),
        
        'data_emissao': fields.date('Emissão', required=False, help='Data da Emissão'),
        'data_aprovacao': fields.date('Aprovação', required=False, help='Data da Aprovação'),
        'data_vencimento': fields.date('Vencimento', required=False, help='Data de Vencimento'),
        'data_libertacao': fields.date('Libertação', required=False, help='Data de Libertação'),
        
        # 'concurso_id': fields.many2one('dotcom.lancamento.concurso','Concurso', required=False,),
        'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=True),
        # 'period_id': fields.many2one('configuration.period','Período'),
        
        'importador_id': fields.many2one('dotcom.parceiro.importador','Importador', required=False, domain="[('activo','=',True),]",),
        'fornecedor_id': fields.many2one('dotcom.parceiro.fornecedor','Fornecedor', required=False, domain="[('activo','=',True),]",),
        'director_id': fields.many2one('dotcom.director.tecnico','Dir. Técnico',domain="[('active','=',True),]",),

        'comercial_name_id': fields.many2one('dotcom.prod.comercial_name','Nome Comercial', readonly=False,),
        'grupo_terapeutico_id': fields.many2one('dotcom.grupo.terapeutico','Gr Terapêutico', required=False,readonly=False),

        'linha_ids': fields.one2many('modelo.rel.bief.all.linha','parent_id','Linhas', readonly=False,),

        'report_type':fields.selection([("pdf","PDF"), ("xls","Excel"), ("html","HTML")],'Type'),
        'from' : fields.date('Início', required=False),
        'to' : fields.date('Término', required=False),
        'group_by':fields.selection([
            ("tipo_bief","Tipo de BIEF"),

            ('data_emissao','Data da Emissão'),
            ('data_aprovacao','Data da Aprovação'),
            ('data_vencimento','Data de Vencimento'),
            ('data_libertacao','Data de Libertação'),

            ("director", "Director"),
            ("importador", "Importador"),
            ("fornecedor", "Fornecedor"),
            # ("concurso", "Concurso"),
            ],'Agrupar por'),
        # 'currency':fields.selection([("main","Principal"),
        #                             ("secondary","Secundária")],'Moeda'),
        # 'nota': fields.char('Nota', size=512, required=False,),
        }
    _defaults ={
        # 'state': 'submetido',
        # 'tipo': 'submetido',
        'report_type': lambda *a: 'pdf',
        'group_by': lambda *a: 'tipo_bief',
        'to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'from': lambda *a: (datetime.now() - timedelta(days=30)).strftime('%Y-%m-01'),
        # 'currency': lambda *a: 'main',
        }
    def _change(self, cr, uid, ids, vals, context=None):
        self.write(cr,uid,ids,vals)
        return {'value': vals}

    def on_ch(self, cr, uid, ids, valor, descricao, context=None):
        msg('bief_all.on_ch_ %s valor: %s'%(descricao,valor))
        if context is None: context = {}
        vals = {}
        if descricao in ['comercial_name_id']:
            if not valor: vals = {'grupo_terapeutico_id': False,}            
            if valor:
                oid = self.pool.get('dotcom.prod.comercial_name').browse(cr,uid,valor)
                vals = {'grupo_terapeutico_id': oid.grupo_terapeutico_id.id}
        return self._change(cr, uid, ids, vals)

    def get_totais(self, cr, uid,parent_id, campo, valor, context={}):
        msg('bief_all.get_totais bief_id: %s where %s=%s'%(parent_id,campo,valor))
        bief_model = self.pool.get('dotcom.importacao.bief')
        bief_linha_model = self.pool.get('dotcom.bief.linha')
        bief_linha_ids = bief_linha_model.search(cr,uid,[('parent_id','=',parent_id),(campo,'=',valor)])
        quant, preco, total =  0,0,0  
        for linha_id in bief_linha_model.browse(cr,uid,bief_linha_ids):
            quant += linha_id.quant
            preco += linha_id.preco
            total += linha_id.total
        return quant, preco, total

    def processar(self, cr, uid,ids, context={}):
        msg('bief_all.processar ids: %s'%ids)
        bief_model = self.pool.get('dotcom.importacao.bief')
        bief_linha_model = self.pool.get('dotcom.bief.linha')
        linha_model = self.pool.get('modelo.rel.bief.all.linha')

        query = []
        for document in self.browse(cr,uid,ids):
            query.append(('state','!=','rascunho'),('ano_id','=',document.ano_id.id))
            if document.tipo_bief: query.append(('tipo_bief','=',document.tipo_bief))
            if document.ano_id: query.append(('ano_id','=',document.ano_id.id))
            if document.importador_id: query.append(('importador_id','=',document.importador_id.id))
            if document.fornecedor_id: query.append(('fornecedor_id','=',document.fornecedor_id.id))
            if document.director_id: query.append(('director_id','=',document.director_id.id))

            if document.data_emissao: query.append(('data_emissao','=',document.data_emissao))
            if document.data_aprovacao: query.append(('data_aprovacao','=',document.data_aprovacao))
            if document.data_vencimento: query.append(('data_vencimento','=',document.data_vencimento))
            if document.data_libertacao: query.append(('data_libertacao','=',document.data_libertacao))

            for linha_id in document.linha_ids:
                linha_model.unlink(cr, uid, [linha_id.id])

            query_ids = []
            for bief_id in bief_model.browse(cr,uid,bief_model.search(cr,uid,query)):
                if document.comercial_name_id:
                    bief_linha_ids = bief_linha_model.search(cr,uid,[('parent_id','=',bief_id.id),('comercial_name_id','=',document.comercial_name_id.id)])
                    if bief_linha_ids: query_ids.append(bief_id)
                elif document.grupo_terapeutico_id:
                    bief_linha_ids = []
                    for linha_id in bief_id.linha_ids:
                        if linha_id.comercial_name_id.grupo_terapeutico_id.id == document.grupo_terapeutico_id.id:
                            bief_linha_ids.append(bief_id)
                    if bief_linha_ids: query_ids.append(bief_id)
                else: query_ids.append(bief_id)

            for bief_id in query_ids:
                quant, preco, total = bief_id.quant, bief_id.preco, bief_id.total
                if document.comercial_name_id: quant, preco, total = self.get_totais(cr,uid,bief_id.id,'comercial_name_id',document.comercial_name_id.id)
                elif document.comercial_name_id: quant, preco, total = self.get_totais(cr,uid,bief_id.id,'grupo_terapeutico_id',document.comercial_name_id.grupo_terapeutico_id.id)
                vals = {
                    'parent_id': ids[0],
                    'bief_id': bief_id.id,
                    
                    'tipo_bief': DICT[bief_id.tipo_bief],
                    'state': DICT[bief_id.state],
                    
                    'concurso': bief_id.concurso_id and bief_id.concurso_id.doc_numero,
                    'ano': bief_id.ano_id.name,
                    # 'periodo': bief_id.periodo_id.name,
                    'importador': bief_id.importador_id.name,
                    'fornecedor': bief_id.fornecedor_id.name,
                    'director': bief_id.director_id and bief_id.director_id.name,

                    'quant': quant,
                    'preco': preco,
                    'total': total,
                    }
                linha_model.create(cr, uid,vals)

    def validar(self, cr, uid,ids,context=None):
        msg('validar. ids: %s'%ids)
        if context is None: context = {}
        # self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')

    def start_report(self, cr, uid,ids, context={}): 
        msg('bief_all.start_report ids: %s'%ids)
        data = self.read(cr,uid,ids,)[-1] 
        msg('data: %s'%data)
        bief_ids, group_by= [], ''
        comercial_name_id, grupo_terapeutico_id = False, False
        self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            grupo_terapeutico_id = document.grupo_terapeutico_id and document.grupo_terapeutico_id.id or False
            if document.comercial_name_id:
                comercial_name_id = document.comercial_name_id
                grupo_terapeutico_id = False
            group_by = document.group_by or ''
            for linha_id in document.linha_ids:
                # vals = {'doc_numero':linha_id.bief_id.doc_numero, 'tipo_bief':linha_id.bief_id.tipo_bief, 'bief_id':linha_id.bief_id,}
                bief_ids.append(linha_id.bief_id.id)
            msg('start_report - bief_ids: %s,    comercial_name_id: %s'%(bief_ids,comercial_name_id))
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'report_bief_all',
            'datas':{
                    'model': 'modelo.rel.bief.all',
                    'id': ids[0] or False,
                    'ids': ids or [],
                    'report_type': data['report_type'],
                    'form': data,
                    'bief_ids': bief_ids,
                    'comercial_name_id': comercial_name_id.id,
                    'grupo_terapeutico_id': grupo_terapeutico_id,
            },
            'nodestroy': False,
        }

modelo_rel_bief_all()


# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

class bief_all_parser(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(bief_all_parser, self).__init__(cr, uid, ids, data, context)
        #self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}#{'SELLER':_('Vendedor')}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def get_totais(self, cr, uid,parent_id, campo, valor, context={}):
        msg('bief_all.get_totais bief_id: %s where %s=%s'%(parent_id,campo,valor))
        bief_model = self.pool.get('dotcom.importacao.bief')
        bief_linha_model = self.pool.get('dotcom.bief.linha')
        bief_linha_ids = bief_linha_model.search(cr,uid,[('parent_id','=',parent_id),(campo,'=',valor)])
        quant, preco, total =  0,0,0  
        for linha_id in bief_linha_model.browse(cr,uid,bief_linha_ids):
            quant += linha_id.quant
            preco += linha_id.preco
            total += linha_id.total
        return quant, preco, total

    def generate_records(self, cr, uid, ids, data, context):
        msg('generate_records ids: %s, data[from]: %s'%(ids,data))
        pool= pooler.get_pool(cr.dbname)
        result = []
        bief_model = pool.get('dotcom.importacao.bief')
        licence_model = pool.get('dotcom.licence')
        user_model = pool.get('res.users')  
        cn_model = pool.get('dotcom.prod.comercial_name') 
        gterapeutico_model = pool.get('dotcom.grupo.terapeutico') 

        print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        form = data['form'] or False
        bief_ids = data['bief_ids'] or []
        comercial_name_id = data['comercial_name_id'] or False
        grupo_terapeutico_id = data['grupo_terapeutico_id'] or False
        group_by = form['group_by']
        report_type = form['report_type']
        inicio = form['from'] or datetime.strptime(print_date, '%Y-%m-%d')
        termino = form['to'] or datetime.strptime(print_date, '%Y-%m-%d')
        grupo = ''
        
        
        # error('Parre ja!','Parre ja!')
        licenca = 'Não Licenciado'
        # licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
        # if licenca_id:
        #   licenca = licence_model.browse(cr,uid,licenca_id).partner_name

        company_id = user_model.browse(cr,uid,uid).company_id
        company_name = 'Ministério da Saúde - DNF'
        company_logo = company_id.logo or ''
        if company_id:
            company_name = company_id.name or '' 
            company_logo = company_id.logo or ''

            # company_id_street = company_id.street or ''
            # company_id_phone = company_id.phone or ''
            # company_id_tin = company_id.partner_id.nuit or ''
        
        msg('company_name: %s'%company_name)
        for oid in bief_model.browse(cr,uid,bief_ids): 

            quant, preco, total = oid.quant, oid.preco, oid.total
            tema = ''
            if comercial_name_id:
                comercial_name_id = cn_model.browse(cr,uid,comercial_name_id)
                tema = 'Nome Comercial: %s'%comercial_name_id.name 
                quant, preco, total = self.get_totais(cr,uid,oid.id,'comercial_name_id',comercial_name_id.id)
            elif grupo_terapeutico_id:
                grupo_terapeutico_id = gterapeutico_model.browse(cr,uid,grupo_terapeutico_id)
                tema = 'Grupo Terapêutico: %s'%grupo_terapeutico_id.name
                quant, preco, total = self.get_totais(cr,uid,oid.id,'grupo_terapeutico_id',grupo_terapeutico_id.id)
            
            if group_by == 'tipo_bief': grupo = 'Tipo de BIEF: %s'%DICT[oid.tipo_bief]
            if group_by == 'director': grupo = 'Director: %s'%DICT[oid.director_id.name]
            if group_by == 'importador': grupo = 'Importador: %s'%DICT[oid.importador_id.name]
            if group_by == 'fornecedor': grupo = 'Fornecedor: %s'%DICT[oid.fornecedor_id.name]

            if group_by == 'data_emissao': grupo = 'Data da Emissão: %s'%oid.data_emissao
            if group_by == 'data_aprovacao': grupo = 'Data da Aprovação: %s'%oid.data_aprovacao
            if group_by == 'data_vencimento': grupo = 'Data de Vencimento: %s'%oid.data_vencimento
            if group_by == 'data_libertacao': grupo = 'Data de Libertação: %s'%oid.data_libertacao
            msg('grupo: %s'%grupo)

            lista = {
                'tema': tema or '',
                'grupo': grupo or '',
                'inicio': inicio or '',
                'termino': termino or '',

                'licenca': licenca or '',
                'company_name': company_name or '',
                'company_logo': company_logo or '',
                'print_date': print_date or '',

                'doc_numero': oid.doc_numero or '',
                'state': DICT[oid.state] or '',
                'tipo_bief': DICT[oid.tipo_bief] or '',
                'concurso_id': oid.concurso_id and str('%s'%oid.concurso_id.doc_numero) or '',
                'data_emissao': oid.data_emissao or '',
                'ano_id': oid.ano_id.name or '',

                'importador_id': oid.importador_id.name or '',
                'fornecedor_id': oid.fornecedor_id.name or '',
                'director_id': oid.director_id and oid.director_id.name or '',
                
                'qtd': quant or '',
                'preco': preco or '',
                'total': total or '',
                }
            result.append(lista)
        msg('result: %s'%result)
        result = sorted(result, key=lambda d: (d['grupo']))# d['ref'], d['name']
        return result
jasper_reports.report_jasper('report.report_bief_all','modelo.rel.bief.all',parser=bief_all_parser)







# [{
#     'fornecedor_id': u'BioTch SA',
#     'concurso_id': '',
#     'ano_id': u'2020',
#     'qtd': '',
#     'company_logo': 'xxxxxxxxx',
#     'director_id': '',
#     'state': 'Rascunho',
#     'print_date': '11/01/2021 11:46:16',
#     'doc_numero': u'BIEF/DNF/2021/00001',
#     'licenca': 'N\xc3\xa3o Licenciado',
#     'importador_id': u'BBC, LDA',
#     'termino': u'2021-01-10',
#     'tipo_bief': 'Servi\xc3\xa7o Nacional de Sa\xc3\xbade - Concurso',
#     'inicio': u'2020-12-01',
#     'data_emissao': '2021-01-07',
#     'preco': '',
#     'grupo': 'BIEF: Servi\xc3\xa7o Nacional de Sa\xc3\xbade - Concurso - Rascunhos',
#     'total': '',
#     'company_name': u'MISAU - Direcc\xe3o Nacional de Farm\xe1cia'
# }] 


