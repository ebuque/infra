# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'emitido': 'Emitido',
    }

def _is(op):#⦿⨱⌧⎂╳🔴🔵
	if op: return 'Sim'#Azul=🔵 
	return 'Não'#'Vermelho=🔴 

def join_it(txt_bool,ms):
	if txt_bool and len(txt_bool) > 0: return ('%s: %s'%(ms,txt_bool))
	return''

def set_label(txt_bool,ms):
	if txt_bool and len(txt_bool) > 0: return ('%s:'%(ms))
	return''

class eminota_parser(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(eminota_parser, self).__init__(cr, uid, ids, data, context)
		#self.sheet_names = []
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
		return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		msg('generate_records ids: %s, data: %s'%(ids,data))
		pool= pooler.get_pool(cr.dbname)
		result = []
		eminota_model = pool.get('dotcom.emissao.notas')
		licence_model = pool.get('dotcom.licence')
		user_model = pool.get('res.users')  

		oid = eminota_model.browse(cr,uid,ids[0])
		
		licenca = 'Não Licenciado'
		# licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
		# if licenca_id:
		# 	licenca = licence_model.browse(cr,uid,licenca_id).partner_name
 
		company_id = user_model.browse(cr,uid,uid).company_id
		company_name = 'Ministério da Saúde - DNF'
		company_logo = company_id.logo or ''
		if company_id:
			company_name = company_id.name or '' 
			company_logo = company_id.logo or ''

			# company_id_street = company_id.street or ''
			# company_id_phone = company_id.phone or ''
			# company_id_tin = company_id.partner_id.nuit or ''
		
		print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
		msg('company_name: %s'%company_name)
		for linha_id in oid.linha_ids:
			bief_id = linha_id.bief_id
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',
				
				'doc_numero': oid.doc_numero or '',
				'data': oid.data or '',
				'ano_id': oid.ano_id.name or '',
				'period_id': oid.period_id.name or '',
				'importador_id': '[%s] %s'%(oid.importador_id.ref,oid.importador_id.name) or '',
				'nota': oid.nota or '---',

				'bief_id': '[%s] %s'%(bief_id.doc_numero,DICT[bief_id.tipo_bief]) or '',
				'data_aprovacao': bief_id.data_aprovacao or '',
				}
			result.append(lista)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_eminota','dotcom.emissao.notas',parser=eminota_parser)