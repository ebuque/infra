# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class calculopreco(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(calculopreco, self).__init__(cr, uid, ids, data, context)
		#self.sheet_names = []
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
	   return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		msg('generate_records ids: %s, data: %s'%(ids,data))
		pool= pooler.get_pool(cr.dbname)
		result = []
		calculopreco_model = pool.get('dotcom.calculo.precos')
		licence_model = pool.get('dotcom.licence')
		seq_model = pool.get('dotcom.sequencia')
		user_model = pool.get('res.users')  

		oid = calculopreco_model.browse(cr,uid,ids[0])
		
		licenca = 'Não Licenciado'
		# licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
		# if licenca_id:
		# 	licenca = licence_model.browse(cr,uid,licenca_id).partner_name
 
		company_id = user_model.browse(cr,uid,uid).company_id
		company_name = 'Ministério da Saúde - DNF'
		company_logo = company_id.logo or ''
		if company_id:
			company_name = company_id.name or '' 
			company_logo = company_id.logo or ''

			# company_id_street = company_id.street or ''
			# company_id_phone = company_id.phone or ''
			# company_id_tin = company_id.partner_id.nuit or ''
		
		print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
		msg('company_name: %s'%company_name)
		for linha_id in oid.linha_ids: 
			lista = {
				'licenca': licenca or '',
				'company_name': company_name or '',
				'company_logo': company_logo or '',
				'print_date': print_date or '',

				'importador_id': oid.importador_id.name or '',
				'doc_numero': oid.doc_numero or '',
				'data': oid.data or '',
				'data_aprovacao': oid.data_aprovacao or '',
				'period_id': oid.period_id.name or '',
				'ano_id': oid.ano_id.name or '',
	
				'factura': oid.factura or '',	
				'liberacao_id': oid.liberacao_id.doc_numero or '',	
				'data_factura': oid.data_factura or '',	
				
				'moeda_id': oid.moeda_id.name or '',	
				'moeda_factura_id': oid.moeda_factura_id.name or '',	
				'cambio_factura': oid.cambio_factura or '',	
				'total_fob': oid.total_fob or '',	
				'total_cif': oid.total_cif or '',	
				'seguro': oid.seguro or '',	
				'frete': oid.frete or '',	
				'fact_conv': oid.fact_conv or '',	
				
				'dai_1': oid.dai or '',	
				'li': oid.li or '',	
				'lf': oid.lf or '',	
				'lfe': oid.lfe or '',	
				
				'iva': oid.iva or '',	
				'da': oid.da or '',	
				'ice': oid.ice or '',	
				'oc': oid.oc or '',	
				'nota': oid.nota or '',	



				'lote_nr': linha_id.lote_nr or '',	
				'prod_id': linha_id.prod_id.name or '',	
				'comercial_name_id': linha_id.comercial_name_id.name or '',	
				'forma': linha_id.forma or '',	
				'dosagem': linha_id.dosagem or '',	
				'apresentacao': linha_id.apresentacao or '',	
				'fabricante_id': linha_id.fabricante_id.full_name or '',	
				
				'quant': linha_id.quant or '',	
				'fob_origem': linha_id.fob_origem or '',	
				'fob': linha_id.fob or '',	
				'cif': linha_id.cif or '',	
				'dai': linha_id.dai or '',	
				'pvf': linha_id.pvf or '',	
				'pvp': linha_id.pvp or '',	
				'pvp_farmac': linha_id.pvp_farmac or '',	
				}
			result.append(lista)
		# print(result)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_calculopreco','dotcom.calculo.precos',parser=calculopreco)



# aaa = """
# licenca,company_name,company_logo,print_date,importador_id,doc_numero,data,data_aprovacao,period_id,ano_id,factura,liberacao_id,data_factura,moeda_id,moeda_factura_id,cambio_factur,total_fob,total_cif,seguro,frete,fact_conv,dai,li,lf,lfe,iva,da,ice,oc,nota,lote_nr,prod_id,comercial_name_id,forma,dosagem,apresentacao,fabricante_id,
#quant,fob_origem,fob,cif,dai,pvf,pvp,pvp_farmac
# """
