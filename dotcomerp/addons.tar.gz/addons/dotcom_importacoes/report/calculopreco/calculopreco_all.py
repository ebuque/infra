# -*- coding: utf-8 -*-
##############################################################################
#
#	DotCom, LDA,
#	Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU Affero General Public License as
#	published by the Free Software Foundation, either version 3 of the
#	License, or (at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU Affero General Public License for more details.
#
#	You should have received a copy of the GNU Affero General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)


DICT = {
        'psicotropico': 'Psicotrópico',
        'estupefaciente': 'Estupefaciente',
        'percursor': 'Percursor',

        'medicamento': 'Medicamento',
        'saude': 'Produto de Saúde',
        
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',
    }

class modelo_rel_calculopreco_all_linha(osv.osv_memory):
    _name='modelo.rel.calculopreco.all.linha' 
    _columns = {
        'parent_id': fields.many2one('modelo.rel.calculopreco.all','Parente', readonly=True,),
        'calculopreco_id': fields.many2one('dotcom.quotas.vigor','calculopreco', readonly=True, required=True,),
        
        'data_calculopreco': fields.date('UDMB',help="Ultima Data do Movimento do calculopreco"),
        'data_actualizacao': fields.date('UDMA',help="Ultima Data do Movimento da Actualização"),
        'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False),
        
        'prod_id': fields.many2one('dotcom.produto.farmaceutico','Produto', readonly=False, domain="[('subs_controlada','=',True)]"),
        'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo', readonly=True,),
        'em_vigor': fields.boolean('Em Vigor', readonly=True),
        }
modelo_rel_calculopreco_all_linha()

class modelo_rel_calculopreco_all(osv.osv_memory):
    _name='modelo.rel.calculopreco.all' 
    _columns = {
        'data_calculopreco': fields.date('UDMB',help="Ultima Data do Movimento do calculopreco"),
        'data_actualizacao': fields.date('UDMA',help="Ultima Data do Movimento da Actualização"),
        'ano_id': fields.many2one('configuration.fiscalyear','Ano Fiscal', required=False),
        
        'prod_id': fields.many2one('dotcom.produto.farmaceutico','Produto', readonly=False, domain="[('subs_controlada','=',True)]", create=False),
        'tipo_prod': fields.selection([('psicotropico','Psicotrópico'),('estupefaciente','Estupefaciente'),('percursor','Percursor'),],'Tipo Prod', readonly=False,),
        'em_vigor': fields.selection([('all','Todos'),('sim','Sim'),('nao','Não'),],'Em Vigor', readonly=False,),
        
        'linha_ids': fields.one2many('modelo.rel.calculopreco.all.linha','parent_id','Linhas', readonly=True,),

        'report_type':fields.selection([("pdf","PDF"), ("xls","Excel"), ("html","HTML")],'Type'),
        'from' : fields.date('Início', required=False),
        'to' : fields.date('Término', required=False),
        'group_by':fields.selection([
            ("ano_id","Ano Fiscal"),
            ("prod_id","Produto"),
            ('tipo_prod','Tipo de Produto'),
            ],'Agrupar por'),
        }
    _defaults ={
        'em_vigor': 'all',
        'report_type': lambda *a: 'pdf',
        'group_by': lambda *a: 'ano_id',
        'to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'from': lambda *a: (datetime.now() - timedelta(days=30)).strftime('%Y-%m-01'),
        }

    def _change(self, cr, uid, ids, vals, context=None):
        self.write(cr,uid,ids,vals)
        return {'value': vals}

    def on_ch(self, cr, uid, ids, valor, descricao, context=None):
        msg('calculopreco_all.on_ch_ %s valor: %s'%(descricao,valor))
        if context is None: context = {}
        vals = {}
        if descricao in ['prod_id']:
            if not valor: vals = {'tipo_prod': False,}            
            if valor:
                oid = self.pool.get('dotcom.produto.farmaceutico').browse(cr,uid,valor)
                vals = {'tipo_prod': oid.tipo_prod}
            return self._change(cr, uid, ids, vals)

        if descricao in ['em_vigor'] and not valor:            
            return self._change(cr, uid, ids, {'em_vigor': 'all',})

    def processar(self, cr, uid,ids, context={}):
        msg('calculopreco_all.processar ids: %s'%ids)
        calculopreco_model = self.pool.get('dotcom.quotas.vigor')
        linha_model = self.pool.get('modelo.rel.calculopreco.all.linha')

        query, em_vigor = [], False
        for document in self.browse(cr,uid,ids):

            if document.tipo_prod: query.append(('tipo_prod','=',document.tipo_prod))
            if document.ano_id: query.append(('ano_id','=',document.ano_id.id))            
            if document.prod_id: query.append(('prod_id','=',document.prod_id.id))

            if document.data_calculopreco: query.append(('data_calculopreco','=',document.data_calculopreco))
            if document.data_actualizacao: query.append(('data_actualizacao','=',document.data_actualizacao))
            if document.em_vigor != 'all': 
                if document.em_vigor == 'sim': em_vigor = True
                query.append(('em_vigor','=', em_vigor))

            for linha_id in document.linha_ids:
                linha_model.unlink(cr, uid, [linha_id.id])

            for calculopreco_id in calculopreco_model.browse(cr,uid,calculopreco_model.search(cr,uid,query)):
                vals = {
                    'parent_id': ids[0],
                    'calculopreco_id': calculopreco_id.id,
                    
                    'data_calculopreco': calculopreco_id.data_calculopreco,
                    'data_actualizacao': calculopreco_id.data_actualizacao,
                    'ano_id': calculopreco_id.ano_id.id,
                    
                    'prod_id': calculopreco_id.prod_id.id,
                    'tipo_prod': calculopreco_id.tipo_prod,
                    'em_vigor': calculopreco_id.em_vigor,
                    }
                linha_model.create(cr, uid,vals)

    def validar(self, cr, uid,ids,context=None):
        msg('validar. ids: %s'%ids)
        if context is None: context = {}
        # self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            if not document.linha_ids: error('Acção Inválida!','Documento sem linhas.')

    def start_report(self, cr, uid,ids, context={}): 
        msg('calculopreco_all.start_report ids: %s'%ids)
        data = self.read(cr,uid,ids,)[-1] 
        msg('data: %s'%data)
        calculopreco_ids, group_by= [], ''
        prod_id, tipo_prod = False, False
        self.validar(cr,uid,ids,context)
        for document in self.browse(cr,uid,ids):
            group_by = document.group_by or ''
            for linha_id in document.linha_ids:
                calculopreco_ids.append(linha_id.calculopreco_id.id)
            msg('start_report - calculopreco_ids: %s'%(calculopreco_ids))
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'report_calculopreco_all',
            'datas':{
                    'model': 'modelo.rel.calculopreco.all',
                    'id': ids[0] or False,
                    'ids': ids or [],
                    'report_type': data['report_type'],
                    'form': data,
                    'calculopreco_ids': calculopreco_ids,
            },
            'nodestroy': False,
        }

modelo_rel_calculopreco_all()


# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

class calculopreco_all_parser(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(calculopreco_all_parser, self).__init__(cr, uid, ids, data, context)
        #self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}#{'SELLER':_('Vendedor')}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}

    def generate_records(self, cr, uid, ids, data, context):
        msg('generate_records ids: %s, data[from]: %s'%(ids,data))
        pool= pooler.get_pool(cr.dbname)
        result = []
        calculopreco_model = pool.get('dotcom.quotas.vigor')
        licence_model = pool.get('dotcom.licence')
        user_model = pool.get('res.users')  
        prod_model = pool.get('dotcom.produto.farmaceutico') 

        print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        form = data['form'] or False
        calculopreco_ids = data['calculopreco_ids'] or []
        group_by = form['group_by']
        report_type = form['report_type']
        inicio = form['from'] or datetime.strptime(print_date, '%Y-%m-%d')
        termino = form['to'] or datetime.strptime(print_date, '%Y-%m-%d')
        grupo = ''
        
        
        # error('Parre ja!','Parre ja!')
        licenca = 'Não Licenciado'
        # licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
        # if licenca_id:
        #   licenca = licence_model.browse(cr,uid,licenca_id).partner_name

        company_id = user_model.browse(cr,uid,uid).company_id
        company_name = 'Ministério da Saúde - DNF'
        company_logo = company_id.logo or ''
        if company_id:
            company_name = company_id.name or '' 
            company_logo = company_id.logo or ''

            # company_id_street = company_id.street or ''
            # company_id_phone = company_id.phone or ''
            # company_id_tin = company_id.partner_id.nuit or ''
        
        msg('company_name: %s'%company_name)
        for oid in calculopreco_model.browse(cr,uid,calculopreco_ids): 

            if group_by == 'tipo_prod': grupo = 'Tipo de Produto: %s'%DICT[oid.tipo_prod]
            if group_by == 'prod_id': grupo = 'Produto: %s'%oid.prod_id.name
            if group_by == 'ano_id' or grupo == '': grupo = 'Ano Fiscal: %s'%oid.ano_id.name
            msg('grupo: %s'%grupo)

            lista = {
                'grupo': grupo or '',
                'inicio': inicio or '',
                'termino': termino or '',

                'licenca': licenca or '',
                'company_name': company_name or '',
                'company_logo': company_logo or '',
                'print_date': print_date or '',

                'prod_id': oid.prod_id.name or '',
                'tipo_prod': DICT[oid.tipo_prod] or '',
                'ano_id': oid.ano_id.name or '',

                'data_calculopreco': oid.data_calculopreco or '',
                'data_actualizacao': oid.data_actualizacao or '',
                'em_vigor': (oid.em_vigor and 'Sim') or 'Não',
                    
                'quota': oid.quota or '0.0',
                'quota_calculopreco_aprovadas': oid.quota_calculopreco_aprovadas or '0.0',
                'diferenca': oid.diferenca or '0.0',
                }
            result.append(lista)
        msg('result: %s'%result)
        # result = sorted(result, key=lambda d: (d['grupo']))# d['ref'], d['name']
        return result
jasper_reports.report_jasper('report.report_calculopreco_all','modelo.rel.calculopreco.all',parser=calculopreco_all_parser)
