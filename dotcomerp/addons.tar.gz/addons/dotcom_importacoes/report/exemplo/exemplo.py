# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
from tools.translate import _
import logging
logger = logging.getLogger('report_logs')

def error(title,message):
	raise osv.except_osv(_(title), _(message))

def msg(msg):
	logger.info('\n _______. %s ._______' %msg)

class exemplo(JasperDataParser.JasperDataParser):
	def __init__(self, cr, uid, ids, data, context):
		super(exemplo, self).__init__(cr, uid, ids, data, context)
	
	def generate_data_source(self, cr, uid, ids, data, context):
		return 'records'
	
	def generate_parameters(self, cr, uid, ids, data, context):
	   return {}#{'SELLER':_('Vendedor')}
	
	def generate_properties(self, cr, uid, ids, data, context):
		return {}
	
	def generate_records(self, cr, uid, ids, data, context):
		pool= pooler.get_pool(cr.dbname)
		user_model, result = pool.get('res.users'), []
 
		uid = user_model.browse(cr,uid,uid)
		uid_name = uid.name
		empresa = uid.company_id.name

		msg('empresa: %s,	uid_name: %s'%(empresa,uid_name))
		for i in [1,2,3,4,5,6]: 
			lista = {'nr': str(i),	   'uid_name': uid_name or ' - - - ',	   'empresa': empresa or ' - - - '}
			result.append(lista)
		msg('result: %s'%result)
		return result
jasper_reports.report_jasper('report.report_ex','report.exemplo',parser=exemplo)






class report_exemplo(osv.osv_memory):
	_name='report.exemplo' 
	_columns = {
		'name': fields.char('Name', size=120, readonly=False,),
	}

	def start_report(self, cr, uid,ids, context={}): 
		data = self.read(cr,uid,ids,)[-1] 
		msg('exemplo.start_report ids: %s,	 data: %s'%(ids,data))

		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'report_ex',
			'datas':{
					'model': 'report.exemplo',
					'id': ids[0] or False,
					'ids': ids or [],
					'report_type': 'pdf',
					'form': data,
			},
			'nodestroy': False,
		}

report_exemplo()