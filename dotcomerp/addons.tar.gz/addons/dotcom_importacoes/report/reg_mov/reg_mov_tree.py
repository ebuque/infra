# -*- coding: utf-8 -*-
##############################################################################
#
#   DotCom, LDA,
#   Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU Affero General Public License as
#   published by the Free Software Foundation, either version 3 of the
#   License, or (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU Affero General Public License for more details.
#
#   You should have received a copy of the GNU Affero General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################



# -*- encoding: utf-8 -*-
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('importacoes_logs')

def error(title,message):
    raise osv.except_osv(_(title), _(message))

def msg(msg):
    logger.info('\n _______. %s ._______' %msg)


DICT = {
        'imes': 'Importação Especial',
        'snsc': 'Serviço Nacional de Saúde - Concurso',
        'snsd': 'Serviço Nacional de Saúde - Doação',
        'lnme': 'Lista Nacional de Medicamentos Essenciais',
        'extra': 'Extra Lista',
        'prosa': 'Produtos de Saúde',

        'rascunho': 'Rascunho',
        'submetido': 'Submetido',
        'validar': 'Validar',
        'validado': 'Validado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado',
        'rascunho_2': 'Rascunho',

        'anual': 'Anual',
        'semestral': 'Semestral',
        'mensal': 'Mensal',
    }

class reg_mov_tree_parser(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(reg_mov_tree_parser, self).__init__(cr, uid, ids, data, context)
        #self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}#{'SELLER':_('Vendedor')}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        msg('generate_records ids: %s, data: %s'%(ids,data))
        pool= pooler.get_pool(cr.dbname)
        result = []
        reg_mov_model = pool.get('reg.mov')
        licence_model = pool.get('dotcom.licence')
        user_model = pool.get('res.users')  

        print_date = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        # inicio = form['from'] or datetime.strptime(print_date, '%Y-%m-%d')
        # termino = form['to'] or datetime.strptime(print_date, '%Y-%m-%d')
        
        
        # error('Parre ja!','Parre ja!')
        licenca = 'Não Licenciado'
        # licenca_id = licence_model.check_expiry(cr,uid,'dotcom_cm',context)
        # if licenca_id:
        #   licenca = licence_model.browse(cr,uid,licenca_id).partner_name

        company_id = user_model.browse(cr,uid,uid).company_id
        company_name = 'Ministério da Saúde - DNF'
        company_logo = company_id.logo or ''
        if company_id:
            company_name = company_id.name or '' 
            company_logo = company_id.logo or ''

            # company_id_street = company_id.street or ''
            # company_id_phone = company_id.phone or ''
            # company_id_tin = company_id.partner_id.nuit or ''
        
        for oid in reg_mov_model.browse(cr,uid,ids): 
            lista = {
                # 'grupo': grupo or '',
                # 'inicio': inicio or '',
                # 'termino': termino or '',

                'licenca': licenca or '',
                'company_name': company_name or '',
                'company_logo': company_logo or '',
                'print_date': print_date or '',

                'name': oid.name or '',
                'nr_processo': oid.nr_processo or '',
                'processo': oid.processo or '',
                'operacao': oid.operacao or '',
                'datetime': oid.datetime or '',
                'period_id': oid.period_id.name or '',
                'user_id': oid.user_id.name or '',
                }
            result.append(lista)
        msg('result: %s'%result)
        return result
jasper_reports.report_jasper('report.report_reg_mov_tree','reg.mov',parser=reg_mov_tree_parser)


# print_date,company_logo,company_name,licenca,name,processo,nr_processo,operacao,datetime,period_id,user_id
    # REF, PROCESSO, NR_PROCESSO,    OPERAÇÃO,    DATA E HORA, PERÍODO, USUÁRIO