# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2009 Tiny SPRL (<http://tiny.be>).
#    Copyright (C) 2010 OpenERP s.a. (<http://openerp.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name': 'Módulo de Importações',
    'version': '1.0',
    'description': """Módulo de Importações de Produtos""",
    'author': 'DotCom, LDA',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'depends': [
                'base',
                'dotcom_base',
                'dotcom_licence',
                'decimal_precision',
                'dotcom_report_repository',
                'base_setup',
                'board',
                 ],
    'init_xml': [],
    # 'init_xml': ['data/dotcom.passenger.manifest.cidades.csv'],
    'update_xml':[
        'security/dotcom_security.xml',
        'security/ir.model.access.csv',
        
        'report/report.xml',
        'report/bief/bief_all.xml',
        'report/liberacao/liberacao_all.xml',
        'report/prod/prod_all.xml',
        'report/quotavigor/quotavigor_all.xml',
        # 'report/exemplo/exemplo.xml',
        
        'view/menu.xml',
        'view/dotcom_importacao_bief.xml',
        'view/dotcom_historico_bief.xml',
        'view/dotcom_importacao_liberacao.xml',
        'view/dotcom_quota_vigor.xml',
        'view/dotcom_quota_certificado.xml',
        'view/dotcom_quota_actualizacao.xml',
        'view/dotcom_sequencia.xml',
        'view/dotcom_calculo_precos.xml',
        'view/dotcom_lancamento_concurso.xml',
        'view/dotcom_emissao_notas.xml',
        'view/config_cancelamento.xml',
        'view/dotcom_num_registo.xml',
        'view/dotcom_registo_movimentos.xml',

        'geral/view/menu.xml',
        'geral/view/dotcom_parceiro_importador.xml',
        'geral/view/dotcom_parceiro_fornecedor.xml',
        'geral/view/dotcom_produto_farmaceutico.xml',
        'geral/view/dotcom_transf_titularidades.xml',
        'geral/view/director_tecnico.xml',
        'geral/view/res_inherits.xml',
        'geral/view/excel_import.xml', 
        # 'geral/view/excel_export.xml', 
        'geral/view/dotcom_grupo_terapeutico.xml', 
        ],
    'demo_xml': [],
    'images' : ['static/icon.png'],
    'test': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: