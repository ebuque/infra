create or replace function inline_0() returns integer as '

declare v_exists integer;
begin
select into v_exists count(*) from pg_class where relname = ''tkt_number_idx'';
if v_exists = 0 then
    CREATE INDEX tkt_number_idx ON dotcom_ticket_processed (operator, ticket);
end if;
return null;
end;' language 'plpgsql'


select inline_0();
drop function inline_0();  