# - * - coding: utf-8 - * -
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_travel_agency')

class dotcom_guia_pagamento(osv.osv):
    
    _name = 'dotcom.guia.pagamento'
    _description = 'Guia de Pagamento'
    _columns ={
                'ref':fields.char('Ref', size=20, required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'name':fields.char('Descrição', size=128, required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'payment_method': fields.many2one('modos.pagamento', 'Método de Pagamento', required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'date':fields.date('Data', size=128, required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'amount':fields.float('Valor', required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'bank_id': fields.many2one('res.bank', 'Banco', required=False,readonly=True,states={'draft':[('readonly',False)]}),
                'trans_number':fields.char('Número da Transacção', size=64, required=False,readonly=True,states={'draft':[('readonly',False)]}),
                'date_emissao':fields.date('Data de emissão', size=128, required=True,readonly=True,states={'draft':[('readonly',False)]}),
                'notes':fields.text('Notas', required=False,readonly=True,states={'draft':[('readonly',False)]}),
                'user_id': fields.many2one('res.users','Usuário',required=True,readonly=True),
                'need_data': fields.boolean('Needs aditional data'),
                'company_id': fields.many2one('res.company','Empresa'),
                'state': fields.selection([
                        ('draft','Rascunho'),
                        ('done','Emitido'),
                        ('cancel','Cancelado'),
                        ],'Estado', select=True, readonly=True),
               }
    
    _defaults = {
                    'state': lambda *a: 'draft',
                    'date': lambda *a: time.strftime('%Y-%m-%d'),
                    'user_id': lambda s, cr, u, c: u,
                    'need_data': lambda *a: False,
                    'company_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_get(cr, uid, 'guia.pagamento', context=c),
                }
    
    _rec_name = 'ref'
    
    def on_change_modo_pagamento(self, cr, uid, ids, modo):
        vals = {}
        if modo:
            result = self.pool.get('modos.pagamento').browse(cr,uid,modo).extra_data or False
            vals = {'need_data':result}
        return {'value':vals}
        
    
    def emitir(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr,uid,ids,{'state':'done'})
        return True
    
    def reset(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr,uid,ids,{'state':'draft'})
        return True
    
    def cancel(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        self.write(cr,uid,ids,{'state':'cancel'})
        return True
    
dotcom_guia_pagamento()
