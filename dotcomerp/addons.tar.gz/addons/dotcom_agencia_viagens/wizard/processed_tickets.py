# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('support_restore_ticket')


class dotcom_ticket_processed(osv.osv):
    
    def find_check(self, cr, uid, operator='', ticket_number='', rvenda=False, context={}):
        query = [('operator','=',operator),('ticket','=',ticket_number)]
        if rvenda:
            query.append(('sale_id','!=',rvenda))
        found = self.search(cr, uid, query)
        logger.info('\nFound %s' % found)
        if found:
            doc_type = self.pool.get('dotcom.venda').browse(cr, uid, rvenda)#, ['doc_type']).get('doc_type', (False,))[0]
            doc_type_obj = doc_type and doc_type.doc_type and doc_type.doc_type.id or False

            regs = self.read(cr, uid, found, ['sale_id'])
            for reg in regs:
                venda_id = reg.get('sale_id',(False,))[0]
                venda_lst = self.pool.get('dotcom.venda').read(cr, uid, venda_id, ['document_number','doc_type'])
                venda_doc = venda_lst.get('doc_type', (False,))[0]
                if venda_doc and doc_type_obj and (venda_doc == doc_type_obj):
                    venda = venda_lst.get('document_number','')
                    raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s já foi registado no sistema no documento numero %s ') % (ticket_number, venda))
                    break
            return False
        else:
            return True
    
    _name = 'dotcom.ticket.processed'
    _description = 'Bilhetes Processados'
    _columns = {
        'ticket_id': fields.many2one('dotcom.travel.ticket','Bilhete', readonly=True, ondelete='cascade'),
        'sale_id': fields.many2one('dotcom.venda', 'Documento de Venda', readonly=True, ondelete='cascade'),
        'operator': fields.char('Código Operadora', size=3, readonly=True),
        'ticket': fields.char('Numero do Bilhete', size=30, readonly=True),
    }
    #_sql_constraints = [('operator_ticket_unique', 'unique(operator,ticket)', 'Numero do bilhete previamente registado')]
    
    def _get_ids(self, cr, uid, ticket_ids=[]):
        res = []
        res = self.search(cr, uid, [('ticket_id','in', ticket_ids)])
        return res
    
dotcom_ticket_processed()

class dotcom_ticket_processed_wizard(osv.osv):
    _name='dotcom.ticket.processed.wizard'

    _columns = {
        'user_id': fields.many2one('res.users','User', readonly=True),
        'time': fields.datetime('Date and Time', readonly=True)
    }
    _defaults ={
        'time': lambda *a: datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'user_id': lambda s, cr, u, c: u,
    }
    _rec_name = 'time'
    
    def process_tickets(self, cr, uid, ids, tkt_ids = [], context={}):
        tickets = self.pool.get('dotcom.travel.ticket').search(cr,uid,[('estado','not in',['cancel','draft', ''])])
        contador = 0
        res = {}
        res_create = []

        for read in self.pool.get('dotcom.travel.ticket').read(cr, uid, tickets, ['posted_ticket_id', 'id', 'ticket_number', 'code_01', 'code_02', 'sale_id', 'estado']):

            id = read.get('id', False)
            estado = read.get('estado', False)
            logger.info('\nProcessing ticket with id: %s and estado: %s' % (id, estado))
            ticket = read.get('posted_ticket_id', False)
            if ticket:
                logger.info('\nTicket already processed')
            else:
                vals = {}
                
                sale = read.get('sale_id', False)
                
                vals['ticket_id'] = id
                vals['sale_id'] = sale and sale[0]
                operator = read.get('code_01', False)
                ticket = read.get('code_02', False)
                
                tkt_nbr = read.get('ticket_number', '')
                
                if not operator:
                    operator = tkt_nbr[:3]
                vals['operator'] = operator
                
                if not ticket:
                    tkt_number = str(tkt_nbr).split()
                    if len(tkt_number) > 1:
                        ticket = tkt_number[1]
                    else:
                        ticket = str(tkt_nbr)[3:]

                split = str(ticket).split('/')
                if len(split) > 1:
                    base = split[0]
                    vals['ticket'] = base
                    res_create.append(vals)
                    cur_create = []
                    lista = vals.copy()
                    for each in range(1, len(split)):
                        key = str(split[each])
                        number = len(key)
                        cur_base = base[:-number]
                        lista.update({'ticket': '%s%s' % (cur_base, key)})
                        #cur_create.append(lista)
                    #for one in cur_create:
                        logger.info('\n\nCreating: %s' % lista)
                        self.pool.get('dotcom.ticket.processed').create(cr, uid, lista)
                else:
                    vals['ticket'] = ticket
                    res_create.append(vals)
        for each in res_create:
            res[id] = self.pool.get('dotcom.ticket.processed').create(cr, uid, each)
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
 
dotcom_ticket_processed_wizard()