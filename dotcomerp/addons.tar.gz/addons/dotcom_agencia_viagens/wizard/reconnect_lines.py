# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('support_restore_ticket')

class dotcom_support_restore_ticket_sales(osv.osv_memory):
    _name='dotcom.support.restore.ticket.sales'

    _columns = {
        'user_id': fields.many2one('res.users','User', readonly=True),
        'time': fields.datetime('Date and Time', readonly=True)
    }
    _defaults ={
        'time': lambda *a: datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'user_id': lambda s, cr, u, c: u,
    }
    
    def process_tickets(self, cr, uid,ids, context={}):
        tickets = self.pool.get('dotcom.travel.ticket').search(cr,uid,[])
        contador = 0
        for ticket_id in tickets:
            ticket = self.pool.get('dotcom.travel.ticket').browse(cr, uid, ticket_id)
            
            if ticket.sale_line_id:
                continue
            else:
                venda = ticket.sale_id
                if venda.sales_lines:
                    for linha in venda.sales_lines:
                        logger.info('A processar linha: %s' % linha.id)
                        try:
                            tkt = (linha.prod_desc).encode('utf-8').split('/')
                            if tkt and len(tkt)>=2:
                                bilhete = tkt[1].strip()
                                if bilhete == ticket.ticket_number:
                                    self.pool.get('dotcom.travel.ticket').write(cr, uid, ticket_id, {'sale_line_id':linha.id})
                                    contador += 1
                            else:
                                continue
                        except UnicodeDecodeError:
                            continue  
        logger.info('Actualizadas %i bilhetes' %contador)
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
 
dotcom_support_restore_ticket_sales()