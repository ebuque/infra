# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_ticket_analysis_wizard(osv.osv_memory):
    _name='jasper.ticket.analysis.wizard'

    _columns ={
        'from' : fields.date('From', required=False),
        'to' : fields.date('To', required=False),
        'partner_id': fields.many2one('res.partner','Cliente'),
        'sale_id': fields.many2one('dotcom.venda','Sale',domain=[('state','in',['validated','done'])]),
        'salesman_id': fields.many2one('res.users','Salesman'),
        'report_type':fields.selection([("pdf","PDF"),
                                        ("xls","Excel"),
                                        ("html","HTML")
                                        ],'Type'),
        }
    _defaults ={
        'report_type': lambda *a: 'xls',
    }
    
    def start_report(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,)[-1]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'dotcom_ticket_analysis',
            'datas':{
                    'model':'dotcom.travel.ticket',
                    'id':context.get('active_ids') and context.get('active_ids')[0] or False,
                    'ids':context.get('active_ids') and context.get('active_ids') or [],
                    'report_type':'xls',
                    'form':data
            },
            'nodestroy':False,
        }
 
jasper_ticket_analysis_wizard()