# - * - coding: utf-8 - * -
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_travel_agency')
from itertools import groupby

def remove_dups(lst):
    return [k for k,items in groupby(lst)]

class dotcom_travel_city(osv.osv):

    _name = 'dotcom.travel.city'
    _description = 'Cidades'
    _columns ={
                'airport_code':fields.char('Ref', size=128, readonly=False, required=True),
                'airport_name':fields.char('Airport', size=128, readonly=False, required=False),
                'city_name':fields.char('City', size=128, readonly=False, required=False),
                'country_name':fields.char('Country', size=128, readonly=False, required=False),
                'country_code':fields.char('Country code', size=128, readonly=False, required=False),
                'latitude':fields.char('Latitude', size=128, readonly=False, required=False),
                'longitude':fields.char('Longitude', size=64, readonly=False, required=False),
                'world_area_code':fields.char('World Area Code', size=128, readonly=False, required=False),
                'country_name_nl':fields.char('Country name - NL', size=128, readonly=False, required=False),
                'city_name_nl':fields.char('City Name - NL', size=128, readonly=False, required=False),
                'city_name_geo_name_id':fields.char('City Geo Name', size=128, readonly=False, required=False),
                'country_name_geo_name_id':fields.char('Country Geo Name', size=128, readonly=False, required=False),
                #'complete_name': fields.function(_name_get_fnc, type="char", string='Name'),
               }
    
    _rec_name = 'city_name'
    
    def name_search(self, cr, uid, name, args=None, operator='ilike', context=None, limit=100):
        if not args:
            args = []
        # short-circuit ref match when possible
        if name and operator in ('=', 'ilike', '=ilike', 'like'):
            ids = self.search(cr, uid, [('airport_code', operator, name)] + args, limit=limit, context=context)
            if ids:
                return self.name_get(cr, uid, ids, context)
        return super(dotcom_travel_city,self).name_search(cr, uid, name, args, operator=operator, context=context, limit=limit)
    
    def name_get(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        if not len(ids):
            return []
        reads = self.read(cr, uid, ids, ['airport_code','city_name'], context=context)
        res = []
        for record in reads:
            name = record['airport_code']
            if record['city_name']:
                name = record['city_name']+' / '+name
            res.append((record['id'], name))
        return res
    
dotcom_travel_city()

class dotcom_travel_passenger(osv.osv):
    
    _name = 'dotcom.travel.passenger'
    _description = 'Passengers'
    _columns = {
                'passport_nr': fields.char('Passport Number',size=13,),
                'country': fields.many2one('res.country','Country',required=False),
                'contact': fields.char('Contact',size=120,required=False),
                'name': fields.char('Name',size=120,required=True),
                'ticket_id':fields.many2one('dotcom.travel.ticket','Ticket'),
                }
    _rec_name = 'name'
    
dotcom_travel_passenger()

class res_partner(osv.osv):
    
    _name = 'res.partner'
    
    _inherit = 'res.partner'
    _columns =  {
                    'is_travel_company': fields.boolean('Travel Company',invisible=False)
                }
    _defaults = {
                    'is_travel_company': lambda *a: False,
                }
    
res_partner()

class dotcom_entidade_emissora(osv.osv):
    _name = 'dotcom.travel.sistema.emissao'
    _description = 'Sistemas de emissão de bilhetes'
    _columns = {
            'ref': fields.char('Referencia', size=10, required=True),
            'name': fields.char('Nome', size=90, required=True),
            'desc': fields.text('Informacoes Adicionais'),
    }
    
    _sql_constraints = [
        ('uniq_entity_name','unique(name)', 'O nome da entidade emissora deve ser único! '),
        ]
dotcom_entidade_emissora()

class dotcom_travel_ticket(osv.osv):

    def parse_passenger_names(self, cr, uid, ids, name, arg, context=None):
        res = {}
        for record in self.browse(cr, uid, ids, context=context):
            names = ''
            all_names = []
            for passageiro in record.passenger_ids:
                current_name = passageiro.name or ''
                all_names.append(current_name)
                try:
                    for item in all_names[:-1]:
                        if names:
                            names = names + ' / %s' % item
                        else:
                            names = '%s' % item
                    names = names + ' / %s' % all_names[-1]
                except Exception, er:
                    logger.info('\nException: \n%s' % str(er))
            res[record.id] = names
        return res
    
    def parse_operator_code(self, cr, uid, ids, name, arg, context=None):
        res = {}
        for record in self.read(cr, uid, ids, ['id','ticket_number'], context=context):
            id = record.get('id', False)
            number = record.get('ticket_number', False)
            retval = False
            try:
                number = str(number).split()
                val = number and number[0]
                if len(val) > 3:
                    val = val[:3]
                    
                retval = val
            except Exception:
                pass
            res[id] = retval
        return res
    
    def parse_ticket_number(self, cr, uid, ids, name, arg, context=None):
        res = {}
        for record in self.read(cr, uid, ids, ['id','ticket_number'], context=context):
            id = record.get('id', False)
            number = record.get('ticket_number', False)
            retval = False
            try:
                number = str(number).split()
                if len(number) == 1:
                    val = number[0][3:]
                else:
                    val = number and number[1]
                retval = val
            except Exception:
                pass
            res[id] = retval
        return res
    
    def _get_destination(self, cr, uid, ids, name, arg, context=None):
        if context is None:
            context = {}
        res = {}
        for each in self.browse(cr, uid, ids):
            destination = None
            for flight in each.flights_ids:
                destination = flight and flight.destination and flight.destination.id
            res[each.id] = destination
        return res
    
    def _get_state(self, cr, uid, ids, name, arg, context=None):
        if context is None:
            context = {}
        res = {}
        for each in self.browse(cr, uid, ids):
            sale = each.sale_id
            res[each.id] = sale and sale.state
        return res
    
    def parse_route(self, cr, uid, ids, name, arg, context=None):
        res = {}
        for each in self.browse(cr, uid, ids):
            rota = ''
            route_lst = []
            for route in each.flights_ids:
                origin = route and route.origin and route.origin.city_name or ''#read and read['origin']
                destination = route and route.destination.city_name or ''#read and read['destination']
                route_lst.append(origin)
                route_lst.append(destination)
            if route_lst:
                try:
                    route_lst_group = remove_dups(route_lst)
                    for item in route_lst_group[:-1]:
                        if rota:
                            rota = rota + ' - %s' % item
                        else:
                            rota = '%s' % item
                    rota = rota + ' - %s' % route_lst_group[-1]
                except Exception, er:
                    logger.info('\nException: \n%s' % str(er))
            res[each.id] = rota
        return res

    _name = 'dotcom.travel.ticket'
    _description = 'Ticket Document'
    _columns = {
                'flights_ids': fields.one2many('dotcom.travel.flight','ticket_id','Flights',required=False),
                'passenger_ids': fields.one2many('dotcom.travel.passenger','ticket_id','Passengers',required=False,),
                'ticket_number': fields.char('Ticket Number', size=30,required=True),
                'sale_id': fields.many2one('dotcom.venda', 'Sale', ondelete='cascade'),
                'sale_line_id': fields.many2one('dotcom.venda.linha', 'Sale'),
                'discount': fields.float('Desconto'),
                'discount_service': fields.float('Serviço'),
                'sistema_emissao_id': fields.many2one('dotcom.travel.sistema.emissao', 'Sistema de Emissão', required=True),
                
                'doc_type': fields.related('sale_id','doc_type', type='many2one', relation='documento.tipo', string='Doctype'),
                'partner_id': fields.related('sale_id','partner_id', type='many2one', relation='res.partner', string='Cliente', store=True),
                'accounting': fields.selection([
                        ('nao_contabilistico','No'),
                        ('contabilistico','Yes'),
                        ],'Contabilistico', select=True, readonly=False),
                'estado': fields.function(_get_state, method=True, string='Estado', type='char', size=20, store=True),
                
                'prod_id': fields.many2one('product.product','Product', required=True , domain=[('is_ticket','=',True)]),
                'prod_price': fields.float('Ticket Price',digits_compute=dp.get_precision('Account'),required=True),
                'prod_tax': fields.float('Tax Price',digits_compute=dp.get_precision('Account'),required=False),
                
                'service_id': fields.many2one('product.product','Services', required=False , domain=[('type','=','service')]),
                'service_price': fields.float('Services',digits_compute=dp.get_precision('Account'),required=True),
                'service_vat': fields.many2one('iva.iva','Vat', required=True),
                
                'copy': fields.integer('Copies', required=False),
                
                'mark_up': fields.float('Mark Up',digits_compute=dp.get_precision('Account'),required=False),
                'extra': fields.float('Extra',digits_compute=dp.get_precision('Account'),required=False),
                'du_tax': fields.float('DU Tax',digits_compute=dp.get_precision('Account'),required=False),
                'incitement': fields.float('Incitement',digits_compute=dp.get_precision('Account'),required=False),
                'lam': fields.float('LAM',digits_compute=dp.get_precision('Account'),required=False),
                'irps': fields.float('IRPS(20% Incitement)',digits_compute=dp.get_precision('Account'),required=False, readonly=True),
                'notes': fields.text('Notes',required=False),
                'date': fields.related('sale_id','document_date', type='date', relation='dotcom.venda', string='Document Date', readonly=True),
                'salesman_id': fields.related('sale_id','user_id', type='many2one', relation='res.users', string='Salesman', readonly=True),
                'saved': fields.selection([
                        ('no','No'),
                        ('yes','Yes'),
                        ],'Saved', select=True, readonly=False),
                'state': fields.selection([
                        ('valid','Valid'),
                        ('cancel','Cancelled'),
                        ],'State', select=True, readonly=False),
                'parsed_names': fields.function(parse_passenger_names, method=True, string='Passageiro(s)', type='char', size=500, store=True),
                'parsed_route': fields.function(parse_route, method=True, string='Rota', type='char', size=500, store=True),
                'destination_id': fields.function(_get_destination, method=True, string='Destino', type='many2one', obj='dotcom.travel.city', store=True),
                
                'code_01': fields.function(parse_operator_code, method=True, string="Operadora", type='char', size=3, store=True),
                'code_02': fields.function(parse_ticket_number, method=True, string="Bilhete", type='char', size=30, store=True),
                'posted_ticket_id': fields.one2many('dotcom.ticket.processed','ticket_id','Processamentos', readonly=True),
                't_company_id':fields.many2one('dotcom.travel.company','Companhia Aérea',required=True),
                #function(parse_ticket_id, method=True, string="Bilhete Emitido", type='many2one', relation='dotcom.ticket.processed', store=False),
                }
    _rec_name = 'ticket_number'
    _defaults = {'state':'valid', 'estado': 'draft', 'copy':0, 'saved':'no', 'parsed_names': '', 'discount': 0, 'discount_service': 0,'accounting':'contabilistico'}
    _sql_constraints = [
        ('tax_lower_price','CHECK (prod_tax<=prod_price)', 'The ticket price must be greater than the ticket price tax! '),
        ]
    
    def _check_ticket_number(self, cr, uid, ticket_number,tipo = 'contabilistico', context=None):
        if context is None:
            context = {}
        logger.info('\nCOntexto %s' % context)
        logger.info('TIPO : %s' % tipo)
        ticket_number = str(ticket_number).strip()
        #if not ticket_number.replace('/','').replace(' ','').isdigit():
        #    raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s não está bem formatado') % ticket_number)
        #string = '%%%s%%' % ticket_number
        string = ticket_number
        venda = context.get('sale', False)
        if tipo == 'contabilistico':
            settings = [
                ('ticket_number','=',string),
                ('accounting','=','contabilistico'),
                ('estado','not in',['cancel','draft']),
                ('sale_id','!=', venda)
                ]
            logger.info('\nSearch Query: %s' % settings)
            exists = self.search(cr,uid,settings)
            if exists and len(exists)>0:
                ticket = self.browse(cr,uid,exists[0]).sale_id
                number = ticket and ticket.document_number
                tipo = ticket and ticket.doc_type.name
                raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s já foi registado no sistema na %s numero %s ') % (ticket_number, tipo, number))
        return True

    def unlink(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        invoices = self.browse(cr, uid, ids,context=context)
        unlink_ids = []
        for t in invoices:
            res = self.pool.get('dotcom.venda.linha').search(cr, uid, [('create_order','=',t.id)])
            self.pool.get('dotcom.venda.linha').unlink(cr, uid, res)
            unlink_ids.append(t.id)
        osv.osv.unlink(self, cr, uid, unlink_ids, context=context)
        return True
    
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        if vals.get('passenger_ids') is None or vals.get('passenger_ids') is False or len(vals.get('passenger_ids'))==0:
            raise osv.except_osv(_('Invalid action !'), _('O bilhete deve ser ao menos de um passageiro'))
        tkt_number = vals.get('ticket_number') or None
        vals['saved'] = 'yes'
        tipo = vals.get('accounting')
        #if tipo is None:
        sale = vals.get('sale_id', False)
        if sale:
            tipo = self.pool.get('dotcom.venda').browse(cr,uid,sale).doc_type.contabilidade
        tkt_number = str(tkt_number).strip()
        vals['accounting'] = tipo
        context['sale'] = sale
        #self._check_ticket_number(cr, uid, tkt_number, tipo= tipo, context=context)
        #if not tkt_number.replace('/','').replace('[0]','').replace(' ','').isdigit():
        #   raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s não está bem formatado') % tkt_number)
        #copias = False
        copias = vals.get('copy', False)

        if copias and copias>0:
            res = False
            for action in range(1,vals.get('copy')+1):
                vals['ticket_number'] = tkt_number + '[%i]' % action
                res = super(dotcom_travel_ticket, self).create(cr, uid, vals, context=context)
            return res
        else:
            vals['copy'] = 0
            return super(dotcom_travel_ticket, self).create(cr, uid, vals, context=context)
    
    def update_processed(self, cr, uid, ids, tkt_nbr = '', sale_id=False, context=None):
        if context is None:
            context = {}
        
        result = self.pool.get('dotcom.ticket.processed')._get_ids(cr, uid, ticket_ids=ids)
        self.pool.get('dotcom.ticket.processed').unlink(cr, uid, result)
        
        operator = tkt_nbr[:3]
        vals = {}
        vals['sale_id'] = sale_id
        vals['ticket_id'] = ids and ids[0]
        vals['operator'] = operator
        
        tkt_number = str(tkt_nbr).split()
        if len(tkt_number) > 1:
            ticket = tkt_number[1]
        else:
            ticket = str(tkt_nbr)[3:]
        
        res_create = []
        ticket1 = ticket.split('/')
        if len(ticket1) > 1:
            base = ticket1[0]
            res_create.append(base)
            for each in range(1, len(ticket1)):
                key = str(ticket1[each])
                number = len(key)
                cur_base = base[:-number]
                res_create.append('%s%s' % (cur_base, key))
        else:
            res_create.append(ticket1 and ticket1[0])
        
        for create in res_create:
            self.pool.get('dotcom.ticket.processed').find_check(cr, uid, operator=operator, ticket_number=create, rvenda=sale_id, context=context)
            vals['ticket'] = create
            self.pool.get('dotcom.ticket.processed').create(cr, uid, vals)
        return True
    
    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        if vals.has_key('ticket_number'):
            tkt_number = vals.get('ticket_number') or None
            tkt_number = str(tkt_number).strip()
            tipo = self.read(cr, uid, ids[0], ['accounting']).get('accounting', False)# .browse(cr,uid,ids[0]).accounting
            venda = self.browse(cr,uid,ids[0]).sale_id.id
            if tipo is None:
                #venda = self.browse(cr,uid,ids[0]).sale_id.id
                tipo = self.pool.get('dotcom.venda').browse(cr,uid,venda).doc_type.contabilidade
            context['sale'] = venda
            for id in ids:
                self.update_processed(cr, uid, [id], tkt_nbr = vals.get('ticket_number', ''), sale_id = venda, context = context)
                
            #if tipo == 'contabilistico':
                #self._check_ticket_number(cr, uid, tkt_number, context=context)
            #if not tkt_number.replace('/','').replace(' ','').isdigit():
            #    raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s não está bem formatado') % tkt_number)
        copias = False
        copias = vals.get('copy')
        vals['copy'] = 0
        created = super(dotcom_travel_ticket, self).write(cr,uid,ids,vals,context=context)
        if copias and copias>0:
            for action in range(0,vals.get('copy')-1):
                tkt_number = self.browse(cr,uid,ids[0]).ticket_number
                vals['ticket_number'] = tkt_number + '[%i]' % action
                super(dotcom_travel_ticket, self).create(cr, uid, vals, context=context)
        return super(dotcom_travel_ticket, self).write(cr,uid,ids,vals,context=context)
    
    def copy(self, cr, uid, id, vals, context=None):
        if context is None:
            context={}
        if vals is None:
            vals = {}
        #name = self.read(cr, uid, [id], ['ticket_number'], context)[0]['ticket_number']
        #vals['ticket_number'] = name +' ' +'[0]'
        vals['copy'] = 0
        vals['estado'] = 'draft'
        return super(dotcom_travel_ticket, self).copy(cr, uid,id, vals, context=context)
    
    def on_change_price(self, cr, uid, ids, prod_id, context=None):
        if context is None:
            context = {}
        product = self.pool.get('product.product').browse(cr,uid,prod_id)
        product_price = product.list_price or 0
        if product.includes_vat:
            product_price = product.price_iva or 0
        return {'value':{'prod_price':product_price}}
    
    def on_change_incentivo(self, cr, uid, ids, incitement,lam, context=None):
        if context is None:
            context = {}
        incentivo = incitement or 0
        extra_tax = lam or 0
        return {'value':{'irps':(incentivo+lam)/5}}
    
    def on_change_service(self, cr, uid, ids, service_id, context=None):
        if context is None:
            context = {}
        product = self.pool.get('product.product').browse(cr,uid,service_id)
        product_price = product.list_price or 0
        if product.includes_vat:
            product_price = product.price_iva or 0
        iva = product.iva_id.id
        return {'value':{'service_price':product_price,'service_vat':iva}}
    
    def on_change_number(self, cr, uid, ids, number, context=None):
        if context is None:
            context = {}
        res = {}
        if number:
            #split = str(number).strip().split()
            #if len(split)==1:
            #    res['ticket_number'] = '%s %s' % (str(number)[:3],str(number)[3:])
            #elif len(split)>2:
            nb = str(number).replace(' ','')
            res['ticket_number'] = '%s %s' % (str(nb)[:3],str(nb)[3:])
            logger.info('\nTicket parsed: %s' % res)
        return {'value':res}

dotcom_travel_ticket()

class dotcom_travel_flight(osv.osv):
    _name = 'dotcom.travel.flight'
    _table = 'dotcom_travel_voo'
    _decription = 'Flight'
    _columns = {
                'number':fields.char('Flight Number',size=10,),
                'ticket_id':fields.many2one('dotcom.travel.ticket','Ticket'),
                'company_id':fields.many2one('dotcom.travel.company','Travel Company',required=True),
                'origin':fields.many2one('dotcom.travel.city','Departure',required=True),
                'destination':fields.many2one('dotcom.travel.city','Arrival',required=True),
                'departure':fields.datetime('Departure Time'),
                'arrival':fields.datetime('Arrival Time')
                }
    _rec_name = 'number'
    _defaults = {'company_id': lambda self, cr, uid, c: c.get('travel_company', False)}
    #
    #def name_search(self, cr, uid, name='', domain=[], operator='ilike', context=None, limit=80):
    #    ids = []
    #    places = self.pool.get('dotcom.travel.city').name_search(cr, uid, name=name)
    #    by_code = self.search(cr, uid, [('number',operator,name)])
    #
dotcom_travel_flight()

class dotcom_travel_company(osv.osv):
            
    def _check_percentual_value(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        for record in self.read(cr, uid, ids, ['comissao']):
            comissao = record.get('comissao', 0)
            if comissao not in range(0, 101):
                return False
        return True
            
    _name = 'dotcom.travel.company'
    _decription = 'Travel Company'
    _columns = {
                'ref':fields.char('Reference',size=60,required=True),
                'name':fields.char('Name',size=250,required=True),
                'country_id':fields.many2one('res.country','Country',required=False),
                'comissao': fields.integer('Comissão (%%)'),
                'contact_ids': fields.one2many('dotcom.travel.company.contact','company_id','Contacts',required=False,),
                }
    _rec_name = 'ref'
    _defaults = {'comissao': 0}
    _constraints = [(_check_percentual_value, 'O valor da comissão deve estar no intervalo de 0 à 100', ['comissao'])]
    
dotcom_travel_company()

class dotcom_travel_company_contact(osv.osv):
    _name = 'dotcom.travel.company.contact'
    _decription = 'Travel Company Contacts'
    _columns = {
                'name':fields.char('Name',size=250, required=True),
                'company_id':fields.many2one('dotcom.travel.company','Travel Company',),
                'phone':fields.char('Phone',size=250),
                'email':fields.char('Email',size=250),
                'street':fields.char('Street',size=250),
                'city':fields.char('city',size=250),
                'country': fields.many2one('res.country','Country',required=False),
                }
    _rec_name = 'name'
    
dotcom_travel_company_contact()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
