# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_agencia_viagens import JasperDataParser
from dotcom_doc import amount_to_text
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
import logging
from tools.translate import _
logger = logging.getLogger('dotcom_vendas_report')

class jasper_report_venda2(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_report_venda2, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
        
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result = []
        sub = {}
        sub_res = []
        venda_id = None

        venda = pool.get('dotcom.venda').browse(cr,uid,ids[0])
        licenca = ''
        
        licenca_obj = pool.get('dotcom.licence')
        licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_agencia_viagens',context)
        licenca = 'Não Licenciado'
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
  
        company = venda.company_id
        company_logo = company.logo or False
        company_name = company.name or ''
        company_street = company.street or ''
        company_phone = company.phone or ''
        company_fax = company.fax or ''
        company_tin = company.partner_id.nuit or ''
        company_city = company.city or ''
        company_email = company.email or ''
        company_web = company.website or ''
        company_id = str(company.id)
        logo_temp = ''
        
        extra_data = venda.extra_data or False
        should_print = venda.pagamento_directo or False
        
        #logger.info('Extra Data %s , Should Print %s' % (extra_data, should_print))
        
        if (extra_data and should_print) == True:
            extra_data = 'PRINT'
        elif ((extra_data==False) and (should_print==True)):
            extra_data = 'extenso'
        else:
            extra_data = ''
        
        doc_total = abs(venda.total_document or 0)
        doc_currency_name = venda.doc_currency and venda.doc_currency.name or ''
        total_str = amount_to_text.amount_to_text_pt(doc_total, doc_currency_name) or ''
#         total_str = pool.get('dotcom.recebimento').get_amount_extense(cr, uid, None, abs(doc_total), doc_currency_name) or ''

        #logger.info('TOTAL EXTENSO %s, \nMOEDA %s'% (total_str, doc_currency_name))
        
        extenso = total_str or venda.total_amount_str or ''
        banco_ref = venda.banco_id and venda.banco_id.bic or ''
        banco_nome = venda.banco_id and venda.banco_id.name or ''
        banco = '%s - %s' % (banco_ref, banco_nome)
        transaccao = venda.transaction or ''
        metodo = venda.payment_method and venda.payment_method.name
        
        if company_logo:
            logo_temp = 'logo_'+company_id+'.png'
            logotipo = base64.b64decode(str(company_logo).decode('latin-1'))
            pathfinder = '/opt/dotcomerp/server/openerp/addons/dotcom_doc/report2/logos/'+'logo_'+company_id+'.png'
            ficheiro = open(pathfinder, 'w+')
            try:
                ficheiro.write(logotipo)
            finally:
                ficheiro.close()
        
        parent_partner_name = ''
        if venda.partner_id.parent_id:
            parent_partner_name = venda.partner_id.parent_id.name
        partner_name = venda.partner_name or ''
        partner_address = venda.partner_address or ''
        partner_tin = venda.partner_nuit_name or ''
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        doc_date = venda.document_date
        doc_due_date = venda.due_date
        
        doc_payterm = venda.payment_term_id.name or ''
        
        doc_type_name = venda.doc_type.name or ''
        doc_number = venda.document_number or ''
        
        doc_currency_symbol = venda.doc_currency.symbol or ''
        doc_subtotal = abs(venda.lines_sum or 0)
        doc_discount = abs(venda.total_discount or 0)
        
        doc_vat = abs(venda.total_vat or 0)
        non_tickets = pool.get('product.product').search(cr,uid,[('type','=','service'),('is_ticket','=',False)])
        for iva in venda.taxes_ids:
            sub = {'iva':iva.iva_id.name,'iva_base':iva.vat_base or 0,'iva_amount':iva.vat_amount or 0,'motivo_isencao':iva.iva_id.motivo_isencao or ''}
            sub_res.append(sub)
            
        isento_base = 0
        isento_amount = 0
        
        normal_vat_base = 0
        normal_vat_amount = 0
        
        me = company.partner_id.id
        counter = 0
        
        banco_1 = ''
        conta_1 = ''
        nib_1 = ''
        moeda_1 = ''
        
        banco_2 = ''
        conta_2 = ''
        nib_2 = ''
        moeda_2 = ''
        
        desconto_comercial_perc = venda.desconto or 0
        
        exchanged_currency = 0
        exchanged_total = 0
        
        if venda.print_other_currency and venda.alternative_currency:
            doc_currency = venda.alternative_currency
            alternative_amount = venda.alternative_currency_value or 0
            exchanged_currency = doc_currency.name or ''
            exchanged_total = abs(doc_total/alternative_amount)
        
        desconto_comercial = abs(venda.desconto_comercial or 0)
        
        accounts = pool.get('res.partner.bank').search(cr,uid,[('partner_id','=',me),('footer','=',True)],limit=2)
        #logger.info('Accounts : %s' % str(accounts))
        if accounts and len(accounts)>0:
            for account in accounts:
                counter = counter + 1
                #logger.info('COUNTER : %s' % str(counter))
                if counter == 1:
                    conta = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_1 = conta.bank_name or ''
                    conta_1 = conta.acc_number or ''
                    nib_1 = conta.nib or ''
                    moeda_1 = conta.currency_id.name or ''
                    #logger.info('CONTA 0 : done')
                    continue
                elif counter == 2:
                    acc = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_2 = acc.bank_name or ''
                    conta_2 = acc.acc_number or ''
                    nib_2 = acc.nib or ''
                    moeda_2 = acc.currency_id.name or ''
                    #logger.info('CONTA 1 : done and BREAK')
                    break
                else:
                    break
        
        motivo_isencao = ''
        for line in venda.taxes_ids:
            if line.iva_id.tax==0:
                isento_base = abs(isento_base + line.vat_base or 0)
                isento_amount = abs(isento_amount + line.vat_amount or 0)
                motivo_isencao = venda.iva_isento and venda.iva_isento.name or ''
            else:
                normal_vat_base = abs(normal_vat_base + line.vat_base or 0)
                normal_vat_amount = abs(normal_vat_amount + line.vat_amount or 0)
        segunda = venda.seg_via or False
        
        notes = venda.notes or ''
        converted_from_str = venda and venda.converted_from_str or ''
        if converted_from_str:  notes = notes + '\n%s' % converted_from_str
        
        v_ref = venda.origin_document_number or ''
        
        print_labels = []
        if venda.only_original:
            labe = venda.impressao and venda.impressao.name or ''
            print_labels = [labe]
        else:
            for print_label in venda.doc_type.prints_ids:
                print_labels.append(print_label.name or '')
        
        if not print_labels:
            raise osv.except_osv(_('Acção Inválida !'), _('Não foram definidas vias de impressão!'))

        for label in print_labels:
            #print_name = _('Segunda Via')
            lines = self.pool.get('dotcom.venda.linha').search(cr, uid, [('document_top','=',venda.id)], order='sequence')
            if venda.join_lines is False:
                for line in self.pool.get('dotcom.venda.linha').browse(cr, uid, lines):
                    line_prod_code = line.prod_id.default_code or ''
                    line_prod_desc = line.prod_desc or line.prod_id.name  or ''
                    line_unit = line.prod_uom.name or ''
                    line_qty = abs(line.qty or 0)
                    line_unit_price = abs(line.unit_price or 0)
                    line_desc = abs(line.discount_pct or 0)
                    line_tax = abs(line.tax_id.tax or 0)
                    line_total = abs(line.line_total)
                    line_notes = line.notes or ''
                    
                    if line.iva_incluido:
                        valor_iva = 0
                        valor_iva_total = 0
                        imposto = abs(line.tax_id.tax or 0)
                        valor_iva_total = abs((line.qty*line.unit_price)-((line.qty*line.unit_price)/(imposto/100+1)))
                        valor_iva = abs((line.unit_price)-((line.unit_price)/(imposto/100+1)))

                        iva_id = line.tax_id.id
                        line_unit_price = abs(self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, iva_id, line_unit_price,  context=context))
                    passangers = ''
                    route = ''
                    tkt_nr = ''
                    if line.prod_id.is_ticket and str(line.create_order)!='':
                        for passageiro in line.create_order.passenger_ids:
                            passangers += passageiro.name + ' / '
                        passangers = passangers.rstrip(' / ')
                        for rota in line.create_order.flights_ids:
                            route += rota.origin.airport_code+'-'+rota.destination.airport_code+ ' / '
                        route = route.rstrip(' / ')
                        tkt_nr = line.create_order.ticket_number
                        if tkt_nr:
                            tkt_nr = 'Bilhete Nr. '+tkt_nr
                    data = {
                        'path': os.getcwd(),
                        'venda_id': venda.id,
                        'print_name': label,
                        'sub_report': sub_res,
                        'company_logo' : logo_temp,
                        'company_name' : company_name,
                        'company_street' : company_street,
                        'company_phone' : company_phone,
                        'company_fax' : company_fax,
                        'company_tin' : company_tin,
                        'company_city' : company_city,
                        'company_email': company_email,
                        'company_web': company_web,
                        
                        'passageiros': passangers,
                        'rota': route,
                        'ticket': tkt_nr,
                        
                        'parent_partner': parent_partner_name,
                        'partner_name' : partner_name,
                        'partner_address' : partner_address,
                        'partner_tin' : partner_tin,
                        
                        'doc_date' : doc_date,
                        'doc_due_date' : doc_due_date,
                        'doc_payterm' : doc_payterm,
                        'doc_currency_name' : doc_currency_name,
                        'doc_type_name' : doc_type_name,
                        'doc_number' : doc_number,
                        
                        'line_prod_code' : line_prod_code,
                        'line_prod_desc' : line_prod_desc,
                        'line_unit' : line_unit,
                        'line_qty' : line_qty,
                        'line_unit_price' : line_unit_price,
                        'line_desc' : line_desc,
                        'line_tax' : line_tax,
                        'line_total' : line_total,
                        'line_notes': line_notes,
    
                        'doc_currency_symbol' : doc_currency_symbol,
                        'doc_subtotal' : doc_subtotal,
                        'doc_discount' : doc_discount,
                        'doc_total' : doc_total,
                        'doc_vat' : doc_vat,
                        
                        'iva_isento_base':isento_base,
                        'iva_isento_amount': isento_amount,
                        'iva_17_base': normal_vat_base,
                        'iva_17_amount': normal_vat_amount,
                        'licenca': licenca,
                        
                        'notes': notes,
                        
                        'banco': banco_1,
                        'conta': conta_1,
                        'nib': nib_1,
                        'moeda': moeda_1,
                        
                        'banco_1': banco_2,
                        'conta_1': conta_2,
                        'nib_1': nib_2,
                        'moeda_1': moeda_2,
                        
                        'print_date': now,
                        
                        'extra': extra_data,
                        'extenso': extenso,
                        'banco_tr': banco,
                        'transaccao': transaccao,
                        'metodo_pagamento': metodo,
                        
                        'desconto_comercial':desconto_comercial,
                        'exchanged_total': exchanged_total,
                        'exchanged_currency': exchanged_currency,
                        'desconto_comercial_perc': desconto_comercial_perc,
                        
                        'motivo_isencao': motivo_isencao,
                        'v_ref': v_ref,
                    }
                
                    result.append(data)
            else:
                adicionado = []
                for line in self.pool.get('dotcom.venda.linha').browse(cr, uid, lines):
                    if line.prod_id.is_ticket is True and line.create_order:
                        line2_temp_id = pool.get('dotcom.venda.linha').search(cr,uid,[('document_top','=',venda.id),('create_order','=',line.create_order.id),('prod_id','in',non_tickets)],limit=1)
                        line2_id = line2_temp_id and line2_temp_id[0] or False
                        #if line2_id:
                        
                        line_unit_price = 0
                        line_desc = 0
                        line_tax = 0
                        line_total = 0
                        
                        if line2_id:
                            line2_obj = pool.get('dotcom.venda.linha').browse(cr,uid,line2_id)
                            line_unit_price = line2_obj.unit_price or 0
                            line_desc = line2_obj.discount_pct or 0
                            line_tax = line2_obj.line_amount_tax or 0
                            line_total = line2_obj.line_total or 0
                            
                        line_prod_code = line.prod_id.default_code or ''
                        line_prod_desc = line.prod_desc or line.prod_id.name  or ''
                        line_unit = line.prod_uom.name or ''
                        line_qty = abs(line.qty or 0)
                        line_unit_price = abs((line.unit_price or 0) + line_unit_price)
                        line_desc = abs(line.discount_pct or 0  + line_desc)
                        line_tax = abs(line.line_amount_tax + line_tax)
                        line_total = abs(line.line_total + line_total)
                        line_notes = line.notes or ''
                        
                        if line.iva_incluido:
                            valor_iva = 0
                            valor_iva_total = 0
                            imposto = abs(line.tax_id.tax or 0)
                            valor_iva_total = abs((line.qty*line.unit_price)-((line.qty*line.unit_price)/(imposto/100+1)))
                            valor_iva = abs((line.unit_price)-((line.unit_price)/(imposto/100+1)))
                            
                            #line_unit_price = line_unit_price - valor_iva
                            #line_total = line_total - valor_iva_total
                            iva_id = line.tax_id.id
                            line_unit_price = abs(self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, iva_id, line_unit_price,  context=context))
                        
                        passangers = ''
                        route = ''
                        tkt_nr = ''
                        if line.prod_id.is_ticket and str(line.create_order)!='':
                            for passageiro in line.create_order.passenger_ids:
                                passangers += passageiro.name + ' / '
                            passangers = passangers.rstrip(' / ')
                            for rota in line.create_order.flights_ids:
                                route += rota.origin.airport_code+'-'+rota.destination.airport_code+ ' / '
                            route = route.rstrip(' / ')
                            tkt_nr = line.create_order.ticket_number
                            if tkt_nr:
                                tkt_nr = 'Bilhete Nr. '+tkt_nr
                        
                        data = {
                            'print_name': label,
                            'sub_report': sub_res,
                            'venda_id': venda.id,
                            'company_logo' : logo_temp,
                            'company_name' : company_name,
                            'company_street' : company_street,
                            'company_phone' : company_phone,
                            'company_fax' : company_fax,
                            'company_tin' : company_tin,
                            'company_city' : company_city,
                            'company_email': company_email,
                            'company_web': company_web,
                            
                            'passageiros': passangers,
                            'rota': route,
                            'ticket': tkt_nr,
                            
                            'partner_name' : partner_name,
                            'partner_address' : partner_address,
                            'partner_tin' : partner_tin,
                            
                            'doc_date' : doc_date,
                            'doc_due_date' : doc_due_date,
                            'doc_payterm' : doc_payterm,
                            'doc_currency_name' : doc_currency_name,
                            'doc_type_name' : doc_type_name,
                            'doc_number' : doc_number,
                            
                            'line_prod_code' : line_prod_code,
                            'line_prod_desc' : line_prod_desc,
                            'line_unit' : line_unit,
                            'line_qty' : abs(line_qty),
                            'line_unit_price' : abs(line_unit_price),
                            'line_desc' : line_desc,
                            'line_tax' : line_tax,
                            'line_total' : abs(line_total),
                            'line_notes': line_notes,
        
                            'doc_currency_symbol' : doc_currency_symbol,
                            'doc_subtotal' : abs(doc_subtotal),
                            'doc_discount' : abs(doc_discount),
                            'doc_total' : abs(doc_total),
                            'doc_vat' : abs(doc_vat),
                            
                            'iva_isento_base':isento_base,
                            'iva_isento_amount': abs(isento_amount),
                            'iva_17_base': abs(normal_vat_base),
                            'iva_17_amount': abs(normal_vat_amount),
                            'licenca': licenca,
                            
                            'notes': notes,
                        
                            'banco': banco_1,
                            'conta': conta_1,
                            'nib': nib_1,
                            'moeda': moeda_1,
                            
                            'banco_1': banco_2,
                            'conta_1': conta_2,
                            'nib_1': nib_2,
                            'moeda_1': moeda_2,
                            
                            'print_date': now,
                            
                            'extra': extra_data,
                            'extenso': extenso,
                            'banco_tr': banco,
                            'transaccao': transaccao,
                            'metodo_pagamento': metodo,
                            
                            'desconto_comercial': abs(desconto_comercial),
                            'exchanged_total': abs(exchanged_total),
                            'exchanged_currency': abs(exchanged_currency),
                            'desconto_comercial_perc': abs(desconto_comercial_perc),
                            
                            'motivo_isencao': motivo_isencao,
                            'v_ref': v_ref,
                        }
                    
                        result.append(data)
                    elif str(line.create_order) == '':
                        line_prod_code = line.prod_id.default_code or ''
                        line_prod_desc = line.prod_desc or line.prod_id.name  or ''
                        line_unit = line.prod_uom.name or ''
                        line_qty = abs(line.qty or 0)
                        line_unit_price = abs(line.unit_price or 0)
                        line_desc = abs(line.discount_pct or 0)
                        line_tax = abs(line.line_amount_tax)
                        line_total = abs(line.line_total)
                        line_notes = line.notes or ''
                        
                        if line.iva_incluido:
                            valor_iva = 0
                            valor_iva_total = 0
                            imposto = abs(line.tax_id.tax or 0)
                            valor_iva_total = abs((line.qty*line.unit_price)-((line.qty*line.unit_price)/(imposto/100+1)))
                            valor_iva = abs((line.unit_price)-((line.unit_price)/(imposto/100+1)))
                            
                            #line_unit_price = line_unit_price - valor_iva
                            #line_total = line_total - valor_iva_total
                            iva_id = line.tax_id.id
                            line_unit_price = abs(self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, iva_id, line_unit_price,  context=context))
                        data = {
                            'print_name': label,
                            'sub_report': sub_res,
                            'venda_id': venda.id,
                            'company_logo' : logo_temp,
                            'company_name' : company_name,
                            'company_street' : company_street,
                            'company_phone' : company_phone,
                            'company_fax' : company_fax,
                            'company_tin' : company_tin,
                            'company_city' : company_city,
                            'company_email': company_email,
                            'company_web': company_web,
                            
                            'partner_name' : partner_name,
                            'partner_address' : partner_address,
                            'partner_tin' : partner_tin,
                            
                            'doc_date' : doc_date,
                            'doc_due_date' : doc_due_date,
                            'doc_payterm' : doc_payterm,
                            'doc_currency_name' : doc_currency_name,
                            'doc_type_name' : doc_type_name,
                            'doc_number' : doc_number,
                            
                            'line_prod_code' : line_prod_code,
                            'line_prod_desc' : line_prod_desc,
                            'line_unit' : line_unit,
                            'line_qty' : abs(line_qty),
                            'line_unit_price' : abs(line_unit_price),
                            'line_desc' : line_desc,
                            'line_tax' : line_tax,
                            'line_total' : abs(line_total),
                            'line_notes': line_notes,
        
                            'doc_currency_symbol' : doc_currency_symbol,
                            'doc_subtotal' : doc_subtotal,
                            'doc_discount' : doc_discount,
                            'doc_total' : doc_total,
                            'doc_vat' : doc_vat,
                            
                            'iva_isento_base':isento_base,
                            'iva_isento_amount': isento_amount,
                            'iva_17_base': normal_vat_base,
                            'iva_17_amount': normal_vat_amount,
                            'licenca': licenca,
                            
                            'notes': notes,
                        
                            'banco': banco_1,
                            'conta': conta_1,
                            'nib': nib_1,
                            'moeda': moeda_1,
                            
                            'banco_1': banco_2,
                            'conta_1': conta_2,
                            'nib_1': nib_2,
                            'moeda_1': moeda_2,
                            
                            'print_date': now,
                            
                            'extra': extra_data,
                            'extenso': extenso,
                            'banco_tr': banco,
                            'transaccao': transaccao,
                            'metodo_pagamento': metodo,
                            
                            'desconto_comercial': abs(desconto_comercial),
                            'exchanged_total': abs(exchanged_total),
                            'exchanged_currency': abs(exchanged_currency),
                            'desconto_comercial_perc': abs(desconto_comercial_perc),
                            
                            'motivo_isencao': motivo_isencao,
                            'v_ref': v_ref,
                        }
                
                        result.append(data)
                    else:
                        continue
        print result
        return result

jasper_reports.report_jasper('report.dotcom_venda_report2','dotcom.venda',parser=jasper_report_venda2)