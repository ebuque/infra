# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
import time
import base64
from tools.translate import _
import os
import logging
logger = logging.getLogger('LISTA DE BILHETES')

class jasper_lista_bilhetes(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_lista_bilhetes, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        return {	
                'DOCUMENTO': _('Lista de Bilhetes'),
                'label_numero': 'Numero do Bilhete',
                'label_documento': 'Documento',
                'label_doc_nr': 'Numero do Documento',
                'label_cliente': 'Parceiro',
                'label_passageiros': 'Passageiros',
                'label_rota': 'Rota',
                'label_destino': 'Destino',
                'label_sistema': 'Sistema',
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
        
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        
        company_id = self.pool.get('res.company')._company_default_get(cr, uid, 'dotcom.venda', context=context)
        company_obj = self.pool.get('res.company').browse(cr, uid, company_id)
        company_name = company_obj and company_obj.name or ''
        
        for bilhete in pool.get('dotcom.travel.ticket').browse(cr, uid, ids):
            numero = bilhete and bilhete.ticket_number or ''
            documento = bilhete and bilhete.sale_id and bilhete.sale_id.doc_type and bilhete.sale_id.doc_type.name or ''
            doc_nr = bilhete and bilhete.sale_id and bilhete.sale_id.document_number or ''
            partner = bilhete and bilhete.sale_id and bilhete.sale_id.partner_name or ''
            sistema = bilhete and bilhete.sistema_emissao_id and bilhete.sistema_emissao_id.name or ''
            
            rota = bilhete and bilhete.parsed_route or ''
            destino_ref = bilhete and bilhete.destination_id and bilhete.destination_id.airport_code or ''
            destino_name = bilhete and bilhete.destination_id and bilhete.destination_id.city_name or ''
            destino = ''
            if destino_name and destino_ref:
                destino = '[%s]%s' % (destino_ref, destino_name)
            
            passageiros = ''
            for passageiro in bilhete.passenger_ids:
                nome_passageiro = passageiro and passageiro.name or ''
                if passageiros:
                    passageiros = passageiros + '\\n%s' % nome_passageiro
                else:
                    passageiros = nome_passageiro
            
            data_documento = ''
            data_bilhete = bilhete and bilhete.sale_id and bilhete.sale_id.document_date
            if data_bilhete:
                data_documento = datetime.strptime(data_bilhete, '%Y-%m-%d').strftime('%d/%m/%Y')
            
            data = {
                'company_name' : company_name,
                'val_numero': numero,
                'val_documento': documento,
                'val_doc_number': doc_nr,
                'val_cliente': partner,
                'val_passageiros': passageiros,
                'val_rota': rota,
                'val_destino': destino,
                'val_sistema': sistema,
                'data': data_documento,
                
            }
            result.append(data)
        print result
        result = sorted(result, key=lambda d: (d['data'], d['val_cliente'], d['val_documento'], d['val_doc_number']))
        return result

jasper_reports.report_jasper('report.dotcom_ticket_list','dotcom.travel.ticket',parser=jasper_lista_bilhetes)
