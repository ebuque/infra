# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
#from PIL import Image
#import StringIO
import logging
logger = logging.getLogger('dotcom_guias_report')
from tools.translate import _

class jasper_report_guia(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_report_guia, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        return {	
                'NOTES': _('Notas'),
                'TRANS': _('Transacção'),
                'BANCO': _('Banco'),
                'VALOR': _('Valor'),
                'PAYMENT_METHOD': _('Método de Pagamento'),
                'DATA_EMISSAO': _('Data de Emissão'),
                'DATA': _('Data'),
                'REPORT_TITLE': _('Guia de Pagamento'),
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
   
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result = []
        guia_id = None

        guia = pool.get('dotcom.guia.pagamento').browse(cr,uid,ids[0])
 
        company = guia.company_id
        company_name = company.name or ''
        company_street = company.street or ''
        company_phone = company.phone or ''
        company_fax = company.fax or ''
        company_tin = company.partner_id.nuit or ''
        company_city = company.city or ''
        
        licenca_obj = pool.get('dotcom.licence')
        licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
        
        partner_name = guia.name or ''
        payment_method = guia.payment_method.name or ''
        amount = guia.amount or 0
        banco = guia.bank_id.name or ''
        trans_number = guia.trans_number or ''
        date_emissao = datetime.strptime(guia.date_emissao, '%Y-%m-%d').strftime('%d/%m/%Y')
        data = datetime.strptime(guia.date, '%Y-%m-%d').strftime('%d/%m/%Y')
        notes = guia.notes or ''
        
        
        data = {
            'licenca': licenca,
            'company_name' : company_name,
            'path': os.getcwd(),
            'company_street' : company_street,
            'company_phone' : company_phone,
            'company_fax' : company_fax,
            'company_tin' : company_tin,
            'company_city' : company_city,
            
            'desc': partner_name,
            'modo_pagamento': payment_method,
            'valor': amount,
            'doc_date': data,
            'data_emissao': date_emissao,
            'banco':banco,
            'trans': trans_number,
            'notes': notes,
        }
        result.append(data)
        print result
        logger.info('RESULTADO> %s' % result)
        return result

jasper_reports.report_jasper('report.dotcom_guia_report','dotcom.guia.pagamento',parser=jasper_report_guia)
