# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
import time
import base64
from tools.translate import _
import os
import logging
logger = logging.getLogger('dotcom_ticket_analysis')

class jasper_ticket_analysis(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_ticket_analysis, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = ['Ticket Sale Analysis - DotComERP']
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        
        salesman = ''
        sale = ''
        string = ''
        
        if 'form' in data:
            de = data['form']['from'] or False
            ate = data['form']['to'] or False
            sale = data['form']['sale_id'] or False
            salesman = data['form']['salesman_id'] or False
            
            string = ''
            if de:
                de = str(datetime.strptime(data['form']['from'], '%Y-%m-%d').strftime('%d/%m/%Y'))
                string = 'From %s '%de
            if ate:
                ate = str(datetime.strptime(data['form']['to'], '%Y-%m-%d').strftime('%d/%m/%Y'))
                string = string + 'To %s '%ate
            if sale:
                pool= pooler.get_pool(cr.dbname)
                sale = pool.get('dotcom.venda').browse(cr,uid,sale[0]).document_number or ''
            
            if salesman:
                pool= pooler.get_pool(cr.dbname)
                salesman = pool.get('res.users').browse(cr,uid,salesman[0]).name
        
        return {	
                'DOCUMENTO': _('Ticket Sale Analysis'),
                'label_ticket': _('Ticket Number'),
                'label_passenger': _('Passengers'),
                'label_route': _('Route'),
                'label_fare': _('Fare'),
                'label_tax': _('Tax'),
                'label_total': _('Total'),
                'label_service': _('P.S'),
                'label_tax_vat': _('VAT 17%'),
                'label_mark_up': _('Mark Up'),
                'label_extra': _('Extra'),
                'label_tax_du': _('DU Tax'),
                'label_incitement': _('Incitement'),
                'label_irps': _('IRPS'),
                'label_lam': _('LAM'),
                'label_desc': _('Descontos'),
                'label_sale': _('Doc. Number'),
                'label_user': _('Cliente'),
                'label_notes': _('Notes'),
                'date_filter': _(string),
                'label_sistema': _('Sistema de Emissão'),
                'document_filter': _(('Document Number: %s') % sale),
                'user_filter': salesman or 'Todos',
                'label_operator': _('Operadora')
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
        
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        term = []
        
        sort_term1='data_ticket'
        sort_term2='data_document'

        company_name = pool.get('res.users').browse(cr, uid, uid).company_id.name or ''
        currency_name = pool.get('res.users').browse(cr, uid, uid).company_id.currency_id.name or ''
        term.append(('estado','in',['validated','done']))
        
        if 'form' in data:
            from_date = data['form']['from'] or None
            to_date = data['form']['to'] or None
            sale = data['form']['sale_id'] or None
            salesman = data['form']['salesman_id'] or None
            client = data['form']['partner_id'] or False
            
            if from_date:
                term.append(('date','>=',from_date))
            if to_date:
                term.append(('date','<=',to_date))
            if sale:
                term.append(('sale_id','=',sale[0]))
            if salesman:
                term.append(('salesman_id','=',salesman[0]))
            if client:
                term.append(('partner_id','=',client[0]))
        if ids:
            term.append(('id','in', ids))
        tickets = pool.get('dotcom.travel.ticket').search(cr,uid,term)
        logger.info('Tickets %s'%tickets)
        if tickets and len(tickets)>0:
            for documento in pool.get('dotcom.travel.ticket').browse(cr,uid,tickets):
                desc = 0
                sale = documento.sale_id
                
                if 'form' in data:
                    if sale and sale.doc_type.contabilidade != 'contabilistico':
                        continue
                data_ticket_number = documento.ticket_number or ''
                data_passenger = ''
                data_route = ''
                
                for person in documento.passenger_ids:
                    data_passenger += person.name + '/'
                data_passenger = data_passenger.rstrip('/')
                if documento.flights_ids and len(documento.flights_ids)>0:
                    for route in documento.flights_ids:
                        data_route += (route.destination.airport_code or '') + '/'
                    data_route = data_route.rstrip('/')
                
                data_total_ticket = documento.prod_price or 0
                
                data_tax = documento.prod_tax or 0
                data_fare = data_total_ticket - data_tax
                data_service = documento.service_price or 0
                data_vat_val = documento.service_vat.tax or 0
                data_vat = data_vat_val*0.01*data_service
                if documento.sale_line_id:
                    iva_inc = documento.sale_line_id.iva_incluido
                    iva_val = documento.service_vat
                    #desc = documento.sale_line_id.discounted_val
                    if iva_inc:
                        valor = iva_val.tax/100
                        valor = valor + 1
                        valor_servico = documento.service_price/valor
                        valor_iva = documento.service_price - valor_servico
                        
                        data_service = valor_servico
                        data_vat = valor_iva
                
                for line in (sale and sale.sales_lines or []):
                    if line.create_order.id == documento.id:
                        desc = desc + line.discounted_val or 0
                        logger.info('Adicionado desconto: %.2f' % desc)
                    else:
                        continue
                
                data_markup = documento.mark_up or 0
                data_extra = documento.extra or 0
                data_du_tax = documento.du_tax or 0
                data_incentivo = documento.incitement or 0
                data_lam = documento.lam or 0
                data_irps = (data_incentivo+data_lam)/5
                data_total = data_total_ticket+data_service+data_vat+data_markup+data_extra+data_du_tax+data_incentivo+data_lam+data_irps-desc
                data_user = sale and sale.partner_name or sale.partner_id and  sale.partner_id.name or ''
                data_notes =  sale.notes or ''
                data_document = (sale and sale.doc_type.ref or '') +' '+ (sale and sale.document_number or '')
                tkt_number = str(data_ticket_number or '').split()
                logger.info('TKT_NUMBER: %s' % str(tkt_number))
                if tkt_number and len(tkt_number)>=2:
                    tkt_number = tkt_number[1]
                else:
                    tkt_number = data_ticket_number[3:] or ''
                data_data = sale and sale.document_date or ''
                
                sistema = documento.sistema_emissao_id and documento.sistema_emissao_id.name or ''
            
                operadora = documento.t_company_id and documento.t_company_id.ref or ''
                data = {
                    'data_total_ticket':data_total_ticket,
                    'tkt_number': tkt_number,
                    'data_tax': data_tax,
                    'data_desc': desc,
                    'data_fare': data_fare,
                    'data_service': data_service,
                    'data_vat': data_vat,
                    'data_markup': data_markup,
                    'data_extra': data_extra,
                    'data_du_tax': data_du_tax,
                    'data_incentivo': data_incentivo,
                    'data_lam': data_lam,
                    'data_irps': data_irps,
                    'data_total': data_total,
                    'data_user': data_user,
                    'data_notes': data_notes,
                    'data_document': data_document,
                    'data_ticket': data_ticket_number,
                    'data_passenger': data_passenger,
                    'data_route': data_route,
                    'currency_name':currency_name,
                    'company_name': company_name,
                    'data_data': data_data,
                    'sistema': sistema,
                    'operator': operadora,
                }
                result.append(data)
        print result
        logger.info('\n\nPRINT: %s' % result)
        result = sorted(result, key=lambda d: (d['data_data'], d['tkt_number'], d['data_document']))
        return result

jasper_reports.report_jasper('report.dotcom_ticket_analysis','dotcom.travel.ticket',parser=jasper_ticket_analysis)
