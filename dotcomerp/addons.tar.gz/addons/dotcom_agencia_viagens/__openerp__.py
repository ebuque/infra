# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name': 'DotCom ERP - Travel Agency',
    'version': '1.3.1',
    'description': '''DotCom ERP Module for Travel Agencies management.''',
    'author': 'DotCom, LDA',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'depends': ['base','dotcom_licence','dotcom_cm','dotcom_base','dotcom_stock','dotcom_doc','dotcom_doc_base','dotcom_doc_reports','jasper_reports','dotcom_report_repository','product_pricelist'],
    'init_xml': [],
    'update_xml': [
        'view/product_product_view.xml',
        'report_parser/report.xml',
        'view/dotcom_sales_view.xml',
        'view/dotcom_travel_views.xml',
        'view/dotcom_travel_company.xml',
        'data/dotcom.travel.city.csv',
        'data/sistema_emissao.xml',
        'view/ticket_analysis_view.xml',
        'wizard/reconnect_lines_view.xml',
        'wizard/processed_tickets.xml',
        'data/report.xml',
        'security/dotcom_agencia_viagens_security.xml',
        'security/ir.model.access.csv',
    ],
    'demo_xml': [],
    'images' : [],
    'test': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: