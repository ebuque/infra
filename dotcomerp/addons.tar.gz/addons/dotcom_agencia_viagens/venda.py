# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

class product_product(osv.osv):
    _name = 'product.product'
    _inherit = 'product.product'
    _columns = {
                    'is_ticket': fields.boolean('Is a ticket')
                }
    _defaults = {'is_ticket':lambda *a: False}
product_product()

class dotcom_venda_linha(osv.osv):
    
    _name = 'dotcom.venda.linha'
    
    _inherit = 'dotcom.venda.linha'
    _columns =  {
                    'create_order': fields.many2one('dotcom.travel.ticket', 'Creation Order'),
                    'is_service': fields.boolean('Servico'),
                    'is_ticket': fields.boolean('Bilhete'),
                }
    
    def on_change_pct_amount(self,cr,uid,ids,prod_id,qty,unit_price,tax_id,line_amount_tax,discount_pct,discounted_val,line_total,iva_incluso,context=None):
        if context is None:
            context = {}

        res = super(dotcom_venda_linha, self).on_change_pct_amount(cr,uid,ids,prod_id,qty,unit_price,tax_id,line_amount_tax,discount_pct,discounted_val,line_total,iva_incluso,context=context)
        
        #if type(ids) in [list,long,int]:
        for id in self.browse(cr, uid, ids):
            try:
                order_id = id.create_order and id.create_order.id or None
                if order_id:
                    if id.is_ticket:
                        self.pool.get('dotcom.travel.ticket').write(cr, uid, [order_id], {'discount': discounted_val})
                    if id.is_service:
                        self.pool.get('dotcom.travel.ticket').write(cr, uid, [order_id], {'discount_service': discounted_val})
            except Exception:
                pass
        return res

dotcom_venda_linha()

class dotcom_venda(osv.osv):
    _name = 'dotcom.venda'
    _inherit = 'dotcom.venda'
    _columns = {
                    'tickets': fields.one2many('dotcom.travel.ticket','sale_id','Tickets',readonly=True,states={'reset':[('readonly',False)],'draft':[('readonly',False)]}),
                    'join_lines': fields.boolean('Join Lines'),
                }
    _defaults = {'join_lines':lambda *a: False}
    
    def write(self, cr, uid, ids, vals, context={}):
        if context is None:
            context = {}
        res = super(dotcom_venda, self).write(cr, uid, ids, vals, context=context)
        state = vals.get('state', False)
        if state:
            tickets = vals.get('tickets', [])
            all_tickets = []
            logger.info('\nTickets: %s' % tickets)
            if type(ids) != list:
                ids = [ids]
            for venda in self.browse(cr, uid, ids):
                if tickets:
                    for ticket in tickets:
                        tmp_tickets = ticket and ticket[0]
                        if tmp_tickets not in all_tickets:
                            all_tickets.append(tmp_tickets)
                else:
                    tickets = self.pool.get('dotcom.travel.ticket').search(cr, uid, [('sale_id','=', venda.id)])
                    for ticket in tickets:
                        if ticket not in all_tickets:
                            all_tickets.append(ticket)
            self.pool.get('dotcom.travel.ticket').write(cr, uid, tickets, {'estado': state})
        return res
    
    def copy(self, cr, uid, id, vals, context=None):
        if context is None:
            context={}
        venda = self.browse(cr,uid,id,context=context)
        vals['tickets']=None
        default = {}
        copia = super(dotcom_venda, self).copy(cr, uid, id, vals, context=context)
        logger.info('Registo copiado com o ID: %s' % copia)
        for ticket in venda.tickets:
            default['sale_id'] = copia
            self.pool.get('dotcom.travel.ticket').copy(cr,uid,ticket.id,default,context=context)
        #self.botao_sale(cr, uid, [copia], context=context)
        return copia
    
    def cancel(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = super(dotcom_venda, self).cancel(cr, uid, ids, context=context)
        result = []
        for each in self.browse(cr, uid, ids):
            for ticket in each.tickets:
                result.append(ticket.id)
                
        unlink_processed = self.pool.get('dotcom.ticket.processed')._get_ids(cr, uid, ticket_ids=result)
        self.pool.get('dotcom.ticket.processed').unlink(cr, uid, unlink_processed)
        return res
    
    def unlink(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        super(dotcom_venda, self).unlink(cr,uid,ids,context=context)
        tickets = self.pool.get('dotcom.travel.ticket').search(cr,uid,[('sale_id','in',ids)])
        self.pool.get('dotcom.travel.ticket').unlink(cr,uid,tickets,context=context)
        
        lines = self.pool.get('dotcom.venda.linha').search(cr,uid,[('document_top','in',ids)])
        self.pool.get('dotcom.venda.linha').unlink(cr,uid,lines,context=context)
        
        return True
    
    def on_change_join_lines(self, cr, uid, ids, join, context=None):
        if context is None:
            context = {}
        if join is True:
            self.write(cr,uid,ids,{'join_lines':True})
        else:
            self.write(cr,uid,ids,{'join_lines':False})
        return True
    
    #def cancel_now(self, cr, uid, ids, context=None):
    #    if context is None:
    #        context = {}
    #    res = super(dotcom_venda, self).cancel_now(cr, uid, ids, context=context)
    #    tickets = self.read(cr, uid, ids and ids[0], ['tickets']).get('tickets', [])
    #    if tickets:
    #        self.pool.get('dotcom.travel.ticket').write(cr, uid, tickets, {'estado':'cancel'})
    #    return res
    #
    #def post(self, cr, uid, ids, context=None):
    #    if context is None:
    #        context = {}
    #    res = super(dotcom_venda, self).post(cr, uid, ids, context=context)
    #    tickets = self.read(cr, uid, ids and ids[0], ['tickets']).get('tickets', [])
    #    if tickets:
    #        self.pool.get('dotcom.travel.ticket').write(cr, uid, tickets, {'state':'done'})
    #    return res
    #
    def check_all_tickets(self, cr, uid, ids, ticket_number, tipo='contabilistico', context=None):
        if context is None:
            context = {}
        ticket_number = str(ticket_number).strip()
        #string = '%%%s%%' % ticket_number
        string = ticket_number
        #if tipo=='contabilistico':    
        settings = [
            ('ticket_number','=', string),
            ('accounting','=',tipo),
            #('state','!=','cancel'),
            ('estado','not in',['cancel','draft', '']),
            ('sale_id','not in',ids)
            ]
        exists = self.pool.get('dotcom.travel.ticket').search(cr,uid,settings)
        #logger.info('\nSETTINGS: %s\nSEARCH RESULTS: %s' % (settings,exists))
        if exists:
            ticket = self.pool.get('dotcom.travel.ticket').browse(cr,uid,exists[0]).sale_id
            number = ticket and ticket.document_number
            tipo = ticket and ticket.doc_type.name
            raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s já foi registado no sistema na %s numero %s ') % (ticket_number, tipo, number))
        return True
    
    #def write(self, cr, uid, ids, vals, context=None):
    #    if context is None:
    #        context = {}
    #    try:
    #        id = ids and ids[0]
    #    except Exception:
    #        id = ids
    #    one = self.browse(cr, uid, id)
    #    tipo = one and one.doc_type and one.doc_type.contabilidade or 'contabilistico'
    #    for ticket in one.tickets:
    #        number = ticket and ticket.ticket_number
    #        self.check_all_tickets(cr, uid, [id], number, tipo,context=context)
    #    return super(dotcom_venda, self).write(cr, uid, ids, vals, context=context)
    #
    
    def post(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res= True
        res = super(dotcom_venda, self).post(cr, uid, ids, context=context)
        logger.info('\nA iniciar processo de verificaçao de tickets\n')
        self.process_tickets(cr, uid, ids)
        return res
    
    def process_tickets(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        for each in self.browse(cr, uid, ids):
            tipo = each and each.doc_type and each.doc_type.contabilidade or 'contabilistico'
            if tipo == 'contabilistico':
                logger.info('\nA processar documento contabilistico')
                ticket_ids = []
                vals = {}
                sale_id = each.id
                vals['sale_id'] = sale_id
                
                for ticket in each.tickets:
                    vals['ticket_id'] = ticket.id
                    operator = ticket.code_01
                    vals['operator'] = operator#ticket.code_01#operator_ids.get(id, '')
                    tkt_nbr = ticket.code_02
                    logger.info('\nA processar bilhete %s%s' % (ticket.code_01,ticket.code_02))

                    res_create = []
                    ticket = tkt_nbr.split('/')
                    if len(ticket) > 1:
                        base = ticket[0]
                        res_create.append(base)
                        for each in range(1, len(ticket)):
                            key = str(ticket[each])
                            number = len(key)
                            cur_base = base[:-number]
                            res_create.append('%s%s' % (cur_base, key))
                    else:
                        res_create.append(ticket and ticket[0])
                    
                    for create in res_create:
                        logger.info('\nOperator: %s\nTicket: %s' % (operator, create))
                        self.pool.get('dotcom.ticket.processed').find_check(cr, uid, operator=operator, ticket_number=create, rvenda=sale_id, context=context)
                        vals['ticket'] = create
                        self.pool.get('dotcom.ticket.processed').create(cr, uid, vals)
        return True
    
    def compute(self, cr, uid, doc_id, context=None):
        if context is None:
            context = {}
        venda = self.browse(cr, uid, doc_id)
        ticks = []
        tipo = venda and venda.doc_type and venda.doc_type.contabilidade or 'contabilistico'
        for ticket in venda.tickets:
            if ticket.ticket_number in ticks:
                raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s encontra-se repetido no documento') % (ticket.ticket_number))
            else:
                ticks.append(ticket.ticket_number)
        #if tipo == 'contabilistico':
        #    for ticket in ticks:
        #        if not ticket.replace('/','').replace(' ','').isdigit():
        #            raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s não está bem formatado') % ticket)
        #        #self.check_all_tickets(cr, uid, [doc_id], ticks, tipo,context=context)
        return super(dotcom_venda, self).compute(cr, uid, doc_id, context=context)
 
    def botao_sale(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        vendas = self.browse(cr, uid, ids, context)
        created_ids = []
        for venda in vendas:
            if venda.state in ['draft','reset']:
                tipo = venda.doc_type.contabilidade or 'contabilistico'
                for linha in venda.sales_lines:
                    if linha.create_order:
                        self.pool.get('dotcom.venda.linha').unlink(cr,uid,linha.id,context)
                    else:
                        continue
                for iva in venda.taxes_ids:
                    self.pool.get('dotcom.venda.iva').unlink(cr,uid,iva.id,context)
                for ticket in venda.tickets:
                    iva_bilhete = False
                    iva_servico = False
                    tkt_number = str(ticket.ticket_number or '')
                    #if not tkt_number.replace('/','').replace(' ','').isdigit():
                        #raise osv.except_osv(_('Invalid action !'), _('O bilhete com o numero %s não está bem formatado') % tkt_number)
                    context['sale'] = venda and venda.id
                    #self.pool.get('dotcom.travel.ticket')._check_ticket_number(cr, uid, tkt_number,tipo, context=context)
                    if ticket.sale_id is not None and ticket.state=='valid':
                        
                        irps = 0
                        product_id = ticket.prod_id
                        if product_id:
                            venda = self.pool.get('dotcom.venda').browse(cr,uid,ticket.sale_id.id,context)
                            product_obj = self.pool.get('product.product').browse(cr,uid,product_id.id,context)
                            line = {}
                            iva = product_obj.iva_id.id or None
                            tax_amount = 0
                            if iva is None:
                                iva = self.pool.get('iva.iva').search(cr,uid,[])
                                if iva and len(iva)>0:
                                    iva = iva[0]
                                    tax_amount = 0.01*(iva.tax or 0)
        
                            price = ticket.prod_price or 0
                            extra = ticket.extra or 0
                            incitement = ticket.incitement or 0
                            lam = ticket.lam or 0
                            mark_up = ticket.mark_up or 0
                            du_tax = ticket.du_tax or 0
                            irps = (incitement+lam)/5 or 0
                            discount = ticket.discount or 0
                            
                            if product_id.includes_vat:
                                iva_bilhete = True
                            
                            self.pool.get('dotcom.travel.ticket').write(cr,uid,ticket.id,{'irps':irps})
                            #vals['irps'] = irps
                            price = price+extra+incitement+lam+mark_up+du_tax+irps
                            
                            line = {
                                'document_top': ticket.sale_id.id,
                                'prod_id': product_id.id,
                                'prod_desc': product_obj.name+ ' / ' +(ticket.ticket_number or ''),
                                'unit_price': price,
                                'discount_pct': 0,
                                'line_total': price,
                                'total_temp': price,
                                'tax_id': iva,
                                'qty': 1,
                                'discount_pct': 0,
                                'discounted_val': discount,
                                'line_amount_tax': (tax_amount*price),
                                'create_order': ticket.id,
                                'iva_incluido': iva_bilhete,
                                'is_ticket': True,
                                'price_id': self.pool.get('product.pvp.version')._get_default(cr, uid),
                            }
                            
                            line_id = self.pool.get('dotcom.venda.linha').create(cr,uid,line)
                            created_ids.append(line_id)
                            logger.info('LINE1 INFORMATION: %s' % line)
                            
                            service_price = ticket.service_price or 0
                            vat_id = ticket.service_vat or None
                            service_id = ticket.service_id or False
                            if service_id:
                                service_obj = self.pool.get('product.product').browse(cr,uid,service_id.id)
                                service_name = service_obj.name or ''
                                service_tax = 0
                                if service_obj.includes_vat:
                                    iva_servico = True
                                if vat_id:
                                    iva_obj = self.pool.get('iva.iva').browse(cr,uid,vat_id.id,context)
                                    iva_amount = iva_obj.tax or 0
                                    logger.info('IVA AMOUNT: %s, TYPE %s' % (iva_amount, type(iva_amount)))
                                    iva_amount = float(str(iva_amount))
                                    service_tax = (iva_amount/100)*service_price
                                
                                service_discount = ticket.discount_service or 0
                                line2 = {
                                    'document_top': ticket.sale_id.id,
                                    'prod_id': service_id.id,
                                    'prod_desc': str(service_name)+' / '+(ticket.ticket_number or ''),
                                    'unit_price': service_price,
                                    'discount_pct': 0,
                                    'line_total': service_price,
                                    'total_temp': service_price,
                                    'tax_id': vat_id.id,
                                    'qty': 1,
                                    'discount_pct': 0,
                                    'discounted_val': service_discount,
                                    'line_amount_tax': service_tax,
                                    'create_order': ticket.id,
                                    'iva_incluido': iva_servico,
                                    'is_service': True,
                                    'price_id': self.pool.get('product.pvp.version')._get_default(cr, uid),
                                }
                                logger.info('LINE2 INFORMATION: %s' % line2)
                                line_id2 = self.pool.get('dotcom.venda.linha').create(cr,uid,line2)
                                self.pool.get('dotcom.travel.ticket').write(cr,uid,ticket.id,{'sale_line_id':line_id2})
            else:
                raise osv.except_osv(_('Invalid action !'), _('O documento não pode ser actualizado porque não está em Rascunho !'))
        return True
    
dotcom_venda()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: