# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_doador(osv.osv):
    
    def _check_mail(self, cr, uid, ids):
        for doador in self.browse(cr, uid, ids):
            if doador.email:
                if re.match("^[a-zA-Z0-9._%-]+@[a-zA-Z0-9._%-]+.[a-zA-Z]{2,6}$", passageiro.email or ''):
                    return True
                else:
                    return False
            else:
                return True
    
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for doador in self.browse(cr, uid, ids, context=context):
            ref = doador.ref and doador.ref or ''
            nome = doador.nome or ''
            friendly_name = '['+ref + '] ' + nome
            res[doador.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.doador'
    _columns={
        'ref':fields.char('Ref.', size=50, required=True, ),
        'nome':fields.char('Nome', size=100, readonly=False, required=True),
        'telefone':fields.char('Telefone', size=50),
        'celular':fields.char('Cel.', size=50),
        'email':fields.char('E-Mail',size=50,required=False),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projectos', readonly=True),
        
        'origem':fields.selection([('nacional','Nacional'),('estrangeiro','Estrangeiro')],'Origem'),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=True),
    }
    
    _rec_name='friendly_name'


    _sql_constraints = [
        ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
dotcom_gestao_projectos_doador()


class dotcom_gestao_projectos_doador_projecto(osv.osv):
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for doador in self.browse(cr, uid, ids, context=context):
            ref = doador.ref and doador.ref or ''
            nome = doador.nome or ''
            friendly_name = '['+ref + '] ' + nome
            res[doador.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.doador.projecto'
    _columns={
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Doador/Financiador', required=True),
        'ref':fields.char('Ref.', size=50, required=True, ),
        'nome':fields.char('Nome', size=100, readonly=False, required=True),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projectos', readonly=True),
        'origem':fields.selection([('nacional','Nacional'),('estrangeiro','Estrangeiro')],'Origem'),
        'principal':fields.boolean('Principal'),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=True),
    }
    
    
    _rec_name='friendly_name'
    
    def on_change_doador(self,cr,uid,ids,doador_id,context=None):
        if context is None:
            context={}
        
        val={}
        if bool(doador_id)!=False:
            doador_object=self.pool.get('dotcom.gestao.projectos.doador').browse(cr,uid,doador_id)
            val={'ref':doador_object.ref,'nome':doador_object.nome,'origem':doador_object.origem}
        else:
            val={'ref':'','nome':'','origem':''}
            
        return {'value':val}
    
dotcom_gestao_projectos_doador_projecto()   
    