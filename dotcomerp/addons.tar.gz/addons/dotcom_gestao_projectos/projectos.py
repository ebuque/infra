# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_projecto(osv.osv):
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.nome or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.projecto'
    _columns={
        'ref':fields.char('Ref.', size=50, required=True, readonly=True, states={'rascunho':[('readonly',False)]}),
        'nome':fields.char('Nome', size=100, required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'data_inicio':fields.date('Data Início',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'data_fim':fields.date('Data Fim',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'gestor':fields.char('Gestor', size=100, required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'doadores_ids':fields.one2many('dotcom.gestao.projectos.doador.projecto','projecto_id','Financiadores',readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
                
        'programas_ids':fields.one2many('dotcom.gestao.projectos.programa','projecto_id','Programas',readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'projectos_ids':fields.one2many('dotcom.gestao.projectos.lancamentos','projecto_id','Projectos'),
        
        'state':fields.selection([
                                    ('rascunho','Rascunho'),
                                    ('activo','Acivo'),
                                    ('expirado','Expirado'),
                                    ('cancelado','Cancelado'),
                                    ('outro_rascunho','Rascunho'),
                                    ],
                                    'Estado'),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=True),
    }
    
    _rec_name='friendly_name'
    
    _defaults={
        'state':'rascunho'
    }
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
    
    def activar_projecto(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            contador=0
            lista_doadores=[]
            for doador in documento.doadores_ids:
                
                if doador.principal==True:
                    contador=contador+1
                    
                logger.info('VALORES ACHADOS NA LISTA DE DOADORES %s' %str())
                if lista_doadores.__contains__(doador.doador_id.id):
                    raise osv.except_osv(_('Acção Inválida !'), _('Não é permitida a repetição de um doador/financiador no mesmo project !!'))
                else:
                    lista_doadores.append(doador.doador_id.id)
                
            if contador>1:
                raise osv.except_osv(_('Acção Inválida !'), _('Não é permitida a existência de projectos com mais de um doador principal !!'))
            
            
            self.write(cr,uid,documento.id,{'state':'activo'})
        
        return True
    
    
    def voltar_rascunho(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids,context):
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
        
        return True
    
    
dotcom_gestao_projectos_projecto()


class dotcom_gestao_projectos_programa(osv.osv):
    
    #def _friendly_name(self, cr, uid, ids, field, arg, context=None):
    #    res = {}
    #    for conta in self.browse(cr, uid, ids, context=context):
    #        #ref = conta.ref and conta.ref or ''
    #        nome = conta.nome or ''
    #        friendly_name = '['+ref + '] ' + nome
    #        res[conta.id] = friendly_name
    #    return res
    
    _name='dotcom.gestao.projectos.programa'
    _columns={
        #'ref':fields.char('Ref.', size=50, required=True, ),
        'data_inicio':fields.date('Data Início',required=True),
        'data_fim':fields.date('Data Fim',required=True),
        'nome':fields.char('Nome', size=100, readonly=False, required=True),
        'gestor':fields.char('Gestor', size=100, required=True),
        
        #'doadores_ids':fields.one2many('dotcom.gestao.projectos.doador','projecto_id','Financiador', ),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Project'),
        'state':fields.selection([
                                    ('activo','Acivo'),
                                    ('expirado','Expirado'),
                                    ('cancelado','Cancelado')],
                                    'Estado'),
    }
    
    _rec_name='nome'
    
    
    _defaults={
        #'doador_id':lambda self, cr, uid, c: c.get('doador_id', False),
        'gestor':lambda self, cr, uid, c: c.get('gestor', False),
        'data_inicio':lambda self, cr, uid, c: c.get('data_inicio', False),
        'data_fim':lambda self, cr, uid, c: c.get('data_fim', False),
    }
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
dotcom_gestao_projectos_programa()