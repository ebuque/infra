# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name': 'Gestão de Projectos',
    'version': '1.2',
    'description': '''Gestão de Projectos''',
    'author': 'DotCom, LDA',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'depends': ['dotcom_doc_base','jasper_reports','dotcom_licence'],
    'init_xml': [],
    'update_xml': [
        
        'view/dotcom_menu.xml',
        'view/dotcom_contas_view.xml',
        'view/dotcom_doador_view.xml',
        'view/dotcom_projecto_view.xml',
        'view/dotcom_rubrica_view.xml',
        'view/dotcom_orcamento_view.xml',
        'view/dotcom_niveis_aprovacao_view.xml',
        'view/dotcom_documentos_view.xml',
        'view/dotcom_movimento_view.xml',
        'view/dotcom_analise_orcamental_view.xml',
        'view/dotcom_conciliacao_bancaria_view.xml',
        'view/dotcom_analise_movimento_view.xml',
        'view/dotcom_extrato_conta_view.xml',
        'view/dotcom_tipo_movimento_view.xml',
        'view/dotcom_inherit_view.xml',
        #'view/inherits.xml',
        'data/dotcom.gestao.projectos.tipo.movimento.csv',
        #'security/ir.model.access.csv',
#         'data/plano_contas_data.xml',
        ],
    'demo_xml': [],
    'images' : [],
    'test': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
