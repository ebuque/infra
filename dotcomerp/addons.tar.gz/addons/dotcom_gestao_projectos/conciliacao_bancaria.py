# -*- encoding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')



class dotcom_gestao_projectos_conciliacao_bancaria(osv.osv):
    _name='dotcom.gestao.projectos.concilaicao.bancaria'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=True,required=True, states={'rascunho':[('readonly',False)]}),
        'periodo_inicial_id':fields.many2one('configuration.period','Período  Inicial',readonly=True, domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False),]",states={'rascunho':[('readonly',False)]}),
        'periodo_final_id':fields.many2one('configuration.period','Período Final',readonly=True, domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False),]",states={'rascunho':[('readonly',False)]}),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, readonly=True, states={'rascunho':[('readonly',False)]}),
        'banco_id':fields.many2one('res.bank','Banco',readonly=True),
        'titular':fields.char('Titular',size=100,readonly=True),
        'data':fields.date('Data', required=True, readonly=True,states={'rascunho':[('readonly',False)]}),
        'total_debitos':fields.float('Total Debitado',readonly=True),
        'total_creditos':fields.float('Total Creditado', readonly=True),
        'total_conciliado':fields.float('Total Reconciliado', readonly=True),
        'total_nao_conciliado':fields.float('Total não Reconciliado', readonly=True),
        'conciliados':fields.boolean('Incluir Reconciliados'),
        
        'lancamentos_ids':fields.one2many('dotcom.gestao.projectos.conciliacao.bancaria.linha','conciliacao_id','Lancamentos', readonly=True),
        
        #'lancamentos_movimentos_ids':fields.one2many('dotcom.gestao.projectos.lancamentos','conciliacao_id','Lancamento Movimento')
        
        'state':fields.selection([
                                    ('rascunho','Rascunho'),
                                    ('emitido','Emitido'),
                                    ('cancelado','Cancelado')
                                    ])
    }
    
    _order='create_date desc'
    
    _defaults={
        'state':'rascunho',
        'data':lambda *a: time.strftime('%Y-%m-%d'),
    }
    
    
    def on_change_data(self,cr,uid,ids,data,context=None):
        if context is None:
            context={}
        
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                        ('date_start','<=',data),
                                                                        ('date_stop','>=',data)
                                                                        ])
        if len(periodos_ids)<=0:
            raise osv.except_osv(_('Error !'), _('Ano Fiscal Sem Periodos Definidos'))
        
        periodo=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
        val={'ano_fiscal_id':periodo.fiscalyear_id.id}
        return {'value':val}
    
    
    def on_change_conta(self,cr,uid,ids,conta_id,context={}):
        if context is None:
            context={}
        conta=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_id)
        val={
                'banco_id':conta.banco_id.id,
                #'numero':conta.numero,
                'titular':conta.titular,
                #'moeda_lancamento_id':conta.moeda_lancamento_id.id
              }
        return{'value':val}
    
    
    def actualizar_conciliacao_bancaria(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            lancamentos_ids=[]
            total_debito=0
            total_credito=0
            
            total_credito_conciliado=0
            total_debito_conciliado=0
            
            total_credito_nao_conciliado=0
            total_debito_nao_conciliado=0
            
            for lancamento in documento.lancamentos_ids:
                self.pool.get('dotcom.gestao.projectos.conciliacao.bancaria.linha').unlink(cr,uid,lancamento.id)
            
            if bool(documento.periodo_inicial_id.id)==False and bool(documento.periodo_final_id.id)==False:
                if documento.conciliados==True:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                            ('conta_id','=',documento.conta_id.id),
                                                                                                            ('state','=','emitido'),
                                                                                                            ('data','<=',documento.data),
                                                                                                            #('confirmacao_conciliacao','=',True)
                                                                                                            ])
                else:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                            ('conta_id','=',documento.conta_id.id),
                                                                                                            ('state','=','emitido'),
                                                                                                            ('data','<=',documento.data),
                                                                                                            ('confirmacao_conciliacao','=',False)
                                                                                                            ])
            
                        
            for lancamento in lancamentos_ids:
                lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                if lancamento.tipo_movimento=='receita':
                    total_debito=total_debito+lancamento.valor
                if lancamento.tipo_movimento=='dispesas':
                    total_credito=total_credito+lancamento.valor
                
                if lancamento.confirmacao_conciliacao==True:
                    if lancamento.tipo_movimento=='receita':
                        total_debito_conciliado=total_debito_conciliado+lancamento.valor
                        
                    if lancamento.tipo_movimento=='dispesas':
                        total_credito_conciliado=total_credito_conciliado+lancamento.valor
                    
                    
                elif lancamento.confirmacao_conciliacao==False:
                    if lancamento.tipo_movimento=='dispesas':
                        total_credito_nao_conciliado=total_credito_nao_conciliado+lancamento.valor
                    
                    if lancamento.tipo_movimento=='receita':
                        total_debito_nao_conciliado=total_debito_nao_conciliado+lancamento.valor
                
                val={
                    'data':lancamento.data,
                    #'tipo_movimento_id':lancamento.tipo_movimento_id.id,
                    'rubrica_id':lancamento.rubrica_id.id,
                    #'credito':lancamento.credito,
                    #'debito':lancamento.debito,
                    'confirmacao':lancamento.confirmacao_conciliacao,
                    'conciliacao_id':documento.id,
                    'lancamento_movimento':lancamento.id,
                }
                if lancamento.tipo_movimento=='dispesas':
                    val['credito']=lancamento.valor
                    val['debito']=0
                    
                elif lancamento.tipo_movimento=='receita':
                    val['credito']=0
                    val['debito']=lancamento.valor
                self.pool.get('dotcom.gestao.projectos.conciliacao.bancaria.linha').create(cr,uid,val)
            
            total_conciliado=total_debito_conciliado-total_credito_conciliado
            total_nao_conciliado=total_debito_nao_conciliado-total_credito_nao_conciliado
            self.write(cr,uid,documento.id,{
                                            'total_debitos':total_debito,
                                            'total_creditos':total_credito,
                                            'total_conciliado':total_conciliado,
                                            'total_nao_conciliado':total_nao_conciliado
                                            })
            
        return {}  
            
    
    def emitir_conciliacao(self, cr,uid,ids,context={}):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            
            total_credito_conciliado=0
            total_debito_conciliado=0
            
            total_credito_nao_conciliado=0
            total_debito_nao_conciliado=0
            for lancamento in documento.lancamentos_ids:
                logger.info('MOVIMENTOS ACHADOS %s' %str())
                if lancamento.confirmacao==True:
                    if lancamento.tipo_movimento=='dispesas':
                        total_credito_conciliado=total_credito_conciliado+lancamento.valor
                    elif lancamento.tipo_movimento=='receita':
                        total_debito_conciliado=total_debito_conciliado+lancamento.valor
                    #self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.lancamento_movimento.id,{'confirmacao_conciliacao':True})
                else:
                    if lancamento.tipo_movimento=='dispesas':
                        total_credito_nao_conciliado=total_credito_nao_conciliado+lancamento.valor
                    elif lancamento.tipo_movimento=='receita':
                        total_debito_nao_conciliado=total_debito_nao_conciliado+lancamento.valor
                    
            total_conciliado=total_debito_conciliado-total_credito_conciliado
            total_nao_conciliado=total_debito_nao_conciliado-total_credito_nao_conciliado
            self.write(cr,uid,documento.id,{
                                            'state':'emitido',
                                            'total_conciliado':total_conciliado,
                                            'total_nao_conciliado':total_nao_conciliado
                                            })
    
    
    def calcular_totais(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            
            total_credito_conciliado=0
            total_debito_conciliado=0
            
            total_credito_nao_conciliado=0
            total_debito_nao_conciliado=0
            for lancamento in documento.lancamentos_ids:
                logger.info('MOVIMENTOS ACHADOS %s' %str())
                if lancamento.confirmacao==True:
                    #if lancamento.tipo_movimento=='dispesas':
                    total_credito_conciliado=total_credito_conciliado+lancamento.credito
                    #elif lancamento.tipo_movimento=='receita':
                    total_debito_conciliado=total_debito_conciliado+lancamento.debito
                    #self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.lancamento_movimento.id,{'confirmacao_conciliacao':True})
                else:
                    #if lancamento.tipo_movimento=='dispesas':
                    total_credito_nao_conciliado=total_credito_nao_conciliado+lancamento.credito
                    #elif lancamento.tipo_movimento=='receita':
                    total_debito_nao_conciliado=total_debito_nao_conciliado+lancamento.debito
                    
            total_conciliado=total_debito_conciliado-total_credito_conciliado
            total_nao_conciliado=total_debito_nao_conciliado-total_credito_nao_conciliado
            self.write(cr,uid,documento.id,{
                                            'total_conciliado':total_conciliado,
                                            'total_nao_conciliado':total_nao_conciliado
                                            })
    
    
    def unlink(self,cr,uid,ids,context=None):
        if context is None:
            context={}
                    
        lista=[]
        if type(ids)==list:
            lista=ids
        else:
            lista.append(ids)
        local_object=self.browse(cr,uid,lista[0])
        
        if local_object.state=='rascunho':
            osv.osv.unlink(self, cr, uid, [local_object.id], context=context)
            
        elif local_object.state!='rascunho' :
            raise osv.except_osv(_('Acção Invalida !'), _('Não é possivel apagar Movimentos emitidos!!'))
        
        return True
    
dotcom_gestao_projectos_conciliacao_bancaria()


class dotcom_gestao_projectos_conciliacao_bancaria_linha(osv.osv):
    _name='dotcom.gestao.projectos.conciliacao.bancaria.linha'
    _columns={
        #'tipo_movimento_id':fields.many2one('dotcom.tesouraria.movimento.tesouraria','Movimento Tesouraria',readonly=True, required=True),
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica',readonly=True, domain="[('tipo_movimento','=',tipo_movimento)]"),
        'credito':fields.float('Credito',readonly=True,),
        'data':fields.date('Data', required=True, readonly=False,),
        'debito':fields.float('Debito',readonly=True),
        'confirmacao':fields.boolean('Reconciliação'),
        'conciliacao_id':fields.many2one('dotcom.gestao.projectos.concilaicao.bancaria','Conciliacao',),
        
        'lancamento_movimento':fields.many2one('dotcom.gestao.projectos.lancamentos','Lancamento Movimento'),
    }
    
    
    def conciliar_linha(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            if documento.confirmacao==False:
                self.write(cr,uid,documento.id,{'data':documento.conciliacao_id.data,'confirmacao':True})
                self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,documento.lancamento_movimento.id,{'confirmacao_conciliacao':True})
            
            self.pool.get('dotcom.gestao.projectos.concilaicao.bancaria').calcular_totais(cr,uid,[documento.conciliacao_id.id])
        return True
        
    
    def desconciliar_linha(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            if documento.confirmacao==True:
                self.write(cr,uid,documento.id,{'data':documento.conciliacao_id.data,'confirmacao':False})
                self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,documento.lancamento_movimento.id,{'confirmacao_conciliacao':False})
                
            self.pool.get('dotcom.gestao.projectos.concilaicao.bancaria').calcular_totais(cr,uid,[documento.conciliacao_id.id])
        return True
            
    
    def on_change_confirmacao(self, cr,uid,ids,confirmacao,context=None):
        if context is None:
            context={}
            
        documento=self.browse(cr,uid,ids[0])
        val={}
        if confirmacao==True:
            val={'data':documento.conciliacao_id.data}
        else:
            val={'data':None}
            
        return {'value':val}
    
dotcom_gestao_projectos_conciliacao_bancaria_linha()
