# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_movimento(osv.osv):
    
    def cambio_secundario(self,cr,uid,context=None):
        if context is None:
            context={}
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr,uid, context=context)
        cambio=1
        moeda_secund=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
        logger.info('MOEDA SECUNDARIA CAMBIO %s' %str(moeda_secund.rate))
        return moeda_secund.rate
    
    
    def _total_movimentado(self, cr, uid, ids, field, arg, context=None):
        res = {}
                
        for documento in self.browse(cr, uid, ids, context=context):
            total_debito=0
            for lancamento in documento.lancamento_movimentos_ids:
                total_debito=total_debito+lancamento.valor
            res[documento.id] = total_debito
        return res
    
    
    def _total_credito(self, cr, uid, ids, field, arg, context=None):
        res = {}
                
        for documento in self.browse(cr, uid, ids, context=context):
            
            total_credito=0
            for lancamento in documento.lancamento_movimentos_ids:
                total_credito=total_credito+lancamento.credito
            res[documento.id] = total_credito
        return res
    
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for movimento in self.browse(cr, uid, ids, context=context):
            #nome = movimento.numero_movimentos or ''
            friendly_name = movimento.numero_movimentos or ''
            res[movimento.id] = friendly_name
        return res
    
    
    _name='dotcom.gestao.projectos.movimento'
    _columns={
        'data':fields.datetime('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=True,required=True,),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'cambio_secundario':fields.float('Câmbio MP/MS', help="Câmbio para a moeda Secundaria(MP/MS)",readonly=True, states={'rascunho':[('readonly',False)]}),
        'tipo_documento_id':fields.many2one('dotcom.gestao.projectos.documento','Tipo Documento',readonly=True, required=True,domain="[('tipo_documento','!=','transferencia')]", states={'rascunho':[('readonly',False)]}),
        'sequencia_id':fields.many2one('dotcom.sequence','Sequencia', required=True,readonly=True, domain="[('documento_id','=',tipo_documento_id)]", states={'rascunho':[('readonly',False)]}),
        'total_movimentado':fields.function(_total_movimentado, type='float', string='Total Debito', method=True, store=True),
        #'total_credito':fields.function(_total_credito, type='float', string='Total Credito', method=True, store=True),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',readonly=True ,required=True, domain="[('tipo_conta','=','banco')]",states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto', required=True,readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', required=False, domain="[('projecto_id','=',projecto_id)]",readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador.projecto','Financiador Princ.', domain="[('projecto_id','=',projecto_id)]", required=False,readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'local_realizacao':fields.char('Local Real.', size=100,readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'descricao':fields.char('Descrição', size=100,readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'lancamento_movimentos_ids':fields.one2many('dotcom.gestao.projectos.lancamentos', 'movimento_id','Lancamentos',readonly=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'lancamento_conversao_ids':fields.one2many('dotcom.gestao.projectos.lancamentos', 'movimento_conversao_moeda_id','Lancamentos',readonly=True,),
        
        'numero_movimentos':fields.char('Numero', size=50, readonly=True),
        #'movimento_contabilidade_id':fields.many2one('dotcom.contabilidade.movimentos','Mov. Contab.', readonly=True, help="Movimento Gerado na Contabilidade"),
        
        
        
        'state':fields.selection([
                    ('rascunho','Rascunho'),
                    ('emitido','Emitido'),
                    ('cancelado','Cancelado'),
                    ('outro_rascunho','Rascunho'),
                    ],'Estado'),
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (numero_movimentos,tipo_documento_id)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    _order='create_date desc'
    
    _rec_name='data'
    
    _defaults={
        'state':'rascunho',
        'data':lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
        #'tipo_documento_id':validator.getDocumento,
    }
    
    
    def create(self,cr,uid,value,context=None):
        if context is None:
            context={}
            
        data=value['data']
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                        ('date_start','<=',data),
                                                                        ('date_stop','>=',data),
                                                                        ('special','=',False),
                                                                        ('closing','=',False),
                                                                        ])
        periodo=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
        value['periodo_id']=periodo.id
        value['ano_fiscal_id']=periodo.fiscalyear_id.id
        
        #programa_id=value['programa_id']
        #programa_object=self.pool.get('dotcom.gestao.projectos.programa').browse(cr,uid,programa_id)
        ##value['doador_id']=programa_object.doador_id.id
        
        return super(dotcom_gestao_projectos_movimento, self).create(cr, uid, value, context=context)
    
    
    def on_change_tipo_documento(self,cr,uid,ids,tipo_documento_id,context=None):
        if context is None:
            context={}
        value={}
        if bool(tipo_documento_id)==True:
            tipo_documento_object=self.pool.get('dotcom.gestao.projectos.documento').browse(cr,uid,tipo_documento_id)

            for sequencia in tipo_documento_object.sequenciador_ids:
                if sequencia.default_sequence==True:
                    value={'sequencia_id':sequencia.id}
                else:
                    value={'sequencia_id':None}
                        
            logger.info('OBJECT DO TIPO DE MOVIMENTO %s' %str(value))
            #value['tipo_movimento']=tipo_documento_object.tipo_movimento
            
        else:
            value={'sequencia_id':None}
        
        logger.info('VALUE ACHADO DEPOIS DO ONCHANGE %s' %str(value))
        return {'value':value}
  
    
    def on_change_projecto(self,cr,uid,ids,projecto_id,context=None):
        if context is None:
            context={}
        
        value={}
        if bool(projecto_id)==True:
            projecto_object=self.pool.get('dotcom.gestao.projectos.projecto').browse(cr,uid,projecto_id)
            doador_principal=False
            for doador in projecto_object.doadores_ids:
                if doador.principal==True:
                    doador_principal=doador
                    value={'doador_id':doador_principal.id}
        return {'value':value}
            
    
    def on_change_data(self,cr,uid,ids,data,context=None):
        if context is None:
            context={}
        
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                        ('date_start','<=',data),
                                                                        ('date_stop','>=',data),
                                                                        ('special','=',False),
                                                                        ('closing','=',False),
                                                                        ])
        if len(periodos_ids)<=0:
            raise osv.except_osv(_('Error !'), _('Ano Fiscal Sem Periodos Definidos'))
        
        periodo=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
        val={'periodo_id':periodo.id, 'ano_fiscal_id':periodo.fiscalyear_id.id}
        return {'value':val}
    
    
    def on_change_moeda(self,cr,uid,ids,moeda_id,conta_id,context=None ):
        if context is None:
            context={}
        
        if bool(conta_id)==True:
            logger.info('IDENTIFICADOR DA CONTA %s' %str(conta_id))
            conta_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_id)
            lancamento = conta_object and conta_object.moeda_lancamento_id and conta_object.moeda_lancamento_id.id or False
            if not bool(lancamento == moeda_id):
                logger.info('\nMOEDA DE LANCAMENTO: %s, \nTYPE: %s' % (lancamento, type(lancamento)))
                logger.info('\nMOEDA DE envio: %s, \nTYPE: %s' % (moeda_id, type(moeda_id)))
                #raise osv.except_osv(_('Acção Inválida !'), _('A moeda de lançamento deve ser igual a moeda da conta'))
                
        moeda = self.pool.get('res.currency').browse(cr, uid, moeda_id)
        cambio = moeda.rate or 1
        
        return {'value':{'cambio':cambio}}
    
    
    def on_change_conta(self,cr,uid,ids,conta_id,context=None):
        if context is None:
            context={}
        
        value={}   
        if bool(conta_id)==True:
            conta_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_id)
            value={
                'moeda_lancamento_id':conta_object.moeda_lancamento_id.id
            }
        else:
            value={
                'moeda_lancamento_id':False
            }
        return {'value':value}
    
    
    def criar_movimento_contabilidade(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            
            moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,ids, context=context),
            moeda_primaria= self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)           
            moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,ids, context=context),        
            
            moeda_secundaria= self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
            
            data=datetime(*(time.strptime(documento.data, '%Y-%m-%d %H:%M:%S')[0:6])).strftime('%Y-%m-%d')
            logger.info('DATA ACHADA PARA O MOVIMENTO %s' %str(data))
            
            movimnto_val={
                'data':data,
                'ano_fiscal_id':documento.ano_fiscal_id.id,
                'diario_id':documento.tipo_documento_id.diario_contabilidade_id.id,
                'documento_id':documento.tipo_documento_id.documento_contabilidade_id.id,
                'periodo':documento.periodo_id.id,
                'notas_internas':'',
                'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                'cambio':documento.cambio,
                'cambio_secundario':documento.cambio_secundario,
                'lancamento_abertura':False,
                'lancamento_fecho':False,
                #'iva_id':documento.id,
            }
            movimento_id=self.pool.get('dotcom.contabilidade.movimentos').create(cr,uid,movimnto_val)
            movimento_object=self.pool.get('dotcom.contabilidade.movimentos').browse(cr,uid,movimento_id)
            
            valor_total=0
            
            for lancamento in documento.lancamento_movimentos_ids:
                lancamento_novo={
                                'conta_id':lancamento.rubrica_id.plano_conta_id.id,
                                'data_lancamento':data,
                                'ano_fiscal_id':documento.ano_fiscal_id.id,
                                'periodo_id':documento.periodo_id.id,
                                'tipo_lancamento':'normal',
                                'movimento_id':movimento_id,
                                'reflexao_iva':False,
                                'reflexao_centro':False,
                                'acerto':'all',
                                'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                                'moeda_documento':movimento_object.moeda_lancamento_id.id,
                                'moeda_secundaria_id':movimento_object.moeda_secundaria_id.id,
                                'moeda_primaria_id':moeda_primaria_id,
                                'cambio':movimento_object.cambio,
                                'cambio_secundario':movimento_object.cambio_secundario,
                                #'lancamento_iva_id':documento.id,
                            }
                valor_total=valor_total+lancamento.valor
                if documento.tipo_movimento=='credito':
                    lancamento_novo['credito']=lancamento.valor
                    lancamento_novo['debito']=0
                else:
                    lancamento_novo['credito']=0
                    lancamento_novo['debito']=lancamento.valor
                
                self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento_novo)
#
            lancamento_novo={
                            'conta_id':documento.conta_id.plano_conta_id.id,
                            'data_lancamento':data,
                            'ano_fiscal_id':documento.ano_fiscal_id.id,
                            'periodo_id':documento.periodo_id.id,
                            'tipo_lancamento':'normal',
                            'movimento_id':movimento_id,
                            'reflexao_iva':False,
                            'reflexao_centro':False,
                            'acerto':'all',
                            'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                            'moeda_documento':movimento_object.moeda_lancamento_id.id,
                            'moeda_secundaria_id':movimento_object.moeda_secundaria_id.id,
                            'moeda_primaria_id':moeda_primaria_id,
                            'cambio':movimento_object.cambio,
                            'cambio_secundario':movimento_object.cambio_secundario,
                            #'lancamento_iva_id':documento.id,
                        }
            #valor_total=valor_total+lancamento.valor
            if documento.tipo_movimento=='credito':
                lancamento_novo['credito']=0
                lancamento_novo['debito']=valor_total
            else:
                lancamento_novo['credito']=valor_total
                lancamento_novo['debito']=0
                
            self.pool.get('dotcom.contabilidade.lancamentos.diarios').create(cr,uid,lancamento_novo)
            self.pool.get('dotcom.contabilidade.movimentos').processar_emitir(cr,uid,[movimento_id])
            self.write(cr,uid,documento.id,{'movimento_contabilidade_id':movimento_id})
        return True
        
    
    def emitir(self, cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            
            if len(documento.lancamento_movimentos_ids)<=0:
                raise osv.except_osv(_('Error !'), _('Movimento sem lançamentos por Emitir..!'))
            
            data=documento.data
            #logger.info('DATA ACTUAL DO CABEC %s' %str(data))
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                        ('date_start','<=',data),
                                                                        ('date_stop','>=',data),
                                                                        ('special','=',False),
                                                                        ('closing','=',False),
                                                                        ])
            period_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
            total_valor=0

            self.generate_sequence(cr,uid,documento.id)
            self.write(cr,uid,documento.id,{'state':'emitido','periodo_id':periodos_ids[0],'ano_fiscal_id':period_object.fiscalyear_id.id})
            
            if len(documento.lancamento_movimentos_ids)>0:
                for lancamento in documento.lancamento_movimentos_ids:
                    total_valor=total_valor+lancamento.valor
                    logger.info('ATRIBUICAO DE PROJECTOS EM EXECUCAO')
                    
                    # val_lancamento_analise={
                    #     'valor':lancamento.valor,
                    #     'rubrica_id':lancamento.rubrica_id.id
                    # }
                    # lancamento_analise_id=self.pool.get('dotcom.gestao.projectos.lancamento.analise.grafica').create(cr,uid,val_lancamento_analise)
                    # 
                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,
                                                                                   {'state':'emitido',
                                                                                    'projecto_id':documento.projecto_id.id,
                                                                                    'data':documento.data,
                                                                                    'periodo_id':periodos_ids[0],
                                                                                    'cambio_moeda':documento.cambio,
                                                                                    'movimento_conversao_moeda_id':documento.id,
                                                                                    # 'lancamento_analise_id':lancamento_analise_id,
                                                                                    #'tipo_movimento':documento.tipo_movimento
                                                                                    })
                    if lancamento.conta_id.state=='rascunho':
                        self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,lancamento.conta_id.id,{'state':'emitida'})
                    
                    if lancamento.rubrica_id.state=='rascunho':
                        self.pool.get('dotcom.gestao.projectos.rubrica').write(cr,uid,lancamento.rubrica_id.id,{'state':'emitida'})
                    #     
            if total_valor<=0:
                raise osv.except_osv(_('Acção Inválida !'), _('Não podem ser emitidos documentos com valor total igual a zero(0)..!' ))
            
            #if bool(documento.movimento_contabilidade_id.id)==False:
            #    self.criar_movimento_contabilidade(cr,uid,[documento.id])
        
        return True    
        
    
    def generate_sequence(self, cr, uid, document_id,context=None):
        documento_pool = self.pool.get('dotcom.gestao.projectos.movimento')
        documento = documento_pool.browse(cr,uid,document_id)
        doc_number = ''
        if documento.numero_movimentos is False or documento.numero_movimentos=='':
            sequence_id = documento.sequencia_id.id
            if sequence_id:
                sequence_obj = self.pool.get('dotcom.sequence')
                sequence = sequence_obj.browse(cr,uid,sequence_id)

                now = datetime.now()
                year = int(now.year)
                
                day = documento.data
                data_doc=datetime(*(time.strptime(day, '%Y-%m-%d %H:%M:%S')[0:6])).strftime('%Y-%m-%d')
                doc_date = datetime(*(time.strptime(data_doc, '%Y-%m-%d')[0:6]))
                date_year = doc_date.strftime('%Y')
                
                logger.info('Document Date and Year: %s and %s, Fiscal Year: %s' % (str(day),str(date_year),str(sequence.fiscal_year_id.code)))
                
                if (int(sequence.fiscal_year_id.code)!=int(date_year)):
                    raise osv.except_osv(_('Acção Inválida !'), _('A data selecionada não corresponde ao ano fiscal'))
                else:
                    doc_number = sequence_obj.next_by_id(cr, uid, sequence_id) or sequence_obj.next_by_code(cr, uid, sequence.code)
        else:
            doc_number = documento.numero_movimentos
        
        documento_pool.write(cr,uid,documento.id,{'numero_movimentos':doc_number})
        return doc_number
    
    
    def cancelar(self, cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            for lancamento in documento.lancamento_movimentos_ids:
                #if bool(lancamento.fecho_caixa_movimento_id.id)==True and lancamento.state_processamento=='processado':
                #    raise osv.except_osv(_('Acção Inválida !'), _('Não é possível cancelar movimentos em períodos fechados..!' ))
                
                self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'state':'cancelado'})
            self.write(cr,uid,documento.id,{'state':'cancelado'})
        return True
       
            
    def voltar_rascunho(self, cr,uid,ids,context=None):
        if context is None:
            context={}

        for documento in self.browse(cr,uid,ids):
            #self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            # for      in documento.lancamento_movimentos_ids:
                #if bool(lancamento.fecho_caixa_movimento_id.id)==True and lancamento.state_processamento=='processado':
                #    raise osv.except_osv(_('Acção Inválida !'), _('Não é possível cancelar movimentos em períodos fechados..!' ))
                # if bool(lancamento.lancamento_analise_id.id)!=False:
                #     self.pool.get('dotcom.gestao.projectos.lancamento.analise.grafica').unlink(cr,uid,lancamento.lancamento_analise_id.id)
                # self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'state':'rascunho'})
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
        return True

dotcom_gestao_projectos_movimento()



class dotcom_gestao_projectos_movimentos_internos(osv.osv):
    _name='dotcom.gestao.projetcos.movimentos.internos'
    _columns={
        'data':fields.datetime('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,required=True,),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
        'tipo_documento_id':fields.many2one('dotcom.gestao.projectos.documento','Tipo Documento',readonly=True, required=True, domain="[('tipo_documento','=','transferencia')]", states={'rascunho':[('readonly',False)]}),
        'sequencia_id':fields.many2one('dotcom.sequence','Sequencia', required=True,readonly=True, domain="[('documento_id','=',tipo_documento_id)]", states={'rascunho':[('readonly',False)]}),
        'numero_movimentos':fields.char('Numero', size=50, readonly=True),
        
        'conta_origem_id':fields.many2one('dotcom.gestao.projectos.conta','Conta Origem',readonly=True ,required=True,states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'conta_destino_id':fields.many2one('dotcom.gestao.projectos.conta','Conta Destino',readonly=True ,required=True, domain="[('id','!=',conta_origem_id)]",states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'moeda_origem_id':fields.many2one('res.currency','Moeda C. Origem',required=True,readonly=True, ),
        'moeda_destino_id':fields.many2one('res.currency','Moeda C. Destino',required=True,readonly=True, ),
        
        'valor_origem':fields.float('Valor Origem',required=True),
        'valor_destino':fields.float('Valor Destino',required=True),
        
        'cambio_origem':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'cambio_destino':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'lancamento_movimentos_ids':fields.one2many('dotcom.gestao.projectos.lancamentos', 'movimento_interno_id','Lancamentos',readonly=True,),
        'state':fields.selection([
                    ('rascunho','Rascunho'),
                    ('emitido','Emitido'),
                    ('cancelado','Cancelado'),
                    ('outro_rascunho','Rascunho'),
                    ],'Estado'),
    }
    
    _defaults={
        'state':'rascunho',
        'data':lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
        #'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
        #'tipo_documento_id':validator.getDocumento,
    }
    
    _rec_name='data'
    
    
    
    def actualizar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            
            for linha in documento.lancamento_movimentos_ids:
                self.pool.get('dotcom.gestao.projectos.lancamentos').unlink(cr,uid,linha.id)
            
            
            tipo_movimento_origem=self.pool.get('dotcom.gestao.projectos.tipo.movimento').search(cr,uid,[('ref','=','MT-09')])
            lancamento={
                'data':documento.data,
                'periodo_id':documento.periodo_id.id,
                'valor':documento.valor_origem,
                'descricao':'Saída por Tranferência',
                'cambio_moeda':documento.cambio_origem,
                'movimento_interno_id':documento.id,
                'conta_id':documento.conta_origem_id.id,
                'moeda_lancamento_id':documento.moeda_origem_id.id,
                'cambio':documento.cambio_origem,
                'tipo_movimento':'despesas',
                'tipo_movimento_id':tipo_movimento_origem[0]
            }
                       
            tipo_movimento_destino=self.pool.get('dotcom.gestao.projectos.tipo.movimento').search(cr,uid,[('ref','=','MT-06')])
            lancamento2=lancamento.copy()
            lancamento2['valor']=documento.valor_destino
            lancamento2['cambio_moeda']=documento.cambio_destino
            lancamento2['descricao']='Entrada por Tranferência',
            lancamento2['cambio']=documento.cambio_destino
            lancamento2['conta_id']=documento.conta_destino_id.id,
            lancamento2['moeda_lancamento_id']=documento.moeda_destino_id.id,
            lancamento2['tipo_movimento']='receita'
            lancamento2['tipo_movimento_id']=tipo_movimento_destino[0]
            
            self.pool.get('dotcom.gestao.projectos.lancamentos').create(cr,uid,lancamento)
            self.pool.get('dotcom.gestao.projectos.lancamentos').create(cr,uid,lancamento2)
        
        return True
  
    
    def on_change_valor_origem(self,cr,uid,ids,valor_origem,cambio_origem,conta_destino_id,cambio_destino,context=None):
        if context is None:
            context={}
        
        val={}
        if bool(conta_destino_id):
            #conta_destino_object=self.pool.get('dotcom.gestao.projectos.conta').
            valor_origem_moeda_principal=valor_origem*cambio_origem
            valor_destino_cambiado=valor_origem_moeda_principal/cambio_destino
            val={'valor_destino':valor_destino_cambiado}
            
        return {'value':val}
    
    
    def on_change_conta_origem(self,cr,uid,ids,conta_id,valor_origem,cambio_destino,context=None):
        if context is None:
            context={}
        
        val={}
        if conta_id:
            conta_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_id)
                            
            val={'moeda_origem_id':conta_object.moeda_lancamento_id.id,'cambio_origem':conta_object.moeda_lancamento_id.rate}
            
        return {'value':val}
 
   
    def on_change_conta_destino(self,cr,uid,ids,conta_id,context=None):
        if context is None:
            context={}
        
        val={}
        if conta_id:
            conta_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_id)
            val={'moeda_destino_id':conta_object.moeda_lancamento_id.id,'cambio_destino':conta_object.moeda_lancamento_id.rate}
            
        return {'value':val}
    
    
    def on_change_cambio_origem(self,cr,uid,ids,cambio_origem,cambio_destino,valor_origem,context=None):
        if context is None:
            context={}
            
        valor_origem_moeda_principal=valor_origem*cambio_origem
        valor_destino_cambiado=0
        if cambio_destino>0:
            valor_destino_cambiado=valor_origem_moeda_principal/cambio_destino
        
        return {'value':{'valor_destino':valor_destino_cambiado}}
    
    
    def on_change_cambio_destino(self,cr,uid,ids,cambio_origem,cambio_destino,valor_origem,context=None):
        if context is None:
            context={}
            
        valor_origem_moeda_principal=valor_origem*cambio_origem
        valor_destino_cambiado=valor_origem_moeda_principal/cambio_destino
        
        return {'value':{'valor_destino':valor_destino_cambiado}}
    
    
    def create(self, cr,uid,value,context=None):
        if context is None:
            context={}
            
        data=value['data']
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                        ('date_start','<=',data),
                                                                        ('date_stop','>=',data)])
        
        conta_origem_id=value['conta_origem_id']
        conta_origem_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_origem_id)
        value['moeda_origem_id']=conta_origem_object.moeda_lancamento_id.id
        
        conta_destino_id=value['conta_destino_id']
        conta_destino_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta_destino_id)
        value['moeda_destino_id']=conta_destino_object.moeda_lancamento_id.id
        
        if len(periodos_ids)>0:
            periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodos_ids[0])
            value['ano_fiscal_id']=periodo_object.fiscalyear_id.id
            value['periodo_id']=periodo_object.id
        
        ident=super(dotcom_gestao_projectos_movimentos_internos, self).create(cr, uid, value, context=context)
        return ident
    
    
    def emitir(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            for lancamento in documento.lancamento_movimentos_ids:
                if lancamento.conta_id.id==documento.conta_origem_id.id:
                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'descricao':'Saída por tranferência'})
                elif lancamento.conta_id.id==documento.conta_destino_id.id:
                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'descricao':'Entrada por tranferência'})
            
            self.write(cr,uid,documento.id,{'state':'emitido'})
        return True
    
    
    def voltar_rascunho(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
        return True
        
    
    def cancelar(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'cancelado'})
        return True
    
dotcom_gestao_projectos_movimentos_internos()



class dotcom_gestao_projectos_tipo_movimentos(osv.osv):
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.descricao or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.tipo.movimento'
    _columns={
        'ref':fields.char('Ref',size=50, required=True),
        'descricao':fields.char('Descricao', size=100, required=True),
        'conta_caixa':fields.boolean('Caixa'),
        'conta_banco':fields.boolean('Banco'),
        'cheque':fields.boolean('Cheque'),
        
        #'tipo_movimento':fields.selection([
        #                                    ('credito','Credito'),
        #                                    ('debito','Debito')
        #                                    ],'Tipo Movimento'),
        
        'tipo_movimento':fields.selection([
                                        ('despesas','Pagamentos'),
                                        ('receita','Recebimentos')
                                        ],'Tipo Movimento'),
        
        'friendly_name': fields.function(_friendly_name, type='char', string='Tipo de Movimento', method=True, store=True),
    }
    
    _rec_name='friendly_name'
    
    _sql_constraints = [
        ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        validator.validar_referencias(cr,uid,referencia)
        return{}
    
dotcom_gestao_projectos_tipo_movimentos()   
    
    
    