# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_progectos_documento(osv.osv):
    _name='dotcom.gestao.projectos.documento'
    _columns={
        
        'ref':fields.char('Ref', size=100, required=True),
        'nome':fields.char('Nome', size=100, required=True),
        #'tipo_movimento':fields.selection([
        #                                    ('movimento','Movimento'),
        #                                    ('deposito','Depósito'),
        #                                    ('transferencia','Tranferência')
        #                                    ],'Tipo', required=True,),
        #'documento_contabilidade_id':fields.many2one('dotcom.contabilidade.documento','Doc. Contab.', help="Documento de Contabilidade"),
        #
        #'diario_contabilidade_id':fields.many2one('dotcom.contabilidade.diario','Diário Contab.', help="Diário de Contabilidade"),
        'sequenciador_ids':fields.one2many('dotcom.sequence','documento_id','Sequenciador',readonly=False),
        'tipo_documento':fields.selection([
                                        ('receita','Receita'),
                                        ('dispesas','Despesas'),
                                        ('transferencia','Tranferência'),
                                        ], 'Tipo', readonly=False, required=True),
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
    _rec_name='nome'
    
    
dotcom_gestao_progectos_documento()