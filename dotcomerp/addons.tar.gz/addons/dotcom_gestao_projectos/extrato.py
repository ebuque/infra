# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
from validators import validator
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_enxtrato_contas(osv.osv):
    
    def _moeda_lancamento(self,cr,uid,context=None):
        if context is None:
            context={}
        
        result=()
        this=[]   
        moedas_lancamento=self.pool.get('res.currency').search(cr,uid,[])
        for moeda in moedas_lancamento:
            moeda=self.pool.get('res.currency').browse(cr,uid,moeda)
            result=(str(moeda.id),moeda.name)
            this.append(result)
        
        result=('all','Todas Moedas')
        this.append(result)
        
        return this
    
    _name='dotcom.gestao.projectos.extrato.contas'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False),
        'moeda_lancamento_id':fields.selection(_moeda_lancamento,'Moeda Lanc.',required=False),
        'data_inicio':fields.datetime('Data Início', required=False),
        'data_fim':fields.datetime('Data Fim',required=False),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta', ),
        #'cheques_predatados':fields.boolean('Cheques Pré-datados'),
        'saldo_anterior':fields.boolean('Saldo Anterior'),
        'linhas_extrato_ids':fields.one2many('dotcom.gestao.projectos.extrato.contas.linha','extrato_id', readonly=False),
        
    }
    
    _defaults={
        'saldo_anterior':True,
        'data_inicio':validator.data_primeiro_movimento,
        'data_fim':validator.data_ultimo_movimento,
        #'cheques_predatados':True,
        #'ano_fiscal_id':validator.ano_fiscal_ultimo_movimento,
    }
 
    def pesquisar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        linhas_lancamentos_ids=self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').search(cr,uid,[])
        for linha in linhas_lancamentos_ids:
            self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').unlink(cr,uid,linha)
            
        for documento in self.browse(cr,uid,ids):
            if documento.conta_id.id:
                lancamentos_movimentos_ids=[]
                
                lancamentos_movimentos_anteriores_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('conta_id','=',documento.conta_id.id),
                                                                                                                ('state','=','emitido'),
                                                                                                                ('data','<',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_anteriores_ids))
                
                total_debito_anterior=0
                total_credito_anterior=0
                total_saldo_anterior=0
                
                for lancamento in lancamentos_movimentos_anteriores_ids:
                    lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    total_debito_anterior=total_debito_anterior+lancamento.debito
                    total_credito_anterior=total_credito_anterior+lancamento.credito
                    #logger.info('NUMERO DE LANCAMENTOS ANTERIORES ACHADOS %s' %str(lancamentos_movimentos_anteriores_ids))    
                
                lancamentos_movimentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('conta_id','=',documento.conta_id.id),
                                                                                                                ('state','=','emitido'),
                                                                                                                #('data','>=',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_ids))
                saldo_anterior=total_debito_anterior-total_credito_anterior
                
                credito_total=0
                debito_total=0
                for lancamento in lancamentos_movimentos_ids:
                    linha_lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    credito=0
                    debito=0
                    if linha_lancamento.tipo_movimento=='receita':
                        debito=linha_lancamento.valor_moeda_conta
                    elif linha_lancamento.tipo_movimento=='despesas':
                        credito=linha_lancamento.valor_moeda_conta
                        
                    credito_total=credito_total+credito
                    debito_total=debito_total+debito
                    natureza=''
                    saldo=0
                    if credito_total>debito_total:
                        natureza='C'
                        saldo=credito_total-debito_total
                    elif debito_total>credito_total:
                        saldo=debito_total-credito_total
                        natureza='D'
                    

                    val={
                            'data':linha_lancamento.data,
                            'periodo_id':linha_lancamento.periodo_id.id,
                            'conta_id':linha_lancamento.conta_id.id,
                            'credito':credito,
                            'debito':debito,
                            'saldo':saldo,
                            'lancamento_id':linha_lancamento.id,
                            'descricao':linha_lancamento.descricao,
                            'rubrica_id':linha_lancamento.rubrica_id.id,
                            'natureza':natureza,
                            'credito_anterior':total_credito_anterior,
                            'debito_anterior':total_debito_anterior,
                            'saldo_anterior':total_saldo_anterior,
                            'movimento_id':linha_lancamento.movimento_id.id,
                            'movimento_interno_id':linha_lancamento.movimento_interno_id.id,
                            'programa_id':linha_lancamento.programa_id.id,
                            'projecto_id':linha_lancamento.projecto_id.id,
                            'extrato_id':documento.id,
                            #'saldo_anterior':saldo_anterior,
                        }
                        
                    
                    logger.info('ENTROU NO PROCESSO 3 %s' %str(val) )
                    self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').create(cr,uid,val)

        logger.info('ENTROU NO PROCESSO 3' )
        return True
            
           
dotcom_gestao_projectos_enxtrato_contas()



class dotcom_gestao_projectos_extrato_contas_linha(osv.osv):
    _name='dotcom.gestao.projectos.extrato.contas.linha'
    _columns={
        'data':fields.date('data',readonly=True),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=True),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta', readonly=True),
        'credito':fields.float('Crédito',readonly=True),
        'debito':fields.float('Débito',readonly=True),
        'saldo':fields.float('Saldo',readonly=True),
        'lancamento_id':fields.many2one('dotcom.gestao.projectos.lancamentos','Lancamento'),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', required=False, readonly=True),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=False, readonly=True),
        'debito_anterior':fields.float('Debito Anterior'),
        'credito_anterior':fields.float('Credito Anterior'),
        'saldo_anterior':fields.float('Saldo Anterior'),
        'descricao':fields.char('Descricao',size=100,readonly=True),
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rúbrica', readonly=True),
        'natureza':fields.char('Natureza', size=10,required=True),
        'extrato_id':fields.many2one('dotcom.gestao.projectos.extrato.contas','Extrato',readonly=True),
        'extrato_projecto_id':fields.many2one('dotcom.gestao.projectos.extrato.projecto','Extrato Projecto',readonly=True),
        'extrato_financiador_id':fields.many2one('dotcom.gestao.projectos.extrato.financiador','Extrato Finaciador',readonly=True),
        'movimento_id':fields.many2one('dotcom.gestao.projectos.movimento','Movimento',readonly=True),
        'movimento_interno_id':fields.many2one('dotcom.gestao.projetcos.movimentos.internos','Movimento',readonly=True),
    }
    
    _order='create_date desc'
    
    
    def abrir_movimento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        action={}
        for documento in self.browse(cr,uid,ids):
            
            if bool(documento.lancamento_id.movimento_id.id)!=False:
                action={
                        'type': 'ir.actions.act_window',
                        'name': 'Movimento',
                        'view_mode': 'form',
                        'view_type': 'form',
                        'res_model': 'dotcom.gestao.projectos.movimento',
                        'res_id':documento.lancamento_id.movimento_id.id,
                        'target': 'new',
                        'context': context,
                        'nodestroy': True,
                    }
            
            elif bool(documento.lancamento_id.movimento_interno_id.id)!=False:
                action={
                        'type': 'ir.actions.act_window',
                        'name': 'Movimento Interno',
                        'view_mode': 'form',
                        'view_type': 'form',
                        'res_model': 'dotcom.gestao.projetcos.movimentos.internos',
                        'res_id':documento.lancamento_id.movimento_interno_id.id,
                        'target': 'new',
                        'context': context,
                        'nodestroy': True,
                    }
        
        return action
    
    
    def mostrar_talao_deposito(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        action={}
        for documento in self.browse(cr,uid,ids):
            talao_deposito_ids=self.pool.get('dotcom.tesouraria.talao.deposito').search(cr,uid,[
                                                                                                ('movimento_id','=',documento.talao_deposito_id.id),
                                                                                                ('state','=','emitido')
                                                                                                ])
            if len(talao_deposito_ids)>0:
                logger.info('TALAO DE DEPOSITO ACHADO %s' %str(talao_deposito_ids))
                action= {
                            'type': 'ir.actions.act_window',
                            'name':'Talão de Depósito' ,
                            'view_mode': 'form',
                            'view_type': 'form',
                            'res_model': 'dotcom.tesouraria.talao.deposito',
                            'res_id':talao_deposito_ids[0],
                            'target': 'new',
                            'context': context,
                            'nodestroy': True,
                        }
                    
        return action
#

dotcom_gestao_projectos_extrato_contas_linha()




class dotcom_gestao_projectos_enxtrato_projecto(osv.osv):
    
    def _moeda_lancamento(self,cr,uid,context=None):
        if context is None:
            context={}
        
        result=()
        this=[]   
        moedas_lancamento=self.pool.get('res.currency').search(cr,uid,[])
        for moeda in moedas_lancamento:
            moeda=self.pool.get('res.currency').browse(cr,uid,moeda)
            result=(str(moeda.id),moeda.name)
            this.append(result)
        
        result=('all','Todas Moedas')
        this.append(result)
        
        return this
    
    _name='dotcom.gestao.projectos.extrato.projecto'
    _columns={
        #'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False),
        'moeda_lancamento_id':fields.selection(_moeda_lancamento,'Moeda Lanc.',required=False),
        'data_inicio':fields.datetime('Data Início', required=False),
        'data_fim':fields.datetime('Data Fim',required=False),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',),
        #'cheques_predatados':fields.boolean('Cheques Pré-datados'),
        'saldo_anterior':fields.boolean('Saldo Anterior'),
        'linhas_extrato_ids':fields.one2many('dotcom.gestao.projectos.extrato.contas.linha','extrato_projecto_id', readonly=False),
        
    }
    
    _defaults={
        'saldo_anterior':True,
        'data_inicio':validator.data_primeiro_movimento,
        'data_fim':validator.data_ultimo_movimento,
        #'cheques_predatados':True,
        #'ano_fiscal_id':validator.ano_fiscal_ultimo_movimento,
    }
 
    def pesquisar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        linhas_lancamentos_ids=self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').search(cr,uid,[])
        for linha in linhas_lancamentos_ids:
            self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').unlink(cr,uid,linha)
            
        for documento in self.browse(cr,uid,ids):
            if documento.projecto_id.id:
                lancamentos_movimentos_ids=[]
                
                lancamentos_movimentos_anteriores_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('projecto_id','=',documento.projecto_id.id),
                                                                                                                ('state','=','emitido'),
                                                                                                                ('data','<',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_anteriores_ids))
                
                total_debito_anterior=0
                total_credito_anterior=0
                #len()
                
                for lancamento in lancamentos_movimentos_anteriores_ids:
                    lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    total_debito_anterior=total_debito_anterior+lancamento.debito
                    total_credito_anterior=total_credito_anterior+lancamento.credito
                    #logger.info('NUMERO DE LANCAMENTOS ANTERIORES ACHADOS %s' %str(lancamentos_movimentos_anteriores_ids))    
                
                lancamentos_movimentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('projecto_id','=',documento.projecto_id.id),
                                                                                                                ('state','=','emitido'),
                                                                                                                #('data','>=',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_ids))
                
                credito_total=0
                debito_total=0
                for lancamento in lancamentos_movimentos_ids:
                    linha_lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    
                    credito=0
                    debito=0
                    if linha_lancamento.tipo_movimento=='receita':
                        debito=linha_lancamento.valor
                    elif linha_lancamento.tipo_movimento=='despesas':
                        credito=linha_lancamento.valor
                        
                    credito_total=credito_total+credito
                    debito_total=debito_total+debito
                    natureza=''
                    saldo=0
                    if credito_total>debito_total:
                        natureza='C'
                        saldo=credito_total-debito_total
                    elif debito_total>credito_total:
                        saldo=debito_total-credito_total
                        natureza='D'
 
                    val={
                            'data':linha_lancamento.data,
                            'periodo_id':linha_lancamento.periodo_id.id,
                            'conta_id':linha_lancamento.conta_id.id,
                            'credito':credito,
                            'debito':debito,
                            'saldo':saldo,
                            'descricao':linha_lancamento.descricao,
                            'rubrica_id':linha_lancamento.rubrica_id.id,
                            'natureza':natureza,
                            'valor_anterior':0,
                            'saldo_anterior':0,
                            'movimento_id':linha_lancamento.movimento_id.id,
                            'projecto_id':linha_lancamento.projecto_id.id,
                            'programa_id':linha_lancamento.programa_id.id,
                            'extrato_projecto_id':documento.id,
                            #'saldo_anterior':saldo_anterior,
                        }                        
                        #    val['talao_deposito_id']=linha_lancamento.talao_deposito_id.id
                    logger.info('ENTROU NO PROCESSO 3' )
                    self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').create(cr,uid,val)

        logger.info('ENTROU NO PROCESSO 3' )
        return True
            
        
        
    
dotcom_gestao_projectos_enxtrato_projecto()




class dotcom_gestao_projectos_enxtrato_financiador(osv.osv):
    
    def _moeda_lancamento(self,cr,uid,context=None):
        if context is None:
            context={}
        
        result=()
        this=[]   
        moedas_lancamento=self.pool.get('res.currency').search(cr,uid,[])
        for moeda in moedas_lancamento:
            moeda=self.pool.get('res.currency').browse(cr,uid,moeda)
            result=(str(moeda.id),moeda.name)
            this.append(result)
        
        result=('all','Todas Moedas')
        this.append(result)
        
        return this
    
    _name='dotcom.gestao.projectos.extrato.financiador'
    _columns={
        #'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False),
        'moeda_lancamento_id':fields.selection(_moeda_lancamento,'Moeda Lanc.',required=False),
        'data_inicio':fields.datetime('Data Início', required=False),
        'data_fim':fields.datetime('Data Fim',required=False),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Fianciador', required=False),
        #'cheques_predatados':fields.boolean('Cheques Pré-datados'),
        'saldo_anterior':fields.boolean('Saldo Anterior'),
        'linhas_extrato_ids':fields.one2many('dotcom.gestao.projectos.extrato.contas.linha','extrato_financiador_id', readonly=False),
        
    }
    
    _defaults={
        'saldo_anterior':True,
        'data_inicio':validator.data_primeiro_movimento,
        'data_fim':validator.data_ultimo_movimento,
        #'cheques_predatados':True,
        #'ano_fiscal_id':validator.ano_fiscal_ultimo_movimento,
    }
 
    def pesquisar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        linhas_lancamentos_ids=self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').search(cr,uid,[])
        for linha in linhas_lancamentos_ids:
            self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').unlink(cr,uid,linha)
            
        for documento in self.browse(cr,uid,ids):
            if documento.doador_id.id:
                lancamentos_movimentos_ids=[]
                
                financiadores_ids=self.pool.get('dotcom.gestao.projectos.doador.projecto').search(cr,uid,[
                                                                                                            ('doador_id','=',documento.doador_id.id)
                                                                                                            ])
                
                
                lancamentos_movimentos_anteriores_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('doador_id','in',financiadores_ids),
                                                                                                                ('state','=','emitido'),
                                                                                                                ('data','<',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_anteriores_ids))
                
                total_debito_anterior=0
                total_credito_anterior=0
                #len()
                
                for lancamento in lancamentos_movimentos_anteriores_ids:
                    lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    total_debito_anterior=total_debito_anterior+lancamento.debito
                    total_credito_anterior=total_credito_anterior+lancamento.credito
                    #logger.info('NUMERO DE LANCAMENTOS ANTERIORES ACHADOS %s' %str(lancamentos_movimentos_anteriores_ids))    
                
                lancamentos_movimentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('doador_id','in',financiadores_ids),
                                                                                                                ('state','=','emitido'),
                                                                                                                #('data','>=',documento.data_inicio),
                                                                                                                #('data','<=',documento.data_fim)
                                                                                                                ])
                
                logger.info('LANCAMENTOS ACHADOS ATE O MOMENTO %s' %str(lancamentos_movimentos_ids))
                
                credito_total=0
                debito_total=0
                for lancamento in lancamentos_movimentos_ids:
                    linha_lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    
                    credito=0
                    debito=0
                    if linha_lancamento.tipo_movimento=='receita':
                        debito=linha_lancamento.valor
                    elif linha_lancamento.tipo_movimento=='despesas':
                        credito=linha_lancamento.valor
                        
                    credito_total=credito_total+credito
                    debito_total=debito_total+debito
                    natureza=''
                    saldo=0
                    if credito_total>debito_total:
                        natureza='C'
                        saldo=credito_total-debito_total
                    elif debito_total>credito_total:
                        saldo=debito_total-credito_total
                        natureza='D'
 
                    val={
                            'data':linha_lancamento.data,
                            'periodo_id':linha_lancamento.periodo_id.id,
                            'conta_id':linha_lancamento.conta_id.id,
                            'credito':credito,
                            'debito':debito,
                            'saldo':saldo,
                            'descricao':linha_lancamento.descricao,
                            'rubrica_id':linha_lancamento.rubrica_id.id,
                            'natureza':natureza,
                            'valor_anterior':0,
                            'saldo_anterior':0,
                            'movimento_id':linha_lancamento.movimento_id.id,
                            'projecto_id':linha_lancamento.projecto_id.id,
                            'programa_id':linha_lancamento.programa_id.id,
                            'extrato_financiador_id':documento.id,
                            #'saldo_anterior':saldo_anterior,
                        }                        
                        #    val['talao_deposito_id']=linha_lancamento.talao_deposito_id.id
                    logger.info('ENTROU NO PROCESSO 3' )
                    self.pool.get('dotcom.gestao.projectos.extrato.contas.linha').create(cr,uid,val)

        logger.info('ENTROU NO PROCESSO 3' )
        return True
            
        
        
    
dotcom_gestao_projectos_enxtrato_financiador()


class dotcom_gestao_progectos_analise_receitas_despesas(osv.osv):
    _name='dotcom.gestao.projectos.analise.receitas.despesas'
    _columns={
        'data_inicio':fields.date('Data Inicio',required=True),
        'data_fim':fields.date('Data Fim',required=True),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Financiador'),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=False, ),
        'linhas_ids':fields.one2many('dotcom.gestao.projectos.analise.receitas.despesas.linha','analise_id',),
    }
    
    
    def pesquisar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context ={}
            
        for documento in self.browse(cr,uid,ids):
            
            for linha in documento.linhas_ids:
                self.pool.get('dotcom.gestao.projectos.analise.receitas.despesas.linha').unlink(cr,uid,linha.id)
            
            
            rubricas_ids=self.pool.get('dotcom.gestao.projectos.rubrica').search(cr,uid,[
                                                                                        ('tipo_interno','=','m')
                                                                                        ])
            total_credito=0
            total_debito=0
            for rubrica in rubricas_ids:
                lancamentos_ids=[]
                
                if bool(documento.doador_id.id)==False and bool(documento.projecto_id.id)==False:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                        ('rubrica_id','=',rubrica),
                                                                                                        ('data','>=',documento.data_inicio),
                                                                                                        ('data','<=',documento.data_fim),
                                                                                                        ])
                    logger.info('ENTROU NO PROCESSO 1')
                
                elif bool(documento.doador_id.id)==True and bool(documento.projecto_id.id)==False:
                    
                    doador_projecto_ids=self.pool.get('dotcom.gestao.projectos.doador.projecto').search(cr,uid,[
                                                                                                ('doador_id','=',documento.doador_id.id)])
                    
                    if len(doador_projecto_ids)>0:
                        lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                            ('rubrica_id','=',rubrica),
                                                                                                            ('data','>=',documento.data_inicio),
                                                                                                            ('data','<=',documento.data_fim),
                                                                                                            ('doador_id','=',doador_projecto_ids[0]),
                                                                                                            ])
                    logger.info('ENTROU NO PROCESSO 2')
                    
                elif bool(documento.doador_id.id)==False and bool(documento.projecto_id.id)==True:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                        ('rubrica_id','=',rubrica),
                                                                                                        ('data','>=',documento.data_inicio),
                                                                                                        ('data','<=',documento.data_fim),
                                                                                                        ('projecto_id','=',documento.projecto_id.id),
                                                                                                        ])
                    logger.info('ENTROU NO PROCESSO 3')
                    
                elif bool(documento.doador_id.id)==True and bool(documento.projecto_id.id)==True:
                    
                    doador_projecto_ids=self.pool.get('dotcom.gestao.projectos.doador.projecto').search(cr,uid,[
                                                                                                ('doador_id','=',documento.doador_id.id),
                                                                                                ('projecto_id','=',documento.projecto_id.id)])
                    
                    
                    
                    if len(doador_projecto_ids)>0:
                        doador_object=self.pool.get('dotcom.gestao.projectos.doador.projecto').browse(cr,uid,doador_projecto_ids[0])
                        logger.info('ENTROU NO PROCESSO LANCAMENTOS ACHADOS %s' %str(doador_object))
                        lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                            ('rubrica_id','=',rubrica),
                                                                                                            ('data','>=',documento.data_inicio),
                                                                                                            ('data','<=',documento.data_fim),
                                                                                                            ('projecto_id','=',documento.projecto_id.id),
                                                                                                            ('doador_id','=',doador_object.id),
                                                                                                            ])
                        logger.info('ENTROU NO PROCESSO 4')
                logger.info('ENTROU NO PROCESSO LANCAMENTOS ACHADOS %s' %str(lancamentos_ids))
                    
                credito=0
                debito=0
                for lancamento in lancamentos_ids:
                    lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    logger.info('ENTROU NO PROCESSO LANCAMENTOS ACHADOS %s' %str(lancamento.doador_id.id))
                    if(lancamento.tipo_movimento=='receita'):
                        debito=debito+lancamento.valor_moeda_base
                    elif(lancamento.tipo_movimento=='despesas'):
                        credito=debito+lancamento.valor_moeda_base
                
                total_credito=total_credito+credito
                total_debito=total_debito+debito
                val={
                    'analise_id':documento.id,
                    'rubrica_id':rubrica,
                    'credito':credito,
                    'debito':debito,
                    'saldo':total_debito-total_credito,
                }
                self.pool.get('dotcom.gestao.projectos.analise.receitas.despesas.linha').create(cr,uid,val)
                
        return True        
            
        
        
    
dotcom_gestao_progectos_analise_receitas_despesas()


class dotcom_getao_projectos_analise_receitas_despesas_linha(osv.osv):
    _name='dotcom.gestao.projectos.analise.receitas.despesas.linha'
    _columns={
        'analise_id':fields.many2one('dotcom.gestao.projectos.analise.receitas.despesas','Analise'),
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica','Rubrica',required=True,),
        'credito':fields.float('Crédito',required=True),
        'debito':fields.float('Débito',required=True),
        'saldo':fields.float('Saldo',required=True),
    }
    
dotcom_getao_projectos_analise_receitas_despesas_linha
