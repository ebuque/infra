# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_extrato_abertura_fecho_caixa(osv.osv):
    _name='dotcom.gestao.projectos.extrato.abertura.fecho.caixa'
    _columns={
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta' , readonly=False),
        'linhas_extrato_ids':fields.one2many('dotcom.gestao.projectos.abertura.fecho.caixa.linha','extrato_id','Linhas', readonly=True),
    }
    
dotcom_gestao_projectos_extrato_abertura_fecho_caixa()


class dotcom_gestao_projectos_historico_abertura_fecho_caixa(osv.osv):
    _name='dotcom.gestao.projectos.historico.abertura.fecho.caixa'
    _columns={
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta' , domain="[('tipo_conta','=','caixa')]", readonly=False),
        'linhas_extrato_ids':fields.one2many('dotcom.gestao.projectos.abertura.fecho.caixa.linha','historico_id','Linhas', readonly=False),
    }
    
    def pesquisar_linhas_lancamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
              
        
        for documento in self.browse(cr,uid,ids):
            
            for lancamento in documento.linhas_extrato_ids:
                self.pool.get('dotcom.gestao.projectos.abertura.fecho.caixa.linha').unlink(cr,uid,lancamento.id)
            
            lista_movimentos_caixa_ids=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                        ('conta_id','=',documento.conta_id.id),
                                                                                                        ('state','=','emitido'),])
            
            logger.info('NUMERO DE CONTA %s' %str(documento.conta_id.ref))
            

    
            contador=0
            for movimentos_caixa in lista_movimentos_caixa_ids:
                movimentos_caixa=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').browse(cr,uid,movimentos_caixa)
                logger.info('NUMERO DE FECHO DE CAIXA ACHADAS %s' %str(movimentos_caixa.tipo_movimento))                
                value={
                    'data':movimentos_caixa.data,
                    'valor':movimentos_caixa.valor_abetura,
                    'operacao':movimentos_caixa.tipo_movimento,
                    'historico_id':documento.id,
                    'abertura_id':movimentos_caixa.id
                }
                    
                object_id=self.pool.get('dotcom.gestao.projectos.abertura.fecho.caixa.linha').create(cr,uid,value)
                #objecto=self.pool.get('dotcom.gestao.projectos.abertura.fecho.caixa.linha').browse(cr,uid,object_id)
                #
                ##logger.info('VALOR ACHADO NA ABERTURA %s' %str(objecto.val))
                #if len(lista_fecho_ids)>contador:
                #    fecho=self.pool.get('dotcom.tesouraria.movimentos.fecho.caixa.linha').browse(cr,uid,lista_fecho_ids[0])
                #    val={
                #        'data':abertura.data,
                #        'valor':fecho.valor_fecho,
                #        #'valor_abertura':abertura.valor_abetura,
                #        'fecho_id':fecho.id,
                #        'operacao':'fecho',
                #        'historico_id':documento.id
                #    }
                #    
                #    self.pool.get('dotcom.gestao.projectos.abertura.fecho.caixa.linha').create(cr,uid,val)
                #    
                #    
                #    contador=contador+1
                #    logger.info('VALOR ACHADO NO FECHO %s' %str(objecto.valor))
        return True
   
   
    def emitir_cancelamento(self,cr,uid,ids,context=None):
   
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            contador=0
            ultimo_elemento_lista=None
            for linha in documento.linhas_extrato_ids:
                if linha.selecionar==True:
                    contador=contador+1
                ultimo_elemento_lista=linha
            if contador<=0:
                raise osv.except_osv(_('Acção Inválida !'), _('Nenhum movimento de Abertura/Feicho para cancelar..!' ))
            else:
                if contador>1:
                    raise osv.except_osv(_('Acção Inválida !'), _('Não podem ser cancelados dois(2) movimentos em simultaneo..!' ))
                else:
                    
                    lista_movimentos=documento.linhas_extrato_ids
                    #ultimo_elemento_lista=lista_movimentos[len(lista_movimentos)-1]
                    for linha in documento.linhas_extrato_ids:
                        if linha.selecionar==True and linha.id==ultimo_elemento_lista.id:
                            if linha.operacao=='abertura':
                                lancamentos_conta_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                        ('data','>',linha.data),
                                                                                                                        ('conta_id','=',documento.conta_id.id),
                                                                                                                        ('state','=','emitido'),
                                                                                                                         ])
                                if len(lancamentos_conta_ids)>0:
                                    raise osv.except_osv(_('Acção Inválida !'), _('Caixa com movimentos posteriores a esta abertura..!' ))
                                
                                self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,documento.conta_id.id,{'state_abertura':'fechada'})
                                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,linha.abertura_id.id,{'state':'rascunho','state_fecho':'rascunho'})
                            if linha.operacao=='fecho':
                                self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,documento.conta_id.id,{'state_abertura':'aberta'})
                                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,linha.abertura_id.id,{'state':'rascunho','state_fecho':'rascunho'})
                                for lancamento in linha.abertura_id.movimentos_ids:
                                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'state_processamento':'por_processar'})
                            
                            self.pool.get('dotcom.gestao.projectos.abertura.fecho.caixa.linha').unlink(cr,uid,linha.id)
                        elif linha.selecionar==True and linha.id!=ultimo_elemento_lista.id:
                            logger.info('IDENTIFICADOR DA ULTIMA LINHA %s' %str(ultimo_elemento_lista.id))
                            logger.info('IDENTIFICADOR DA LINHA SELECCIONADA %s' %str(linha.id))
                            raise osv.except_osv(_('Acção Inválida !'), _('Somente pode ser cancelado o último movimento da lista..!' ))
        return True
   
dotcom_gestao_projectos_historico_abertura_fecho_caixa()


class dotcom_gestao_projectos_abertura_fecho_caixa_linha(osv.osv):
    _name='dotcom.gestao.projectos.abertura.fecho.caixa.linha'
    _columns={
        'data':fields.datetime('Data', readonly=True),
        #'data_fecho':fields.date('Data Fecho'),
        #'valor_abertura':fields.float('Valor Abertura'),
        'abertura_id':fields.many2one('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha','Abertura'),
        #'fecho_id':fields.many2one('dotcom.tesouraria.movimentos.fecho.caixa.linha','Fecho'),
        'valor':fields.float('Valor',readonly=True),
        'operacao':fields.selection([('abertura','Abertura'),('fecho','Fecho')],'Operação',readonly=True),
        'extrato_id':fields.many2one('dotcom.gestao.projectos.extrato.abertura.fecho.caixa', 'Extrato'),
        'selecionar':fields.boolean('Selecionar'),
        'historico_id':fields.many2one('dotcom.gestao.projectos.historico.abertura.fecho.caixa', 'Historico'),
    }
    
    _order='create_date asc'
    
    
    
    def imprimir_linha(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        logger.info('PROCESSO DE IMPRESSAO EM EXECUCAO')

        return {
                'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
                'view_id': False,
                'res_model': 'dotcom.gestao.projectos.abertura.fecho.caixa.linha',
                'report_name': 'dotcom_tesouraria_extracto_fecho_caixa_report',
                'domain': [],
                'context': dict(context, active_ids=ids),
                'type': 'ir.actions.report.xml',
                'report_type': 'pdf',
                'res_id': ids or ids[0]
            }
    
    
dotcom_gestao_projectos_abertura_fecho_caixa_linha()