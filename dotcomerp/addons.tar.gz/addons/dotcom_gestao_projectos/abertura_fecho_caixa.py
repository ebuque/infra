# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

#Tabela para a abertura diaria das caixas
class dotcom_gestao_projectos_abertura_caixa(osv.osv):
    _name='dotcom.gestao.projectos.abertura.caixa'
    _columns={
        'data':fields.datetime('Data',required=True),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=True, ),
        #'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, domain="[('tipo_conta','=','caixa')]"),
        #'conta_destino_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, domain="[('tipo_conta','=','banco')]"),
        'abrir_caixa':fields.boolean('Abrir Cáixa'),
        'fechar_caixa':fields.boolean('Fechar Cáixa'),
        'state':fields.selection([
                                    ('rascunho','Rascunho'),
                                    ('emitido','Emitido'),
                                    #('fechada','Fechada')
                                ],'Estado'),
        
        'movimentos_abertura_ids':fields.one2many('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha','abertura_id', 'Moviementos Abertura', readonly=True)
    }
    
    _defaults={
        'state':'rascunho',
        'data':lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    
    def on_change_abertura_caixa(self,cr,uid,ids,abertura,context=None):
        if context is None:
            context={}
        
        val={}
        if abertura==True:
            val={'fechar_caixa':False}
        return {'value':val}
    
    
    def on_chnage_fecho_caixa(self,cr,uid,ids,fecho,context=None):
        if context is None:
            context={}
            
        val={}
        if fecho==True:
            val={'abrir_caixa':False}
        return {'value':val}
    
    
    def on_change_data(self,cr,uid,ids,data,context=None):
        if context is None:
            context={}
        
        #data = data.date()
        #logger.info('DATA ACHADA ATE AO MOMENTO %s' %str(data.date(data)))
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                            ('date_start','<=',data),
                                                                            ('date_stop','>=',data),
                                                                            ('special','=',False),
                                                                            ('closing','=',False),
                                                                        ])
        
        if len(periodos_ids)<=0:
            raise osv.except_osv(_('Acção Inválida !'), _('Ano fiscal e/ou Periodos não Criados'))
        logger.info('PERIODOS ACHADOS NA PESQUISA %s' %str(periodos_ids))        
        val={'periodo_id':periodos_ids[0],'movimentos_abertura_ids':None}
        return {'value':val}
    
    
    def abrir_caixa(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            contador=0
            
            for lancamento in documento.movimentos_abertura_ids:
                #self.pool.get('dotcom.tesouraria.movimentos.abertura.caixa').write(cr,uid,lancamento.id,{'data':documento.data})
                if lancamento.conta_id.state_abertura=='fechada' and lancamento.abrir==True:
                    validator.validar_data_ultima_abertura_fecho_caixa(self,cr,uid,lancamento.conta_id,lancamento.data,context)
                    contador=contador+1
                    self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,lancamento.conta_id.id,{'state_abertura':'aberta','state':'emitida'})
                    self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,lancamento.id,{'state':'emitido','abertura_id':None})
                #else:
                #    raise osv.except_osv(_('Acção Inválida !'), _('Conta ['+str(lancamento.conta_id.ref)+"]"+str(lancamento.conta_id.decricao)))
            
            if contador<=0:
                raise osv.except_osv(_('Acção Inválida !'), _('Nenhuma caixa seleccionada para ser aberta'))
            self.write(cr,uid,documento.id,{'state':'emitido'})            
            
        return {}
    
    
    def create(self,cr,uid,value,context=None):
        if context is None:
            context={}
        
        data=value['data']
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('date_start','<=',data),
                                                                                ('date_stop','>=',data),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),
                                                                            ])
        if len(periodos_ids)>0:
            value['periodo_id']=periodos_ids[0]
        return super(dotcom_tesouraria_abertura_caixa, self).create(cr, uid, value, context=context)
    
    
    def pesquisar_linhas(self, cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            
            for lancamento in documento.movimentos_abertura_ids:
                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').unlink(cr,uid,lancamento.id)
            
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                            ('date_start','<=',documento.data),
                                                                            ('date_stop','>=',documento.data),
                                                                            ('special','=',False),
                                                                            ('closing','=',False),
                                                                        ])
            if len(periodos_ids)>0:
                logger.info('ENTROU NO PROCESSO DOS PERIODOS')
                self.write(cr,uid,documento.id,{'periodo_id':periodos_ids[0]})
            
            contas_fechadas=self.pool.get('dotcom.gestao.projectos.conta').search(cr,uid,[
                                                                                ('tipo_conta','=','caixa'),
                                                                                ('state_abertura','=','fechada'),
                                                                                ])
            #logger.info('CONTAS FECHADAS %s' %str(contas_fechadas))
            for conta_id in contas_fechadas:
                movimentos_fecho_anteriores_ids=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                                ('conta_id','=',conta_id),
                                                                                                                ('tipo_movimento','=','fecho'),
                                                                                                                ('state','=','emitido')
                                                                                                                ])
                #logger.info('CONTAS FECHADAS %s' %str(len(movimentos_fecho_anteriores_ids)))
                if len(movimentos_fecho_anteriores_ids)>0:
                    ultimo_movimento=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').browse(cr,uid,movimentos_fecho_anteriores_ids[len(movimentos_fecho_anteriores_ids)-1])
                    #logger.info('VALOR EXISTENTE %s' %str(ultimo_movimento.valor_existente))
                    #logger.info('VALOR ULTIMO FECHO %s' %str(ultimo_movimento.valor_fecho))
                    #logger.info('VALOR REMANESCENTE %s' %str(ultimo_movimento.valor_remanescente))
                    value={
                            'valor_ultimo_fecho':ultimo_movimento.valor_ultimo_fecho,
                            'valor_abetura':ultimo_movimento.valor_abetura,
                            'data':documento.data,
                            'conta_id':conta_id,
                            'abertura_id':documento.id,
                            'tipo_movimento':'abertura',
                        }
                    logger.info('VALOR A SER CRIADO %s' %str(value))
                    identificador =self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').create(cr,uid,value)
                    
                else:
                    val={
                        'valor_ultimo_fecho':0,
                        'valor_abetura':0,
                        'data':documento.data,
                        'conta_id':conta_id,
                        'abertura_id':documento.id,
                        'tipo_movimento':'abertura',
                        }
                    identificador=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').create(cr,uid,val)
                    logger.info('ENTROU 2 %s' %str(identificador))
        return True
    
dotcom_gestao_projectos_abertura_caixa()


class dotcom_gestao_projectos_movimentos_abertura_caixa(osv.osv):
    _name='dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha'
    _columns={
        'data':fields.datetime('Data',required=True),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, readonly=True, domain="[('tipo_conta','=','caixa'),('state_abertura','=','fechada')]"),
        'valor_ultimo_fecho':fields.float('Último Fecho', readonly=True),
        'valor_abetura':fields.float('Valor Abertura', readonly=True),
        'abrir':fields.boolean('Abrir Caixa'),
        'abertura_id':fields.many2one('dotcom.gestao.projectos.abertura.caixa','Abertura'),
        'fecho_caixa_id':fields.many2one('dotcom.gestao.projectos.fecho.caixa','Fecho Caixa'),
        'tipo_movimento':fields.selection([('abertura','Abertura'),('fecho','Fecho')],'Tipo Movimento',required=True, ),
        'movimentos_ids':fields.one2many('dotcom.gestao.projectos.lancamentos','fecho_caixa_movimento_id','Movimentos'),
        'state':fields.selection([('rascunho','Fechado'),('emitido','Aberto')], 'Estado', readonly=True),
        'state_fecho':fields.selection([('rascunho','Aberta'),('emitido','Fechada')], 'Estado', readonly=True),
    }
    
    _rec_name='data'
    
    _defaults={
        'data':lambda self, cr, uid, c: c.get('data', False),
        'state':'rascunho',
    }
    
    
    def imprimir_linha(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        logger.info('IDENTIFICADDOR ACHADO PARA A LINHA %s' %str(ids[0]))
        return {
                'name': _('Recibo de Venda: %s') % str(ids and ids[0]),
                'view_id': False,
                'res_model': 'dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha',
                'report_name': 'dotcom_tesouraria_fecho_caixa_report',
                'domain': [],
                'context': dict(context, active_ids=ids),
                'type': 'ir.actions.report.xml',
                'report_type': 'pdf',
                'res_id': ids and ids[0] or False
            }
    
    
    def on_change_conta(self,cr,uid,ids,conta_id,context=None):
        if context is None:
            context={}
        
        val={}
        movimentos_fecho_anteriores_ids=self.pool.get('dotcom.tesouraria.movimentos.fecho.caixa.linha').search(cr,uid,[
                                                                                                                ('conta_id','=',conta_id),                                                                                                    
                                                                                                                ])
        if len(movimentos_fecho_anteriores_ids)>0:
            ultimo_movimento=self.pool.get('dotcom.tesouraria.movimentos.fecho.caixa.linha').browse(cr,uid,movimentos_fecho_anteriores_ids[len(movimentos_fecho_anteriores_ids)-1])
            val={
                'valor_ultimo_fecho':ultimo_movimento.valor_remanescente,
                'valor_abetura':ultimo_movimento.valor_remanescente}
        else:
            val={
                'valor_ultimo_fecho':0,
                'valor_abetura':0}
        
        return {'value':val}
        
    
    def fechar_caixa(self,cr,uid,ids,context):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            if documento.state_fecho=='rascunho':
                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,documento.id,
                                                                                               {'state':'emitido','state_fecho':'emitido',
                                                                                                'data':documento.fecho_caixa_id.data})
                self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,documento.conta_id.id,{'state_abertura':'fechada'})
                validator.validar_data_ultima_abertura_fecho_caixa(self,cr,uid,documento.conta_id,documento.data,context)
                validator.validar_fecho_caixa(self,cr,uid,documento.conta_id,documento.data,context)
                for lancamento in documento.movimentos_ids:
                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'state_processamento':'processado'})
            else:
                for lancamento in documento.movimentos_ids:
                    self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'fecho_caixa_id':None})
            #logger.info('DATA DO FECHO DE CAIXA %s' %str(linha_fechar.data))    
        return True
    
    
    def abrir_caixa(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_tesouraria',context)
            contador=0

            if documento.conta_id.state_abertura=='fechada':
                validator.validar_data_ultima_abertura_fecho_caixa(self,cr,uid,documento.conta_id,documento.data,context)
                contador=contador+1
                self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,documento.conta_id.id,{'state_abertura':'aberta','state':'emitida'})
                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,documento.id,
                                                                                        {'state':'emitido',
                                                                                         'abertura_id':None,
                                                                                         'data':documento.abertura_id.data})
                #if contador<=0:
                #    raise osv.except_osv(_('Acção Inválida !'), _('Nenhuma caixa seleccionada para ser aberta'))
                self.write(cr,uid,documento.id,{'state':'emitido'})            
            
        return {}
    
    
    def mostrar_historico(self, cr,uid,ids,context=None):
        if context is None:
            context={}
        
        label=''
        for documento in self.browse(cr,uid,ids):
            lista_aberturas_ids=self.search(cr,uid,[('conta_id','=',documento.conta_id.id),('state','=','emitido')])
            lista_movimentos_ids=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                    ('conta_id','=',documento.conta_id.id),
                                                                                                    ('state','=','emitido')
                                                                                                    ])
            logger.info('NUMERO DE CONTA %s' %str(documento.conta_id.ref))
            
            logger.info('NUMERO DE FECHO DE CAIXA ACHADAS %s' %str(lista_aberturas_ids))
            
            extrato_id=self.pool.get('dotcom.tesouraria.extrato.abertura.fecho.caixa').create(cr,uid,{'conta_id':documento.conta_id.id})
            contador=0
            for abertura in lista_movimentos_ids:
                abertura=self.browse(cr,uid,abertura)
                
                
                
                value={
                    'data':abertura.data,
                    'valor':abertura.valor_abetura,
                    'operacao':abertura.tipo_movimento,
                    'extrato_id':extrato_id
                }
                    
                object_id=self.pool.get('dotcom.tesouraria.abertura.fecho.caixa.linha').create(cr,uid,value)
                objecto=self.pool.get('dotcom.tesouraria.abertura.fecho.caixa.linha').browse(cr,uid,object_id)
                
                #logger.info('VALOR ACHADO NA ABERTURA %s' %str(objecto.val))
                #if len(lista_movimentos_ids)>contador:
                #    fecho=self.pool.get('dotcom.tesouraria.movimentos.fecho.caixa.linha').browse(cr,uid,lista_movimentos_ids[contador])
                #    val={
                #        'data':abertura.data,
                #        'valor':fecho.valor_fecho,
                #        #'valor_abertura':abertura.valor_abetura,
                #        'operacao':'fecho',
                #        'extrato_id':extrato_id
                #    }
                #    
                #    self.pool.get('dotcom.tesouraria.abertura.fecho.caixa.linha').create(cr,uid,val)
                #    
                #    
                #    contador=contador+1
                #    logger.info('VALOR ACHADO NO FECHO %s' %str(objecto.valor))
        
            label='Extrato Abertura/Fecho Caixas ['+str(documento.conta_id.ref)+']'+str(documento.conta_id.decricao)            
        return {
            'type': 'ir.actions.act_window',
            'name':label ,
            'view_mode': 'form',
            'view_type': 'form',
            'res_model': 'dotcom.tesouraria.extrato.abertura.fecho.caixa',
            'res_id':extrato_id,
            'target': 'new',
            'context': context,
            'nodestroy': True,
        }
    
    
dotcom_gestao_projectos_movimentos_abertura_caixa()   


class dotcom_gestao_projectos_fecho_caixa(osv.osv):
    _name='dotcom.gestao.projectos.fecho.caixa'
    _columns={
        'data':fields.datetime('Data',required=True),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=True, ),
        'movimentos_fecho_ids':fields.one2many('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha','fecho_caixa_id', 'Moviementos Abertura', readonly=True)
    }
    
    
    _defaults={
        'data':lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    def on_change_data(self,cr,uid,ids,data,context=None):
        if context is None:
            context={}
        
        periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                            ('date_start','<=',data),
                                                                            ('date_stop','>=',data),
                                                                        ])
        
        if len(periodos_ids)<=0:
            raise osv.except_osv(_('Acção Inválida !'), _('Ano fiscal e/ou Periodos não Criados'))
        logger.info('PERIODOS ACHADOS NA PESQUISA %s' %str(periodos_ids))        
        val={'periodo_id':periodos_ids[0],'movimentos_fecho_ids':None}
        return {'value':val}
    
    
    def actualizar_linhas(self,cr,uid,ids,context):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                            ('date_start','<=',documento.data),
                                                                            ('date_stop','>=',documento.data),
                                                                            ('special','=',False),
                                                                            ('closing','=',False),
                                                                        ])
            
            for linha_conta_fechar in documento.movimentos_fecho_ids:
                self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').unlink(cr,uid,linha_conta_fechar.id)
            
            
            self.write(cr,uid,documento.id,{'periodo_id':periodos_ids[0]})
            
            lista_contas=self.pool.get('dotcom.gestao.projectos.conta').search(cr,uid,[
                                                                                ('tipo_conta','=','caixa'),
                                                                                ('state_abertura','=','aberta')])
           
            
            if len(lista_contas)<=0:
                raise osv.except_osv(_('Acção Inválida !'), _('Não existem contas em aberto' ))
            
            
            for conta in lista_contas:
                movimento_abertura_ids=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                            ('conta_id','=',conta),
                                                                                                            ('data','<=',documento.data),
                                                                                                            ('state','=','emitido'),
                                                                                                            ('tipo_movimento','=','abertura')
                                                                                                        ])
        
                
                
                conta_object=self.pool.get('dotcom.gestao.projectos.conta').browse(cr,uid,conta)
                logger.info('REFERENCIA DA CONTA %s' %str(conta_object.ref))
                logger.info('MOVIMENTOS DE ABERTURA ACHADOS %s' %str(movimento_abertura_ids))
                if len(movimento_abertura_ids)>0:
                    
                    ultima_abertura=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').browse(cr,uid,movimento_abertura_ids[len(movimento_abertura_ids)-1])
                    #logger.info('ULTIMA ABERTURA TESTE %s' %str(ultima_abertura.valor_abetura))
                    lancamentos_conta_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                                ('conta_id','=',conta),
                                                                                                                ('data','>=',ultima_abertura.data),
                                                                                                                ('data','<=',documento.data),
                                                                                                                ('state','=','emitido'),
                                                                                                                ('state_processamento','=','por_processar')
                                                                                                            ])
                    
                    credito=0
                    debito=0
                    for lancamento in lancamentos_conta_ids:
                        lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                        credito=credito+lancamento.credito
                        debito=debito+lancamento.debito
                        
                        
                    #logger.info('VALOR CREDITADO %s' %str(credito))
                    #logger.info('VALOR DEBITADO %s' %str(debito))
                    saldo=debito-credito
                    valor_existente=saldo+ultima_abertura.valor_abetura
                    
                    if ultima_abertura.data<=documento.data:
                        val={
                            'conta_id':conta,
                            'data':documento.data,
                            'valor_ultimo_fecho':valor_existente,
                            'valor_abetura':valor_existente,
                            #'valor_remanescente':0,
                            'state_fecho':'rascunho',
                            'fecho_caixa_id':documento.id,
                            'tipo_movimento':'fecho',
                        }
                        logger.info('LANCAMENTOS ACHADOS PARA A CONTA %s' %str(val))
                        fecho_caixa_id=self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').create(cr,uid,val)
                        logger.info('LANCAMENTOS ACHADOS PARA A CONTA %s' %str(fecho_caixa_id))
                    
                        for lancamento in lancamentos_conta_ids:
                            self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento,{'fecho_caixa_movimento_id':fecho_caixa_id})
                
        return True    

    
    def fechar_caixa(self,cr,uid,ids,context):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            contador=0
            for linha_fechar in documento.movimentos_fecho_ids:
                logger.info('DATA DO FECHO DE CAIXA %s' %str(documento.data))
                if linha_fechar.abrir==True:
                    
                    contador=contador+1
                    #self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').feichar_caixa_linha(cr,uid,linha_fechar)
                    self.pool.get('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha').write(cr,uid,linha_fechar.id,{'state':'emitido','state_fecho':'emitido','data':documento.data})
                    self.pool.get('dotcom.gestao.projectos.conta').write(cr,uid,linha_fechar.conta_id.id,{'state_abertura':'fechada'})
                    validator.validar_data_ultima_abertura_fecho_caixa(self,cr,uid,linha_fechar.conta_id,linha_fechar.data,context)
                    validator.validar_fecho_caixa(self,cr,uid,linha_fechar.conta_id,linha_fechar.data,context)
                    for lancamento in linha_fechar.movimentos_ids:
                        self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'state_processamento':'processado'})
                else:
                    for lancamento in linha_fechar.movimentos_ids:
                        self.pool.get('dotcom.gestao.projectos.lancamentos').write(cr,uid,lancamento.id,{'fecho_caixa_id':None})
                logger.info('DATA DO FECHO DE CAIXA %s' %str(linha_fechar.data))    
            if contador<=0:
                raise osv.except_osv(_('Acção Inválida !'), _('Nenhuma caixa seleccionada' ))
        return True

dotcom_gestao_projectos_fecho_caixa()



#Tabela para a Tranferência de Cheques de um conta caixa(conta_origem_id) para outra(conta_destino_id)
#class dotcom_tesouraria_transferecia_cheques(osv.osv):
#    _name='dotcom.tesouraria.transferencia.cheques'
#    _columns={
#        'data':fields.date('Data',required=True),
#        'conta_origem_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, domain="[('tipo_conta','!=','banco')]"),
#        'conta_destino_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',required=True, domain="[('tipo_conta','!=','banco')]"),
#        'state':fields.selection([
#                                ('rascunho','Rascunho'),
#                                ('emitido','Emitido'),
#                                ('cancelado','Cancelado')
#                            ],'Estado'),
#    }
#    
#    _defaults={
#        'state':'rascunho',
#    }
#dotcom_tesouraria_transferecia_cheques()