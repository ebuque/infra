# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

class dotcom_res_company(osv.osv):
    _name = 'res.company'
    _inherit = 'res.company'
    _columns={
        
        'verificar_orcamento':fields.boolean('Verificar Orçamento'),
        'emitir_alerta':fields.boolean('Emitir Alerta'),
        'comparar_maior':fields.boolean('Maior'),
        'comparar_menor':fields.boolean('Menor'),
        'seleccionar_orcamento':fields.boolean('Seleccionar'),
        'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orçamento'),
    }
    
    def on_change_maior(self,cr,uid,ids,maior,context=None):
        if context is None:
            context={}
        
        logger.info('PROCESSO EM EXECUCAO %s' %str())
        if maior==True:
            return {'value':{'comparar_menor':False,'seleccionar_orcamento':False,'orcamento_id':None}}
        else:
            return {}
        
    def on_change_menor(self,cr,uid,ids,menor,context=None):
        if context is None:
            context={}
        
        if menor==True:
            return {'value':{'comparar_maior':False,'seleccionar_orcamento':False,'orcamento_id':None}}
        else:
            return {}
        
    def on_change_seleccionar(self,cr,uid,ids,seleccionar,context=None):
        if context is None:
            context={}
        
        if seleccionar==True:
            return {'value':{'comparar_maior':False,'comparar_menor':False,}}
        else:
            return {}
    
dotcom_res_company()