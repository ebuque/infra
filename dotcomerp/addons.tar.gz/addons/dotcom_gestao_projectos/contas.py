# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_conta(osv.osv):
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.decricao or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.conta'
    _columns={
        'ref':fields.char('Ref.', size=50, required=True, ),
        'titular':fields.char('Titular', size=100, readonly=True),
        'decricao':fields.char('Descrição',required=True, size=100),
        'numero':fields.char('Número', size=50,),
        'nib':fields.char('NIB', size=50, ),
        'banco_id':fields.many2one('res.bank','Banco'),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'agencia':fields.char('Agência', size=100),
        'gestor':fields.char('Gestor', size=100),
        'telefone':fields.char('Telefone', size=50),
        'celular':fields.char('Cel.', size=50),
        'iban':fields.char('IBAN', size=50),
        'swift':fields.char('SWIFT', size=50),
        
        #movimentos da conta
        #'lancamentos_movimento_ids':fields.one2many('dotcom.tesouraria.lancamento.movimentos','conta_id','Lancmaentos', readonly=True, domain=[('state','=','emitido')]),
        
        'tipo_conta':fields.selection([
                                        ('caixa','Caixa'),
                                        ('banco','Banco'),
                                        #('caixa_balcao','Caixa Balcao Venda')
                                        ],
                                        'Tipo Conta', required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        
        'contabilidade':fields.boolean('Contabilidade'),
        #'state_abertura':fields.selection([('aberta','Aberta'),('fechada','Fechada')],'Disponibilidade'),
        'state':fields.selection([('rascunho','Rascunho'),('emitida','Emitida')]),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=True),
        
        #

    }
    
    
    _defaults={
        #'state_abertura':'fechada',
        'state':'rascunho',
        #'titular':validator.getCompany,
    }
    _rec_name='friendly_name'


    _sql_constraints = [
        ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    

dotcom_gestao_projectos_conta()