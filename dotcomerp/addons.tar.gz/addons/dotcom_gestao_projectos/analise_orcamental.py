# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')


class dotcom_gestao_projectos_analise_orcamental(osv.osv):
    
    
    def _acerto(self,cr,uid,context=None):
        if context is None:
            context = {}
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
        
        ano_ids=self.search(cr,uid,[])
        result=()
        this=[]
                
        result=('mp',str(moeda_primaria.name))
        this.append(result)
        
        result=('ms',str(moeda_secundaria.name))
        this.append(result)
        
        result=('ml','Moeda da Conta')
        this.append(result)
            
        return this
    
    _name='dotcom.gestao.projectos.analise.orcamental'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,required=True,),
        'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orçamento', domain="[('ano_fiscal_id','=',ano_fiscal_id)]", required=True),
        'conversao_moeda':fields.selection(_acerto,'Moeda', required=True),
        
        'tipo_analise':fields.selection([
                                        ('mensal','Mensal'),
                                        ('trimestral','Trimestral'),
                                        ('anual','Anual')],'Tipo Análise', required=True),
        
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', ),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Financiador'),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=False, readonly=True),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', domain="[('projecto_id','=',projecto_id)]", required=False),
        
        'periodo_id':fields.many2one('configuration.period','Período', domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False)]" ),
        'periodo_trimestral':fields.selection([
                                                ('primero_trimestre','1 Trimestre'),
                                                ('segundo_trimestre','2 Trimestre'),
                                                ('terceiro_trimestre','3 Trimestre'),
                                                ('quarto_trimestre','4 Trimestre')],'Periodo Trimestral', required=False),
        
        'linhas_analise_ids':fields.one2many('dotcom.gestao.projectos.analise.orcamental.linhas','analise_id','Linhas', readonly=True),
    }
    
    _defaults={
        'tipo_analise':'mensal',
        'conversao_moeda':'mp'
    }
    
    
    def on_change_anofiscal(self,cr,uid,ids,ano_fisacal_id,context=None):
        if context is None:
            context={}
        
        result=()
        this=[]
        if ano_fisacal_id:
            ano_fisacal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fisacal_id)
            
        return {}
    
    
    def on_chege_orcamento(self,cr,uid,ids,orcamento_id,context=None):
        if context is None:
            context ={}
        
        val={}
        if orcamento_id:
            orcamento_object=self.pool.get('dotcom.gestao.projectos.orcamento').browse(cr,uid,orcamento_id)
            val={'projecto_id':orcamento_object.projecto_id.id}
        logger.info('VALOR A SER RETORNADO')    
        return{'value':val}
    
    
    #Pega os peridos mensais(Janeiro, Fevereiro....Dezembro), de um dado ano fiscal e especifico trimestre,
    #deixando de fora os periodos especiais como os de abertura e de feixo(Mes 13,...15)
    def pegar_periodos_trimestrais(self,cr,uid,ids,periodo,ano_fisacal_id,context=None):
        if context is None:
            context={}
        
        periodos_ids=[]  
        if periodo=='primero_trimestre':
            startDate = str(ano_fisacal_id.code)+"-01-01"
            
            dataInicial = datetime.strptime(startDate, "%Y-%m-%d")
            # logger.info('DATA ACHADA ATE AO MOMENTO %s' %str(dataInicial))
            endtDate = str(ano_fisacal_id.code)+"-03-31"
            dataFinal= datetime.strptime(endtDate, "%Y-%m-%d")
            # logger.info('DATA ACHADA ATE AO MOMENTO %s' %str(dataFinal))
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',ano_fisacal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),
                                                                                ('date_start','>=',dataInicial),
                                                                                ('date_stop','<=',dataFinal)])
        elif periodo=='segundo_trimestre':
            startDate = str(ano_fisacal_id.code)+"/04/01"
            dataInicial = datetime.strptime(startDate, "%Y/%m/%d")
            
            endtDate = str(ano_fisacal_id.code)+"/06/30"
            dataFinal= datetime.strptime(endtDate, "%Y/%m/%d")
            
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',ano_fisacal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),
                                                                                ('date_start','>=',dataInicial),
                                                                                ('date_stop','<=',dataFinal)])
        elif periodo=='terceiro_trimestre':
            startDate = str(ano_fisacal_id.code)+"/07/01"
            dataInicial = datetime.strptime(startDate, "%Y/%m/%d")
            
            endtDate = str(ano_fisacal_id.code)+"/09/30"
            dataFinal= datetime.strptime(endtDate, "%Y/%m/%d")
            
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',ano_fisacal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),
                                                                                ('date_start','>=',dataInicial),
                                                                                ('date_stop','<=',dataFinal)])
        elif periodo=='quarto_trimestre':
            startDate = str(ano_fisacal_id.code)+"/10/01"
            dataInicial = datetime.strptime(startDate, "%Y/%m/%d")
            
            endtDate = str(ano_fisacal_id.code)+"/12/31"
            dataFinal= datetime.strptime(endtDate, "%Y/%m/%d")
            
            periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',ano_fisacal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),
                                                                                ('date_start','>=',dataInicial),
                                                                                ('date_stop','<=',dataFinal)])
        
        return periodos_ids
        
    
    #Calcula o valor total movimentado em uma rubrica num intervalo de periodos
    def valor_movimentado_rubrica(self,cr,uid,ids,rubrica_id,lista_periodos,projecto_id,conversao_moeda,context=None):
        if context is None:
            context={}
            
        lancamento_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                    ('projecto_id','=',projecto_id),
                                                    ('rubrica_id','=',rubrica_id),
                                                    ('state','=','emitido'),
                                                     # ('data','>=',periro_lista.date_start),
                                                     # ('data','<=',periro_lista.date_stop),
                                                     ('periodo_id','in',lista_periodos)
                                            ])
        # logger.info('NUMERO DE LANCAMENTOS ACHADOS %s' %str(lancamento_ids))
        
        total_valor=0
        for lancamento in lancamento_ids:
            lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
            if conversao_moeda=='mp':
                total_valor=total_valor+lancamento.valor_moeda_base
            elif conversao_moeda=='ms':
                total_valor=total_valor+lancamento.valor_moeda_secundaria
                
        # logger.info('NUMERO DE LANCAMENTOS ACHADOS %s' %str(total_valor))
        return total_valor        
        
    
    #calcula o valor total orcamentado para uma rubrica nos periodos selecionados num dado orcamento
    def calcular_valor_orcamentado(self,cr,uid,ids,orcamento_id,rubrica_id,periodos_ids,conversao_moeda,context=None ):
        if context is None:
            context={}
         
        valor_orcamentado_periodo=0    
        for periro_lista in periodos_ids:
            periro_lista=self.pool.get('configuration.period').browse(cr,uid,periro_lista)
            
            periodo_code=periro_lista.code[:2]
            # periro_lista=self.get_periodo(cr,uid,ids,periodo)
                   
            orcamento_periodo_ids=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').search(cr,uid,[
                                ('orcamento_id','=',orcamento_id),
                                ('state','=','emitido'),
                                ('rubrica_id','=',rubrica_id),
                ])
            # logger.info(' ORCAMENTADO ACHADOS PARA O PERIODO %s' %str(orcamento_periodo_ids))      
            if len(orcamento_periodo_ids)>0:
                
                for orcamento in orcamento_periodo_ids:
                    orcamento_obj=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').browse(cr,uid,orcamento)
                    # logger.info(' ORCAMENTADO ACHADOS PARA O PERIODO %s' %str(orcamento_obj.rubrica_id.friendly_name))
                    
                    
                    if conversao_moeda=='mp':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan_mp
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev_mp
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar_mp
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio_mp   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun_mp
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul_mp
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago_mp
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set_mp     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov_mp
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez_mp
                            
                    if conversao_moeda=='ms':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan_ms
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev_ms
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar_ms
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_ms
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio_ms   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun_ms
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul_ms
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago_ms
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set_ms     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_ms  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov_ms
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez_ms
                            
                    if conversao_moeda=='ml':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez     
            
        return valor_orcamentado_periodo    
    
    
    
    def carregar_linhas_orcamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
                            
        for documento in self.browse(cr,uid,ids):
            
            for linha in documento.linhas_analise_ids:
                self.pool.get('dotcom.gestao.projectos.analise.orcamental.linhas').unlink(cr,uid,linha.id)
            
            # 
            periodos_ids=[]
            if  documento.tipo_analise=='mensal':
                if bool(documento.periodo_id.id)!=False: 
                    periodos_ids.append(documento.periodo_id.id)
                else:
                    raise osv.except_osv(_('Invalid action !'), _('Seleccione o periodo.!!'))    
            elif documento.tipo_analise=='trimestral':
                periodos_ids=self.pegar_periodos_trimestrais(cr,uid,ids,documento.periodo_trimestral,documento.ano_fiscal_id)
            elif documento.tipo_analise=='anual':
                periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',documento.ano_fiscal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),])
            
            # logger.info('PERIODOS ACHADOS %s' %str(periodos_ids))
            
            
            rubricas_ids=[]
            if bool(documento.rubrica_id.id)!=False:
                rubricas_ids.append(documento.rubrica_id.id)
            else:
                rubricas_ids=self.pool.get('dotcom.gestao.projectos.rubrica').search(cr,uid,[])
            
            for rubrica in rubricas_ids:
                valor_total_movimentado=self.valor_movimentado_rubrica(cr,uid,ids,rubrica,periodos_ids,documento.orcamento_id.projecto_id.id,documento.conversao_moeda)
                valor_total_orcamentado=self.calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_id.id,rubrica,periodos_ids,documento.conversao_moeda)
                logger.info('VALOR TOTAL MOVIMENTADO %s' %str(valor_total_movimentado))
                
                
                if valor_total_orcamentado!=0:
                    
                    valor_desvio=valor_total_movimentado-valor_total_orcamentado
                    # logger.info('VALOR TOTAL ORCAMENTADO %s' %str(valor_desvio))
                    # logger.info('VALOR TOTAL ORCAMENTADO %s' %str(valor_total_orcamentado))
                    
                    percentagem=float((valor_desvio*100)/valor_total_orcamentado)
                    
                    val={
                            # 'doador_id':documento.orcamento_id.doador_id.id,
                            #'programa_id':orcamento_obj.programa_id.id,
                            'rubrica_id':rubrica,
                            'valor_orcamentado':valor_total_orcamentado,
                            'valor_movimentado':valor_total_movimentado,
                            'desvio':valor_desvio,
                            'percentagem':percentagem,
                            'analise_id':documento.id
                        }
                    self.pool.get('dotcom.gestao.projectos.analise.orcamental.linhas').create(cr,uid,val)                
        return {}
    
    
    
    def get_periodo(self,cr,uid,ids,periodo_id,context=None):
        if context is None:
            context={}
        periodo_code=periodo_id.code
        periodo_code=periodo_code[:2]
        periodo=None
        lista=[]
        if periodo_code=='01':
            jan=None
            lista.append(jan)
            
        elif periodo_code=='02':
            fev=None
            lista.append(fev)
            
        if periodo_code=='03':
            mar=None
            lista.append(mar)
            
        elif periodo_code=='04':
            abr=None
            lista.append(abr)
            
        if periodo_code=='05':
            maio=None
            lista.append(maio)
            
        elif periodo_code=='06':
            jun=None
            lista.append(jun)
            
        if periodo_code=='07':
            jul=None
            lista.append(jul)
            
        elif periodo_code=='08':
            ago=None
            lista.append(ago)
            
        if periodo_code=='09':
            set=None
            lista.append(set)
            
        elif periodo_code=='10':
            out=None
            lista.append(out)
            
        if periodo_code=='11':
            nov=None
            lista.append(nov)
            
        elif periodo_code=='12':
            dez=None
            lista.append(dez)
        
        return lista
    
dotcom_gestao_projectos_analise_orcamental()



class dotcom_gestao_projectos_analise_orcamental_linhas(osv.osv):
    _name='dotcom.gestao.projectos.analise.orcamental.linhas'
    _columns={
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Financiador'),
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', ),
        #'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa',),
        'valor_orcamentado':fields.float('Valor Orçamentado',required=True),
        'valor_movimentado':fields.float('Valor Movimentado',required=True),
        'desvio':fields.float('Desvio', required=True),
        'percentagem':fields.float('Percentagem(%)'),
        'analise_id':fields.many2one('dotcom.gestao.projectos.analise.orcamental','Analise'),
        
        'analise_global_id':fields.many2one('dotcom.gestao.projectos.analise.orcamental.global','Analise'),
    }
    
    
    def carregar_linhas_comparativas(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            lista_rubricas_receitas_ids=[]
            lista_rubricas_despesas_ids=[]
    
dotcom_gestao_projectos_analise_orcamental_linhas()



class dotcom_gestao_projectos_analise_orcamental_global(osv.osv):
    
    
    def _acerto(self,cr,uid,context=None):
        if context is None:
            context = {}
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
        
        ano_ids=self.search(cr,uid,[])
        result=()
        this=[]
                
        result=('mp',str(moeda_primaria.name))
        this.append(result)
        
        result=('ms',str(moeda_secundaria.name))
        this.append(result)
        
        result=('ml','Moeda da Conta')
        this.append(result)
            
        return this
    
    
    
    
    
    _name='dotcom.gestao.projectos.analise.orcamental.global'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,required=True,),
        'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento.geral','Orçamento', domain="[('ano_fiscal_id','=',ano_fiscal_id)]", required=True),
        'conversao_moeda':fields.selection(_acerto,'Moeda', required=True),
        
        'tipo_analise':fields.selection([
                                        ('mensal','Mensal'),
                                        ('trimestral','Trimestral'),
                                        ('anual','Anual')],'Tipo Análise', required=True),
        
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', ),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador','Financiador'),
        
        
        'periodo_id':fields.many2one('configuration.period','Período', domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False)]" ),
        'periodo_trimestral':fields.selection([
                                                ('primero_trimestre','1 Trimestre'),
                                                ('segundo_trimestre','2 Trimestre'),
                                                ('terceiro_trimestre','3 Trimestre'),
                                                ('quarto_trimestre','4 Trimestre')],'Periodo Trimestral', required=False),
        
        'linhas_analise_ids':fields.one2many('dotcom.gestao.projectos.analise.orcamental.linhas','analise_global_id','Linhas', readonly=True),
        
    }
    
    _defaults={
        'tipo_analise':'mensal',
        'conversao_moeda':'mp'
    }
    
    
    def on_change_anofiscal(self,cr,uid,ids,ano_fisacal_id,context=None):
        if context is None:
            context={}
        
        result=()
        this=[]
        if ano_fisacal_id:
            ano_fisacal_object=self.pool.get('configuration.fiscalyear').browse(cr,uid,ano_fisacal_id)
            
        return {}
    
    
    def on_chege_orcamento(self,cr,uid,ids,orcamento_id,context=None):
        if context is None:
            context ={}
        
        val={}
        if orcamento_id:
            orcamento_object=self.pool.get('dotcom.gestao.projectos.orcamento').browse(cr,uid,orcamento_id)
            val={'projecto_id':orcamento_object.projecto_id.id}
        logger.info('VALOR A SER RETORNADO')    
        return{'value':val}
    
    
    def carregar_linhas_orcamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
                            
        for documento in self.browse(cr,uid,ids):
            
            for linha in documento.linhas_analise_ids:
                self.pool.get('dotcom.gestao.projectos.analise.orcamental.linhas').unlink(cr,uid,linha.id)
            
            
            periodos_ids=[]
            if  documento.tipo_analise=='mensal':
                if bool(documento.periodo_id.id)!=False: 
                    periodos_ids.append(documento.periodo_id.id)
                else:
                    raise osv.except_osv(_('Invalid action !'), _('Seleccione o periodo.!!'))    
            elif documento.tipo_analise=='trimestral':
                periodos_ids=self.pool.get('dotcom.gestao.projectos.analise.orcamental').pegar_periodos_trimestrais(cr,uid,ids,documento.periodo_trimestral,documento.ano_fiscal_id)
            elif documento.tipo_analise=='anual':
                periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',documento.ano_fiscal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),])
            
            rubricas_ids=[]
            if bool(documento.rubrica_id.id)!=False:
                rubricas_ids.append(documento.rubrica_id.id)
            else:
                rubricas_ids=self.pool.get('dotcom.gestao.projectos.rubrica').search(cr,uid,[])
            
            for rubrica in rubricas_ids:
                valor_total_movimentado=self.valor_movimentado_rubrica(cr,uid,ids,rubrica,periodos_ids,documento.conversao_moeda)
                valor_total_orcamentado=self.calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_id.id,rubrica,periodos_ids,documento.conversao_moeda)
                logger.info('TOTAL ORCAMENTADO %s' %str(valor_total_movimentado))
                
                if valor_total_orcamentado!=0:
                    
                    valor_desvio=valor_total_movimentado-valor_total_orcamentado
                    
                    percentagem=float((valor_desvio*100)/valor_total_orcamentado)
                    
                    val={
                            # 'doador_id':documento.orcamento_id.doador_id.id,
                            #'programa_id':orcamento_obj.programa_id.id,
                            'rubrica_id':rubrica,
                            'valor_orcamentado':valor_total_orcamentado,
                            'valor_movimentado':valor_total_movimentado,
                            'desvio':valor_desvio,
                            'percentagem':percentagem,
                            'analise_global_id':documento.id
                        }
                    self.pool.get('dotcom.gestao.projectos.analise.orcamental.linhas').create(cr,uid,val)   
                
        return {}
    
    def valor_movimentado_rubrica(self,cr,uid,ids,rubrica_id,lista_periodos,conversao_moeda,context=None):
        if context is None:
            context={}
            
        lancamento_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                    ('rubrica_id','=',rubrica_id),
                                                    ('state','=','emitido'),
                                                    ('periodo_id','in',lista_periodos)
                                            ])
        
        total_valor=0
        for lancamento in lancamento_ids:
            lancamento=self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
            if conversao_moeda=='mp':
                total_valor=total_valor+lancamento.valor_moeda_base
            elif conversao_moeda=='ms':
                total_valor=total_valor+lancamento.valor_moeda_secundaria
                
        # logger.info('NUMERO DE LANCAMENTOS ACHADOS %s' %str(total_valor))
        return total_valor    
    
    
    #calcula o valor total orcamentado para uma rubrica nos periodos selecionados num dado orcamento Global
    def calcular_valor_orcamentado(self,cr,uid,ids,orcamento_id,rubrica_id,periodos_ids,conversao_moeda,context=None ):
        if context is None:
            context={}
         
        valor_orcamentado_periodo=0    
        for periro_lista in periodos_ids:
            periro_lista=self.pool.get('configuration.period').browse(cr,uid,periro_lista)
            
            periodo_code=periro_lista.code[:2]
            # periro_lista=self.get_periodo(cr,uid,ids,periodo)
                   
            orcamento_periodo_ids=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').search(cr,uid,[
                                ('orcamento_geral_id','=',orcamento_id),
                                ('state_2','=','emitido'),
                                ('rubrica_id','=',rubrica_id),
                ])
            # logger.info(' ORCAMENTADO ACHADOS PARA O PERIODO %s' %str(orcamento_periodo_ids))      
            if len(orcamento_periodo_ids)>0:
                for orcamento in orcamento_periodo_ids:
                    orcamento_obj=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').browse(cr,uid,orcamento)
                    # logger.info(' ORCAMENTADO ACHADOS PARA O PERIODO %s' %str(orcamento_obj.rubrica_id.friendly_name))
                    
                    
                    if conversao_moeda=='mp':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan_mp
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev_mp
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar_mp
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio_mp   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun_mp
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul_mp
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago_mp
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set_mp     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov_mp
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez_mp
                            
                    if conversao_moeda=='ms':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan_ms
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev_ms
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar_ms
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_ms
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio_ms   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun_ms
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul_ms
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago_ms
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set_ms     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_ms  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov_ms
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez_ms
                            
                    if conversao_moeda=='ml':
                        if periodo_code=='01':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan
                        elif periodo_code=='02':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev
                        if periodo_code=='03':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar
                        elif periodo_code=='04':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr
                        if periodo_code=='05':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio   
                        elif periodo_code=='06':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun
                        if periodo_code=='07':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul
                        elif periodo_code=='08':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago
                        if periodo_code=='09':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set     
                        elif periodo_code=='10':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr  
                        if periodo_code=='11':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov
                        elif periodo_code=='12':
                            valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez     
            
        return valor_orcamentado_periodo    
    
dotcom_gestao_projectos_analise_orcamental_global()
