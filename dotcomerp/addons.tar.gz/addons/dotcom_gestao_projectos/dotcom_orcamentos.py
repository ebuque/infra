# -*- coding: utf-8 -*-

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_PLANO_CONTAS')

class dotcom_orcamentos(osv.osv):
    _name='dotcom.contabilidade.orcamentos'
    _columns={
        'ref':fields.char('Orçamento',size=25,required=True,readonly=True,states={'rascunho':[('readonly',False)]}),
        'nome':fields.char('Nome',size=50,required=True,readonly=True,states={'rascunho':[('readonly',False)]}),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True,readonly=True,states={'rascunho':[('readonly',False)]}),
        'custos_orcamentos_ids':fields.one2many('dotcom.custos.orcamentos','orcamento_id','Custos de Orçamento'),
        'custos_orcamentos_contas_ids':fields.one2many('dotcom.custos.centro.orcamentos','orcamento_id','Custos de Orçamento',readonly=True,states={'rascunho':[('readonly',False)]}),
        'conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Conta',readonly=True,states={'rascunho':[('readonly',False)]}),
        'plano_custos_id':fields.many2one('dotcom.contabilidade.centros.custos','Plano',readonly=True,states={'rascunho':[('readonly',False)]}),
        'conta_centro_custo_id':fields.many2one('dotcom.contabilidade.conta.centro.custos','Conta C. Custo', readonly=True,states={'rascunho':[('readonly',False)]}),
        'state':fields.selection([
                    ('rascunho','Rascunho'),
                    ('emitido','Emitido'),
                    ('cancelado','Cancelado'),
                    ('outro_rascunho','Rascunho'),
                    ],'Estado'),
        
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        'moeda_secundaria_id': fields.many2one('res.currency','Moeda Secundária',),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)]}),
        'cambio_secundario':fields.float('Câmbio MP/MS', help='Cámbio da moeda Principal(MP) para a moeda secundária(MS)',readonly=True, states={'rascunho':[('readonly',False)]}),
        'data':fields.date('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)]}),
        
        
    }
    _rec_name='nome'    
    
    _sql_constraints = [
        ('name_uniq', 'unique (nome)', 'Nome já registrado no sistema. Nome do Orçamento deve ser único !')
    ]
    
    _defaults={
        'data':lambda *a: time.strftime('%Y-%m-%d'),
        'ano_fiscal_id':validator._get_default_year,
        #'cambio_secundario':lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria_cambio(cr, uid,'dotcom.contabilidade.plano.contas', context=c),
        'moeda_lancamento_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=c),
        'moeda_secundaria_id':lambda self,cr,uid,c: self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=c),
        'state':'rascunho'
    }
      
    
    
    def visualisar_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        visualizacao_id=self.pool.get('dotcom.contabilidade.visualizacao.orcamnto').create(cr,uid,{})
        for documento in self.browse(cr,uid,ids):
            for linha in documento.custos_orcamentos_ids:
                self.pool.get('dotcom.custos.orcamentos').write(cr,uid,linha.id,{'visualizacao_mp_id':visualizacao_id,
                                                                                 'visualizacao_ms_id':visualizacao_id
                                                                                 })                
        return {
            'name':'Visualizacao do Orçamento',
            'view_mode': 'form',
            'view_id': False,
            'view_type': 'form',
            'res_model': 'dotcom.contabilidade.visualizacao.orcamnto',
            'res_id': visualizacao_id,
            'type': 'ir.actions.act_window',
            'nodestroy': True,
            'target': 'new',
            'domain': '[]',
            'context': context
        }
    
    
    def on_change_currency(self, cr, uid, ids, currency_id,moeda_secundaria_id, context=None):
        if context is None:
            context = {}
        res = {}
        if currency_id:
            moeda = self.pool.get('res.currency').browse(cr, uid, currency_id)
            moeda_secundaria=self.pool.get('res.currency').browse(cr, uid, moeda_secundaria_id)
            cambio = moeda.rate or 1
            res['cambio'] = cambio
            res['cambio_secundario']=moeda_secundaria.rate or 1
            #for documento in self.browse(cr,uid,ids):
            #    logger.info('MAIS DE 1 LANCAMENTO')
            #    if len(documento.lancamentos_diarios_ids)>0:
            #        for lancamento in documento.lancamentos_diarios_ids:
            #            self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento.id,{
            #                            'moeda_documento':currency_id,
            #                            'moeda_lancamento_id':currency_id,
            #                            'cambio':cambio,
            #                            'cambio_secundario':moeda_secundaria.rate
            #                
            #                })
                    
        return {'value':res}
        
    
    def emitir(self, cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):

            self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
            
            for linha in documento.custos_orcamentos_ids:
                if linha.conta.tipo_interno!='m':
                    raise osv.except_osv(_('Acção Invalida !'), _('Tipo da Conta '+linha.conta.ref+' Nao Permitido!!'))
        self.write(cr,uid,ids,{'state':'emitido'})
        return True
    
    def voltar_rascunho(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
            
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
        return {}
        
    def cancelar(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_contabilidade',context)
            self.write(cr,uid,documento.id,{'state':'cancelado'})
        return {}
    
    
    def on_change_conta_id(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            for orcamento in documento.custos_orcamentos_ids:
                self.pool.get('dotcom.custos.orcamentos').unlink(cr,uid,orcamento.id)            
            
            filhos_ids=self.pool.get('dotcom.contabilidade.plano.contas').search(cr,uid,[('parent_id','=',documento.conta_id.id)])
            logger.info('FILHOS %s' %str(filhos_ids))
        
            
            logger.info('ID %s' %str(ids))
            for filho in filhos_ids:
                custo_orcamento={
                    'conta':filho,
                    'orcamento_id':documento.id
                }
                logger.info('ORCAMENTO %s' %str(custo_orcamento))
                self.pool.get('dotcom.custos.orcamentos').create(cr,uid,custo_orcamento)
        
        return {}
               
        
    def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
        if context is None:
            context = {}
        result = super(dotcom_orcamentos, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
        a = []
        
        #logger.info('\nFIELDS VIEW GET \n%s' %str(result))
        moeda_lancamento_id=self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.contabilidade.plano.contas', context=context)
        moeda_lancamento=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento_id)

        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context)
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        dicionario= moeda_primaria_id[0]
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,dicionario)
        
        simbolo_moeda=moeda_secundaria.name
        
        
        
        nome_moeda_lancamento=str(moeda_lancamento and moeda_lancamento.name)
        nome_moeda_primaria = str(moeda_primaria and moeda_primaria.name)
        nome_moeda_secundaria=str(moeda_secundaria and moeda_secundaria.name)


        fields = result['fields']
        #if fields.has_key('cambio_secundario'):
        #    documento = fields['cambio_secundario']
        #    documento['string'] = "Cambio "+moeda_primaria.name+'/'+simbolo_moeda
        #    fields['cambio_secundario'] = documento
        #if fields.has_key('cambio'):
        #    logger.info('CAMBIO ENCONTRADO')
        #    documento = fields['cambio']
        #    documento['string'] = 'Cambio '+moeda_primaria.name
        #    fields['cambio'] = documento    
            
        result['fields'] = fields
        view = result['arch']
        
        view=view.replace('VM',nome_moeda_primaria+'/'+nome_moeda_secundaria)
        view=view.replace('TB','Valor')    
        
        result['arch'] = view
        
        return result
        
    def calculra(self, cr,uid,ids,context=None):
        if context is None:
            context={}
        return True
    
dotcom_orcamentos()


class dotcom_visualizacao_orcamentos(osv.osv):
    _name='dotcom.contabilidade.visualizacao.orcamnto'
    _columns={
        'linhas_orcamentos_mp_ids':fields.one2many('dotcom.custos.orcamentos','visualizacao_mp_id','Linhas Primarias'),
        'linhas_orcamentos_ms_ids':fields.one2many('dotcom.custos.orcamentos','visualizacao_ms_id','Linhas Secundarias'),
    }
    
    
    def fechar_poupup(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        self.unlink(cr,uid,ids)
        return{}
    
    def fields_view_get(self, cr, uid, view_id=None, view_type='form', context=None, toolbar=False,submenu=False):
        if context is None:
            context = {}
        result = super(dotcom_visualizacao_orcamentos, self).fields_view_get(cr, uid, view_id, view_type, context, toolbar,submenu)
        a = []

        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context)
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        dicionario= moeda_primaria_id[0]
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,dicionario)
        
        simbolo_moeda=moeda_secundaria.name

        nome_moeda_primaria = str(moeda_primaria and moeda_primaria.name)
        nome_moeda_secundaria=str(moeda_secundaria and moeda_secundaria.name)
        
        
        view = result['arch']
  
        if nome_moeda_primaria:
            view = view.replace('MP',nome_moeda_primaria)
        if nome_moeda_secundaria:
            view=view.replace('MS',nome_moeda_secundaria)

        result['arch'] = view

        return result
    
    
dotcom_visualizacao_orcamentos()