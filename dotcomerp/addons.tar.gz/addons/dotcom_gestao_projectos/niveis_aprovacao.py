# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

class dotcom_gestao_projectos_niveis_aprovacao(osv.osv):
    _name='dotcom.gestao.projectos.niveis.aprovacao'
    _columns={
        'ref':fields.char('Referencia', size=50, required=True),
        'descricao':fields.char('Descricao', size=50, required=True),
    }

    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}


dotcom_gestao_projectos_niveis_aprovacao