# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

class dotcom_gestao_projectos_orcamento(osv.osv):
    
    def cambio_secundario(self,cr,uid,context=None):
        if context is None:
            context={}
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr,uid, context=context)
        cambio=1
        moeda_secund=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
        logger.info('MOEDA SECUNDARIA CAMBIO %s' %str(moeda_secund.rate))
        return moeda_secund.rate
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.decricao or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    
    _name='dotcom.gestao.projectos.orcamento'
    _columns={
        'data':fields.date('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', domain="[('projecto_id','=',projecto_id)]", required=False),
        'ref':fields.char('Ref.', size=50, required=True, readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'decricao':fields.char('Orçamento',required=True, size=100,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'cambio_secundario':fields.float('Câmbio MP/MS', help="Câmbio para a moeda Secundaria(MP/MS)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'tipo_rubrica':fields.selection([
                                        ('receita','Receita'),
                                        ('despesas','Despesas')
                                        ], 'Tipo', readonly=True,required=False, states={'rascunho':[('readonly',False)]}),
        
        'state':fields.selection([
                    ('rascunho','Rascunho'),
                    ('emitido','Emitido'),
                    ('cancelado','Cancelado'),
                    ('outro_rascunho','Rascunho'),
                    ],'Estado'),
        
        'orcamentos_programas_ids':fields.one2many('dotcom.gestao.projectos.orcamentos.linhas','orcamento_id','Orcamentos',readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=False),
    }
    
    _defaults={
        'data':lambda *a: time.strftime('%Y-%m-%d'),
        'state':'rascunho',
        'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
        #'titular':validator.getCompany,
    }
    _rec_name='friendly_name'


    _sql_constraints = [
        ('name_uniq', 'unique (ref,ano_fiscal_id)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    def criar_ano_seguinte(self, cr,uid,ids,context=None):
        if context is None:
            context ={}
        
        identificador=None
        for documento in self.browse(cr,uid,ids):
            anos_ficais_seguintes=self.pool.get('configuration.fiscalyear').search(cr,uid,[('date_start','>',documento.ano_fiscal_id.date_stop)])
            
            if len(anos_ficais_seguintes)<=0:
                raise osv.except_osv(_('Invalid action !'), _('Não existe ano seguinte para ser orçamentado!'))
            else:
                data=datetime.now()
                val={
                    'data':data,
                    'ano_fiscal_id':anos_ficais_seguintes[0],
                    'projecto_id':documento.projecto_id.id,
                    'ref':documento.ref,
                    'decricao':documento.decricao,
                    'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                    'cambio':documento.cambio,
                    'cambio_secundario':documento.cambio_secundario,
                    'percentagem':10,
                    'orcamento_id':documento.id,
                }
                
                if bool(documento.programa_id.id)!=False:
                    val['programa_id']=documento.programa_id.id
                    
                identificador=self.pool.get('dotcom.gestao.projectos.orcamento.copia').create(cr,uid,val)
                
        return {
                'type': 'ir.actions.act_window',
                'name': 'Criar Orçamento do ano seguinte',
                'view_mode': 'form',
                'view_type': 'form',
                'res_model': 'dotcom.gestao.projectos.orcamento.copia',
                'res_id':identificador,
                'target': 'new',
                'context': context,
                'nodestroy': True,
            }
    
    
    def on_change_moeda(self,cr,uid,ids,moeda_id,context=None ):
        if context is None:
            context={}

        val={}
        if moeda_id:
            moeda = self.pool.get('res.currency').browse(cr, uid, moeda_id)
            cambio = moeda.rate or 1
            val={'cambio':cambio}    
            
        return {'value':val}
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
    
    def emitir_orcamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            if len(documento.orcamentos_programas_ids)<=0:
                raise osv.except_osv(_('Error !'), _('Orçamento sem linhas'))
            
            self.write(cr,uid,documento.id,{'state':'emitido'})
        return True
    
    
    def voltar_rascunho_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
            
        return True
        
    
    def cancelar_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'cancelado'})
            
        return True
    
       
dotcom_gestao_projectos_orcamento()


class dotcom_gestao_projectos_orcamentos_linhas(osv.osv):
    
    def _calculador_primaria_jan(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.jan/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_jan(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.jan/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_fev(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.fev/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_fev(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.fev/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_mar(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.mar/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_mar(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.mar/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_abr(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.abr/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_abr(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.abr/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_maio(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.maio/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_maio(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.maio/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_jun(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.jun/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_jun(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.jun/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_jul(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.jul/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_jul(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.jul/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_ago(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.ago/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_ago(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.ago/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_set(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.set/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_set(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.set/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_out(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.out/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_out(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.out/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_nov(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=cambio*centro.nov
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_nov(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.nov/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_dez(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.dez/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_dez(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.dez/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_primaria_total(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio
            valor=centro.total/cambio
            res[centro.id] = valor
        return res
    
    def _calculador_secundaria_total(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for centro in self.browse(cr, uid, ids, context=context):
            cambio=centro.cambio_secundario
            valor=centro.total/cambio
            res[centro.id] = valor
        return res
    
    _name='dotcom.gestao.projectos.orcamentos.linhas'
    _columns={
            #'conta':fields.many2one('dotcom.contabilidade.plano.contas','Conta',size=20, required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
            'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False),
            'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=False),
            
            'doador_id':fields.many2one('dotcom.gestao.projectos.doador.projecto','Doador', domain="[('projecto_id','=',projecto_id)]", required=False),
            'distribuir':fields.boolean('Distribuir', help="Distribuir o Valor total pelos Periodos"),
            'igualar':fields.boolean('I', help="Igualar o valor Total a todos os Periodos"),
            'calcular':fields.boolean('C'),
            'total':fields.float('Total'),
            'jan':fields.float('Jan'),
            'fev':fields.float('Fev'),
            'mar':fields.float('Mar'),
            'abr':fields.float('Abr'),
            'maio':fields.float('Maio'),
            'jun':fields.float('Jun'),
            'jul':fields.float('Jul'),
            'ago':fields.float('Ago'),
            'set':fields.float('Set'),
            'out':fields.float('Out'),
            'nov':fields.float('Nov'),
            'dez':fields.float('Dez'),
            
            'total_mp':fields.function(_calculador_primaria_total, type='float', string='Total', method=True, store=True),
            'jan_mp':fields.function(_calculador_primaria_jan, type='float', string='Jan', method=True, store=True),
            'fev_mp':fields.function(_calculador_primaria_fev, type='float', string='Fev', method=True, store=True),
            'mar_mp':fields.function(_calculador_primaria_mar, type='float', string='Mar', method=True, store=True),
            'abr_mp':fields.function(_calculador_primaria_abr, type='float', string='Abr', method=True, store=True),
            'maio_mp':fields.function(_calculador_primaria_maio, type='float', string='Maio', method=True, store=True),
            'jun_mp':fields.function(_calculador_primaria_jun, type='float', string='Jun', method=True, store=True),
            'jul_mp':fields.function(_calculador_primaria_jul, type='float', string='Jul', method=True, store=True),
            'ago_mp':fields.function(_calculador_primaria_ago, type='float', string='Ago', method=True, store=True),
            'set_mp':fields.function(_calculador_primaria_set, type='float', string='Set', method=True, store=True),
            'out_mp':fields.function(_calculador_primaria_out, type='float', string='Out', method=True, store=True),
            'nov_mp':fields.function(_calculador_primaria_nov, type='float', string='Nov', method=True, store=True),
            'dez_mp':fields.function(_calculador_primaria_dez, type='float', string='Dez', method=True, store=True),
            
            'total_ms':fields.function(_calculador_secundaria_total, type='float', string='Total', method=True, store=True),
            'jan_ms':fields.function(_calculador_secundaria_jan, type='float', string='Jan', method=True, store=True),
            'fev_ms':fields.function(_calculador_secundaria_fev, type='float', string='Fev', method=True, store=True),
            'mar_ms':fields.function(_calculador_secundaria_mar, type='float', string='Mar', method=True, store=True),
            'abr_ms':fields.function(_calculador_secundaria_abr, type='float', string='Abr', method=True, store=True),
            'maio_ms':fields.function(_calculador_secundaria_maio, type='float', string='Maio', method=True, store=True),
            'jun_ms':fields.function(_calculador_secundaria_jun, type='float', string='Jun', method=True, store=True),
            'jul_ms':fields.function(_calculador_secundaria_jul, type='float', string='Jul', method=True, store=True),
            'ago_ms':fields.function(_calculador_secundaria_ago, type='float', string='Ago', method=True, store=True),
            'set_ms':fields.function(_calculador_secundaria_set, type='float', string='Set', method=True, store=True),
            'out_ms':fields.function(_calculador_primaria_out, type='float', string='Out', method=True, store=True),
            'nov_ms':fields.function(_calculador_secundaria_nov, type='float', string='Nov', method=True, store=True),
            'dez_ms':fields.function(_calculador_secundaria_dez, type='float', string='Dez', method=True, store=True),
            
            'tipo_rubrica':fields.selection([
                                        ('receita','Receita'),
                                        ('despesas','Despesas')
                                        ], 'Tipo', readonly=False,required=True, states={'rascunho':[('readonly',False)]}),
            
            'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', required=True, domain="[('orcamentavel','=',True),('tipo_rubrica','=',tipo_rubrica)]" ),
            
            'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=False,readonly=False, ),
            'cambio': fields.float('Câmbio'),
            'cambio_secundario': fields.float('Câmbio Secundário'),
            'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orcamento',required=False),
            'orcamento_geral_id':fields.many2one('dotcom.gestao.projectos.orcamento.geral','Orcamento Geral'),
            'state':fields.related('orcamento_id','state',type='char',relation='dotcom.gestao.projectos.orcamento',string='Estado'),
            'state_2':fields.related('orcamento_geral_id','state',type='char',relation='dotcom.gestao.projectos.orcamento.geral',string='Estado'),
            
            #'visualizacao_mp_id':fields.many2one('dotcom.contabilidade.visualizacao.orcamnto','Visualizacao'),
            #'visualizacao_ms_id':fields.many2one('dotcom.contabilidade.visualizacao.orcamnto','Visualizacao'),
    }
    
    _rec_name='conta'
    
    
    
    #def create(self,cr,uid,value,context={}):
    #    if context is None:
    #        context={}
    #        cambio_primario=value['cambio']
    #        cambio_secundario=value['cambio_secundario']
    
    _defaults={
        'tipo_rubrica': lambda self, cr, uid, c: c.get('tipo_rubrica', False),
        'ano_fiscal_id':lambda self, cr, uid, c: c.get('ano_fiscal_id', False),
        'moeda_lancamento_id': lambda self, cr, uid, c: c.get('moeda_lancamento_id', False),
        'projecto_id':lambda self, cr, uid, c: c.get('projecto_id', False),
        'cambio':lambda self, cr, uid, c: c.get('cambio', 0),
        'cambio_secundario': lambda self, cr, uid, c: c.get('cambio_secundario', 0),
        
    }
    
    def on_change_conta(self,cr,uid,ids,conta_id,context={}):
        if context is None: context={}
        if bool(conta_id)==True:
            conta=self.pool.get('dotcom.contabilidade.plano.contas').browse(cr,uid,conta_id)
            logger.info('CONTA %s' %str(conta))
            if (conta.tipo_interno!='m'):
                raise osv.except_osv(_('Acção Invalida !'), _('Tipo de Conta '+str(conta.ref)+' Nao Permitido!!'))
        return{}
    
    
    def on_change_rubrica(self,cr,uid,ids,rubrica_id,context=None):
        if context is None:
            context={}
        
        if rubrica_id:
            rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica_id)
            if(rubrica_object.tipo_interno!='m'):
                raise osv.except_osv(_('Invalid action !'), _('Tipo de Rubrica não permitido.!'))
            
        return {}
    
    
    def on_change_distribuir(self,cr,uid,ids,distribuir,total,context=None):
        if context==None:
            context={}
        val={}
        if distribuir==True:
            valor=total/12
            val={
                'igualar':False,
                'calcular':False,
                'jan':valor,
                'fev':valor,
                'mar':valor,
                'abr':valor,
                'maio':valor,
                'jun':valor,
                'jul':valor,
                'ago':valor,
                'set':valor,
                'out':valor,
                'nov':valor,
                'dez':valor,
            }
        return {'value':val}
        
    def on_change_igualar(self,cr,uid,ids,igualar,total,context=None):
        if context==None:
            context={}
        val={}
        if igualar==True:
            val={
                'calcular':False,
                'distribuir':False,
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
        return {'value':val}
        
    def on_change_calcular(self,cr,uid,ids,calcular,context=None):
        if context==None:
            context={}
        val={}
        if calcular==True:
            val={
                'igualar':False,
                'distribuir':False,
            }
        return {'value':val}
        
        
    def on_change_total(self,cr,uid,ids,total,distribuir,igualar,context=None):
        if context is None:
            context={}
        val={}
        logger.info('DIST %s' %str(distribuir))
        logger.info('IGUA %s' %str(igualar))
        if distribuir==True:
            logger.info('DISTRIBUIR')
            total=total/12
            val={
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
        elif igualar==True:
            val={
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
            
        return {'value':val}
    
    def on_change_jan(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        logger.info('CAMPO %s' %str(jan))
        #if calcular==True:
        total=jan+fev+mar+abr+mar+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
    
    def on_change_feb(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_mar(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
    
    def on_change_abr(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_maio(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_jun(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_jul(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_ago(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_set(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_out(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_nov(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_dez(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
            
    def create(self, cr, uid, values, context=None):
        if context is None:
            context = {}
            
        rubrica_id = values.get('rubrica_id')
        rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica_id)
        identificador=None
        if(rubrica_object.tipo_interno!='m'):
            raise osv.except_osv(_('Invalid action !'), _('Tipo de Rubrica não permitido.!'))
        else:
            identificador=  super(dotcom_gestao_projectos_orcamentos_linhas, self).create(cr, uid, values, context=context)
        return identificador 
    
dotcom_gestao_projectos_orcamentos_linhas()



class dotcom_gestao_projectos_orcamento_geral(osv.osv):
    
    def cambio_secundario(self,cr,uid,context=None):
        if context is None:
            context={}
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr,uid, context=context)
        cambio=1
        moeda_secund=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
        logger.info('MOEDA SECUNDARIA CAMBIO %s' %str(moeda_secund.rate))
        return moeda_secund.rate
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.decricao or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    
    _name='dotcom.gestao.projectos.orcamento.geral'
    _columns={
        'data':fields.date('Data',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        #'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        #'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', domain="[('projecto_id','=',projecto_id)]", required=False),
        'ref':fields.char('Ref.', size=50, required=True, readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'decricao':fields.char('Orçamento',required=True, size=100,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True,readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]} ),
        'cambio_secundario':fields.float('Câmbio MP/MS', help="Câmbio para a moeda Secundaria(MP/MS)",readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        
        'state':fields.selection([
                    ('rascunho','Rascunho'),
                    ('emitido','Emitido'),
                    ('cancelado','Cancelado'),
                    ('outro_rascunho','Rascunho'),
                    ],'Estado'),
        
        
        'tipo_rubrica':fields.selection([
                                        ('receita','Receita'),
                                        ('despesas','Despesas')
                                        ], 'Tipo', readonly=True,required=False, states={'rascunho':[('readonly',False)]}),
        
        'orcamentos_programas_ids':fields.one2many('dotcom.gestao.projectos.orcamentos.linhas','orcamento_geral_id','Orcamentos',readonly=True, states={'rascunho':[('readonly',False)],'outro_rascunho':[('readonly',False)]}),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=False),
    }
    
    _defaults={
        'data':lambda *a: time.strftime('%Y-%m-%d'),
        'state':'rascunho',
        'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
        #'titular':validator.getCompany,
    }
    _rec_name='friendly_name'


    _sql_constraints = [
        ('name_uniq', 'unique (ref,ano_fiscal_id)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    def criar_ano_seguinte(self, cr,uid,ids,context=None):
        if context is None:
            context ={}
        
        identificador=None
        for documento in self.browse(cr,uid,ids):
            anos_ficais_seguintes=self.pool.get('configuration.fiscalyear').search(cr,uid,[('date_start','>',documento.ano_fiscal_id.date_stop)])
            
            if len(anos_ficais_seguintes)<=0:
                raise osv.except_osv(_('Invalid action !'), _('Não existe ano seguinte para ser orçamentado!'))
            else:
                data=datetime.now()
                val={
                    'data':data,
                    'ano_fiscal_id':anos_ficais_seguintes[0],
                    'projecto_id':documento.projecto_id.id,
                    'ref':documento.ref,
                    'decricao':documento.decricao,
                    'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                    'cambio':documento.cambio,
                    'cambio_secundario':documento.cambio_secundario,
                    'percentagem':10,
                    'orcamento_id':documento.id,
                }
                
                if bool(documento.programa_id.id)!=False:
                    val['programa_id']=documento.programa_id.id
                    
                identificador=self.pool.get('dotcom.gestao.projectos.orcamento.copia').create(cr,uid,val)
                
        return {
                'type': 'ir.actions.act_window',
                'name': 'Criar Orçamento do ano seguinte',
                'view_mode': 'form',
                'view_type': 'form',
                'res_model': 'dotcom.gestao.projectos.orcamento.copia',
                'res_id':identificador,
                'target': 'new',
                'context': context,
                'nodestroy': True,
            }
    
    
    def on_change_moeda(self,cr,uid,ids,moeda_id,context=None ):
        if context is None:
            context={}

        val={}
        if moeda_id:
            moeda = self.pool.get('res.currency').browse(cr, uid, moeda_id)
            cambio = moeda.rate or 1
            val={'cambio':cambio}    
            
        return {'value':val}
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
    
    def emitir_orcamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            if len(documento.orcamentos_programas_ids)<=0:
                raise osv.except_osv(_('Error !'), _('Orçamento sem linhas'))
            
            self.write(cr,uid,documento.id,{'state':'emitido'})
        return True
    
    
    def voltar_rascunho_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
            
        return True
        
    
    def cancelar_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'cancelado'})
            
        return True
    
       
dotcom_gestao_projectos_orcamento_geral()


class dotcom_custos_centro_orcamentos(osv.osv):
    
    _name='dotcom.custos.centro.orcamentos'
    
    _columns={
            #'centro':fields.many2one('dotcom.contabilidade.conta.centro.custos','Centro de Custo',size=20, required=True),
            'total':fields.float('Total'),
            'jan':fields.float('Jan'),
            'fev':fields.float('Fev'),
            'mar':fields.float('Mar'),
            'abr':fields.float('Abr'),
            'maio':fields.float('Maio'),
            'jun':fields.float('Jun'),
            'jul':fields.float('Jul'),
            'ago':fields.float('Ago'),
            'set':fields.float('Set'),
            'out':fields.float('Out'),
            'nov':fields.float('Nov'),
            'dez':fields.float('Dez'),
            'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento'),
    }
    
    _defaults = {
        'orcamento_id': lambda self, cr, uid, c: c.get('orcamento_id', False)
    }
    
    _rec_name='conta'


class dotcom_gestao_projectos_orcamento_copia(osv.osv):
        
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.decricao or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    
    _name='dotcom.gestao.projectos.orcamento.copia'
    _columns={
        'data':fields.date('Data',required=True,),
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=True,),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=True,),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', domain="[('projecto_id','=',projecto_id)]", required=False),
        'ref':fields.char('Ref.', size=50, required=True,),
        'decricao':fields.char('Orçamento',required=True, size=100,),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=True, ),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)", ),
        'cambio_secundario':fields.float('Câmbio MP/MS', help="Câmbio para a moeda Secundaria(MP/MS)",readonly=False, ),
        
        'percentagem':fields.float('Percentage(%)',required=True),
        'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orcamento', required=True,),
        'orcamentos_programas_ids':fields.one2many('dotcom.gestao.projectos.orcamentos.linhas.copia','orcamento_id','Orcamentos',readonly=False, ),
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=False),
    }
    
    
    _defaults={
        'data':lambda *a: time.strftime('%Y-%m-%d'),
        'percentagem':10,
        #'cambio_secundario':lambda self,cr,uid,c: self.cambio_secundario(cr, uid, context=c),
        #'titular':validator.getCompany,
    }
    _rec_name='friendly_name'


    #_sql_constraints = [
    #    ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    #]
    
    def carregar_linhas(self, cr,uid,ids,context=None):
        if context is None:
            context ={}
            
        for documento in self.browse(cr,uid,ids):
            for linha in documento.orcamentos_programas_ids:
                self.pool.get('dotcom.gestao.projectos.orcamentos.linhas.copia').unlink(cr,uid,linha.id)
            
            for linha in documento.orcamento_id.orcamentos_programas_ids:
                jan=linha.jan+linha.jan*documento.percentagem
                fev=linha.fev+linha.fev*documento.percentagem
                mar=linha.mar+linha.mar*documento.percentagem
                abr=linha.abr+linha.abr*documento.percentagem
                maio=linha.maio+linha.maio*documento.percentagem
                jun=linha.jun+linha.jun*documento.percentagem
                jul=linha.jul+linha.jul*documento.percentagem
                ago=linha.ago+linha.ago*documento.percentagem
                set=linha.set+linha.set*documento.percentagem
                out=linha.out+linha.out*documento.percentagem
                nov=linha.nov+linha.nov*documento.percentagem
                dez=linha.dez+linha.dez*documento.percentagem
                total=linha.total+linha.total*documento.percentagem
                
                val={
                    'igualar':False,
                    'calcular':False,
                    'jan':jan,
                    'fev':fev,
                    'mar':mar,
                    'abr':abr,
                    'maio':maio,
                    'jun':jun,
                    'jul':jul,
                    'ago':ago,
                    'set':set,
                    'out':out,
                    'nov':nov,
                    'dez':dez,
                    'total':total,
                    'orcamento_id':documento.id,
                    'ano_fiscal_id':documento.ano_fiscal_id.id,
                    'projecto_id':documento.projecto_id.id,
                    'rubrica_id':linha.rubrica_id.id,
                    'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                    'cambio':documento.cambio,
                    'cambio_secundario':documento.cambio_secundario
                }
                
                self.pool.get('dotcom.gestao.projectos.orcamentos.linhas.copia').create(cr,uid,val)
        return True        
    
    
    def confirmar_criacao(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            val={
                'data':documento.data,
                'ano_fiscal_id':documento.ano_fiscal_id.id,
                'projecto_id':documento.projecto_id.id,
                'ref':documento.ref,
                'decricao':documento.decricao,
                'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                'cambio':documento.cambio,
                'cambio_secundario':documento.cambio_secundario,
                'state':'rascunho',
                #'orcamento_id':documento.id,
            }
                
            if bool(documento.programa_id.id)!=False:
                val['programa_id']=documento.programa_id.id
            
            orcamento_id=self.pool.get('dotcom.gestao.projectos.orcamento').create(cr,uid,val)
            
            for linha in documento.orcamentos_programas_ids:
                val={
                    'igualar':False,
                    'calcular':False,
                    'jan':linha.jan,
                    'fev':linha.fev,
                    'mar':linha.mar,
                    'abr':linha.abr,
                    'maio':linha.maio,
                    'jun':linha.jun,
                    'jul':linha.jul,
                    'ago':linha.ago,
                    'set':linha.set,
                    'out':linha.out,
                    'nov':linha.nov,
                    'dez':linha.dez,
                    'total':linha.total,
                    'orcamento_id':orcamento_id,
                    'ano_fiscal_id':documento.ano_fiscal_id.id,
                    'projecto_id':documento.projecto_id.id,
                    'rubrica_id':linha.rubrica_id.id,
                    'moeda_lancamento_id':documento.moeda_lancamento_id.id,
                    'cambio':documento.cambio,
                    'cambio_secundario':documento.cambio_secundario
                }
                
                self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').create(cr,uid,val)
            
        return {}
    
    
    def on_change_moeda(self,cr,uid,ids,moeda_id,context=None ):
        if context is None:
            context={}

        val={}
        if moeda_id:
            moeda = self.pool.get('res.currency').browse(cr, uid, moeda_id)
            cambio = moeda.rate or 1
            val={'cambio':cambio}    
            
        return {'value':val}
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
    
    def emitir_orcamento(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
        for documento in self.browse(cr,uid,ids):
            if len(documento.orcamentos_programas_ids)<=0:
                raise osv.except_osv(_('Error !'), _('Orçamento sem linhas'))
            
            self.write(cr,uid,documento.id,{'state':'emitido'})
        return True
    
    
    def voltar_rascunho_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        for documento in self.browse(cr,uid,ids):
            self.write(cr,uid,documento.id,{'state':'outro_rascunho'})
            
        return True
        
    
    def cancelar_orcamentos(self,cr,uid,ids,context=None):
        if context is None:
            context={}
        
            
        return {}
    
    
dotcom_gestao_projectos_orcamento_copia()



class dotcom_gestao_projectos_orcamentos_linhas_copia(osv.osv):
    
    _name='dotcom.gestao.projectos.orcamentos.linhas.copia'
    _columns={
            #'conta':fields.many2one('dotcom.contabilidade.plano.contas','Conta',size=20, required=True, domain="[('ano_fiscal_id','=',ano_fiscal_id)]"),
            'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',required=False),
            'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=True),
            'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', required=True ),
            'doador_id':fields.many2one('dotcom.gestao.projectos.doador.projecto','Doador', domain="[('projecto_id','=',projecto_id)]", required=False),
            'distribuir':fields.boolean('Distribuir', help="Distribuir o Valor total pelos Periodos"),
            'igualar':fields.boolean('I', help="Igualar o valor Total a todos os Periodos"),
            'calcular':fields.boolean('C'),
            'total':fields.float('Total'),
            'jan':fields.float('Jan'),
            'fev':fields.float('Fev'),
            'mar':fields.float('Mar'),
            'abr':fields.float('Abr'),
            'maio':fields.float('Maio'),
            'jun':fields.float('Jun'),
            'jul':fields.float('Jul'),
            'ago':fields.float('Ago'),
            'set':fields.float('Set'),
            'out':fields.float('Out'),
            'nov':fields.float('Nov'),
            'dez':fields.float('Dez'),
            
            
            'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=False,readonly=False, ),
            'cambio': fields.float('Câmbio'),
            'cambio_secundario': fields.float('Câmbio Secundário'),
            'orcamento_id':fields.many2one('dotcom.gestao.projectos.orcamento.copia','Orcamento',required=False),
            #'state':fields.related('orcamento_id','state',type='char',relation='dotcom.gestao.projectos.orcamento',string='Estado'),
            
            #'visualizacao_mp_id':fields.many2one('dotcom.contabilidade.visualizacao.orcamnto','Visualizacao'),
            #'visualizacao_ms_id':fields.many2one('dotcom.contabilidade.visualizacao.orcamnto','Visualizacao'),
    }
    
    _rec_name='conta'
    
    
    
    
    def on_change_distribuir(self,cr,uid,ids,distribuir,total,context=None):
        if context==None:
            context={}
        val={}
        if distribuir==True:
            valor=total/12
            val={
                'igualar':False,
                'calcular':False,
                'jan':valor,
                'fev':valor,
                'mar':valor,
                'abr':valor,
                'maio':valor,
                'jun':valor,
                'jul':valor,
                'ago':valor,
                'set':valor,
                'out':valor,
                'nov':valor,
                'dez':valor,
            }
        return {'value':val}
        
    def on_change_igualar(self,cr,uid,ids,igualar,total,context=None):
        if context==None:
            context={}
        val={}
        if igualar==True:
            val={
                'calcular':False,
                'distribuir':False,
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
        return {'value':val}
        
    def on_change_calcular(self,cr,uid,ids,calcular,context=None):
        if context==None:
            context={}
        val={}
        if calcular==True:
            val={
                'igualar':False,
                'distribuir':False,
            }
        return {'value':val}
               
    def on_change_total(self,cr,uid,ids,total,distribuir,igualar,context=None):
        if context is None:
            context={}
        val={}
        logger.info('DIST %s' %str(distribuir))
        logger.info('IGUA %s' %str(igualar))
        if distribuir==True:
            logger.info('DISTRIBUIR')
            total=total/12
            val={
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
        elif igualar==True:
            val={
                'jan':total,
                'fev':total,
                'mar':total,
                'abr':total,
                'maio':total,
                'jun':total,
                'jul':total,
                'ago':total,
                'set':total,
                'out':total,
                'nov':total,
                'dez':total,
            }
            
        return {'value':val}
    
    def on_change_jan(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        logger.info('CAMPO %s' %str(jan))
        #if calcular==True:
        total=jan+fev+mar+abr+mar+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
    
    def on_change_feb(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_mar(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
    
    def on_change_abr(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_maio(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_jun(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_jul(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_ago(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_set(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_out(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_nov(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
        
    def on_change_dez(self,cr,uid,ids,jan,fev,mar,abr,maio,jun,jul,ago,sete,out,nov,dez,context=None):
        if context is None:
            context={}
        val={}
        total=jan+fev+mar+abr+maio+jun+jul+ago+sete+out+nov+dez
        val={'total':total}
        return {'value':val}
            
    def create(self, cr, uid, values, context=None):
        if context is None:
            context = {}
            
        rubrica_id = values.get('rubrica_id')
        rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica_id)
        identificador=None
        #if(rubrica_object.tipo_interno!='m'):
        #    raise osv.except_osv(_('Invalid action !'), _('Tipo de Rubrica não permitido.!'))
        #else:
        identificador=  super(dotcom_gestao_projectos_orcamentos_linhas_copia, self).create(cr, uid, values, context=context)
        return identificador 
    
dotcom_gestao_projectos_orcamentos_linhas_copia()