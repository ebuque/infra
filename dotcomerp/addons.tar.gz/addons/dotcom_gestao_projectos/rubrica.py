# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
import logging
from validators import validator
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')

class dotcom_gestao_projectos_rubricas(osv.osv):
    
    def _friendly_name(self, cr, uid, ids, field, arg, context=None):
        res = {}
        for conta in self.browse(cr, uid, ids, context=context):
            ref = conta.ref and conta.ref or ''
            nome = conta.nome or ''
            friendly_name = '['+ref + '] ' + nome
            res[conta.id] = friendly_name
        return res
    
    _name='dotcom.gestao.projectos.rubrica'
    _columns={
        'ref':fields.char('Ref',size=50,required=True),
        'nome':fields.char('Descicao', size=100, required=True),
        #'descricao':fields.text('Descricao',required=True),
        'tipo_rubrica':fields.selection([
                                        ('receita','Receita'),
                                        ('despesas','Despesas')
                                        ], 'Tipo', readonly=True, states={'rascunho':[('readonly',False)]}),
        'tipo_movimento':fields.selection([
                                            ('credito','Credito'),
                                            ('debito','Debito')
                                            ],'Tipo Movimento'),
        
        'orcamentavel':fields.boolean('Sujeito a orçamento'),
        
        'state':fields.selection([('rascunho','Rascunho'),('emitida','Emitida')],'Estado'),
        
        'friendly_name': fields.function(_friendly_name, type='char', string='Conta', method=True, store=True),
        
        'parent_id': fields.many2one('dotcom.gestao.projectos.rubrica', 'Ascendente', required=False, ondelete="cascade"),
        'child_id': fields.one2many('dotcom.gestao.projectos.rubrica', 'parent_id', string='Sub-contas', readonly=True),
        'tipo_interno':fields.selection([('r','Razão'),('t','Totalizadora'),('m','Movimento')],'Tipo Interno'),
        
        #'plano_conta_id':fields.many2one('dotcom.contabilidade.plano.contas','Plano Contas', required=False,),
    }
    
    _rec_name='friendly_name'
    
    _order='ref asc'
    
    _defaults={
        'state':'rascunho'
    }
    
    _sql_constraints = [
        ('name_uniq', 'unique (ref)', 'A Referência seleccionada já está em uso, por favor seleccione outra !'),
    ]
    
    
    def on_change_referencia(self,cr,uid,ids,referencia,context=None ):
        if context is None:
            context={}
            
        referencia=validator.validar_referencias(cr,uid,referencia)
        return{'value':{'ref':referencia}}
    
 
    def on_change_tipo_rubrica(self,cr,uid,ids,tipo,context={}):
        if context is None:
            context=None
        
        val={}
        if tipo=='receita':
            val['tipo_movimento']='debito'
        elif tipo=='dispesas':
            val['tipo_movimento']='credito'
        return {'value':val}
    
    
    def write_recursive(self, cr, uid, conta_id, context=None):
        if context is None:
            context = {}
        conta = self.browse(cr, uid, conta_id)
        if conta.parent_id:
            self.write_recursive(cr, uid, conta.parent_id.id, context=context)
            if conta.child_id:
                logger.info('A definir conta como Tot')
                self.write(cr, uid, conta.id, {'tipo_interno':'t'})
            else:
                logger.info('A definir conta parent como Mov')
                self.write(cr, uid, conta.id, {'tipo_interno':'m'})
        else:
            if len(conta.ref)>2:
                logger.info('A definir conta como Tot')
                self.write(cr, uid, conta.id, {'tipo_interno':'t'})
            else:
                logger.info('A definir conta como Tot')
                self.write(cr, uid, conta.id, {'tipo_interno':'r'})
        return True
    
    
    def write_recursive_children(self, cr, uid, conta_id ,context=None):
        if context is None:
            context = {}
        conta = self.browse(cr, uid, conta_id, context=context)
        if conta.child_id:
            for child in conta.child_id:
                if child.child_id:
                    self.write_recursive_children(cr, uid, child.id, context=context)
            if len(conta.ref)==2:
                logger.info('A definir conta como Razao')
                self.write(cr, uid, conta.id, {'tipo_interno':'r'})
            else:
                logger.info('A definir conta parent como Totalizadora')
                self.write(cr, uid, conta.id, {'tipo_interno':'t'})
        else:
            if len(conta.ref)==2:
                logger.info('A definir conta como Razao')
                self.write(cr, uid, conta.id, {'tipo_interno':'r'})
            else:
                logger.info('A definir conta parent como Movimento')
                self.write(cr, uid, conta.id, {'tipo_interno':'m'})
                
        return True    
    
    
    def create(self, cr, uid, values, context=None):
        if context is None:
            context = {}
            
        conta = values.get('ref')
        logger.info('CONTA ACHADA %s' %str(conta))
        #ano_fiscal_id=values['ano_fiscal_id']
        nada = validator.validar_numero_caracteres(cr, uid, conta, context=context)
        pai_id = validator.get_rubrica_ascendente(cr, uid, conta, context=context)
        logger.info('A iniciar processo de criação de Conta ref: %s' %str (conta))
        #logger.info('Resultado de procura de conta ascendente, ID: %s' % pai_id)
        if pai_id is None:
            logger.info('Conta ascendente não existe, a iniciar verificações')
            if len(conta)>2:
                #logger.info('Conta possui mais de dois digitos, a iniciar processo de criação de conta ascendente')
                father_values = values.copy()
                ##logger.info('Conta copiada, a definir valores')
                father_values['ref'] = conta[:2]
                father_values['tipo_interno'] = 'r'
                father_values['nome']='CONTA '+str(conta[:2])
                #logger.info('Valores definidos, ref: %s, tipo interno: Razão' % father_values.get('ref'))
                father = super(dotcom_gestao_projectos_rubricas, self).create(cr, uid, father_values, context=context)
                #logger.info('Conta ascendente criada, a definir na conta a criar %s' %father)
                values['parent_id'] = father
            else:
                #logger.info('Conta possui 2 digitos, será definida como conta de Razão')
                values['parent_id'] = None
                values['tipo_interno'] = 'r'
        else:
            values['parent_id'] = pai_id
        #logger.info('A criar conta...')
        base = super(dotcom_gestao_projectos_rubricas, self).create(cr, uid, values, context=context)
        
        #logger.info('Conta criada com ID: %s' % base)
        #logger.info('Inicio do processo de actualização de contas semelhantes')
        sons = self.search(cr, uid, [
                            ('ref','like',conta),
                            #('ano_fiscal_id','=',ano_fiscal_id)
                        ])
        #logger.info('Resultado da procura de Semelhantes: %s' %sons)
        #logger.info('..............................................................')
        if sons and len(sons)>0:
            #logger.info('A ordenar lista: %s' %sons)
            sons = sorted(sons)
            #logger.info('Lista ordenada: %s' %sons)
            reads = self.read(cr, uid, sons, ['ref','id','child_id'])
            reads = sorted(reads, key=lambda d: (d['id'], d['ref']), reverse=True)
            #logger.info('A ler valores e actualizar cada conta')
            for read in reads:
                #logger.info('A processar: %s' % read)
                me = read['id']
                my_ref = read['ref']
                my_father = validator.get_rubrica_ascendente(cr, uid, my_ref, context=context)
                self.write(cr, uid, me, {'parent_id':my_father})
        test = self.write_recursive(cr, uid, base, context=context)
        again = self.write_recursive_children(cr, uid, base, context=context)
        
        base_object=self.browse(cr,uid,base)
        #ano_fiscal_id=base_object.ano_fiscal_id.id
        #logger.info('ANO FISCAL ID %s' %str(ano_fiscal_id))
        parent_id=base_object.parent_id.id
        #logger.info('PARENTE ID %s' %str(parent_id))
        
        #lista_lancamentos=self.verificar_existencia_lancamentos(cr,uid,parent_id,ano_fiscal_id)
        #if len(lista_lancamentos)>0:
        #    
        #    for lancamento in lista_lancamentos:
        #        self.pool.get('dotcom.contabilidade.lancamentos.diarios').write(cr,uid,lancamento,{'conta_id':base})
        #        
        return base
    
    
    #def unlink(self,cr,uid,ids,context=None):
    #    if context is None:
    #        context={}
    #        
    #    plano_contas=self.browse(cr,uid,ids,context)
    #    lista_apagavel=[]
    #    for conta in plano_contas:
    #        #if len(conta.lancametos_contas_centros_ids)>0:
    #        #    raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover este Centro de Custos pois já tem movimentos emitidos.!'))
    #        if conta.tipo_interno!='m' and len(conta.child_id)>0:
    #            raise osv.except_osv(_('Invalid action !'), _('Não é possivel remover este Centro de Custos pois tem sub contas.!'))
    #        
    #        if conta.tipo_interno=='m' :
    #            lista_apagavel.append(conta.id)
    #            
    #            if len(conta.parent_id.ref)>2 and (conta.parent_id.tipo_interno=='t' and len(conta.parent_id.child_id))==1:
    #                self.write(cr,uid,conta.parent_id.id,{'tipo_interno':'m'})
    #                logger.info('CONTA ASCENDENTE PASSA A SER Movimento')
    #            
    #            osv.osv.unlink(self, cr, uid, lista_apagavel, context=context)
    #       
    #    return True
    
    
dotcom_gestao_projectos_rubricas()