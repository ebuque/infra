# -*- coding: utf-8 -*-

import jasper_reports
from osv import osv,fields
from datetime import datetime,timedelta
import time
import os
import pooler
from tools.translate import _
import logging
logger = logging.getLogger('jasper_report_resumo')
#from dotcom_doc import JasperDataParser
from dotcom_contabilidade import JasperDataParser


class analise_comparativa_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(analise_comparativa_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
    
        
        label='Análise Comparativa(Detalhada)'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name          
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        analise_comparativa = pool.get('gestao.projectos.analise.orcamental.comparativa').browse(cr,uid,ids[0])
        ano_fiscal=analise_comparativa.ano_fiscal_id.code
        tipo_analise=analise_comparativa.tipo_analise
        
        periodo=''
        if tipo_analise=='mensal':
            periodo=analise_comparativa.periodo_id.name
            tipo_analise='Mensal'
        elif tipo_analise=='trimestral':
            tipo_analise='Trimestral'
            if analise_comparativa.periodo_trimestral=='primero_trimestre':
                periodo='Primeiro Trimestre'
            elif analise_comparativa.periodo_trimestral=='segundo_trimestre':
                periodo='Segundo Trimestre'
            elif analise_comparativa.periodo_trimestral=='terceiro_trimestre':
                periodo='Terceiro Trimestre'
            elif analise_comparativa.periodo_trimestral=='quarto_trimestre':
                periodo='Qualro Trimestre'
        elif tipo_analise=='anual':
            tipo_analise='Anual'
            periodo='Janeiro - Dezembro'
            
        orcamento_receitas=analise_comparativa.orcamento_receita_id.friendly_name
        orcamento_despesas=analise_comparativa.orcamento_despesas_id.friendly_name
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        moeda=None
        conversao_moeda=analise_comparativa.conversao_moeda
        if conversao_moeda=='mp':
            moeda='Moeda : '+str(moeda_primaria.name)+''
        elif conversao_moeda=='ms':
            moeda='Moeda : '+str(moeda_secundaria.name)+''
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S')) 
       
        
        totais_analise_comparativa=analise_comparativa.analise_linhas_ids[0]
        
        total_orcamento_receita=totais_analise_comparativa.total_orcamento_receita
        total_orcamento_despesa=totais_analise_comparativa.total_orcamento_despesas
        total_desvio=totais_analise_comparativa.desvio
        total_desvio_percentagem=totais_analise_comparativa.desvio_percentual
        
        logger.info('VALOR ACHADO NA ANALISE %s ' %str(total_orcamento_receita))
        logger.info('VALOR ACHADO NA ANALISE %s ' %str(total_orcamento_despesa))
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fiscal or 'cambio_sec',
            'periodo':periodo or '',
            'orcamento_receitas':orcamento_receitas or '',
            'orcamento_despesas':orcamento_despesas or '',
            'tipo_analise':tipo_analise or '',
            'data_hora_lancamento':data_hora_lancamento or '',
            'moeda':moeda or '',
            
            'total_orcamento_receita':str(total_orcamento_receita) or '0',
            'total_orcamento_despesa':str(total_orcamento_despesa) or '0',
            'total_desvio':str(total_desvio) or '0',
            'total_desvio_percentagem':str(total_desvio_percentagem) or '0'
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        logger.info('PROCESSSO DE IMPRESSAO INICIADO')
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        analise_comparativa = pool.get('gestao.projectos.analise.orcamental.comparativa').browse(cr,uid,ids[0])
       
        if len(analise_comparativa.analise_detalhes_ids)>0:
            for lancamento in analise_comparativa.analise_detalhes_ids:
                
                periodo=lancamento.periodo_id.name
                orcamento_receita=lancamento.total_orcamento_receita
                orcamento_despesa=lancamento.total_orcamento_despesas
                desvio=lancamento.desvio
                desvio_percentual=lancamento.desvio_percentual
                
                data={
                    'periodo':periodo or '',
                    'orcamento_receita':orcamento_receita or '0',
                    'orcamento_despesa':orcamento_despesa or '0',
                    'desvio': desvio or '0',
                    'desvio_percentual': desvio_percentual or '0',
                }
                
                result.append(data)               

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        logger.info('#######  RESULTS DO REPORT: ###### %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_analise_orcamental_comparativa_report','gestao.projectos.analise.orcamental.comparativa',parser=analise_comparativa_parser)



class analise_comparativa_simples_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(analise_comparativa_simples_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
    
        
        label='Análise Comparativa'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name          
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        analise_comparativa = pool.get('gestao.projectos.analise.orcamental.comparativa').browse(cr,uid,ids[0])
        ano_fiscal=analise_comparativa.ano_fiscal_id.code
        tipo_analise=analise_comparativa.tipo_analise
        
        periodo=''
        if tipo_analise=='mensal':
            periodo=analise_comparativa.periodo_id.name
            tipo_analise='Mensal'
        elif tipo_analise=='trimestral':
            tipo_analise='Trimestral'
            if analise_comparativa.periodo_trimestral=='primero_trimestre':
                periodo='Primeiro Trimestre'
            elif analise_comparativa.periodo_trimestral=='segundo_trimestre':
                periodo='Segundo Trimestre'
            elif analise_comparativa.periodo_trimestral=='terceiro_trimestre':
                periodo='Terceiro Trimestre'
            elif analise_comparativa.periodo_trimestral=='quarto_trimestre':
                periodo='Qualro Trimestre'
        elif tipo_analise=='anual':
            tipo_analise='Anual'
            periodo='Janeiro - Dezembro'
            
        orcamento_receitas=analise_comparativa.orcamento_receita_id.friendly_name
        orcamento_despesas=analise_comparativa.orcamento_despesas_id.friendly_name
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        moeda=None
        conversao_moeda=analise_comparativa.conversao_moeda
        if conversao_moeda=='mp':
            moeda='Moeda : '+str(moeda_primaria.name)+''
        elif conversao_moeda=='ms':
            moeda='Moeda : '+str(moeda_secundaria.name)+''
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S')) 
       
        
        totais_analise_comparativa=analise_comparativa.analise_linhas_ids[0]

        
        
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fiscal or 'cambio_sec',
            'periodo':periodo or '',
            'orcamento_receitas':orcamento_receitas or '',
            'orcamento_despesas':orcamento_despesas or '',
            'tipo_analise':tipo_analise or '',
            'data_hora_lancamento':data_hora_lancamento or '',
            'moeda':moeda or '',
            
            
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        logger.info('##### PROCESSSO DE IMPRESSAO INICIADO #####')
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        analise_comparativa = pool.get('gestao.projectos.analise.orcamental.comparativa').browse(cr,uid,ids[0])
       
        if len(analise_comparativa.analise_linhas_ids)>0:
            for totais_analise_comparativa in analise_comparativa.analise_linhas_ids:
                
                total_orcamento_receita=totais_analise_comparativa.total_orcamento_receita
                total_orcamento_despesa=totais_analise_comparativa.total_orcamento_despesas
                total_desvio=totais_analise_comparativa.desvio
                total_desvio_percentagem=totais_analise_comparativa.desvio_percentual
                
                data={
                        'total_orcamento_receita':str(total_orcamento_receita) or '0',
                        'total_orcamento_despesa':str(total_orcamento_despesa) or '0',
                        'total_desvio':str(total_desvio) or '0',
                        'total_desvio_percentagem':str(total_desvio_percentagem) or '0'
                }
                
                result.append(data)               

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        logger.info('#######  RESULTS DO REPORT: ###### %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_analise_orcamental_comparativa_simples_report','gestao.projectos.analise.orcamental.comparativa',parser=analise_comparativa_simples_parser)