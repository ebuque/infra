# -*- coding: utf-8 -*-

import jasper_reports
from osv import osv,fields
from datetime import datetime,timedelta
import time
import os
import pooler
from tools.translate import _
import logging
logger = logging.getLogger('jasper_report_resumo')
#from dotcom_doc import JasperDataParser
from dotcom_contabilidade import JasperDataParser


class analise_orcamental_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(analise_orcamental_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
                
        
        label='Análise Orçamental'
            
        #licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_contabilidade',context)
        licenca = 'Nao Licenciado'
        #
        #logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
        
        analise=self.pool.get('dotcom.gestao.projectos.analise.orcamental').browse(cr,uid,ids[0])
        ano_fisacal=analise.ano_fiscal_id.name
        periodo='Período : '+str(analise.periodo_id.name)
        conversao_moeda=analise.conversao_moeda
        orcamento='Orçamento Comparativo : '+str(analise.orcamento_id.decricao)
        
        moeda=None
        if conversao_moeda=='mp':
            moeda='Moeda : '+str(moeda_primaria.name)+''
        elif conversao_moeda=='ms':
            moeda='Moeda : '+str(moeda_secundaria.name)+''
        
        
            
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fisacal or '',
            'moeda':moeda or '',
            'periodo':periodo or '',
            'orcamento':orcamento,
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        analise=self.pool.get('dotcom.gestao.projectos.analise.orcamental').browse(cr,uid,ids[0])
                
        if len(analise.linhas_analise_ids)>0:
            for linha in analise.linhas_analise_ids:
                doador=linha.doador_id.friendly_name
                rubrica=linha.rubrica_id.friendly_name
                valor_orcamentado=linha.valor_orcamentado
                valor_movimentado=linha.valor_movimentado
                desvio=linha.desvio
                percentagem=linha.percentagem
                data={

                    'doador':doador or '',
                    'rubrica':rubrica or '',
                    'valor_orcamentado':valor_orcamentado or '0',
                    'valor_movimentado': valor_movimentado or '0',
                    'desvio': desvio or '0',
                    'percentagem':percentagem or '0',   
                }
                result.append(data)
                #result = sorted(result, key=lambda d: (d['grupo']))                

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_analise_orcamental_report','dotcom.gestao.projectos.analise.orcamental',parser=analise_orcamental_parser)



class analise_orcamental_geral_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(analise_orcamental_geral_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
                
        
        label='Análise Orçamental Geral'
            
        #licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_contabilidade',context)
        licenca = 'Nao Licenciado'
        #
        #logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
        
        analise=self.pool.get('dotcom.gestao.projectos.analise.orcamental.global').browse(cr,uid,ids[0])
        ano_fisacal=analise.ano_fiscal_id.name
        periodo='Período : '+str(analise.periodo_id.name)
        conversao_moeda=analise.conversao_moeda
        orcamento='Orçamento Comparativo : '+str(analise.orcamento_id.decricao)
        
        moeda=None
        if conversao_moeda=='mp':
            moeda='Moeda : '+str(moeda_primaria.name)+''
        elif conversao_moeda=='ms':
            moeda='Moeda : '+str(moeda_secundaria.name)+''
        
        
            
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fisacal or '',
            'moeda':moeda or '',
            'periodo':periodo or '',
            'orcamento':orcamento,
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        analise=self.pool.get('dotcom.gestao.projectos.analise.orcamental.global').browse(cr,uid,ids[0])
                
        if len(analise.linhas_analise_ids)>0:
            for linha in analise.linhas_analise_ids:
                doador=linha.doador_id.friendly_name
                rubrica=linha.rubrica_id.friendly_name
                valor_orcamentado=linha.valor_orcamentado
                valor_movimentado=linha.valor_movimentado
                desvio=linha.desvio
                percentagem=linha.percentagem
                data={

                    'doador':doador or '',
                    'rubrica':rubrica or '',
                    'valor_orcamentado':valor_orcamentado or '0',
                    'valor_movimentado': valor_movimentado or '0',
                    'desvio': desvio or '0',
                    'percentagem':percentagem or '0',   
                }
                result.append(data)
                #result = sorted(result, key=lambda d: (d['grupo']))                

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_analise_orcamental_geral_report','dotcom.gestao.projectos.analise.orcamental',parser=analise_orcamental_geral_parser)




class orcamento_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(orcamento_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
                
        
        label='Orçamento'
            
        #licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_contabilidade',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        orcamento=self.pool.get('dotcom.gestao.projectos.orcamento').browse(cr,uid,ids[0])
        ano_fisacal=orcamento.ano_fiscal_id.name
        ref=orcamento.ref
        decricao=orcamento.decricao
        data=orcamento.data
        cambio=orcamento.cambio
        logger.info('CAMBIO ACHADO %s' %str(cambio))
        #periodo=analise.periodo_id.name
        cambio_secundario=orcamento.cambio_secundario
        logger.info('CAMBIO ACHADO %s' %str(cambio_secundario))
        moeda='Moeda : '+ str(orcamento.moeda_lancamento_id.ref)
        projecto=orcamento.projecto_id.friendly_name
            
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fisacal or '',
            'ref':ref or '',
            'decricao':decricao or '',
            'data':data or '',
            'moeda':moeda or '',
            'cambio':cambio or 1,
            'cambio_secundario':cambio_secundario or 1,
            'projecto':projecto or '',
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        lista_parentes=[]
        
        orcamento=self.pool.get('dotcom.gestao.projectos.orcamento').browse(cr,uid,ids[0])
                
        if len(orcamento.orcamentos_programas_ids)>0:
            lista_lacamentos=orcamento.orcamentos_programas_ids
            
            for linha in orcamento.orcamentos_programas_ids:
                if lista_parentes.__contains__(linha.rubrica_id.parent_id.id):
                    logger.info('parente encontrado')
                else:
                    lista_parentes.append(linha.rubrica_id.parent_id.id)
            
            
           
            for parente in lista_parentes:
                
                
                lancamentos_parentes_ids=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').search(cr,uid,[
                                                                                                        ('orcamento_id','=',orcamento.id),
                                                                                                        ])
                total_grupo=0
                total_grupo_jan=0
                total_grupo_fev=0
                total_grupo_mar=0
                total_grupo_abr=0
                total_grupo_maio=0
                total_grupo_jun=0
                total_grupo_jul=0
                total_grupo_ago=0
                total_grupo_set=0
                total_grupo_out=0
                total_grupo_nov=0
                total_grupo_dez=0
                for lancamento in lancamentos_parentes_ids:
                    lancamento=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').browse(cr,uid,lancamento)
                    
                    if lancamento.rubrica_id.parent_id.id==parente:
                        total_grupo=total_grupo+lancamento.total
                        total_grupo_jan=total_grupo_jan+lancamento.jan
                        total_grupo_fev=total_grupo_fev+lancamento.fev
                        total_grupo_mar=total_grupo_mar+lancamento.mar
                        total_grupo_abr=total_grupo_abr+lancamento.abr
                        total_grupo_maio=total_grupo_maio+lancamento.maio
                        total_grupo_jun=total_grupo_jun+lancamento.jun
                        total_grupo_jul=total_grupo_jul+lancamento.jul
                        total_grupo_ago=total_grupo_ago+lancamento.ago
                        total_grupo_set=total_grupo_set+lancamento.set
                        total_grupo_out=total_grupo_out+lancamento.out
                        total_grupo_nov=total_grupo_nov+lancamento.nov
                        total_grupo_dez=total_grupo_dez+lancamento.dez
                
                for lancamento in lancamentos_parentes_ids:
                    linha=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').browse(cr,uid,lancamento)
                    
                    if linha.rubrica_id.parent_id.id==parente:
                        rubrica=linha.rubrica_id.friendly_name
                        grupo=linha.rubrica_id.parent_id.friendly_name
                            
                        
                        jan=linha.jan
                        fev=linha.fev
                        mar=linha.mar
                        abr=linha.abr
                        maio=linha.maio
                        jun=linha.jun
                        jul=linha.jul
                        ago=linha.ago
                        set=linha.set
                        out=linha.out
                        nov=linha.nov
                        dez=linha.dez
                        total=linha.total
                        
                        data={
                            'rubrica':rubrica or '',
                            'grupo':grupo or '',
                            'jan':jan or '0',
                            'fev':fev or '0',
                            'mar': mar or '0',
                            'abr': abr or '0',
                            'maio':maio or '0',
                            'jun':jun or '0',
                            'jul':jul or '',
                            'ago':ago or '0',
                            'set': set or '0',
                            'out': out or '0',
                            'nov':nov or '0',
                            'dez': dez or '0',
                            'total':total or '0',
                            'total_grupo':total_grupo or '0',
                            'total_grupo_jan':total_grupo_jan or '0',
                            'total_grupo_fev':total_grupo_fev or '0',
                            'total_grupo_mar':total_grupo_mar or '0',
                            'total_grupo_abr':total_grupo_abr or '0',
                            'total_grupo_maio':total_grupo_maio or '0',
                            'total_grupo_jun':total_grupo_jun or '0',
                            'total_grupo_jul':total_grupo_jul or '0',
                            'total_grupo_ago':total_grupo_ago or '0',
                            'total_grupo_set':total_grupo_set or '0',
                            'total_grupo_out':total_grupo_out or '0',
                            'total_grupo_nov':total_grupo_nov or '0',
                            'total_grupo_dez':total_grupo_dez or '0',
                        }
                        result.append(data)
                
        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
    
        result = sorted(result, key=lambda d: (d['grupo']))    
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_orcamento_report','dotcom.gestao.projectos.orcamento',parser=orcamento_parser)