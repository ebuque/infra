# -*- coding: utf-8 -*-

import jasper_reports
from osv import osv,fields
from datetime import datetime,timedelta
import time
import os
import pooler
from tools.translate import _
import logging
logger = logging.getLogger('jasper_report_resumo')
from dotcom_contabilidade import JasperDataParser


class receitas_despesas_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(receitas_despesas_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
    
        
        label='Análise de Receitas e Despesas'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name          
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
                
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S')) 
       
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'data_hora_lancamento':data_hora_lancamento or '',
            #'numero_doc':numero_doc or ''
            #'data':data or '',
            #'moeda':moeda or ''
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        logger.info('####### PROCESSP DE MPRESSAO A SE INICIADO ######')
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        analise = pool.get('dotcom.gestao.projectos.analise.receitas.despesas').browse(cr,uid,ids[0])
       
        if len(analise.linhas_ids)>0:
            for lancamento in analise.linhas_ids:
                debito=lancamento.debito
                credito=lancamento.credito
                rubrica=lancamento.rubrica_id.friendly_name
                grupo=lancamento.rubrica_id.ref[:2]
                
                data={
                    'debito':debito or '0',
                    'credito':credito or '0',
                    'rubrica':rubrica or '',
                    'grupo': grupo or '',
                                    
                }
                
                result.append(data)
                result = sorted(result, key=lambda d: (d['grupo']))                

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        logger.info('#####RESULTS DO REPORT: %s' % result)

        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_analise_receita_despesas_report','dotcom.gestao.projectos.analise.receitas.despesas',parser=receitas_despesas_parser)