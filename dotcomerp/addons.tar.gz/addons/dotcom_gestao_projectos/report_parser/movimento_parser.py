# -*- coding: utf-8 -*-

import jasper_reports
from osv import osv,fields
from datetime import datetime,timedelta
import time
import os
import pooler
from tools.translate import _
import logging
logger = logging.getLogger('jasper_report_resumo')
#from dotcom_doc import JasperDataParser
from dotcom_contabilidade import JasperDataParser


class movimento_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(movimento_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
    
        
        label='Movimento'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name          
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        movimento = pool.get('dotcom.gestao.projectos.movimento').browse(cr,uid,ids[0])
        ano_fiscal=movimento.ano_fiscal_id.code
        ano_fiscal= 'Ano Fiscal :'+str(ano_fiscal)
        
        data=movimento.data
        data=datetime.strptime(data, '%Y-%m-%d %H:%M:%S')
        data=data + timedelta(hours=2)
        data=datetime.strptime(str(data), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        data='Data : '+str(data)
        
        periodo=movimento.periodo_id.name
        periodo='Período : '+str(periodo)
        
        moeda=movimento.moeda_lancamento_id.name
        moeda='Moeda de Lançamento :'+ str(moeda)
        
        conta=movimento.conta_id
        conta='Conta : '+str(movimento.conta_id.friendly_name)
        
        projecto=movimento.projecto_id.friendly_name
        financiador_principal=movimento.doador_id.doador_id.friendly_name
        #banco='Banco : '+str(movimento.conta_id.banco_id.name)+'('+str(movimento.conta_id.banco_id.bic)+')'
        local_realizacao=movimento.local_realizacao
        cambio=movimento.cambio
        cambio='Câmbio '+str(movimento.moeda_lancamento_id.name)+' : '+str(cambio)
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S')) 
       
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'ano_fiscal':ano_fiscal or 'cambio_sec',
            'data':data or '',
            'periodo':periodo or '',
            'moeda':moeda or '',
            'conta':conta or '',
            'projecto':projecto or '',
            'cambio':cambio or '',
            'local_realizacao':local_realizacao or '',
            'financiador_principal':financiador_principal or '',
            'data_hora_lancamento':data_hora_lancamento or '',
            #'numero_doc':numero_doc or ''
            #'data':data or '',
            #'moeda':moeda or ''
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        movimento = pool.get('dotcom.gestao.projectos.movimento').browse(cr,uid,ids[0])
       
        if len(movimento.lancamento_movimentos_ids)>0:
            for lancamento in movimento.lancamento_movimentos_ids:
                tipo_movimento=lancamento.tipo_movimento_id.friendly_name
                doador=lancamento.doador_id.doador_id.friendly_name
                descricao=lancamento.conta_id.decricao
                beneficiario=lancamento.beneficiario
                numero_cheque=lancamento.numero_cheque
                valor=lancamento.valor
                numero=lancamento.numero_recibo
                rubrica=lancamento.rubrica_id.friendly_name
                
                data={
                    'tipo_movimento':tipo_movimento or '',
                    'descricao':descricao or '',
                    'doador':doador or '',
                    'valor': valor or '0',
                    'numero_cheque': numero_cheque or '',
                    'numero':numero or '',
                    'beneficiario':beneficiario or'',
                    'rubrica':rubrica or '',
                    
                }
                
                # list=[]
                # list.append({'nome':'Edson','sobrnome':'Murima'})
                # data['teste']=list
                result.append(data)
                #result = sorted(result, key=lambda d: (d['conta']))                

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        logger.info('RESULTS DO REPORT: %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_movimento_report','dotcom.gestao.projectos.movimento',parser=movimento_parser)