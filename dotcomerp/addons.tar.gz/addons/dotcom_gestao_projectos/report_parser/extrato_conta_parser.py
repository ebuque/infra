# -*- coding: utf-8 -*-

import jasper_reports
from osv import osv,fields
from datetime import datetime,timedelta
import time
import os
import pooler
from tools.translate import _
import logging
logger = logging.getLogger('jasper_report_resumo')
#from dotcom_doc import JasperDataParser
from dotcom_contabilidade import JasperDataParser


class extrato_conta_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(extrato_conta_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
        
        label='Extrato de Contas'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.contas').browse(cr,uid,ids[0])
        data_inicio=extrato.data_inicio
        data_inicio=datetime.strptime(data_inicio, '%Y-%m-%d %H:%M:%S')
        data_inicio=data_inicio + timedelta(hours=2)
        data_inicio=datetime.strptime(str(data_inicio), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        
        data_fim=extrato.data_fim
        data_fim=datetime.strptime(data_fim, '%Y-%m-%d %H:%M:%S')
        data_fim=data_fim + timedelta(hours=2)
        data_fim=datetime.strptime(str(data_fim), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        data=str(data_inicio)+ ' - '+str(data_fim)
        moeda=''
        moeda_id=extrato.moeda_lancamento_id
        if moeda_id=='all':
            moeda='Lançamentos na Várias Moedas'
        elif (moeda_id)==False:
            moeda=''
        else:
            moeda_lancamento=self.pool.get('res.currency').search(cr,uid,[('id','=',moeda_id)])
            moeda_obj=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento[0])
            moeda='Lançamentos em '+str(moeda_obj.name)
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'data':data or '',
            'moeda':moeda or '',
            'data_hora_lancamento':data_hora_lancamento or '',
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.contas').browse(cr,uid,ids[0])
        if len(extrato.linhas_extrato_ids)>0:
            contador=len(extrato.linhas_extrato_ids)
            for lancamento in extrato.linhas_extrato_ids:
                data=lancamento.data
                data=datetime.strptime(data, '%Y-%m-%d').strftime('%d/%m/%Y')
                
                periodo=lancamento.periodo_id.name
                
                #num_diario=lancamento.numero_diario
                #documento=lancamento.documento.ref
                #num_doc=lancamento.num_doc
                conta='['+str(lancamento.conta_id.ref)+'] '+str(lancamento.conta_id.decricao)
                projecto='['+str(lancamento.projecto_id.ref)+'] '+ str(lancamento.projecto_id.nome)
                #descricao=
                debito=lancamento.debito
                credito=lancamento.credito
                saldo=lancamento.saldo
                natureza=lancamento.natureza
                debito_anterior=lancamento.debito_anterior
                credito_anterior=lancamento.credito_anterior
                saldo_anterior=lancamento.saldo_anterior
                
                #if natureza=='receita':
                #    natureza='D'
                #elif natureza=='despesas':
                #    natureza='C'
                
                periodo_id=lancamento.periodo_id.id
                descricao=lancamento.descricao
                rubrica=lancamento.rubrica_id.nome
                grupo=conta
                #debito_anterior=lancamento.debito_anterior
                #credito_anterior=lancamento.credito_anterior
                
            
                #saldo_anterior=lancamento.saldo_anterior
                
                data={
                    'data':data or '',
                    'periodo':periodo or '',
                    'conta':conta or '',
                    'projecto':projecto or '',
                    'descricao':descricao or '',
                    'rubrica':rubrica or '',
                    'debito':debito or '0',
                    'credito':credito or '0',
                    'saldo':saldo or '0',
                    'debito_anterior':debito_anterior or '0',
                    'credito_anterior':credito_anterior or '0',
                    'saldo_anterior':saldo_anterior or '0',
                    'natureza':natureza or '',
                    'grupo':grupo,
                    'periodo_id':periodo_id,
                    'contador':contador
                }
                contador=contador-1
                result.append(data)
                #result = sorted(result, key=lambda d: (d['data_desembarque'],d['destino']))
                result = sorted(result, key=lambda d: (d['grupo']))
                
                #if extrato.imprimir_tudo==True:
                #    self.pool.get('dotcom.gestao.projectos.extrato.contas.contas.linhas').unlink(cr,uid,lancamento.id)

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_extrato_contas_report','dotcom.gestao.projectos.extrato.contas',parser=extrato_conta_parser)




class extrato_projecto_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(extrato_projecto_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
        
        label='Extrato por Projecto'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.projecto').browse(cr,uid,ids[0])
        data_inicio=extrato.data_inicio
        data_inicio=datetime.strptime(data_inicio, '%Y-%m-%d %H:%M:%S')
        data_inicio=data_inicio + timedelta(hours=2)
        data_inicio=datetime.strptime(str(data_inicio), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        
        data_fim=extrato.data_fim
        data_fim=datetime.strptime(data_fim, '%Y-%m-%d %H:%M:%S')
        data_fim=data_fim + timedelta(hours=2)
        data_fim=datetime.strptime(str(data_fim), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        data=str(data_inicio)+ ' - '+str(data_fim)
        moeda=''
        moeda_id=extrato.moeda_lancamento_id
        if moeda_id=='all':
            moeda='Lançamentos na Várias Moedas'
        elif (moeda_id)==False:
            moeda=''
        else:
            moeda_lancamento=self.pool.get('res.currency').search(cr,uid,[('id','=',moeda_id)])
            moeda_obj=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento[0])
            moeda='Lançamentos em '+str(moeda_obj.name)
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'data':data or '',
            'moeda':moeda or '',
            'data_hora_lancamento':data_hora_lancamento or '',
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.projecto').browse(cr,uid,ids[0])
        if len(extrato.linhas_extrato_ids)>0:
            contador=len(extrato.linhas_extrato_ids)
            for lancamento in extrato.linhas_extrato_ids:
                data=lancamento.data
                data=datetime.strptime(data, '%Y-%m-%d').strftime('%d/%m/%Y')
                
                periodo=lancamento.periodo_id.name
                
                #num_diario=lancamento.numero_diario
                #documento=lancamento.documento.ref
                #num_doc=lancamento.num_doc
                conta='['+str(lancamento.conta_id.ref)+'] '+str(lancamento.conta_id.decricao)
                projecto='['+str(lancamento.projecto_id.ref)+'] '+ str(lancamento.projecto_id.nome)
                #descricao=
                debito=lancamento.debito
                credito=lancamento.credito
                saldo=lancamento.saldo
                natureza=lancamento.natureza
                debito_anterior=lancamento.debito_anterior
                credito_anterior=lancamento.credito_anterior
                saldo_anterior=lancamento.saldo_anterior
                
                #if natureza=='receita':
                #    natureza='D'
                #elif natureza=='despesas':
                #    natureza='C'
                
                periodo_id=lancamento.periodo_id.id
                descricao=lancamento.descricao
                rubrica=lancamento.rubrica_id.nome
                grupo=projecto
                #debito_anterior=lancamento.debito_anterior
                #credito_anterior=lancamento.credito_anterior
                
            
                #saldo_anterior=lancamento.saldo_anterior
                
                data={
                    'data':data or '',
                    'periodo':periodo or '',
                    'conta':conta or '',
                    'projecto':projecto or '',
                    'descricao':descricao or '',
                    'rubrica':rubrica or '',
                    'debito':debito or '0',
                    'credito':credito or '0',
                    'saldo':saldo or '0',
                    'debito_anterior':debito_anterior or '0',
                    'credito_anterior':credito_anterior or '0',
                    'saldo_anterior':saldo_anterior or '0',
                    'natureza':natureza or '',
                    'grupo':grupo,
                    'periodo_id':periodo_id,
                    'contador':contador
                }
                contador=contador-1
                result.append(data)
                #result = sorted(result, key=lambda d: (d['data_desembarque'],d['destino']))
                result = sorted(result, key=lambda d: (d['grupo']))
                
                #if extrato.imprimir_tudo==True:
                #    self.pool.get('dotcom.gestao.projectos.extrato.contas.contas.linhas').unlink(cr,uid,lancamento.id)

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_extrato_projectos_report','dotcom.gestao.projectos.extrato.projecto',parser=extrato_projecto_parser)




class extrato_financiador_parser(JasperDataParser.JasperDataParser):
    
    def __init__(self, cr, uid, ids, data, context):
        super(extrato_financiador_parser, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
        
    def generate_data_source(self,cr,uid,ids,data,context):
        return 'records'
    
    def generate_parameters(self,cr,uid,ids,data,context):
        pool=pooler.get_pool(cr.dbname)
        result=[]
                
        utilizador=pool.get('res.users').browse(cr,uid,uid).name
        
        label='Extrato por Financiador'
            
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_tesouraria',context)
        licenca = 'Nao Licenciado'
        
        logger.info('LICENCA %s' %str(licenca) )
        #if licenca_id:
        #    licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name        
        
        user = self.pool.get('res.users').browse(cr,uid,uid)
        companhia = user.company_id.name
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.financiador').browse(cr,uid,ids[0])
        data_inicio=extrato.data_inicio
        data_inicio=datetime.strptime(data_inicio, '%Y-%m-%d %H:%M:%S')
        data_inicio=data_inicio + timedelta(hours=2)
        data_inicio=datetime.strptime(str(data_inicio), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        
        data_fim=extrato.data_fim
        data_fim=datetime.strptime(data_fim, '%Y-%m-%d %H:%M:%S')
        data_fim=data_fim + timedelta(hours=2)
        data_fim=datetime.strptime(str(data_fim), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y %H:%M:%S')
        
        data=str(data_inicio)+ ' - '+str(data_fim)
        moeda=''
        moeda_id=extrato.moeda_lancamento_id
        if moeda_id=='all':
            moeda='Lançamentos na Várias Moedas'
        elif (moeda_id)==False:
            moeda=''
        else:
            moeda_lancamento=self.pool.get('res.currency').search(cr,uid,[('id','=',moeda_id)])
            moeda_obj=self.pool.get('res.currency').browse(cr,uid,moeda_lancamento[0])
            moeda='Lançamentos em '+str(moeda_obj.name)
        
        data_hora_lancamento=str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        return{
            'licenca':licenca or '',
            'label':label or '',
            'empresa':companhia or '',
            'data':data or '',
            'moeda':moeda or '',
            'data_hora_lancamento':data_hora_lancamento or '',
        }
        
        
    def generate_properties(self,cr,uid,ids,data,context):
        return {}
        
    def generate_records(self,cr,uid,ids,data,context):
        
        pool=pooler.get_pool(cr.dbname)
        result=[]
        
        extrato = pool.get('dotcom.gestao.projectos.extrato.financiador').browse(cr,uid,ids[0])
        if len(extrato.linhas_extrato_ids)>0:
            contador=len(extrato.linhas_extrato_ids)
            for lancamento in extrato.linhas_extrato_ids:
                data=lancamento.data
                data=datetime.strptime(data, '%Y-%m-%d').strftime('%d/%m/%Y')
                
                periodo=lancamento.periodo_id.name
                
                #num_diario=lancamento.numero_diario
                #documento=lancamento.documento.ref
                #num_doc=lancamento.num_doc
                conta='['+str(lancamento.conta_id.ref)+'] '+str(lancamento.conta_id.decricao)
                projecto='['+str(lancamento.projecto_id.ref)+'] '+ str(lancamento.projecto_id.nome)
                #descricao=
                debito=lancamento.debito
                credito=lancamento.credito
                saldo=lancamento.saldo
                natureza=lancamento.natureza
                debito_anterior=lancamento.debito_anterior
                credito_anterior=lancamento.credito_anterior
                saldo_anterior=lancamento.saldo_anterior
                
                #if natureza=='receita':
                #    natureza='D'
                #elif natureza=='despesas':
                #    natureza='C'
                
                periodo_id=lancamento.periodo_id.id
                descricao=lancamento.descricao
                rubrica=lancamento.rubrica_id.nome
                grupo=projecto
                #debito_anterior=lancamento.debito_anterior
                #credito_anterior=lancamento.credito_anterior
                
            
                #saldo_anterior=lancamento.saldo_anterior
                
                data={
                    'data':data or '',
                    'periodo':periodo or '',
                    'conta':conta or '',
                    'projecto':projecto or '',
                    'descricao':descricao or '',
                    'rubrica':rubrica or '',
                    'debito':debito or '0',
                    'credito':credito or '0',
                    'saldo':saldo or '0',
                    'debito_anterior':debito_anterior or '0',
                    'credito_anterior':credito_anterior or '0',
                    'saldo_anterior':saldo_anterior or '0',
                    'natureza':natureza or '',
                    'grupo':grupo,
                    'periodo_id':periodo_id,
                    'contador':contador
                }
                contador=contador-1
                result.append(data)
                #result = sorted(result, key=lambda d: (d['data_desembarque'],d['destino']))
                result = sorted(result, key=lambda d: (d['grupo']))
                
                #if extrato.imprimir_tudo==True:
                #    self.pool.get('dotcom.gestao.projectos.extrato.contas.contas.linhas').unlink(cr,uid,lancamento.id)

        else:
            raise osv.except_osv(_('Acção Invalida !'), _('Lista sem Items para imprimir!!'))
        #        
        #logger.info('RESULTS : %s' % result)
        print result
        return result
    
    
jasper_reports.report_jasper('report.dotcom_gestao_projectos_extrato_financiador_report','dotcom.gestao.projectos.extrato.financiador',parser=extrato_financiador_parser)