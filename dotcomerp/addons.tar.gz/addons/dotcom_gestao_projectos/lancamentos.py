# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_lancamento(osv.osv):
    
    def _valor_moeda_base(self,cr,uid,ids,field,arg,context=None):
        if context is None:
            context={}
            
        res={}
        for documento in self.browse(cr,uid,ids):
            valor=documento.valor
            moeda_lancamento=documento.moeda_lancamento_id
            moeda_primaria_id=self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.gestao.projectos.lancamentos')
            
            if moeda_lancamento.id==moeda_primaria_id:
                res[documento.id]=valor
            else:
                cambio_moeda_lancamento=False
                if bool(documento.movimento_id.id)!=False:
                    cambio_moeda_lancamento=documento.movimento_id.cambio
                    
                elif bool(documento.movimento_interno_id.id)!=False:
                    if documento.conta_id.id==documento.movimento_interno_id.conta_origem_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_origem
                        
                    elif documento.conta_id.id==documento.movimento_interno_id.conta_destino_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_destino
                    
                moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id)
                logger.info('MOEDA DEFAULT ACHADA %s' %str(moeda_primaria))
                cambio_moeda_principal=moeda_primaria.rate
                
                valor_lancamento_cambiado=cambio_moeda_lancamento*valor
                valor_cambiado_moeda_principal=valor_lancamento_cambiado/cambio_moeda_principal
                res[documento.id]=valor_cambiado_moeda_principal
                
        return res
    
    
    def _valor_moeda_secundaria(self,cr,uid,ids,field,arg,context=None):
        if context is None:
            context={}
        
        res={}
        for documento in self.browse(cr,uid,ids):
            valor=documento.valor
            moeda_lancamento=documento.moeda_lancamento_id
            moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
            moeda_secundaria_id=moeda_secundaria_id[0]
            
            if moeda_lancamento.id==moeda_secundaria_id:
                res[documento.id]=valor
            else:
                cambio_moeda_lancamento=None
                if bool(documento.movimento_id.id)!=False:
                    cambio_moeda_lancamento=documento.movimento_id.cambio
                
                elif bool(documento.movimento_interno_id.id)!=False:
                    if documento.conta_id.id==documento.movimento_interno_id.conta_origem_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_origem
                        
                    elif documento.conta_id.id==documento.movimento_interno_id.conta_destino_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_destino    
                
                moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id)
                cambio_moeda_secundaria=moeda_secundaria.rate
                
                valor_lancamento_cambiado=cambio_moeda_lancamento*valor
                valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_moeda_secundaria
                res[documento.id]=valor_cambiado_moeda_secundaria
                
        return res
    
    
    def _valor_moeda_conta(self,cr,uid,ids,field,arg,context=None):
        if context is None:
            context={}
        
        res={}
        for documento in self.browse(cr,uid,ids):
            valor=documento.valor
            moeda_lancamento=documento.moeda_lancamento_id
            moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
            moeda_secundaria_id=moeda_secundaria_id[0]
            moeda_conta=documento.conta_id.moeda_lancamento_id
            
            if moeda_lancamento.id==moeda_conta.id:
                res[documento.id]=valor
            else:
                cambio_moeda_lancamento=None
                if bool(documento.movimento_id.id)!=False:
                    cambio_moeda_lancamento=documento.movimento_id.cambio
                
                elif bool(documento.movimento_interno_id.id)!=False:
                    if documento.conta_id.id==documento.movimento_interno_id.conta_origem_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_origem
                        
                    elif documento.conta_id.id==documento.movimento_interno_id.conta_destino_id.id:
                        cambio_moeda_lancamento=documento.movimento_interno_id.cambio_destino    
                
                
                cambio_moeda_conta=moeda_conta.rate
                
                valor_lancamento_cambiado=cambio_moeda_lancamento*valor
                valor_cambiado_moeda_secundaria=valor_lancamento_cambiado/cambio_moeda_conta
                res[documento.id]=valor_cambiado_moeda_secundaria
                
        return res
    
    
    def _state(self,cr,uid,ids,field,arg,context=None):
        if context is None:
            context={}
        
        res={}
        for documento in self.browse(cr,uid,ids):
            state=''
            if bool(documento.movimento_id.id)!=False:
                state=documento.movimento_id.state
            
            elif bool(documento.movimento_interno_id.id)!=False:
                state=documento.movimento_interno_id.state
            
            res[documento.id]=state
                
        return res
    
    
    _name='dotcom.gestao.projectos.lancamentos'
    _columns={
        'data':fields.datetime('Data Mov',required=True),
        'periodo_id':fields.many2one('configuration.period','Período',readonly=False),
        #'periodo_id':fields.related('movimento_id','diario_id',type='many2one',relation='dotcom.contabilidade.diario',string='Diário',readonly=True),
        
        'descricao':fields.char('Descrição', size=100,),
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica', domain="[('tipo_rubrica','=',tipo_movimento)]",required=False ),
        'valor':fields.float('Valor',required=True),
        'valor_moeda_base':fields.function(_valor_moeda_base, type='float', string='Valor MP', method=True, store=True),
        'valor_moeda_secundaria':fields.function(_valor_moeda_secundaria, type='float', string='Valor MS', method=True, store=True),
        'valor_moeda_conta':fields.function(_valor_moeda_conta, type='float', string='Valor Moeda Conta', method=True, store=True),
        
        'cambio_moeda':fields.float('Cambio',),
        'movimento_id':fields.many2one('dotcom.gestao.projectos.movimento','Movimento',ondelete="cascade"),
        'movimento_conversao_moeda_id':fields.many2one('dotcom.gestao.projectos.movimento','Movimento',ondelete="cascade"),
        
        'movimento_interno_id':fields.many2one('dotcom.gestao.projetcos.movimentos.internos','Movimento Interno',ondelete="cascade"),
        'conta_id':fields.many2one('dotcom.gestao.projectos.conta','Conta',readonly=False ,required=True, ),
        'moeda_lancamento_id':fields.many2one('res.currency','Moeda',required=False,),
        'cambio':fields.float('Câmbio MP', help="Câmbio para a moeda principal(MP)",),
        
        'beneficiario':fields.char('Beneficiário', size=100),
        'numero_cheque':fields.char('Nr Cheque', size=50),
        'numero_recibo':fields.char('NF/Recibo nr.', size=50),
        
        'tipo_movimento_id':fields.many2one('dotcom.gestao.projectos.tipo.movimento','Tipo Movimento', required=True),
        
        'tipo_movimento':fields.selection([
                                            ('receita','Receita'),
                                            ('despesas','Despesas')
                                            ],'Tipo Movimento'),
        #
        
        'state_processamento':fields.selection([('por_processar','Por Processar'),('processado','Processado')]),
        
        'state':fields.function(_state, type='char', string='Estado', method=True, store=False),
        #'state':fields.related('movimento_id','state',type='char',relation='dotcom.contabilidade.movimentos',string='Estado'),
        
        'tipo_documento_id':fields.many2one('dotcom.gestao.projectos.documento','Tipo Documento',readonly=False,),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',required=True),
        'programa_id':fields.many2one('dotcom.gestao.projectos.programa','Programa', domain="[('projecto_id','=',projecto_id)]", required=False),
        'doador_id':fields.many2one('dotcom.gestao.projectos.doador.projecto','Doador', domain="[('projecto_id','=',projecto_id)]", required=True),
        
        'confirmacao_conciliacao':fields.float('Confirmacao Conciliacao'),
        
        # 'lancamento_analise_id':fields.many2one('dotcom.gestao.projectos.lancamento.analise.grafica','Analise Grafica'),
        
        'fecho_caixa_movimento_id':fields.many2one('dotcom.gestao.projectos.movimentos.abertura.fecho.caixa.linha','Fecho Caixa'),        
    }
    
    _rec_name='data'
    
    _order='create_date asc'
    
    _defaults={
        'data':lambda self, cr, uid, c: c.get('data', None),
        'conta_id':lambda self, cr, uid, c: c.get('conta_id', False),
        'periodo_id':lambda self, cr, uid, c: c.get('periodo_id', False),
        #'doador_id':lambda self, cr, uid, c: c.get('doador_id', False),
        'projecto_id':lambda self, cr, uid, c: c.get('projecto_id', False),
        #'programa_id':lambda self, cr, uid, c: c.get('programa_id', False),
        'tipo_documento_id':lambda self, cr, uid, c: c.get('tipo_documento_id', False),
        'state':'rascunho',
        'doador_id':lambda self, cr, uid, c: c.get('doador_id', False),
        'moeda_lancamento_id':lambda self, cr, uid, c: c.get('moeda_lancamento_id', False),
        
    }
    
    def on_change_tipo_movimento(self,cr,uid,ids,tipo_movimento_id,context=None):
        if context is None:
            context={}
        val={}
        if bool(tipo_movimento_id)!=False:
            
            tipo_movimento_object=self.pool.get('dotcom.gestao.projectos.tipo.movimento').browse(cr,uid,tipo_movimento_id)
            val={'tipo_movimento':tipo_movimento_object.tipo_movimento}
            logger.info('ENTROU NO PROCESSO %s' %str(tipo_movimento_object.tipo_movimento))
        else:
            val={'tipo_movimento':False}
        logger.info('ENTROU NO PROCESSO %s' %str(val))
        return {'value':val}
            
    
    def on_change_tipo_documento(self,cr,uid,ids,tipo_documento_id,context=None):
        if context is None:
            context={}
        
        value={}
        if bool(tipo_documento_id)==True:
            tipo_documento_object=self.pool.get('dotcom.gestao.projectos.documento').browse(cr,uid,tipo_documento_id)
            value={'tipo_movimento':tipo_documento_object.tipo_documento}
        
        return {'value':value}
    
    
    def on_change_programa(self, cr,uid,ids, programa_id,context=None):
        if context is None:
            context={}
        
        if bool (programa_id)==True:
            programa_object=self.pool.get('dotcom.gestao.projectos.programa').browse(cr,uid,programa_id)
            return {'value':{'doador_id':programa_object.doador_id.id}}
        else:
            return {}

    
    def on_change_data(self,cr,uid,ids,data,conta_id,context=None):
        if context is None:
            context={}
        
        #if conta_id:
        #    conta_object=self.pool.get('dotcom.tesouraria.conta').browse(cr,uid,conta_id)
        #    validator.validar_data_ultima_abertura_fecho_caixa(self,cr,uid,conta_object,data,context)
            
            
        return {}
    
    
    def on_change_moeda(self,cr,uid,ids,moeda_id,context=None ):
        if context is None:
            context={}
        
        val={}
        if bool(moeda_id)==True:                 
            moeda = self.pool.get('res.currency').browse(cr, uid, moeda_id)
            cambio = moeda.rate or 1
            val={'cambio_moeda':cambio}
        
        logger.info('ENTROU NO PROCESSO')
        return {'value':val}
    
    
    def on_change_rubrica(self,cr,uid,ids,rubrica_id,context=None):
        if context is None:
            context={}
        
        if rubrica_id:
            rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica_id)
            if(rubrica_object.tipo_interno!='m'):
                raise osv.except_osv(_('Invalid action !'), _('Tipo de Rubrica não permitido.!'))
            
        return {}
    
    
    def on_change_valor(self,cr,uid,ids,rubrica_id,projecto_id,periodo_id,valor,context=None):
        if context is None:
            context={}
        
        logger.info('### LANCAMENTOS ACHADOS ### %s' %str(rubrica_id))
        res_company_ids=self.pool.get('res.company').search(cr,uid,[])
        company_object=self.pool.get('res.company').browse(cr,uid,res_company_ids[0])
        
        if company_object.verificar_orcamento==True and company_object.emitir_alerta==True:
            logger.info('PROCESSO INICIADO')
            self.comparar_orcamento(cr,uid,rubrica_id,projecto_id,periodo_id,valor,context)
        
        return{}
    
    #comparar o valor total movimentado no projecto(incluindo o do lancamento a ser executado) ao orçamentado,
    #podendo ser o maior, menor ou o selecionado, de acordo com as configuraçoes efectuadas na empresa
    def comparar_orcamento(self,cr,uid,rubrica_id,projecto_id,periodo_id,valor,context=None):
        if context is None:
            context ={}
            
        # res_company_ids=self.pool.get('res.company').search(cr,uid,[])
        # company_object=self.pool.get('res.company').browse(cr,uid,res_company_ids[0])
        
        # if company_object.comparar_maior==True or company_object.comparar_menor==True or company_object.seleccionar_orcamento==True: 
        
        lancamentos_ids=self.search(cr,uid,[
                                                ('projecto_id','=',projecto_id),
                                                ('rubrica_id','=',rubrica_id),
                                                ('state','=','emitido')
                                            ])
        
        
        total_movimentado=0
        for lancamento in lancamentos_ids:
            lancamento=self.browse(cr,uid,lancamento)
            if lancamento.movimento_id.state =='emitido':
                total_movimentado=total_movimentado+lancamento.valor
                logger.info('### LANCAMENTOS ACHADOS ### %s' %str(lancamento.movimento_id.state))
        
        valor_orcamentado=self.pegar_valor_orcamento_comparativo(cr,uid,rubrica_id,projecto_id,periodo_id,context)
        
        logger.info('### VALOR ORCAMENTADO ### %s' %str(valor_orcamentado))
        logger.info('### VALOR MOVIMENTADO ### %s' %str(total_movimentado+valor))
        
        if valor_orcamentado!=0 and total_movimentado+valor>valor_orcamentado:
            raise osv.except_osv(_('Acção Inválida !'), _('O valor a ser passado e superior ao orçamentado !!'))
        
    
    def pegar_valor_orcamento_comparativo(self,cr,uid,rubrica_id,projecto_id,periodo_id,context=None):
        if context is None:
            context={}
        
        
        # periodo_object=self.pool.get('('configuration.period')
        
        res_company_ids=self.pool.get('res.company').search(cr,uid,[])
        company_object=self.pool.get('res.company').browse(cr,uid,res_company_ids[0])
        valor_retorno=0
        periro_object=self.pool.get('configuration.period').browse(cr,uid,periodo_id)
        periodo_code=periro_object.code[:2]
        
        logger.info('PERIODO ACHADO %s' %str(periro_object.code))
        
        orcamento_linha_id=[]
        
        if company_object.seleccionar_orcamento==True:
            orcamento_linha_id=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').search(cr,uid,[
                                                                                                        ('projecto_id','=',projecto_id),
                                                                                                        ('rubrica_id','=',rubrica_id),
                                                                                                        ('state','=','emitido'),
                                                                                                        ('orcamento_id','=',company_object.orcamento_id.id)
                                                                                                        ])
        else:
            orcamento_linha_id=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').search(cr,uid,[
                                                                                                        ('projecto_id','=',projecto_id),
                                                                                                        ('rubrica_id','=',rubrica_id),
                                                                                                        ('state','=','emitido'),
                                                                                                        # ('orcamento_id','=',company_object.orcamento_id.id)
                                                                                                        ])
         
        
            
        valor_inicial=0
        i=0
        for linha_orcamento in orcamento_linha_id:
            valor_orcamentado_periodo=0
            orcamento_obj=self.pool.get('dotcom.gestao.projectos.orcamentos.linhas').browse(cr,uid,linha_orcamento)
            if periodo_code=='01':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jan_mp
            elif periodo_code=='02':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.fev_mp
            if periodo_code=='03':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.mar_mp
            elif periodo_code=='04':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp
            if periodo_code=='05':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.maio_mp   
            elif periodo_code=='06':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jun_mp
            if periodo_code=='07':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.jul_mp
            elif periodo_code=='08':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.ago_mp
            if periodo_code=='09':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.set_mp     
            elif periodo_code=='10':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.abr_mp  
            if periodo_code=='11':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.nov_mp
            elif periodo_code=='12':
                valor_orcamentado_periodo=valor_orcamentado_periodo+orcamento_obj.dez_mp
            
            
            if company_object.comparar_maior==True:
                if valor_orcamentado_periodo>valor_inicial:
                    valor_inicial=valor_orcamentado_periodo
                else:
                    valor_inicial=valor_inicial
            
            elif company_object.comparar_menor==True:
                if i!=0:
                    if valor_orcamentado_periodo>valor_inicial:
                        valor_inicial=valor_inicial
                    else:
                        valor_inicial=valor_orcamentado_periodo
                else:
                    valor_inicial=valor_orcamentado_periodo
            
            i=i+1
        
        return valor_inicial
    
        
    def create(self, cr, uid, values, context=None):
        if context is None:
            context = {}
            
        rubrica_id = values.get('rubrica_id')
        rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica_id)
        identificador=None
        if(rubrica_object.tipo_interno!='m'):
            raise osv.except_osv(_('Invalid action !'), _('Tipo de Rubrica não permitido.!'))
        else:
            identificador=  super(dotcom_gestao_projectos_lancamento, self).create(cr, uid, values, context=context)
        return identificador        
    
    
dotcom_gestao_projectos_lancamento()


