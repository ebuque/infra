# -*- encoding: utf-8 -*-


import time
from datetime import datetime
from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')


class dotcom_gestao_projectos_analise_movimento_grafica(osv.osv):
    _name='gestao.projectos.analise.movimento.grafica'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,required=True,),
        'periodo_inicial_id':fields.many2one('configuration.period','Período Inicial',readonly=False,required=True,domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False)]" ),
        'periodo_final_id':fields.many2one('configuration.period','Período Final',readonly=False,required=True,domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False)]" ),
        'projecto_id':fields.many2one('dotcom.gestao.projectos.projecto','Projecto',),
        'rubrica_ids':fields.many2many('dotcom.gestao.projectos.rubrica','analise_rubrica_rel','analise_id','rubrica_id', 'Rubrica', domain="[('tipo_interno','=','m')]" ),
    }

    
    def mostrar_grafico(self,cr,uid,ids,context={}):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            linhas_lancadas_ids=self.pool.get('dotcom.gestao.projectos.lancamento.analise.grafica').search(cr,uid,[])
            for linha in linhas_lancadas_ids:
                self.pool.get('dotcom.gestao.projectos.lancamento.analise.grafica').unlink(cr,uid,linha)
                
            rubricas_ids=[]
            if len(documento.rubrica_ids)>0:
                for rubrica in documento.rubrica_ids:
                    rubricas_ids.append(rubrica.id)
            else:
                rubricas_ids=self.pool.get('dotcom.gestao.projectos.rubrica').search(cr,uid,[('tipo_interno','=','m')])
            
            priodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                            ('date_start','>=',documento.periodo_inicial_id.date_start),
                                            ('fiscalyear_id','=',documento.ano_fiscal_id.id),
                                            ('date_stop','<=',documento.periodo_final_id.date_stop),
                                        ])

            
            for rubrica in rubricas_ids:
                total_rubrica=0
                
                rubrica_object=self.pool.get('dotcom.gestao.projectos.rubrica').browse(cr,uid,rubrica)
                logger.info('#####VALOR ACHADO NO INICIO#### %s' %str(rubrica_object.friendly_name))
                lancamentos_ids=[]
                if bool(documento.projecto_id.id)!=False:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                        ('periodo_id','in',priodos_ids),
                                                                                                        ('rubrica_id','=',rubrica),
                                                                                                        ('projecto_id','=',documento.projecto_id.id),
                                                                                                        ('state','=','emitido')
                                                                                                        ])
                else:
                    lancamentos_ids=self.pool.get('dotcom.gestao.projectos.lancamentos').search(cr,uid,[
                                                                                                        ('periodo_id','in',priodos_ids),
                                                                                                        ('rubrica_id','=',rubrica),
                                                                                                        ('state','=','emitido')
                                                                                                        # ('projecto_id','=',documento.projecto_id.id)
                                                                                                        ])
                
                
                for lancamento in lancamentos_ids:
                    lancamento =self.pool.get('dotcom.gestao.projectos.lancamentos').browse(cr,uid,lancamento)
                    total_rubrica=total_rubrica+lancamento.valor
                
                logger.info('#####VALOR ACHADO PARA A CRIACAO#### %s' %str(total_rubrica))
                val_analise={
                                'rubrica_id':rubrica,
                                'valor':total_rubrica,
                                'state':'emitido'
                            }
                self.pool.get('dotcom.gestao.projectos.lancamento.analise.grafica').create(cr,uid,val_analise)
                
        return {
                    'type': 'ir.actions.act_window',
                    'name': 'Analise de Movimentos',
                    'view_mode': 'graph',
                    'view_type': 'form',
                    'res_model': 'dotcom.gestao.projectos.lancamento.analise.grafica',
                    'res_id':None,
                    'target': 'new',
                    'context': context,
                    'nodestroy': True,
                }
        
dotcom_gestao_projectos_analise_movimento_grafica()


class dotcom_gestao_projectos_analise_moviumento_grafica_linha(osv.osv):
    _name='dotcom.gestao.projectos.lancamento.analise.grafica'
    _columns={
        'rubrica_id':fields.many2one('dotcom.gestao.projectos.rubrica', 'Rubrica',  ),
        'valor':fields.float('Valor',required=True),
        'state':fields.selection([
                                    ('rascunho','Rascunho'),
                                    ('emitido','Emitido'),
                                    ],'Estado')
    }
    
    
dotcom_gestao_projectos_analise_moviumento_grafica_linha()


class dotcom_gestao_projectos_analise_orcamental_comparativa(osv.osv):
    
    def _acerto(self,cr,uid,context=None):
        if context is None:
            context = {}
        moeda_primaria_id=self.pool.get('res.company').get_mueda_principal(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_primaria=self.pool.get('res.currency').browse(cr,uid,moeda_primaria_id[0])
        logger.info('MOEDA PRIMARIA %s' %str(moeda_primaria.name))
        
        moeda_secundaria_id=self.pool.get('res.company').get_moeda_secundaria(cr, uid,'dotcom.contabilidade.plano.contas', context=context),
        moeda_secundaria=self.pool.get('res.currency').browse(cr,uid,moeda_secundaria_id[0])
        logger.info('MOEDA SECUNDARIA %s' %str(moeda_secundaria.name))
        
        ano_ids=self.search(cr,uid,[])
        result=()
        this=[]
                
        result=('mp',str(moeda_primaria.name))
        this.append(result)
        
        result=('ms',str(moeda_secundaria.name))
        this.append(result)
        
        result=('ml','Moeda da Conta')
        this.append(result)
            
        return this
    
    _name='gestao.projectos.analise.orcamental.comparativa'
    _columns={
        'ano_fiscal_id':fields.many2one('configuration.fiscalyear','Ano Fiscal',readonly=False,required=True,),
        'orcamento_receita_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orçamento Receitas', domain="[('ano_fiscal_id','=',ano_fiscal_id),('tipo_rubrica','=','receita')]", required=True),
        'orcamento_despesas_id':fields.many2one('dotcom.gestao.projectos.orcamento','Orçamento Despesas', domain="[('ano_fiscal_id','=',ano_fiscal_id),('tipo_rubrica','=','despesas')]", required=True),
        
        'conversao_moeda':fields.selection(_acerto,'Moeda', required=True),
        
        'tipo_analise':fields.selection([
                                        ('mensal','Mensal'),
                                        ('trimestral','Trimestral'),
                                        ('anual','Anual')],'Tipo Análise', required=True),
        
        'periodo_id':fields.many2one('configuration.period','Período', domain="[('fiscalyear_id','=',ano_fiscal_id),('special','=',False),('closing','=',False)]" ),
        'periodo_trimestral':fields.selection([
                                                ('primero_trimestre','1 Trimestre'),
                                                ('segundo_trimestre','2 Trimestre'),
                                                ('terceiro_trimestre','3 Trimestre'),
                                                ('quarto_trimestre','4 Trimestre')],'Periodo Trimestral', required=False),
        
        'analise_linhas_ids':fields.one2many('gestao.projectos.analise.orcamental.comparativa.linha','analise_id','Linhas', readonly=True),
        
        'detalhes':fields.boolean('Mostrar Detalhes'),
        
        'analise_detalhes_ids':fields.one2many('gestao.projectos.analise.orcamental.comparativa.detalhes','analise_detalhada_id','Detalhes',readonly=True),
    }
    
    _defaults={
        'tipo_analise':'mensal',
        'conversao_moeda':'mp'
    }
    
    
    def carregar_linhas_comparativas(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        for documento in self.browse(cr,uid,ids):
            
            linhas_anteriores=self.pool.get('gestao.projectos.analise.orcamental.comparativa.linha').search(cr,uid,[])
            for linha in linhas_anteriores:
                self.pool.get('gestao.projectos.analise.orcamental.comparativa.linha').unlink(cr,uid,linha)
            
            lista_detalhes=self.pool.get('gestao.projectos.analise.orcamental.comparativa.detalhes').search(cr,uid,[])
            for detalhe in lista_detalhes:
                self.pool.get('gestao.projectos.analise.orcamental.comparativa.detalhes').unlink(cr,uid,detalhe)
            
            lista_rubricas_receitas_ids=[]
            lista_rubricas_despesas_ids=[]
                        
            for linha_orcamento in documento.orcamento_receita_id.orcamentos_programas_ids:
                lista_rubricas_receitas_ids.append(linha_orcamento.rubrica_id.id)
                
            for linha_orcamento in documento.orcamento_despesas_id.orcamentos_programas_ids:
                lista_rubricas_despesas_ids.append(linha_orcamento.rubrica_id.id)
    
            periodos_ids=[]
            if  documento.tipo_analise=='mensal':
                if bool(documento.periodo_id.id)!=False: 
                    periodos_ids.append(documento.periodo_id.id)
                else:
                    raise osv.except_osv(_('Invalid action !'), _('Seleccione o periodo.!!'))    
            elif documento.tipo_analise=='trimestral':
                periodos_ids=self.pool.get('dotcom.gestao.projectos.analise.orcamental').pegar_periodos_trimestrais(cr,uid,ids,documento.periodo_trimestral,documento.ano_fiscal_id)
            elif documento.tipo_analise=='anual':
                periodos_ids=self.pool.get('configuration.period').search(cr,uid,[
                                                                                ('fiscalyear_id','=',documento.ano_fiscal_id.id),
                                                                                ('special','=',False),
                                                                                ('closing','=',False),])
            
                        
            lista_items_criar=[]
            for periodo in periodos_ids:
                periodo_object=self.pool.get('configuration.period').browse(cr,uid,periodo)
                codigo_periodo=periodo_object.code[:2]
                
                orcamentado_receitas=0
                for rubrica in lista_rubricas_receitas_ids:
                    orcamentado_receitas=self.pool.get('dotcom.gestao.projectos.analise.orcamental').calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_receita_id.id,rubrica,[periodo],documento.conversao_moeda)
                
                orcamentado_despesas=0
                for rubrica in lista_rubricas_despesas_ids:
                    orcamentado_despesas=self.pool.get('dotcom.gestao.projectos.analise.orcamental').calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_despesas_id.id,rubrica,[periodo],documento.conversao_moeda)
                valor_desvio=orcamentado_despesas-orcamentado_receitas
                percentagem=float((valor_desvio*100)/orcamentado_despesas)
                
                val={
                    'total_orcamento_receita':orcamentado_receitas,
                    'total_orcamento_despesas':orcamentado_despesas,
                    'desvio':valor_desvio,
                    'desvio_percentual':percentagem,
                    'sequencia':codigo_periodo,
                    'analise_detalhada_id':documento.id,
                    'periodo_id':periodo,
                    
                }
                if orcamentado_despesas>orcamentado_receitas:
                    val['state']='defice'
                    
                lista_items_criar.append(val)
                lista_items_criar = sorted(lista_items_criar, key=lambda d: (d['sequencia']))
                
            for item in lista_items_criar:
                self.pool.get('gestao.projectos.analise.orcamental.comparativa.detalhes').create(cr,uid,item)
            
            total_orcamentado_receitas=0
            for rubrica in lista_rubricas_receitas_ids:
                total_orcamentado_receitas=total_orcamentado_receitas+self.pool.get('dotcom.gestao.projectos.analise.orcamental').calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_receita_id.id,rubrica,periodos_ids,documento.conversao_moeda)
            
            total_orcamentado_despesas=0
            for rubrica in lista_rubricas_despesas_ids:
                total_orcamentado_despesas=total_orcamentado_despesas+self.pool.get('dotcom.gestao.projectos.analise.orcamental').calcular_valor_orcamentado(cr,uid,ids,documento.orcamento_despesas_id.id,rubrica,periodos_ids,documento.conversao_moeda)
            
            
            valor_desvio=total_orcamentado_despesas-total_orcamentado_receitas
            percentagem=float((valor_desvio*100)/total_orcamentado_despesas)
            
            val={
                    'total_orcamento_receita':total_orcamentado_receitas,
                    'total_orcamento_despesas':total_orcamentado_despesas,
                    'desvio':valor_desvio,
                    'desvio_percentual':percentagem,
                    'analise_id':documento.id
                }
            self.pool.get('gestao.projectos.analise.orcamental.comparativa.linha').create(cr,uid,val)   
            # logger.info('VALOR TOTAL DAS RECEITAS %s' %str(total_orcamentado_receitas))
            # logger.info('VALOR TOTAL DAS DESPESAS %s' %str(total_orcamentado_despesas))
            
        return True
    
    
    def imprimir_analise_comparativa(self,cr,uid,ids,context=None):
        if context is None:
            context={}
            
        action={}
        for documento in self.browse(cr,uid,ids):
            if documento.detalhes==True:
                action={
                            'name': _('Analise Orcamental Comparativa Detalhada: %s') % str(ids and ids[0]),
                            'view_id': False,
                            'res_model': 'gestao.projectos.analise.orcamental.comparativa',
                            'report_name': 'dotcom_gestao_projectos_analise_orcamental_comparativa_report',
                            'domain': [],
                            'context': dict(context, active_ids=ids),
                            'type': 'ir.actions.report.xml',
                            'report_type': 'pdf',
                            'res_id': ids and ids[0] or False    
                        }
            else:
                action={
                            'name': _('Analise Orcamental Comparativa Detalhada: %s') % str(ids and ids[0]),
                            'view_id': False,
                            'res_model': 'gestao.projectos.analise.orcamental.comparativa',
                            'report_name': 'dotcom_gestao_projectos_analise_orcamental_comparativa_simples_report',
                            'domain': [],
                            'context': dict(context, active_ids=ids),
                            'type': 'ir.actions.report.xml',
                            'report_type': 'pdf',
                            'res_id': ids and ids[0] or False    
                        }
        return action
    
    
dotcom_gestao_projectos_analise_orcamental_comparativa()


class dotcom_gestao_projectos_analise_orcamental_comparativa_linha(osv.osv):
    _name='gestao.projectos.analise.orcamental.comparativa.linha'
    _columns={
        'total_orcamento_receita':fields.float('Total Orçamento Receitas'),
        'total_orcamento_despesas':fields.float('Total Orçamento Despesas'),
        'desvio':fields.float('Desvio'),
        'desvio_percentual':fields.float('Desvio em Percentagem(%)'),
        
        'analise_id':fields.many2one('gestao.projectos.analise.orcamental.comparativa','Analise',required=True),
    }
dotcom_gestao_projectos_analise_orcamental_comparativa_linha()


class dotcom_gestao_projectos_analise_orcamental_comparativa_detalhes(osv.osv):
    _name='gestao.projectos.analise.orcamental.comparativa.detalhes'
    _columns={
        'periodo_id':fields.many2one('configuration.period','Período',readonly=False),
        'total_orcamento_receita':fields.float('Orçamento Receitas'),
        'total_orcamento_despesas':fields.float('Orçamento Despesas'),
        'desvio':fields.float('Desvio'),
        'desvio_percentual':fields.float('Desvio em Percentagem(%)'),
        'sequencia':fields.char('Sequencia', size=10),
        
        'state':fields.selection([('defice','Defice')],'State'),
        
        'analise_detalhada_id':fields.many2one('gestao.projectos.analise.orcamental.comparativa','Analise',required=True),
    }
    
    # _order='sequencia desc'
    
dotcom_gestao_projectos_analise_orcamental_comparativa_linha()