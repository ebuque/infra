# -*- coding: utf-8 -*-

import time
import datetime
import calendar
#from lxml import etree
#import netsvc
from osv import osv, fields, orm
from tools.translate import _
import pooler

import logging
logger = logging.getLogger('DOTCOM_LOGGER')



def data_primeiro_movimento(self,cr,uid,context):
    pool= pooler.get_pool(cr.dbname)
    movimentos_pool=pool.get('dotcom.gestao.projectos.movimento')
    #
    movimentos_ids=movimentos_pool.search(cr,uid,[])
    data_movimento=None
    if len(movimentos_ids)>0:
        movimento_object=movimentos_pool.browse(cr,uid,movimentos_ids[len(movimentos_ids)-1])
        data_movimento=movimento_object.data
    data_ultimo=data_ultimo_movimento(self,cr,uid,context)
    data_mes_anterior=data_ultimo_movimento

    return data_movimento


def data_ultimo_movimento(self,cr,uid,context):
    pool= pooler.get_pool(cr.dbname)
    movimentos_pool=pool.get('dotcom.gestao.projectos.movimento')
    
    movimentos_ids=movimentos_pool.search(cr,uid,[('state','=','emitido')])
    data_movimento=None
    if len(movimentos_ids)>0:
        movimento_object=movimentos_pool.browse(cr,uid,movimentos_ids[0])
        data_movimento=movimento_object.data

    return data_movimento


def ano_fiscal_ultimo_movimento(self,cr,uid,context):
    pool= pooler.get_pool(cr.dbname)
    movimentos_pool=pool.get('dotcom.gestao.projectos.movimento')
    
    movimentos_ids=movimentos_pool.search(cr,uid,[])
    data_movimento=None
    if len(movimentos_ids)>0:
        movimento_object=movimentos_pool.browse(cr,uid,movimentos_ids[len(movimentos_ids)-1])
        data_movimento=movimento_object.ano_fiscal_id.id

    return data_movimento


def getCompany(self,cr,uid,context):
    
    pool= pooler.get_pool(cr.dbname)
    user = pool.get('res.users').browse(cr,uid,uid)
    return user.company_id.name


def validar_referencias(cr,uid,referencia):
    #if context is None:
    #    context={}
    
    lista=referencia.split(' ')
    logger.info('NURMEDO DE PARCELAS %s' %str(lista))
    referencia=''
    if len(lista)>1:
        for parcela in lista:
            referencia=str(referencia)+str(parcela)
        
        #raise osv.except_osv(_('Acção Inválida !'), _('Nao são permitidos espaços em branco!!'))
    else:
        referencia=lista[0]
    return referencia


def getDocumento(self,cr,uid,context):
    if context is None:
        context={}
        
    pool= pooler.get_pool(cr.dbname)
    documento_id=self.pool.get('res.company')._get_tipo_documento(cr, uid, 'dotcom.tesouraria.talao.deposito')
    logger.info('DOCUMENTO ID ACHADO NA EMPRESA %s' %str(documento_id))
    
    documento_object=pool.get('dotcom.tesouraria.documento.movimentos').browse(cr,uid,documento_id)
    if bool(documento_id)==False or (bool(documento_id)==True and documento_object.ref=='DT02'):
        documento_pool=pool.get('dotcom.tesouraria.documento.movimentos')
        documentos_ids=documento_pool.search(cr,uid,[('ref','=','DT01')])
    
        if len(documentos_ids)>0:
            documento_id=documentos_ids[0]
        else:
            documento_id=False
    
    return documento_id
        
    #logger
   
def get_rubrica_ascendente(cr,uid,conta,context=None):
    if context is None:
        context={}
    i = None
    pool= pooler.get_pool(cr.dbname)
    obj = pool.get('dotcom.gestao.projectos.rubrica')
    ver = obj.search(cr, uid, [
                ('ref','=',conta),
                #('ano_fiscal_id','=',ano_fiscal_id)                
                ])
    #if ver and len(ver)>0:
    #    raise osv.except_osv(_('Acção Invalida !'), _('No sistema já está definida uma conta com esta referência!'))
    for x in range(1, len(conta)):
        now = conta[:-x]
        res = obj.search(cr, uid, [
                        ('ref','=',now),
                        #('ano_fiscal_id','=',ano_fiscal_id)
                        ])
        if res and len(res)>0:
            i = int(res[0])
            break
        else:
            continue
    return i   
    

def validar_numero_caracteres(cr,uid,conta,context=None):
    if context is None:
        context={}
    tamanho=len(conta)
    if tamanho<=1:
        raise osv.except_osv(_('Acção Invalida !'), _('A conta deve conter no mínimo 2 caracteres!'))
    elif tamanho>=2:
        if conta.isdigit() is False:
            raise osv.except_osv(_('Acção Invalida !'), _('A conta deve conter no mínimo 2 caracteres. Espaços, acentuação, caracteres epecias como !/(#,etc são inválidos!'))
    return {}

   
def validar_fecho_caixa(self,cr,uid,conta_object,data,context):
    if context is None:
        context={}
    pool= pooler.get_pool(cr.dbname)
    
    lancamentos_ids=pool.get('dotcom.tesouraria.lancamento.movimentos').search(cr,uid,[
                                                                                        ('state','=','emitido'),
                                                                                        ('conta_id','=',conta_object.id),
                                                                                        ('data','>',data)])
    if len(lancamentos_ids)>0:
        raise osv.except_osv(_('Acção Inválida !'), _('Conta['+str(conta_object.ref)+']'+str(conta_object.decricao)+'com lançamentos em data posterior a selecionada para o fecho da caixa!!'))
    
    return True 


def validar_data_ultima_abertura_fecho_caixa(self,cr,uid,conta_object,data,context):
    if context is None:
        context={}
        
    pool= pooler.get_pool(cr.dbname)
    abertura_caixa_ids=pool.get('dotcom.gestao.projectos.movimento.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                ('data','>',data),
                                                                                                ('conta_id','=',conta_object.id),
                                                                                                ('state','=','emitido'),
                                                                                                ('tipo_movimento','=','abertura'),
                                                                                                ])
    if len(abertura_caixa_ids)>0:
        raise osv.except_osv(_('Acção Inválida !'), _('Conta ['+str(conta_object.ref)+']'+str(conta_object.decricao)+' não está disponível para Movimentos na data seleccionada!!'))
    
    logger.info('DATA PASSADA PARA A ABERTURA DE CAIXA %s' %str(data))
    fechos_caixa_ids=pool.get('dotcom.gestao.projectos.movimento.abertura.fecho.caixa.linha').search(cr,uid,[
                                                                                                ('data','>',data),
                                                                                                ('conta_id','=',conta_object.id),
                                                                                                ('state','=','emitido'),
                                                                                                ('tipo_movimento','=','fecho'),
                                                                                                ])
    if len(fechos_caixa_ids)>0:
        raise osv.except_osv(_('Acção Inválida !'), _('Conta['+str(conta_object.ref)+']'+str(conta_object.decricao)+' não está disponível para Movimentos na data seleccionada!!'))
    
    return True
        
