# -*- encoding: utf-8 -*-


from lxml import etree
import netsvc
from osv import osv, fields, orm
from tools.translate import _
#from validators import validator
import logging
logger = logging.getLogger('DOTCOM_LOGGER_AGENCIA')