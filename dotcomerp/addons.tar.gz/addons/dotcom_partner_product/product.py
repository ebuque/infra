# -*- coding: utf-8 -*-

#  DotERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#  


import time
from osv import osv, fields, orm
from tools.translate import _

class dotcom_partner_product(osv.osv):

    _name = "dotcom.partner.product.line"
    _description = "Linhas de referencias de Produtos por parceiro"
    _columns = {
                'product_id': fields.many2one('product.product','Produto'),
                'partner_id': fields.many2one('res.partner','Parceiro', required=True),
                'ref': fields.char('Ref', size=64, required=True),
                'date': fields.date('Date and Time'),
                'user_id': fields.many2one('res.users','Usuário', required=True)
                }
    _defaults = {
                'date': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
                'user_id': lambda s, cr, u, c: u,
    }
    
    _sql_constraints = [('parceiro_ref_uniq', 'unique(product_id, partner_id)', 'É permitida apenas uma referëncia por parceiro!'),]
    
dotcom_partner_product()

class product_product(osv.osv):

    _name = 'product.product'
    _inherit = 'product.product'
    _columns = {
                'ref_partner_ids': fields.one2many('dotcom.partner.product.line','product_id','Referëncias de Produtos por parceiro'),
                'ean13': fields.char('C.Barras', size=60, help='Código de barras'),
                }
    
    def _check_ean_key(self, cr, uid, ids, context=None):
        #for product in self.browse(cr, uid, ids, context=context):
        #    res = check_ean(product.ean13)
        return True
product_product()