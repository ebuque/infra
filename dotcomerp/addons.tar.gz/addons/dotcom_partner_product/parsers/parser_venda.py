# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_vendas_report')

class jasper_report_venda(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_report_venda, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result = []
        venda_id = None
        if not context:
            context = {}

        venda = pool.get('dotcom.venda').browse(cr,uid,ids[0], context=context)
        logger.info('\n\n++++++++++++++++++++++++++\nReading FROM PARTNER_PRODUCT\n++++++++++++++++++++++++++\n\n')
        licenca_obj = pool.get('dotcom.licence')
        licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
 
        company = venda.company_id
        company_name = company.name or ''
        company_id = company.id or None
        company_id = str(company_id)
        company_street = company.street or ''
        company_phone = company.phone or ''
        company_fax = company.fax or ''
        company_tin = company.partner_id.nuit or ''
        company_city = company.city or ''
        company_email = company.email or ''
        company_web = company.website or ''
        logo_temp = ''
        
        exchanged_currency = ''
        exchanged_total = ''
        
        me = company.partner_id.id
        counter = 0
        
        banco_1 = ''
        conta_1 = ''
        nib_1 = ''
        moeda_1 = ''
        
        banco_2 = ''
        conta_2 = ''
        nib_2 = ''
        moeda_2 = ''
        
        accounts = pool.get('res.partner.bank').search(cr,uid,[('partner_id','=',me),('footer','=',True)],limit=2)
        #logger.info('Accounts : %s' % str(accounts))
        if accounts and len(accounts)>0:
            for account in accounts:
                counter = counter + 1
                if counter == 1:
                    conta = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_1 = conta.bank_name or ''
                    conta_1 = conta.acc_number or ''
                    nib_1 = conta.nib or ''
                    moeda_1 = conta.currency_id.name or ''
                    logger.info('CONTA 0 : done')
                    continue
                elif counter == 2:
                    acc = pool.get('res.partner.bank').browse(cr,uid,account)
                    banco_2 = acc.bank_name or ''
                    conta_2 = acc.acc_number or ''
                    nib_2 = acc.nib or ''
                    moeda_2 = acc.currency_id.name or ''
                    logger.info('CONTA 1 : done and BREAK')
                    break
                else:
                    break
        
        if company.logo:
            logo_temp = 'logo_'+company_id+'.png'
            logotipo = base64.b64decode(str(company.logo).decode('latin-1'))
            pathfinder = '/opt/dotcomerp/server/openerp/addons/dotcom_doc/report2/logos/'+'logo_'+company_id+'.png'
            ficheiro = open(pathfinder, 'w+')
            try:
                ficheiro.write(logotipo)
            finally:
                ficheiro.close()
        
        product_logo = ''      
        if company.product_logo:
            product_logo = 'product_logo_'+company_id+'.png'
            prod_logo = base64.b64decode(str(company.product_logo).decode('latin-1'))
            pathfinder = '/opt/dotcomerp/server/openerp/addons/dotcom_doc/report2/logos/'+'product_logo_'+company_id+'.png'
            fich = open(pathfinder, 'w+')
            try:
                fich.write(prod_logo)
            finally:
                fich.close()
        
        partner_name = venda.partner_name or ''
        parent_partner_name = ''
        if venda.partner_id.parent_id:
            parent_partner_name = venda.partner_id.parent_id.name
        partner_address = venda.partner_address or ''
        partner_tin = venda.partner_nuit_name or ''
        
        doc_date = venda.document_date
        doc_due_date = venda.due_date
        doc_payterm = venda.payment_term_id.name or ''
        doc_currency_name = venda.doc_currency.name or ''
        doc_type_name = venda.doc_type.name or ''
        doc_number = venda.document_number or ''
        partner_phone = venda.partner_id.phone or ''
        
        doc_currency_symbol = venda.doc_currency.symbol or ''
        doc_subtotal = venda.lines_sum or 0
        doc_discount = venda.total_discount or 0
        doc_total = venda.total_document or 0
        doc_vat = venda.total_vat or 0
        desconto_comercial_perc = venda.desconto or ''
        
        extra_data = venda.extra_data or False
        should_print = venda.pagamento_directo or False
        
        #logger.info('Extra Data %s , Should Print %s' % (extra_data, should_print))
        
        if (extra_data and should_print) == True:
            extra_data = 'PRINT'
        elif ((extra_data==False) and (should_print==True)):
            extra_data = 'extenso'
        else:
            extra_data = ''

        extenso = venda.total_amount_str or ''
        banco_ref = venda.banco_id and venda.banco_id.bic or ''
        banco_nome = venda.banco_id and venda.banco_id.name or ''
        banco = '%s - %s' % (banco_ref, banco_nome)
        transaccao = venda.transaction or ''
        metodo = venda.payment_method and venda.payment_method.name
        
        segunda = venda.seg_via or False
        
        notes = venda.notes or ''
        
        taxas = []
        
        isento_base = 0
        isento_amount = 0
        
        normal_vat_base = 0
        normal_vat_amount = 0
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        desconto_comercial = venda.desconto_comercial or 0
        
        if venda.print_other_currency and venda.alternative_currency:
            doc_currency = venda.alternative_currency
            alternative_amount = venda.alternative_currency_value or 0
            exchanged_currency = doc_currency.name or ''
            exchanged_total = doc_total/alternative_amount
        
        motivo_isencao = ''
        for line in venda.taxes_ids:
            if line.iva_id.tax==0:
                isento_base = isento_base + line.vat_base or 0
                isento_amount = isento_amount + line.vat_amount or 0
                motivo_isencao = venda.iva_isento and venda.iva_isento.name or ''
            else:
                normal_vat_base = normal_vat_base + line.vat_base or 0
                normal_vat_amount = normal_vat_amount + line.vat_amount or 0
        
        print_labels = []
        if venda.seg_via:
            print_labels = ['Segunda Via']
        elif venda.only_original:
            print_labels = ['Original']
        else:
            for print_label in venda.doc_type.prints_ids:
                print_labels.append(print_label.name or '')
        
        if not print_labels:
            raise osv.except_osv(_('Acção Inválida !'), _('Não foram definidas vias de impressão!'))

        for label in print_labels:
            for line in venda.sales_lines:
                line_prod_code = line.prod_id.default_code or ''
                if venda.print_with_ref:
                    logger.info('\n\nPrint Requested With Partner Reference\n\n')
                    product = line.prod_id
                    for mov in product.ref_partner_ids:
                        if mov.partner_id.id == venda.partner_id.id:
                            logger.info('\n\nPartner Reference Found\n\n')
                            line_prod_code = mov.ref or ''
                            break
                line_prod_desc = line.prod_desc or line.prod_id.name  or ''
                line_unit = line.prod_uom and _(line.prod_uom.name) or ''
                line_qty = line.qty or 0
                line_unit_price = line.unit_price or 0
                line_desc = line.discount_pct or 0
                line_tax = line.tax_id.tax or 0
                line_total = line.line_total or 0
                line_notes = line.notes or ''
                
                if line.iva_incluido:
                    valor_iva = 0
                    valor_iva_total = 0
                    imposto = line.tax_id.tax or 0
                    valor_iva_total = (line.qty*line.unit_price)-((line.qty*line.unit_price)/(imposto/100+1))
                    valor_iva = (line.unit_price)-((line.unit_price)/(imposto/100+1))
                    
                    iva_id = line.tax_id.id
                    line_unit_price = self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, iva_id, line_unit_price,  context=context)
                
                data = {
                        'print_name': label,
                        'company_logo' : logo_temp,
                        'product_logo': product_logo,
                        'licenca': licenca,
                        'company_name' : company_name,
                        'path': os.getcwd(),
                        'company_street' : company_street,
                        'company_phone' : company_phone,
                        'company_fax' : company_fax,
                        'company_tin' : company_tin,
                        'company_city' : company_city,
                        'company_email': company_email,
                        'company_web': company_web,
                        
                        'parent_partner': parent_partner_name,
                        'partner_name' : partner_name,
                        'partner_address' : partner_address,
                        'partner_tin' : partner_tin,
                        'partner_phone': partner_phone,
                        
                        'doc_date' : doc_date,
                        'doc_due_date' : doc_due_date,
                        'doc_payterm' : doc_payterm,
                        'doc_currency_name' : doc_currency_name,
                        'doc_type_name' : doc_type_name,
                        'doc_number' : doc_number,
                        'desconto_comercial_perc': desconto_comercial_perc,
                        
                        'line_prod_code' : line_prod_code,
                        'line_prod_desc' : line_prod_desc,
                        'line_unit' : line_unit,
                        'line_qty' : abs(line_qty),
                        'line_unit_price' : abs(line_unit_price),
                        'line_desc' : line_desc,
                        'line_tax' : abs(line_tax),
                        'line_total' : abs(line_total),
                        'line_note': line_notes,

                        'doc_currency_symbol' : doc_currency_symbol,
                        'doc_subtotal' : abs(doc_subtotal),
                        'doc_discount' : abs(doc_discount),
                        'doc_total' : abs(doc_total),
                        'doc_vat' : abs(doc_vat),
                        
                        'iva_isento_base': abs(isento_base),
                        'iva_isento_amount': abs(isento_amount),
                        'iva_17_base': abs(normal_vat_base),
                        'iva_17_amount': abs(normal_vat_amount),
                        
                        'notes': notes,
                        
                        'banco': banco_1,
                        'conta': conta_1,
                        'nib': nib_1,
                        'moeda': moeda_1,
                        
                        'banco_1': banco_2,
                        'conta_1': conta_2,
                        'nib_1': nib_2,
                        'moeda_1': moeda_2,
                        'print_date': now,
                        'desconto_comercial':desconto_comercial,
                        
                        'extra': extra_data,
                        'extenso': extenso,
                        'banco_tr': banco,
                        'transaccao': transaccao,
                        'metodo_pagamento': metodo,
                        
                        'exchanged_total': exchanged_total,
                        'exchanged_currency': exchanged_currency,
                        
                        'motivo_isencao': motivo_isencao,
                }
                result.append(data)
        print result
        return result

jasper_reports.report_jasper('report.dotcom_venda_partner_report','dotcom.venda',parser=jasper_report_venda)