# -*- coding: utf-8 -*-
{
    'name': 'CSV Data Importer',
    'version': '1.0',
    'category': 'Tools',
    'author': 'Dércio Duvane',
    'sequence': 5,
    'summary': 'Loads and Edits CSV file Contents',
    'description': '',
    # 'website': 'https://www.odoo.com/page/crm',
    'depends': ['base','product'],
    'data': ['security/csv_importer_security.xml','security/ir.model.access.csv','views/csv_importer.xml'],
    'css': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
