import logging
import base64
import datetime
import csv

from openerp.osv import osv, fields
logger = logging.getLogger('CSV_IMPORTER')


class csv_importer(osv.Model):
    _name = 'csv.importer'
    _description = 'CSV importing and parsing Module'
    _columns = {
                    'name': fields.char('Name', size=300,readonly=True, states={'draft': [('readonly', False)]}),
                    'file': fields.binary('CSV File', attachment=True,readonly=True, states={'draft': [('readonly', False)]}),
                    'file_created': fields.binary('CSV File',readonly=True),
                    'ignore': fields.integer('Ignore line', readonly=True, states={'draft': [('readonly', False)]}),
                    
                    'importer_lines': fields.one2many('csv.importer.line','importer_id', string='CSV Lines',readonly=True, states={'loaded': [('readonly', False)]}),
                    'state': fields.selection([('draft','Draft'),('loaded','Loaded'),('downloaded','Downloaded'),('done','Done')], 'State', readonly=True),
                    'col_nr': fields.integer('Image Column', help='Download URL From column Nr. and convert it to CSV',readonly=True, states={'loaded': [('readonly', False)],'downloaded': [('readonly', False)]}),
                    'first_line': fields.char('First Line', size=300),
                }
    _defaults = {'name': str(datetime.datetime.now().isoformat()), 'state':'draft', 'ignore': 0}
    
    def action_load_file(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = {}
        read = self.read(cr, uid, ids and ids[0], ['file','ignore', 'id'])
        id = read.get('id', False)
        from random import randrange
        PATH = '/tmp/%s.csv' % randrange(96000)
        file_b64 = read.get('file', False)
        # WRITING FILE TO TEMP FOLDER
        try:
            input_data = base64.b64decode(str(file_b64).decode('latin-1'))
            ficheiro = open(PATH, 'w+')
            try:
                ficheiro.write(input_data)
            finally:
                ficheiro.close()
        except Exception:
            osv.except_osv('Error !', 'Unable to load CSV File!')
        
        # READING FILE
        count = 0
        with open(PATH, 'rb') as r:
            reader = csv.reader(r)
            for row in reader:
                logger.info('\n%s' % row)
                if read.get('ignore', 0) == count:
                    res['first_line'] = row
                    continue
                else:
                    line_pool = self.pool.get('csv.importer.line').create(cr, uid, {'sequence': count,'importer_id': id})
                    r_seq = 0
                    for each in row:
                        this = {}
                        this['line_id'] = line_pool
                        this['sequence'] = r_seq
                        this['name'] = each
                        self.pool.get('csv.importer.line.column').create(cr, uid, this)
                        r_seq += 1
                    count += 1
        self.write(cr, uid, id, res)
        return {'value': res}
csv_importer()

class csv_importer_lines(osv.Model):
    _name = 'csv.importer.line'
    _description = 'Contents of the CSV File'
    _columns = {
                'sequence': fields.integer('Sequence'),
                'importer_id': fields.many2one('csv.importer', 'Importer', invisible=True),
                'lines_ids': fields.one2many('csv.importer.line.column', 'line_id', string='Line Columns'),
    }
    _rec_name = 'sequence'
csv_importer_lines()

class csv_importer_line_column(osv.Model):
    _name = 'csv.importer.line.column'
    _columns = {
                'name': fields.char('Value', size=120),
                'sequence': fields.integer('Sequence'),
                'line_id': fields.many2one('csv.importer.line', 'Line')
    }
csv_importer_line_column()