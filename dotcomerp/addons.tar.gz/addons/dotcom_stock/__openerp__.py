# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


{
    'name': 'DotComERP - Stock Management',
    'version': '1.2.1',
    'description': """The Stock Management of DotComERP.""",
    'author': 'DotCom, LDA',
    'category': 'CM/Application',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'depends': ['base','dotcom_base','dotcom_doc','dotcom_doc_base','product','dotcom_doc_reports','jasper_reports'],
    'init_xml': [],
    'update_xml':[
                'security/dotcom_stock_security.xml',
                'views/stock_config_view.xml',
                'warehouse/warehouse_view.xml',
                'views/stock_view.xml',
                'views/stock_product.xml',
                'views/stock_dotcom_doc.xml',
                'views/stock_dotcom_document_view.xml',
                'views/groups.xml',
                'report/reports.xml',
                'wizard/extracto_artigo_wizard_view.xml',
                'wizard/entrada_saida_wizard_view.xml',
                'wizard/inventory_wizard_view.xml',
                #'wizard/processamento_stock.xml',
                'wizard/mapa_vendas_wizard_view.xml',
                'wizard/stock_reentry_view.xml',
                #'wizard/fix_view.xml',
                'data/data.xml',
                'data/cron_stock_updater.xml',
                
                'security/ir.model.access.csv',
                  ],
    'demo_xml': [],
    'test': [],
    'installable': True,
    'application': False,
    'complexity': 'easy',
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
