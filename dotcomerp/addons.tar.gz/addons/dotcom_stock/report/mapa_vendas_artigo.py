# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
import pooler
from datetime import datetime, timedelta
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_stock_report')

def perc(part, whole):
    try:
        ret = (float(part)*100)/float(whole)
    except ZeroDivisionError:
        ret = 100.0
    return ret

class jasper_stock_venda(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_stock_venda, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        
        inicio = datetime.now().strftime('%d/01/01')
        fim = datetime.now().strftime('%d/%m/%Y')
        if 'form' in data:
            inicio = datetime.strptime(data['form']['date_from'], '%Y-%m-%d').strftime('%d/%m/%Y') or _('Undefined')
            fim = datetime.strptime(data['form']['date_to'], '%Y-%m-%d').strftime('%d/%m/%Y') or  _('Undefined')
            price = _('Total Líquido')

        movement = 'Mapa de Vendas por Produto'
        
        return {	
                'DOCUMENTO': movement,
                'label_data_inicio': _('From'),
                'label_data_fim': _('To'),
                'FROM_DATE': inicio,
                'TO_DATE': fim,
                
                'label_doc_type': _('Document'),
                'label_data': _('Date'),
                'label_armazem': _('Stock Location'),
                'label_qty': _('Quantity'),
                'label_preco': price,
                'label_qty': _('QTY'),
                'label_product': _('Product'),
                'label_unit': _('Un.'),
                'label_total': _('Total'),
                'TOTAL': _('Total Global'),
                'COPYRIGHT': _('DotComERP'),
                
                'label_custo': _('Custo'),
                'label_discount': _('Total Desc.'),
                'label_lucro': _('Margem'),
                'label_lucro_perc': _('Margem (%)'),
                'label_ref': _('Referência'),
                'TOTAL_PAGE': _('Total'),
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
        
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        query_vendas = []
        query_linhas = []
        
        data_from = datetime.now().strftime('%d/%m/%Y')
        data_to = datetime.now().strftime('%d/%m/%Y')
        price = 'pcp'
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        tipo_documents = []

        if 'form' in data:
            products = []
            
            if data['form']['date_from']:
                data_from = datetime.strptime(data['form']['date_from'], '%Y-%m-%d')
                query_vendas.append(('document_date','>=',data_from))
            if data['form']['date_to']:
                data_to = datetime.strptime(data['form']['date_to'], '%Y-%m-%d')
                query_vendas.append(('document_date','<=',data_to))
            
            if data['form']['product_ids']:
                product_id = data['form']['product_ids'] or None
                products = product_id
            
            if data['form']['category_id']:
                category_id = data['form']['category_id'] and data['form']['category_id'][0]
                prods = pool.get('product.product').search(cr, uid, [('categ_id','=',category_id)])
                for prod in prods:
                    if prod not in products:
                        products.append(prod)

            if products:
                query_linhas.append(('prod_id','in',products))
            
            if data['form']['price']:
                price = data['form']['price'] or 'pcp'
                
            if data['form']['warehouse_ids']:
                warehouse_id = data['form']['warehouse_ids'] or None
                warehouse_childs = pool.get('dotcom.stock.location').child_get(cr,uid,warehouse_id)[0]
                query_linhas.append(('stock_location','in',warehouse_childs))
            
            if data['form']['document_ids']:
                tipo_documents = data['form']['document_ids'] or None
            else:
                tipo_documents = pool.get('documento.tipo').search(cr, uid, [('tipo_doc','=','sales')])
            query_vendas.append(('doc_type','in',tipo_documents))
        
        query_vendas.append(('state','in',['validated','done']))
        company_name = pool.get('res.users').browse(cr,uid,uid).company_id.name or ''
        currency = pool.get('res.users').browse(cr,uid,uid).company_id.currency_id.name
        
        licenca_obj = pool.get('dotcom.licence')
        #licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        #licenca = 'Não Licenciado'

        licenca_vals= licenca_obj.check_licence_relatorios(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        licenca_id=False
        if licenca_vals['estado']=='activa':
            licenca_id=licenca_vals['licenca']
            
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
        
        vendas = pool.get('dotcom.venda').search(cr, uid, query_vendas)
        linhas = []
        query_linhas.append(('document_top','in',vendas))
        linhas = pool.get('dotcom.venda.linha').search(cr, uid, query_linhas)
        
        prod_qty = {}
        prod_price = {}
        prod_discount = {}
        
        final_prod = {}
        
        logger.info('\n\nQuery de Vendas:%s\nResultado da query de vendas: %s\n\nQuery das linhas do producto: %s\nResultado: %s' % (query_vendas, vendas, query_linhas, linhas))
        
        for each in pool.get('dotcom.venda.linha').read(cr, uid, linhas, ['qty','discounted_val','line_total','prod_id']):
            prod_id = each['prod_id'] and each['prod_id'][0]

            prod_preco = prod_price.get(prod_id, 0)
            prod_qtd = prod_qty.get(prod_id, 0)
            prod_desconto = prod_discount.get(prod_id, 0)
            
            qtds = prod_qtd + abs(each.get('qty', 0))
            precos = prod_preco + abs(each.get('line_total', 0))
            descontos = prod_desconto + abs(each.get('discounted_val', 0))
            
            prod_qty[prod_id] = qtds
            prod_price[prod_id] = precos
            prod_discount[prod_id] = descontos
            
            final_prod[prod_id] = {'qty': qtds, 'price': precos, 'discount': descontos}
        
        logger.info('\n\n\n\nRESULTADO POR PROD_ID: %s' % final_prod)
        
        for one in final_prod:
            product = pool.get('product.product').browse(cr, uid, one)
            prod_ref = product and product.default_code or ''
            prod_name = product and product.name or ''
            
            current = final_prod.get(one, {})
            qty = current.get('qty', 0)
            preco = current.get('price', 0)
            descontos = current.get('discount', 0)
            
            preco_custo = pool.get('product.product').read(cr, uid, one, [price])
            custo = qty * (preco_custo and preco_custo.get(price, 0))
            id = one
            data = {
                    'COMPANY_NAME': company_name,
                    'licenca': licenca,
                    'line_ref': prod_ref,
                    'line_product': prod_name,
                    'line_qty': qty,
                    'line_price': preco,
                    'line_custo': custo,
                    'line_discount': descontos,
                    'currency': currency,
                    'print_date': now,
                    'id': id,
                }
            result.append(data)
        result = sorted(result, key=lambda d: (d['line_ref'],d['id']), reverse=False)
        return result

jasper_reports.report_jasper('report.dotcom_stock_venda','dotcom.stock.report',parser=jasper_stock_venda)