# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
import pooler
from datetime import datetime, timedelta
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_stock_artigo')

class jasper_stock_extracto_artigo(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_stock_extracto_artigo, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        
        inicio = datetime.now().strftime('%d/%m/%Y')
        fim = datetime.now().strftime('%d/%m/%Y')
        if 'form' in data:
            try:
                inicio = datetime.strptime(data['form']['date_from'], '%Y-%m-%d').strftime('%d/%m/%Y')
            except TypeError:
                inicio = ''
            try:
                fim = datetime.strptime(data['form']['date_to'], '%Y-%m-%d').strftime('%d/%m/%Y') or  _('Undefined')
            except TypeError:
                fim = ''

        return {	
                'DOCUMENTO': _('Stock Movement Statement'),
                'label_data_inicio': _('From'),
                'label_data_fim': _('To'),
                'FROM_DATE': inicio,
                'TO_DATE': fim,
                'label_doc_type': _('Document'),
                'label_total_global': _('Total Global'),
                'label_data': _('Date'),
                'label_armazem': _('Stock Location'),
                'label_qty': _('Quantity'),
                'label_preco_unit': _('Unit Price'),
                'label_pcm': _('Average Cost Price'),
                'label_entrada': _('Entrance Price'),
                'label_saida': _('Sell Price'),
                'label_stock_total': _('Total'),
                'TOTAL': _('Total'),
                'COPYRIGHT': _('DotCom ERP'),
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def modifyTuple(tup, oldval, newval):
        lst=list(tup)
        for i in range(tup.count(oldval)):
            index = lst.index(oldval)
            lst[index]=newval
        return tuple(lst)
    
    def is_update(self, cr, uid, model_id, order_id, context=None):
        if context is None:
            context = {}
        desired = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order', context=context)
        if model_id == desired:
            classe = self.pool.get('ir.model').browse(cr, uid, model_id).model
            order = self.pool.get(classe).browse(cr, uid, order_id)
            doc_type = order and order.doc_type and order.doc_type.type or False
            if doc_type and doc_type == 'reset':
                return True
            else:
                return False
        else:
            return False

    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        query = []
        outros = []
        locations = False
        
        last_prod = False
        
        data_from = datetime.now().strftime('%d/%m/%Y')
        data_to = datetime.now().strftime('%d/%m/%Y')
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))

        if 'form' in data:
            products = []
            if data['form']['date_from']:
                data_from = datetime.strptime(data['form']['date_from'], '%Y-%m-%d')
                #query.append(('date','>=',data_from))
            if data['form']['date_to']:
                data_to = datetime.strptime(data['form']['date_to'], '%Y-%m-%d')
                #query.append(('date','<=',data_to))
            
            if data['form']['product_id']:
                product_id = data['form']['product_id'] or None
                products = product_id

            if data['form']['warehouse_id']:
                warehouse_id = data['form']['warehouse_id'] or None
                warehouse_childs = pool.get('dotcom.stock.location').child_get(cr,uid,warehouse_id)[0]
                query.append(('location_id','in',warehouse_childs))
                locations = warehouse_childs
                
            if data['form']['category_id']:
                category_id = data['form']['category_id'] and data['form']['category_id'][0]
                logger.info('Category %s' % category_id)
                prods = self.pool.get('product.product').search(cr, uid, [('categ_id','=',category_id)])
                for prod in prods:
                    if prod not in products:
                        products.append(prod)

        company_name = pool.get('res.users').browse(cr,uid,uid).company_id.name or ''
        currency_name = pool.get('res.users').browse(cr,uid,uid).company_id.currency_id.name or ''
        
        licenca_obj = pool.get('dotcom.licence')
        # licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        # licenca = 'Não Licenciado'

        licenca_vals= licenca_obj.check_licence_relatorios(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        licenca_id=False
        if licenca_vals['estado']=='activa':
            licenca_id=licenca_vals['licenca']
            
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
        
        if not products:
            products = self.pool.get('product.product').search(cr, uid, [('type','=','product')])
        
        logger.info('\n\nProducts %s' % products)
        for product in products:
            
            logger.info('\nREADING Product %s' % product)
            
            #if not last_prod:
                #query.append(('prod_id','=',product))
            if last_prod:
                try:
                    index = query.index(('prod_id','=',last_prod))
                    del query[index]
                except Exception as ERROR:
                    logger.info('\n\nERRO: %s\n\n' % ERROR.message())
            
            query.append(('prod_id','=',product))
            last_prod = product
            
            outros.append(('state','=','done'))
            relatorios = []
            report_ids = []
            lista_final = []
        
            report_ids = pool.get('dotcom.stock.report').search(cr,uid,query, order='ordem ASC')
            for one in self.pool.get('dotcom.stock.report').read(cr, uid, report_ids, ['ordem', 'id']):
                relatorios_lts = {}
                relatorios_lts['ordem'] = one['ordem']
                relatorios_lts['id'] = one['id']
                relatorios.append(relatorios_lts)
            
            if locations:
                docs_update = self.pool.get('dotcom.stock.document').search(cr, uid, [('type','=','reset')])
                movimentos = self.pool.get('dotcom.stock.order').search(cr, uid, [('doc_type','in',docs_update)])
                modelo = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order', context=context)
                outros = []
                outros.append(('model_id','=',modelo))
                outros.append(('origin_id','in',movimentos))
                outros.append(('state','=','done'))
                outros.append(('prod_id','=',product))
                outros.append(('location_id','not in',locations))
                updates = self.pool.get('dotcom.stock.report').search(cr,uid,outros, order='ordem ASC')
                logger.info('\n\nUpdates %s' % updates)
                for each in self.pool.get('dotcom.stock.report').read(cr, uid, updates, ['ordem', 'id']):
                    relatorios_lts = {}
                    relatorios_lts['ordem'] = each['ordem']
                    relatorios_lts['id'] = each['id']
                    relatorios.append(relatorios_lts)

            #logger.info('\n\n\n\nReports %s' % relatorios)
            for rel in sorted(relatorios, key=lambda d: (d['ordem'],d['id']), reverse=False):
                key = rel.get('id', None)
                if key not in lista_final:
                    lista_final.append(key)
            
            logger.info('LISTA FINAL: %s' % lista_final)
            stock_available=0.0
            previous_stock = 0.0
            for report in pool.get('dotcom.stock.report').browse(cr,uid,lista_final):
                line_warehouse = report.location_id.ref or ''
                
                line_id = report.id
                line_date = datetime.strptime(report.date, '%Y-%m-%d').strftime('%d/%m/%Y')
                line_document = report.origin or ""
                line_qty = report.qty or 0
                if report.operacao == 'reset':
                    stock_available=0.0

                stock_available=stock_available+line_qty

                stock_available=round(stock_available, 2) 
                logger.info('\nline_qty=================%s' % line_qty)
                reset_me = line_qty
                logger.info('\nreset_me=================%s' % reset_me)
                line_unit_price = report.price or 0
                line_pcm = report.average_cost or 0
                line_reset = report.reset or ""
                if line_qty<0:                
                    line_entrada = 0
                    line_saida = line_qty*line_pcm
                    logger.info('\nline_saida=================%s' % line_saida)
                else:
                    line_entrada = line_qty*line_unit_price
                    line_saida = 0
                    logger.info('\nline_entrada=================%s' % line_entrada)
                product_name = report.prod_id.name or ""
                reset_me = 'NO'
                warehouse = report.location_id.id
                if locations and warehouse not in locations:
                    model_id = report.model_id.id
                    order_id = report.origin_id
                    if self.is_update(cr, uid, model_id, order_id, context=context):
                        reset_me = 'YES'
                report_date=datetime.strptime(report.date, '%Y-%m-%d')
                logger.info('\nreport_date%s' % report_date)
                logger.info('\nreport_date (type)%s' % type(report_date))
                logger.info('\nline_qty=================%s' % line_qty)
                if report.state != 'draft' and (report_date <= data_from):
                    if report.operacao == 'reset':
                        previous_stock=0.0
                    previous_stock = previous_stock+line_qty

                if report.state != 'draft' and (report_date >= data_from and report_date <= data_to):
                    logger.info('\nline_qty=================%s' % line_qty)
                    lista = {
                        'COMPANY_NAME': company_name,
                        'currency': currency_name,
                        'line_warehouse': line_warehouse,
                        'line_date': line_date,
                        'line_document': line_document,
                        'line_qty': line_qty,
                        'line_unit_price': line_unit_price,
                        'line_pcm': line_pcm,
                        'line_entrada': line_entrada,
                        'line_saida': line_saida,
                        'product': product_name,
                        'line_reset': line_reset,
                        'licenca':licenca,
                        'line_id': line_id,
                        'print_date': now,
                        'stock_available':stock_available,
                        'previous_stock':previous_stock,
                        'reset_me': reset_me,
                        }
                    logger.info('\nlista=================%s' % lista)
                    logger.info('\nstock_available=================%s' % stock_available)

                    
                    result.append(lista)
                    logger.info('\n%s' % lista)
        
        result = sorted(result, key=lambda d: (d['product'],d['line_id']), reverse=False)
        return result

jasper_reports.report_jasper('report.dotcom_stock_extracto_artigo','dotcom.stock.report',parser=jasper_stock_extracto_artigo)