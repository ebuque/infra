# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc import JasperDataParser
from osv import osv,fields 
import pooler
from datetime import datetime, timedelta
import time
import base64
import os
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_orders_report')

class jasper_stock_order(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_stock_order, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
       return {}
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result = []
        order_id = None
        if not context:
            context = {}

        order = pool.get('dotcom.stock.order').browse(cr,uid,ids[0], context=context)
        
        licenca_obj = pool.get('dotcom.licence')
        licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
 
        company = order.company_id
        company_name = company.name or ''
        company_id = company.id or None
        company_id = str(company_id)
        company_street = company.street or ''
        company_phone = company.phone or ''
        company_fax = company.fax or ''
        company_tin = company.partner_id.nuit or ''
        company_city = company.city or ''
        company_email = company.email or ''
        company_web = company.website or ''
        logo_temp = ''
        
        exchanged_currency = ''
        exchanged_total = ''
        
        logo_temp = company.logo or ''
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        currency = order.currency_id
        currency_name = currency and currency.ref or ''
        currency_ref = currency and currency.name or ''
        currency_this = '[%s] %s' % (currency_ref, currency_name)
        
        moeda_primaria = currency_ref#order.moeda_primaria_id and order.moeda_primaria_id.name or ''
        moeda_secundaria = order.moeda_secundaria_id and order.moeda_secundaria_id.name or ''
        
        doc_type = order.doc_type
        doc_type_name = doc_type and doc_type.name or ''
        is_transfer = False
        if doc_type.type == 'trans':
            is_transfer = True
        
        print_other = False
        exchanged_total = 0
        if order.print_other_currency:
            print_other = 'True'
            primario = order.total_primario or 0
            cambio = order.alternative_currency_value or 1
            moeda_secundaria = order and order.alternative_currency and order.alternative_currency.name or ''
            try:
                exchanged_total = primario / cambio
            except Exception:
                exchanged_total = 0
            
        
        for line in order.stock_lines:
            line_prod_code = line.prod_id.default_code or ''
            line_prod_desc = line.description or line.prod_id and line.prod_id.name or ''
            line_unit = line.prod_uom and _(line.prod_uom.name) or ''
            line_qty = line.qty or 0
            line_unit_price = line.un_price or 0
            
            origem = ''
            destino = ''
            destino_ref = line.location_id and line.location_id.ref or ''
            destino_name = line.location_id and line.location_id.name or ''
            destino = '[%s] %s' % (destino_ref, destino_name)
            if is_transfer:
                origem_ref = line.from_id and line.from_id.ref or ''
                origem_name = line.from_id and line.from_id.name or ''
                origem = '[%s] %s' % (origem_ref, origem_name)
            
            data = {
                    'line_prod_code': line_prod_code,
                    'line_prod_desc': line_prod_desc,
                    'line_unit': line_unit,
                    'line_qty': line_qty,
                    'line_unit_price': line_unit_price,
                    'line_origin': origem,
                    'line_location': destino,
                    'company_logo' : logo_temp,
                    'licenca': licenca,
                    'company_name' : company_name,
                    'path': os.getcwd(),
                    'company_street' : company_street,
                    'company_phone' : company_phone,
                    'company_fax' : company_fax,
                    'company_tin' : company_tin,
                    'company_city' : company_city,
                    'company_email': company_email,
                    'company_web': company_web,
                    'doc_date': order.date or '',
                    'doc_currency_name': currency_this,
                    'doc_type_name': doc_type_name,
                    'doc_number': order.code or '',
                    'print_name': 'Original',
                    'notes': order.notes or '',
                    'doc_total': order.total or 0,
                    'print_other': print_other,
                    'exchanged_total': exchanged_total,
                    'print_date': now,
                    'is_transfer': is_transfer,
                    
                    'doc_currency_symbol': moeda_primaria,
                    'exchanged_currency': moeda_secundaria,
                }
            result.append(data)
        return result

jasper_reports.report_jasper('report.dotcom_stock_order_report','dotcom.stock.order',parser=jasper_stock_order)
