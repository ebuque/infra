# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
import time
import base64
from tools.translate import _
import os
import logging
logger = logging.getLogger('dotcom_stock_artigo')

class jasper_dotcom_stock_inventory(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_dotcom_stock_inventory, self).__init__(cr, uid, ids, data, context)
        self.sheet_names = []
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        
        price = ''
        if 'form' in data:
            temp_price = data['form']['price']
            if temp_price=='unit':
                price = _('Unit Price')
            elif temp_price=='pcm':
                price = _('Average Cost Price')
            elif temp_price=='pcu':
                price = _('PCU')
            elif temp_price=='pcp':
                price = _('PCP')

        return {	
                'DOCUMENTO': _('Inventory'),
                'label_armazem':"Loc",# _('Stock Location'),
                'label_prod': _('Ref'),
                'label_product': _('Description'),
                'label_total_global': _('Total Global'),
                'label_qty': _('Available Stock'),
                'label_preco': price,
                'label_total': _('Total'),
                'label_unit': _('UN'),
                'TOTAL': _('Total'),
                'COPYRIGHT': _('DotComERP'),
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
    
    #def calculate_quantities(self, cr, uid, ids, data_inicio, data_fim, context={}):
    #    if context is None:
    #        context = {}
    #    if not ids:
    #        ids = self.pool.get('product.product').search(cr, uid, [('type','=','product')])
    #    availability = self.pool.get('dotcom.stock.available')
    #    for produto in self.pool.get('product.product').browse(cr, uid, ids):
    #        lista = {}
    #        qty_available = 0
    #        total = 0
    #        reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto and produto.id)], order='create_date asc')
    #        reports_ids = sorted(reports_ids)
    #        for movimento in self.pool.get('dotcom.stock.report').browse(cr, uid, reports_ids):
    #            origin_classe = movimento and movimento.model_id and movimento.model_id.model
    #            qty_available = 0
    #            is_not_act = True
    #            if origin_classe == 'dotcom.stock.order':
    #                origin_id = movimento and movimento.origin_id or None
    #                this = self.pool.get(origin_classe).browse(cr, uid, origin_id)
    #                this_doc_type = this and this.doc_type
    #                if this_doc_type and this_doc_type.type == 'reset':
    #                    is_not_act = False
    #            location = movimento.location_id and movimento.location_id.id
    #            if is_not_act:
    #                logger.info('ADDING QTY>>>')
    #                if lista.has_key(location):
    #                    qty_available = lista.get(location) + movimento.qty or 0
    #                else:
    #                    qty_available = movimento.qty or 0
    #            else:
    #                logger.info('RESETTING QTYS')
    #                qty_available = movimento.qty or 0
    #                prod_id = movimento.prod_id.id
    #                self.pool.get('dotcom.stock.order').reset_stock_locations(cr, uid, location, prod_id, context=context)
    #                lista = {}
    #            lista[location] = qty_available
    #            self.pool.get('dotcom.stock.report').write(cr, uid, movimento.id, {'sequence': movimento.id})
    #        result = availability.search(cr, uid, [('prod_id','=',produto.id)])
    #        availability.unlink(cr, uid, result)
    #        for locale in lista:
    #            new = {}
    #            new['prod_id'] = produto and produto.id
    #            new['location_id'] = locale
    #            new['qty_available'] = lista.get(locale)
    #            total = total + lista.get(locale)
    #            availability.create(cr, uid, new, context=context)
    #        self.pool.get('product.product').write(cr, uid, [produto and produto.id],{'stock_qty':total})
    #    return False
    #
    def processar_anteriores(self, cr, uid, ids, data_inicial, location, stock_zero = False,context={}):
        if context is None:
            context = {}
        if not ids:
            ids = self.pool.get('product.product').search(cr, uid, [('type','=','product')])
        if not location:
            location = self.pool.get('dotcom.stock.location').search(cr, uid, [])
            #logger.info('\nFINAL LOCATION %s\n' % location)
            if location and type(location) != list:
                location = [location]
        
        resultado = {}
        if ids:
            for produto in self.pool.get('product.product').browse(cr, uid, ids):
                produto_lista = {}
                qty_available = 0
                total = 0
                reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto and produto.id),('location_id','in',location),('date','<=',data_inicial)], order='create_date asc')
                reports_ids = sorted(reports_ids)
                preco = 0
                preco_ultimo = 0
                preco_unitario = 0
                last_price = 0
                pcm=0
                lista = {}
                for movimento in self.pool.get('dotcom.stock.report').browse(cr, uid, reports_ids):
                    origin_classe = movimento and movimento.model_id and movimento.model_id.model
                    qty_available = 0
                    is_not_act = True
                    if origin_classe == 'dotcom.stock.order':
                        origin_id = movimento and movimento.origin_id or None
                        this = self.pool.get(origin_classe).browse(cr, uid, origin_id)
                        this_doc_type = this and this.doc_type
                        if this_doc_type and this_doc_type.type == 'reset':
                            is_not_act = False
                    locale = movimento.location_id and movimento.location_id.id
                    if is_not_act:
                        #logger.info('ADDING QTY>>>')
                        if lista.has_key(locale):
                            qty_available = lista.get(locale) + movimento.qty or 0
                        else:
                            qty_available = movimento.qty or 0
                    else:
                        #logger.info('RESETTING QTYS')
                        qty_available = movimento.qty or 0
                        prod_id = movimento.prod_id.id
                        lista = {}
                    pcm = movimento.average_cost or 0
                    preco_ultimo = movimento.prod_id.last_cost_price or 0
                    lista[locale] = qty_available
                    preco_unitario = movimento.price or 0
                
                produto_lista['stock_qty'] = lista
                produto_lista['last_cost_price'] = preco_ultimo
                produto_lista['pcm'] = pcm
                produto_lista['unitario'] = preco_unitario
                
                resultado[produto.id] = produto_lista
        return resultado
    
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        query = []
        price = ''
        group = ''
        products = []
        inicial = None
        use_old = True
        date_ref = None

        print_unavailable = False
        warehouse_childs = []
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        company_name = pool.get('res.users').browse(cr,uid,uid).company_id.name or ''
        currency_name = pool.get('res.users').browse(cr,uid,uid).company_id.currency_id.name or ''
        licenca_obj = pool.get('dotcom.licence')

        # licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        # licenca = 'Não Licenciado'
        licenca_vals= licenca_obj.check_licence_relatorios(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        licenca_id=False
        if licenca_vals['estado']=='activa':
            licenca_id=licenca_vals['licenca']
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
        
        prod_unavailable = [('type','=','product')]
        
        if 'form' in data:
            if data['form']['product_ids']:
                product_id = data['form']['product_ids'] or None
                products = product_id
                logger.info('\n=====================================================================================================================\n')
                logger.info('\nproducts: %s\n' % products)
                logger.info('\n=====================================================================================================================\n')
            if data['form']['category_id']:
                category_id = data['form']['category_id'] and data['form']['category_id'][0]
                logger.info('Category %s' % category_id)
                prods = self.pool.get('product.product').search(cr, uid, [('categ_id','=',category_id)])
                for prod in prods:
                    if prod not in products:
                        products.append(prod)
            if products:
                query.append(('prod_id','in',products))
                prod_unavailable.append(('id','in',products))
            if data['form']['warehouse_ids']:
                warehouse_id = data['form']['warehouse_ids'] or None
                warehouse_childs = pool.get('dotcom.stock.location').child_get(cr,uid,warehouse_id)[0]
                query.append(('location_id','in',warehouse_childs))
            if data['form']['print_no_stock']:
                print_unavailable = data['form']['print_no_stock'] or False
            if data['form']['date']:
                data_report = data['form']['date'] or time.strftime('%Y-%m-%d')
                hoje = time.strftime('%Y-%m-%d')
                
                inicial = datetime.strptime(data_report, '%Y-%m-%d')
                date_ref = inicial.strftime('%d/%m/%Y')
                
                #logger.info('Today: %s\nInicial: %s' % (hoje, inicial))
                
                if hoje != data_report:
                    use_old = False
            price = data['form']['price']
            group = data['form']['group']

        if use_old:    
            logger.info('Query: %s' % query)
            available_ids = pool.get('dotcom.stock.available').search(cr,uid,query)
            #logger.info('available IDS: %s' % available_ids)
            
            person_list = {}
            add_at_zero = {}
            already_there = []
            
            if print_unavailable:
                all_products = self.pool.get('product.product').search(cr, uid, prod_unavailable)
                for each in pool.get('dotcom.stock.available').browse(cr,uid,available_ids):
                    each_product = each.prod_id and each.prod_id.id or None
                    each_location = each.location_id and each.location_id.id or None
                    if person_list.has_key(each_product):
                        array = person_list.get(each_product, [])
                        array.append(each_location)
                        person_list[each_product] = array
                    else:
                        array = []
                        array.append(each_location)
                        person_list[each_product] = array
                    
                    if each_product in all_products:
                        try:
                            all_products.remove(each_product)
                        except Exception:
                            pass
                for product in all_products:
                    person_list[product] = []

                for line in person_list:
                    warehouses = person_list.get(line, [])
                    if not warehouse_childs:
                        warehouse_childs = self.pool.get('dotcom.stock.location').search(cr, uid, [])
                    for child in warehouse_childs:
                        #if child in warehouses:
                        #    continue
                        #else:
                        if add_at_zero.has_key(line):
                            res = add_at_zero.get(line, [])
                            res.append(child)
                            add_at_zero[line] = res
                        else:
                            res = []
                            res.append(child)
                            add_at_zero[line] = res
                #logger.info('LISTA DE PRODUTOS %s' % add_at_zero)
            for available in pool.get('dotcom.stock.available').browse(cr,uid,available_ids):
                line_warehouse = available.location_id.ref or ''
                line_qty = available.qty_available or 0
                line_unit_price = 0
                if available.prod_id:
                    if price=='unit':
                        line_unit_price = available.prod_id.list_price or 0
                    elif price=='pcm':
                        line_unit_price = available.prod_id.last_average_cost or 0
                    elif price=='pcu':
                        line_unit_price = available.prod_id.last_cost_price or 0
                    elif price=='pcp':
                        line_unit_price = available.prod_id.pcp or 0
                    line_product = available.prod_id.name or ''
                    line_product_id = available.prod_id.id or ''
                    line_prod = available.prod_id.default_code or ''
                    if group=='warehouse':
                        line_group = available.location_id.name
                    elif group == 'product':
                        line_group = available.prod_id.name
                    else:
                        line_group = available.prod_id.categ_id and  available.prod_id.categ_id.name or 'Indefinido'
                    
                    line_unit = available.prod_id and available.prod_id.uom_id and available.prod_id.uom_id.name or ''
                    
                    if print_unavailable is False and line_qty ==0 :
                            continue
                    else:
                        data = {
                            'COMPANY_NAME': company_name,
                            'line_prod' : line_prod,
                            'line_product': line_product,
                            'line_warehouse': line_warehouse,
                            'line_price': line_unit_price,
                            'line_qty': line_qty,
                            'line_unit': line_unit,
                            'GROUP': line_group,
                            'licenca':licenca,
                            'currency': currency_name,
                            'print_date': now,
                            'date': date_ref,
                            }
                        
                        result.append(data)
                        if print_unavailable:
                            if line_product_id in already_there:
                                continue
                            else:
                                locations = add_at_zero.get(line_product_id, [])
                                for location in self.pool.get('dotcom.stock.location').browse(cr, uid, locations):
                                    line_warehouse = location and location.ref or ''
                                    line_group = 'Sem Stock'
                                    data = {
                                        'COMPANY_NAME': company_name,
                                        'line_prod' : line_prod,
                                        'line_product': line_product,
                                        'line_warehouse': line_warehouse,
                                        'line_price': line_unit_price,
                                        'line_qty': 0,
                                        'line_unit': line_unit,
                                        'GROUP': line_group,
                                        'licenca':licenca,
                                        'currency': currency_name,
                                        'print_date': now,
                                        'date': date_ref,
                                        }
                                    already_there.append(line_product_id)
                                    result.append(data)
                                del add_at_zero[line_product_id]
            #logger.info('LISTA DE PRODUTOS COM 0 DE STOCK\n%s' % add_at_zero)
            for one in add_at_zero:
                locations = add_at_zero.get(one, [])
                product = self.pool.get('product.product').browse(cr, uid, one)
                
                line_product = product and product.name or ''
                line_prod = product.default_code or ''
                line_unit = product and product.uom_id and product.uom_id.name or ''
                
                line_unit_price = 0
                if price=='unit':
                    line_unit_price = product.list_price or 0
                elif price=='pcm':
                    line_unit_price = product.last_average_cost or 0
                elif price=='pcu':
                    line_unit_price = product.last_cost_price or 0
                elif price=='pcp':
                    line_unit_price = product.pcp or 0
                
                for location in self.pool.get('dotcom.stock.location').browse(cr, uid, locations):
                    line_warehouse = location and location.ref or ''
                    line_group = 'Sem Stock'
                    data = {
                        'COMPANY_NAME': company_name,
                        'line_prod' : line_prod,
                        'line_product': line_product,
                        'line_warehouse': line_warehouse,
                        'line_price': line_unit_price,
                        'line_qty': 0,
                        'line_unit': line_unit,
                        'GROUP': line_group,
                        'licenca':licenca,
                        'currency': currency_name,
                        'print_date': now,
                        'date': date_ref,
                        }
                    result.append(data) 
        else:
            #logger.info('\nFirst Location: %s\n' % warehouse_childs)
            stocks = self.processar_anteriores(cr, uid, products, inicial, warehouse_childs, stock_zero = print_unavailable,context=context)
            for each in stocks:
                prod_id = self.pool.get('product.product').browse(cr, uid, each)
                line_product = prod_id and prod_id.name or ''
                line_prod = prod_id and prod_id.default_code or ''
                line_unit = prod_id and prod_id.uom_id and prod_id.uom_id.name or ''
                line_product_category = prod_id.categ_id and  prod_id.categ_id.name or 'Indefinido'
                
                line_unit_price = stocks[each].get('unitario', 0)
                last_cost = stocks[each].get('last_cost_price', 0)
                pcm = stocks[each].get('pcm', 0)
                
                if price=='unit':
                    line_unit_price = prod_id.list_price or 0
                elif price=='pcm':
                    line_unit_price = pcm or 0
                elif price=='pcu':
                    line_unit_price = last_cost or 0
                elif price=='pcp':
                    line_unit_price = prod_id and prod_id.pcp or 0

                warehouses = stocks[each].get('stock_qty', {})
                for warehouse in warehouses:
                    location = self.pool.get('dotcom.stock.location').browse(cr, uid, warehouse)
                    location_name = location and location.name or ''
                    location_ref = location and location.ref or ''
                    line_warehouse = '[%s] %s' % (location_ref, location_name)
                    line_qty = warehouses[warehouse] or 0
                    line_group = ''
                    if group=='warehouse':
                        line_group = location_name
                    elif group == 'product':
                        line_group = line_product
                    else:
                        line_group = line_product_category
                    if print_unavailable is False and line_qty ==0 :
                        continue
                    else:
                        data = {
                            'COMPANY_NAME': company_name,
                            'line_prod' : line_prod,
                            'line_product': line_product,
                            'line_warehouse': line_warehouse,
                            'line_price': line_unit_price,
                            'line_qty': line_qty,
                            'line_unit': line_unit,
                            'GROUP': line_group,
                            'licenca':licenca,
                            'currency': currency_name,
                            'print_date': now,
                            'date': date_ref,
                            }   
                        result.append(data)
            
        #logger.info('Results:::: \n%s\n' % result)
        result = sorted(result, key=lambda d: (d['GROUP'],d['line_prod']), reverse=False)
        return result

jasper_reports.report_jasper('report.dotcom_inventory_stock','dotcom.stock.report',parser=jasper_dotcom_stock_inventory)