# -*- encoding: utf-8 -*-
##############################################################################
#
#
##############################################################################
import jasper_reports
from dotcom_doc_reports import JasperDataParser
from osv import osv,fields 
import pooler
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import *
import time
import base64
from tools.translate import _
import os
import logging
logger = logging.getLogger('dotcom_stock_report')

class jasper_stock_entrada_saida(JasperDataParser.JasperDataParser):
    def __init__(self, cr, uid, ids, data, context):
        super(jasper_stock_entrada_saida, self).__init__(cr, uid, ids, data, context)
    
    def generate_data_source(self, cr, uid, ids, data, context):
        return 'records'
    
    def generate_parameters(self, cr, uid, ids, data, context):
        
        inicio = datetime.now().strftime('%d/01/01')
        fim = datetime.now().strftime('%d/%m/%Y')
        if 'form' in data:
            inicio = datetime.strptime(data['form']['date_from'], '%Y-%m-%d').strftime('%d/%m/%Y') or _('Undefined')
            fim = datetime.strptime(data['form']['date_to'], '%Y-%m-%d').strftime('%d/%m/%Y') or  _('Undefined')
            price = 'Unit Price'
            if data['form']['price']=='unit':
                price = _('Unit Price')
            else:
                price = _('Average Cost Price')
        movement = ''
        if data['form']['kind']:
            kind = data['form']['kind'] or None
            if kind and kind=='in':
                movement = _('Incoming Stock')
            elif kind=='out':
                movement = _('Outgoing Stock')
            else:
                movement = _('Incoming/Outgoing')
        return {	
                'DOCUMENTO': movement,
                'label_data_inicio': _('From'),
                'label_data_fim': _('To'),
                'FROM_DATE': inicio,
                'TO_DATE': fim,
                'label_doc_type': _('Document'),
                'label_data': _('Date'),
                'label_armazem': _('Stock Location'),
                'label_qty': _('Quantity'),
                'label_preco': price,
                'label_qty': _('QTY'),
                'label_product': _('Product'),
                'label_unit': _('Un.'),
                'label_total': _('Total'),
                'TOTAL': _('Total'),
                'COPYRIGHT': _('DotComERP'),
        }
    
    def generate_properties(self, cr, uid, ids, data, context):
        return {}
        
    def generate_records(self, cr, uid, ids, data, context):
        pool= pooler.get_pool(cr.dbname)
        result=[]
        query = []
        query_stock = []
        query_gc = []
        
        data_from = datetime.now().strftime('%d/%m/%Y')
        data_to = datetime.now().strftime('%d/%m/%Y')
        price = ''
        
        now = str((datetime.now() + timedelta(hours=2)).strftime('%d/%m/%Y %H:%M:%S'))
        
        if 'form' in data:
            products = []
            if data['form']['date_from']:
                data_from = datetime.strptime(data['form']['date_from'], '%Y-%m-%d')
                query.append(('date','>=',data_from))
            if data['form']['date_to']:
                data_to = datetime.strptime(data['form']['date_to'], '%Y-%m-%d')
                query.append(('date','<=',data_to))
            
            if data['form']['product_ids']:
                product_id = data['form']['product_ids'] or None
                products = product_id
            
            if data['form']['category_id']:
                category_id = data['form']['category_id'] and data['form']['category_id'][0]
                logger.info('Category %s' % category_id)
                prods = self.pool.get('product.product').search(cr, uid, [('categ_id','=',category_id)])
                for prod in prods:
                    if prod not in products:
                        products.append(prod)
            if products:
                query.append(('prod_id','in',products))
                
            if data['form']['kind']:
                kind = data['form']['kind'] or None
                if kind and kind=='in':
                    query.append(('qty','>',0))
                elif kind=='out':
                    query.append(('qty','<',0))

            if data['form']['warehouse_ids']:
                warehouse_id = data['form']['warehouse_ids'] or None
                warehouse_childs = pool.get('dotcom.stock.location').child_get(cr,uid,warehouse_id)[0]
                query.append(('location_id','in',warehouse_childs))
                
            if data['form']['price']=='unit':
                price = 'unit'
            else:
                price = 'pcm'
            
            if data['form']['group']=='product':
                group = 'prod'
            else:
                group = 'ware'
                
            if data['form']['document_ids']:
                document_gc_ids = data['form']['document_ids'] or None
                classes = {'sales':'dotcom.venda','purchase':'dotcom.compra','pay_rec':'dotcom.recebimento','payable':'dotcom.pagamento'}
                for doc_gc_id in document_gc_ids:
                    read = self.pool.get('documento.tipo').read(cr, uid, doc_gc_id, ['tipo_doc']).get('tipo_doc')
                    if self.pool.get('dotcom.stock.order').get_model_id(cr, uid, classes.get(read, '')) in query_gc:
                        continue
                    else:
                        query_gc.append(self.pool.get('dotcom.stock.order').get_model_id(cr, uid, classes.get(read, '')))
                        
            if data['form']['stock_document_ids']:
                if self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order') in query_gc:
                    query_gc.append(self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order'))
            if query_gc:
                query.append(('model_id','in',query_gc))
       
        company_name = pool.get('res.users').browse(cr,uid,uid).company_id.name or ''
        currency = pool.get('res.users').browse(cr,uid,uid).company_id.currency_id.name
        
        licenca_obj = pool.get('dotcom.licence')
        # licenca_id = licenca_obj.check_expiry(cr,uid,'dotcom_cm',context)
        # licenca = 'Não Licenciado'
        licenca_vals= licenca_obj.check_licence_relatorios(cr,uid,'dotcom_cm',context)
        licenca = 'Não Licenciado'
        licenca_id=False
        if licenca_vals['estado']=='activa':
            licenca_id=licenca_vals['licenca']
        if licenca_id:
            licenca = licenca_obj.browse(cr,uid,licenca_id).partner_name
        
        report_ids = pool.get('dotcom.stock.report').search(cr,uid,query)
        logger.info('REPORT IDS: %s' % report_ids)
        for report  in pool.get('dotcom.stock.report').browse(cr,uid,report_ids):
            
            line_warehouse = report.location_id.ref or ''
            line_date = datetime.strptime(report.date, '%Y-%m-%d').strftime('%d/%m/%Y')
            line_document = report.origin or ""
            line_product = report.prod_id.name or ""
            line_qty = report.qty or 0
            line_unit = report.prod_id.uom_id.name or ''
            id = report.id

            line_price = 0
            if price=='unit':
                line_price = report.price or 0
            else:
                line_price = report.average_cost or 0
            
            line_group = ''
            if group=='prod':
                line_group = report.prod_id.name
            else:
                line_group = report.location_id.name

            data = {
                'COMPANY_NAME': company_name,
                'licenca': licenca,
                'line_warehouse': line_warehouse,
                'line_date': line_date,
                'line_document': line_document,
                'line_qty': line_qty,
                'line_price': line_price,
                'line_product': line_product,
                'line_unit': line_unit,
                'currency':currency,
                'GROUP': line_group,
                'print_date': now,
                'id': id,
                }
            
            result.append(data)
        logger.info('REPORT IDS: %s' % result)
        result = sorted(result, key=lambda d: (d['GROUP'],d['id']), reverse=False)
        return result

jasper_reports.report_jasper('report.dotcom_stock_entrada_saida','dotcom.stock.report',parser=jasper_stock_entrada_saida)