# -*- coding: utf-8 -*-

from osv import osv
import pooler
from tools.translate import _

def check_stock_permissions(cr, uid, doc=None, action=None,context=None, alert=True):
    #return True
    if context is None:
        context = {}
    pool = pooler.get_pool(cr.dbname)
    user = pool.get('res.users').read(cr,uid,uid,['name'])
    nome = user.get('name', '')
    breaker = False
    if doc is None or action is None:
        raise osv.except_osv(_('Error !'), _('Nao podem ser carregados previlegios para o utilizador %s') % nome)
    else:
        query = []
        query.append((str(action), '=', True))
        #query.append((uid, 'in', 'users'))
        #query.append((doc, 'in', 'documento_stock_ids'))
        #breaker = pool.get('res.groups').search(cr, uid, query)
        this = pool.get('res.groups').search(cr, uid, query)
        if not this:
            breaker = False
        else:
            for each in pool.get('res.groups').read(cr, uid, this, ['users','documento_stock_ids']):
                users = each.get('users', [])
                docs = each.get('documento_stock_ids', [])
                if uid in users and doc in docs:
                    breaker = True
                    break
                else:
                    continue
        #for grupo in user.groups_id:
        #    for documento in grupo.documento_stock_ids:
        #        if documento.id==doc:
        #            act = pool.get('res.groups').read(cr,uid,[grupo.id],[action])
        #            if act[0][action] is True:
        #                breaker = True
        #                break
        #            else:
        #                continue
        #    if breaker is True:
        #        break
        #    else:
        #        continue
        if alert is True and bool(breaker) is False:
            raise osv.except_osv(_('Error !'), ('O utilizador %s nao possui permissoes para executar esta operacao' % nome).decode('utf-8'))
    return bool(breaker)
