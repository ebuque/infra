# -*- coding: utf-8 -*-

#  DotERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#  

import time
from datetime import datetime
# from lxml import etree
# import netsvc
from osv import osv, fields
import decimal_precision as dp
from tools.translate import _
import logging
from dotcom_doc import validator
logger = logging.getLogger('STOCK DEBUGGER')
import group_validator

AVAILABLE_STATES = [('draft','Draft'),('done','OK')]

class dotcom_stock_sequence(osv.osv):
	_name = 'dotcom.stock.sequence'
	_columns = {'name': fields.integer('Numero'),
				'datetime': fields.datetime('Data e Hora', help="Ultima actualização")}
	_defaults = {'datetime': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S')}
dotcom_stock_sequence()

class dotcom_sequence(osv.osv):
	_name = 'dotcom.sequence'
	_inherit = 'dotcom.sequence'
	_columns = {
				'documento_stock_id': fields.many2one('dotcom.stock.document','Stock Usage'),
				}
	
	_sql_constraints = [('sequence_doc_unique', 'unique(code, documento_stock_id)', 'This sequence must be unique per document type.'),]
	
	def create(self, cr, uid, values, context=None):
		if context is None:
			context = {}
		created = None
		if values.has_key('documento_stock_id'):
			doc_id = values['documento_stock_id']
			documento = ''
			if doc_id:
				documento = self.pool.get('dotcom.stock.document').browse(cr,uid,doc_id).ref or ''
			values['name'] = documento
		created = super(dotcom_sequence, self).create(cr,uid,values,context=context)
		if values.has_key('documento_stock_id'):
			if values.has_key('default_sequence') and values['default_sequence'] is True:
				self.pool.get('dotcom.stock.document').write(cr, uid, doc_id, {'default_sequence':created})
				done = self.search(cr, uid, [('documento_stock_id','=',created)])
				if created in done:
					done.remove(created)
				if done:
					for each in done:
						if type(each) != list:
							each = [each]
						self.write(cr, uid, each, {'default_sequence':False})
		return created
	
	def write(self, cr, uid, ids, vals, context=None):
		if context is None:
			context = {}
		if vals.has_key('default_sequence'):
			if vals['default_sequence'] is False:
				for each in self.browse(cr, uid, ids):
					if each.documento_stock_id:
						self.pool.get('dotcom.stock.document').write(cr, uid ,[each.documento_stock_id.id], {'default_sequence':None})
			else:
				for each in self.browse(cr, uid, ids):
					if each.documento_stock_id:
						# done = self.search(cr, uid, [('documento_stock_id','=',each.documento_stock_id.id or None)])
						
						documento_tipo_id = each.documento_stock_id.id 
						doc_type = self.pool.get('dotcom.stock.document').browse(cr, uid, documento_tipo_id)
						if doc_type.default_sequence and doc_type.default_sequence.id <> each.id:
							sec_def = str(doc_type.default_sequence.serie_id.ref or '')
							sec_ano = str(doc_type.default_sequence.fiscal_year_id.name or '')
							raise osv.except_osv(_('Acção Inválida !'), _('Ja foi definida a sequência %s/%s como sequência por defeito para este documento!') %(sec_def, sec_ano))
						else:
							for sequence in doc_type.sequencias_ids:
								if sequence.id <> each.id:
									super(dotcom_sequence, self).write(cr, uid, [sequence.id], {'default_sequence':False})
								else:
									continue
						self.pool.get('dotcom.stock.document').write(cr, uid ,[each.documento_stock_id.id], {'default_sequence':each.id})
		return super(dotcom_sequence, self).write(cr,uid,ids,vals,context=context)
	
dotcom_sequence()

class res_company(osv.osv):
	
	def _should_check_stock(self, cr, uid, context=None):
		if context is None:
			context = {}
		company_read = self.pool.get('res.users').read(cr, uid, uid, ['company_id'])
		company_id = company_read and company_read.get('company_id', False)
		company_id = company_id and company_id[0]
		#logger.info('Company:  %s - %s' % (company_read,company_id))
		check = True
		if company_id:
			allow_obj = self.read(cr, uid, company_id, ['allow_stock'])
			allow = allow_obj and allow_obj.get('allow_stock', False)
			if allow is False:
				check = True
			else:
				check = False
		return check
	
	
	_name = 'res.company'
	_inherit = 'res.company'
	_columns = {'default_sale_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),
				'default_purchase_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),
				'allow_stock': fields.boolean('Permitir Stock Negativo'),}

	
	def on_change_allow(self, cr, uid, ids, allow_stock, context=None):
		if context is None:
			context = {}
		vals = {}
		if allow_stock:
			res = {}
			res['title'] = 'Alerta!'
			res['message'] = 'Caso o stock seja negativo, o preço de custo médio poderá ser alterado!'
			vals['warning'] = res
		return vals
	

res_company()

class product_product(osv.osv):

	
	def auto_update_stock(self, cr, uid,):
		vals = {}
		vals['name'] = 'Processamento Automático: %s' % str(time.strftime('%Y-%m-%d %H:%M:%S'))
		vals['general_processing'] = True
		vals['tipo_action'] = 'products'
		created = self.pool.get('dotcom.stock.entry.wizard').create(cr, uid, vals)
		self.pool.get('dotcom.stock.entry.wizard').process(cr, uid, [created], context={})
		return True
	
	def _get_default_sell_warehouse(self, cr, uid, context=None):
		if context is None:
			context = {}
		res = None
		user = self.pool.get('res.users').browse(cr, uid, uid)
		company_id = user.company_id or False
		if company_id:
			res = company_id.default_sale_warehouse and company_id.default_sale_warehouse.id or None
		return res
	
	
	def _get_default_purchase_warehouse(self, cr, uid, context=None):
		if context is None:
			context = {}
		res = None
		user = self.pool.get('res.users').browse(cr, uid, uid)
		company_id = user.company_id or False
		if company_id:
			res = company_id.default_purchase_warehouse and company_id.default_purchase_warehouse.id or None
		return res
	
	def _stock_available(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for produto in self.pool.get('product.product').browse(cr, uid, ids):
			# lista = {}
			total = 0
			if produto.type == 'product':
				reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto and produto.id),('state','=','done')], order='ordem')
				reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem'])
				reads = sorted(reads, key=lambda d: (d['ordem']))
				for movimento in reads:
					ordem = movimento.get('ordem')
					qty = movimento.get('qty', 0)
					# logger.info('\nOrdem:%s - Qty: %s' % (ordem, qty))
					if movimento.get('reset', False) == 'reset':
						total = qty
					else:
						total = total + qty
			res[produto.id] = total
		return res
	
	def reload(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
			res = self.pool.get('dotcom.stock.entry.wizard').verificar_drafts(cr, uid, ids, context=context)
		return res
	
	def _show_button(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for read in self.pool.get('product.product').read(cr, uid, ids, ['type','id','stock_qty','temp_stock_available']):
			ret = False
			if read.get('type', 'service') == 'product':
				qty = read.get('stock_qty', 0)
				temp = read.get('temp_stock_available', 0)
				if qty!=temp:
					ret = True
			res[read.get('id')] = ret
		return res
	
	_name = 'product.product'
	_inherit = 'product.product'
	_columns = {
				'temp_stock_available': fields.function(_stock_available, method=True, string='Stock Actual',digits=(1,5), type='float', store=False),
				'show_rec_buttton': fields.function(_show_button, method=True, string='Show Button', type='boolean', store=False),
				'stock_qty': fields.float('Quantity at Stock'),
				'stock_available_ids': fields.one2many('dotcom.stock.available','prod_id','Available Stock'),
				'stock_report_ids': fields.one2many('dotcom.stock.report','prod_id','Stock Movement Documents'),
				'last_purchase': fields.date('Last Movement Date', readonly=True),
				'last_cost_price': fields.float('Last Cost Price', readonly=True),
				'last_average_cost': fields.float('Average Cost Price', readonly=True),
				'default_sale_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),
				'default_purchase_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),
				'pcp': fields.float('PCP', readonly=False, help="Preco de Custo Padrao")
				}
	
	_defaults = {
				'default_purchase_warehouse': lambda self,cr,uid,c: self._get_default_purchase_warehouse(cr, uid, context=c),
				'default_sale_warehouse': lambda self,cr,uid,c: self._get_default_sell_warehouse(cr, uid, context=c),
				}

	def copy(self, cr, uid,id, vals, context=None):
		if context is None:
			context={}
		vals.update({'stock_qty':0,'stock_available_ids':None,'stock_report_ids':None,'last_purchase':None,'last_cost_price':None,'last_average_cost':None})
		return super(product_product, self).copy(cr, uid,id, vals, context=context)

	def get_product_qty(self, cr, uid, prod_id, location_id, context=None):
		if context is None:
			context = {}
		prod_obj = self.pool.get('product.product').browse(cr, uid, prod_id)
		res = 0
		# found = False
		if location_id and prod_obj.type=='product':
			if prod_obj.stock_available_ids:
				for locale in prod_obj.stock_available_ids:
					loc_id = locale.location_id and locale.location_id.id or False
					if loc_id and loc_id==location_id:
						# found = True
						res = locale.qty_available
					else:
						continue
		return res

	def get_available_qty(self, cr, uid, prod_id, qty, location_id, context=None):
		if context is None:
			context = {}
		prod_obj = self.pool.get('product.product').browse(cr, uid, prod_id)
		res = False
		found = False
		check = self.pool.get('res.company')._should_check_stock(cr, uid, context=context)
		if check:
			if location_id and qty and prod_obj.type=='product':
				if prod_obj.stock_available_ids:
					for locale in prod_obj.stock_available_ids:
						loc_id = locale.location_id and locale.location_id.id or False
						if loc_id and loc_id==location_id:
							found = True
							if locale.qty_available < qty:
								raise osv.except_osv(_('Acção Inválida !'), _('Quantidade Indisponivel nesta localização'))
							else:
								res = locale.qty_available or 0
						else:
							continue
				else:
					raise osv.except_osv(_('Acção Inválida !'), _('Não há stock disponivel deste produto!'))
			if found is False:
				raise osv.except_osv(_('Acção Inválida !'), _('Não há stock disponivel deste produto nesta localização!'))
		return res

product_product()

class dotcom_venda_linha(osv.osv):
	def _get_default_location(self, cr, uid, doc_type, context={}):
		res = False
		logger.info('\n =====================================***************************doc_type: %s' % doc_type)
		logger.info('\n =====================================***************************context: %s' % context)
		if doc_type:
			documento = self.pool.get('documento.tipo').browse(cr, uid, doc_type)
			location = documento and documento.stock_location and documento.stock_location.id or False
			res = location
		return res
	
	_name = 'dotcom.venda.linha'
	_inherit = 'dotcom.venda.linha'
	_columns = {
				'stock_location': fields.many2one('dotcom.stock.location','Location'),
				'opened': fields.boolean('Opened'),
				'check_qty': fields.boolean('Iva Incluido'),
				}
	_defaults = {'opened':True,
				 'check_qty': lambda *a: True,
				 'stock_location':lambda self, cr, uid, c: self._get_default_location(cr, uid, c.get('doc_type', False), c)
				 }
	
	def onchange_product(self, cr, uid, ids, prod_id, partner_id=False,context=None):
		if context is None:
			context = {}
		values = super(dotcom_venda_linha,self).onchange_product(cr,uid,ids,prod_id,partner_id=partner_id,context=context)
		val = values['value']
		product_obj = self.pool.get('product.product').browse(cr,uid,prod_id)
		# available_at = []
		warehouse_id = None
		if product_obj and product_obj.type=='product':
			warehouse_id = product_obj.default_sale_warehouse and product_obj.default_sale_warehouse.id or False
			val.update({'stock_location':warehouse_id})
		return {'value':val}
		
	def on_change_qty(self,cr,uid,ids,prod_id,qty,unit_price,tax_id,line_amount_tax,discount_pct,discounted_val,line_total,iva_incluso, location_id=None, check_qty=True,context=None):
		if context is None:
			context = {}
		val = super(dotcom_venda_linha, self).on_change_qty(cr,uid,ids,prod_id,qty,unit_price,tax_id,line_amount_tax,discount_pct,discounted_val,line_total,iva_incluso, context=context)
		if prod_id and qty and location_id and check_qty:
			self.on_change_location(cr, uid, ids, location_id, prod_id, qty, context=context)
		return val
		 
	def on_change_location(self, cr, uid, ids, location_id, prod_id, qty, check_qty=True,context=None):
		if context is None:
			context ={}
		if prod_id and qty and location_id and check_qty:
			prod_obj = self.pool.get('product.product').browse(cr, uid, prod_id)
			if prod_obj.type == 'product':
				self.pool.get('product.product').get_available_qty(cr, uid, prod_id, qty,location_id, context=context)
		return {}



dotcom_venda_linha()

class documento_tipo(osv.osv):
	_name = 'documento.tipo'
	_inherit = 'documento.tipo'
	_columns = {
				'stock_location': fields.many2one('dotcom.stock.location','Location'),
				'update_last_price':fields.boolean('Update Last Cost Price'),
				'update_date':fields.boolean('Update Last Movement Date'),
				'update_last_med_price':fields.boolean('Update Average Cost Price'),
				'movimenta_stock': fields.selection([('in','Incoming'),('out','Outgoing'),('do_not','Does not move Stock')],'Move Stock',required=True,states={'draft': [('readonly', False)]}),
				}
	
	_defaults = {
				'update_last_price':lambda *a: False,
				'update_date':lambda *a: False,
				'update_last_med_price':lambda *a: False,
				'movimenta_stock': 'do_not'
	}
	
documento_tipo()

class dotcom_compra_linha(osv.osv):
	
	_name = 'dotcom.compra.linha'
	_inherit = 'dotcom.compra.linha'
	_columns = {
				'stock_location': fields.many2one('dotcom.stock.location','Location'),
				'opened': fields.boolean('Opened'),
				}
	_defaults = {'opened':True}
	
	
	def onchange_product(self, cr, uid, ids, prod_id, context=None):
		if context is None:
			context = {}
		values = super(dotcom_compra_linha,self).onchange_product(cr,uid,ids,prod_id,context)
		val = values['value']
		product_obj = self.pool.get('product.product').browse(cr,uid,prod_id)
		# available_at = []
		warehouse_id = None
		last_cost_price = product_obj.last_cost_price or 0
		val.update({'unit_price':last_cost_price})
		if product_obj and product_obj.type=='product':
			warehouse_id = product_obj.default_purchase_warehouse and product_obj.default_purchase_warehouse.id or False
			val.update({'stock_location':warehouse_id})
		return {'value':val}
	
dotcom_compra_linha()

class dotcom_venda(osv.osv):
	_name = 'dotcom.venda'
	_inherit = 'dotcom.venda'

	def _get_default_purchase_warehouse(self, cr, uid, context=None):
		if context is None:
			context = {}
		res = None
		user = self.pool.get('res.users').browse(cr, uid, uid)
		company_id = user.company_id or False
		if company_id:
			res = company_id.default_purchase_warehouse and company_id.default_purchase_warehouse.id or None
		return res

	_columns = {
				'picking_list': fields.one2many('dotcom.picking.list','sale_id','Picking List',readonly=True),
				'report_id': fields.integer('Report'),
				'permite_rascunho': fields.selection([('sim','Sim'),('nao','Não')],'Permite volta a Rascunho'),
				'default_purchase_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),

				}
	_defaults={
		'permite_rascunho':'sim',
		'default_purchase_warehouse': lambda self,cr,uid,c: self._get_default_purchase_warehouse(cr, uid, context=c),
	}

	def open_wiz(self, cr, uid, ids , context=False):
		return {
			'name': 'Actualização de Produtos',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.stock.product_wizard_venda',
			'type': 'ir.actions.act_window',
			'context': {'venda_id': ids and ids[0]},
			'target':'new',
			}
	def actualizar_armazem_linhas(self,cr,uid,ids,context):
		if context is None:
			context = {}
		model = self.pool.get('dotcom.venda.linha')
		for venda in self.browse(cr,uid,ids,context):
			for line in venda.sales_lines:
				model.write(cr,uid,line.id,{'stock_location':venda.default_purchase_warehouse.id})
		return True
	
	def copy(self, cr, uid,id, vals, context=None):
		if context is None:
			context={}
		vals['picking_list'] = None
		vals['report_id'] = None
		return super(dotcom_venda, self).copy(cr, uid,id, vals, context=context)
	
	def cancel_now(self, cr, uid, id, context=None):
		if context is None:
			context={}
		report_pool = self.pool.get('dotcom.stock.report')
		for each in self.browse(cr, uid, id, context=context):
			ordem = each and each.report_id
			report_search = report_pool.search(cr,uid,[('ordem','=',ordem), ('state','=','draft')])
			if report_search:
				report_pool.unlink(cr,uid,report_search)
		return super(dotcom_venda, self).cancel_now(cr, uid, id, context=context)

	def reset(self,cr,uid, ids,context=None):
		if context is None:
		   context = {}
		for document in self.browse(cr,uid,ids):
			if document.permite_rascunho == 'nao':
				raise osv.except_osv(_('Acção Inválida !'), _('O documento nao pode ser redefinido para rascunho porque contem produto(s) que possui(em) movimento(s) de actualizacao mais recente!'))
		res = super(dotcom_venda, self).reset(cr, uid,ids,context=context)
	   
		return res
	
	def run_reset(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		products = []
		ok = True
		
		for venda in self.browse(cr,uid,ids,context):
			ok = super(dotcom_venda, self).run_reset(cr, uid, [venda.id], context)
			if venda.picking_list:
				signal = 1
				if venda.doc_type.movimenta_stock=='in':
					signal = -1
				elif venda.doc_type.movimenta_stock=='out':
					signal = 1
				else:
					signal = 0
				for linha in venda.sales_lines:
					if linha.prod_id.type=='product' and linha.stock_location:
						stock_location = linha.stock_location.id
						qty = signal * abs(linha.qty or 0)
						prod_id = linha.prod_id.id
						self.pool.get('dotcom.stock.order').check_remaining_qty(cr, uid, prod_id, stock_location, qty, context=context)
						# prod_name = linha.prod_id.name or ''
						logger.info('\nProd_id: %s' % prod_id)
						self.pool.get('dotcom.stock.order').stock_reset(cr, uid, produto=prod_id, location=stock_location, origin=venda.id, classe='dotcom.venda', context=context)
	
						self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
						if prod_id in products:
							continue
						else:
							products.append(prod_id)
						
				report_pool = self.pool.get('dotcom.stock.report')
				report_search = report_pool.search(cr,uid,[('ordem','=',venda.report_id)])
				if report_search:
					report_pool.write(cr,uid,report_search, {'state':'draft'})
				picks = []
				for pick in venda.picking_list:
					picks.append(pick.id)
				self.pool.get('dotcom.picking.list').unlink(cr, uid, picks)
		return ok
	
	def re_post(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		return self.post(cr, uid, ids, context=None)

	def post(self, cr, uid, ids,move_stock = True, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, self._name, context=context)
		created_line=None
		all_lines = []
		res = {}
		
		for venda in self.browse(cr,uid,ids,context):
			origin= venda.doc_type and venda.doc_type.ref
			logger.info('\n===============  Entra Cotacao 1 ===================')
			logger.info('\n =======================move_stock : %s' % move_stock ) 

			if move_stock:
				logger.info('\n===============  Entra Cotacao 2 fhkjasdfbgasdjkbgjkabs===================')
				for picking in venda.picking_list:
					self.pool.get('dotcom.picking.list').unlink(cr,uid,[picking.id])
					logger.info('\n===============  log controler 1===================')
				logger.info('\n===============  log controler 2===================')
				if venda.doc_type.movimenta_stock in ['out','in']:
					logger.info('\n===============  log controler 3===================')
					report_code = self.pool.get('dotcom.stock.order').check_report(cr, uid, object_name = self._name, object_id = venda.id, context=context)
					logger.info('\n=============== FINDING GENERATE_RECORD===================')
					lst_pm_prod = {}
					lst_qty_prod = {}
					signal = 1
					operacao = venda.doc_type.movimenta_stock
					if venda.doc_type.movimenta_stock=='in':
						signal = 1
						
					elif venda.doc_type.movimenta_stock=='out':
						signal = -1

					else:
						signal = 0
					logger.info('\n ====================================TROUBLEMAKER START========================================')
					#MODIFIED number = venda.document_number or self.generate_sequence(cr,uid,venda.id,context)
					logger.info('\n ====================================TROUBLEMAKER END========================================')
					update_movement = False
					if venda.doc_type.update_date is True:
						update_movement = True
					data = venda.document_date or time.strftime('%Y-%m-%d'),
					
					update_last_price = venda.doc_type.update_last_price or False
					update_last_cost_price = venda.doc_type.update_last_med_price or False
					
					
					#MODIFIED origin = venda.doc_type and venda.doc_type.ref + ' ' +number
					
					logger.info('\n len(venda.sales_lines) : %s' % len(venda.sales_lines))
					for line in venda.sales_lines:
						if line.prod_id.type=='product' and line.opened:
							# rep = {}
							prod_id = line.prod_id.id

							logger.info('\n ============================================================================')
							logger.info('\n line.stock_location : %s' % line.stock_location )
							logger.info('\n line.stock_location.id : %s' % line.stock_location.id )
							logger.info('\n ============================================================================')

							stock_location = line.stock_location and line.stock_location.id
							qty = signal* (abs(line.qty) or 0)
							
							# Verifica quantidade disponivel em stock
							self.pool.get('dotcom.stock.order').check_remaining_qty(cr, uid, prod_id, stock_location, qty, context=context)
							
							date = data
							price = (abs(line.line_total) or 0)
							price_unit = abs(line.unit_price or 0)
							desconto = signal* abs(line.desconto_linha or 0)
							desconto = desconto/qty
							desconto_com = signal* abs(line.desconto_comercial or 0)
							desconto_com = desconto_com / qty
							anterior = 0
							qty_anterior = 0
							
							# Obter dados actuais do produto
							if lst_pm_prod.has_key(str(prod_id)):
								anterior =  lst_pm_prod[str(prod_id)]
							else:
								anterior = line.prod_id.last_average_cost or 0
							
							if lst_qty_prod.has_key(str(prod_id)):
								qty_anterior =  lst_qty_prod[str(prod_id)]
							else:
								qty_anterior = line.prod_id.stock_qty or 0 or 0
							pm = (anterior)
							my_currency = venda.company_id.currency_id.id or None
							doc_currency = venda.doc_currency.id or None
							
							####################################################
							#########ADDED FOR DOTCOM###########################
							####################################################
							tax_id = line.tax_id.id or None
							preco_sem_iva = price_unit
							if line.iva_incluido:
								preco_sem_iva = self._get_preco_sem_iva(cr ,uid, tax_id, price_unit, context=context)
							price_unit = preco_sem_iva - desconto_com - desconto
							####################################################
							#########ADDED FOR DOTCOM###########################
							####################################################
							

							
							if venda.doc_type.movimenta_stock=='in':
								# Actualizar PCU
								logger.info('\n++++++++++=====++++++update_last_price  %s+++++++++====+++++++\n' % (update_last_price ))
								if update_last_price is True:
									if my_currency == doc_currency:
										self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
									else:
										self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
								# Actualizar PCM
								if update_last_cost_price is True:
									if my_currency == doc_currency:
										medio_anterior = anterior
										quantidade_anterior = qty_anterior
										pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
										pm = (pm)
										lst_pm_prod[str(prod_id)] = pm
										lst_qty_prod[str(prod_id)] = qty_anterior+qty
										self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
									else:
										medio_anterior = anterior
										quantidade_anterior = qty_anterior
										try:
											pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
										except ZeroDivisionError:
											pm = 0
										pm = (pm)
										lst_pm_prod[str(prod_id)] = pm
										lst_qty_prod[str(prod_id)] = qty_anterior+qty
										self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})



							# Criar Movimento de Stock
							if operacao == 'out':
								pm = line.prod_id.last_average_cost
							state='done'
							created_line = self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,operacao,state,prod_id,stock_location,qty,origin,date,price_unit,pm,model,venda.id,None,context, linha_id=line.id)
							all_lines.append(created_line)
							# Mover Stock (Actualizar quantidades em localizações)
							self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
							if update_movement is True:
								self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
							logger.info('\n\n\nMoved Stock: %s' % created_line)
							
							# Criar Picking List
							pick_list = {}
							pick_list['location_id'] = stock_location
							pick_list['prod_id'] = prod_id
							pick_list['sale_id'] = venda.id
							pick_list['qty'] = qty
							pick_list['date'] = venda.document_date or time.strftime('%Y-%m-%d')
							self.pool.get('dotcom.picking.list').create(cr,uid,pick_list)
							
							res = self.pool.get('dotcom.stock.order').product_list(prod_id, qty, line_id= line and line.id,vals=res) or {}
							
							# Verificacao de dados criados
							self.pool.get('dotcom.stock.report').browse(cr, uid, all_lines)
							logger.info('\n\n\nCREATED %i PRODUCT LINES::\n%s' % (len(all_lines), all_lines))
						else:
							continue
					self.write(cr, uid, venda.id,{'report_id': report_code})
					number = super(dotcom_venda, self).post(cr,uid,ids,context)
					if number:
						#Adaptacao por causa do problema da duplicacao de numero de sequencia recomeda-se recostrucao do algoritmo
						origin = origin+' '+number
						logger.info('\n\n  ================================== all_lines %s:' % all_lines )
						report_pool= self.pool.get('dotcom.stock.report')
						report_verifier_pool=self.pool.get('dotcom.stock.verify')

						report_pool.write(cr,uid,all_lines,{'origin':origin})
						created_report_verifier_line = report_verifier_pool.search(cr,uid,[('report_id','in',all_lines)])

						report_verifier_pool.write(cr,uid,created_report_verifier_line,{'order_name':origin})

				else:
					super(dotcom_venda, self).post(cr,uid,ids,context)
			else:
				super(dotcom_venda, self).post(cr,uid,ids,context)
	   

		return res
	
dotcom_venda()

class dotcom_compra(osv.osv):
	_name = 'dotcom.compra'
	_inherit = 'dotcom.compra'

	def _get_default_sell_warehouse(self, cr, uid, context=None):
		if context is None:
			context = {}
		res = None
		user = self.pool.get('res.users').browse(cr, uid, uid)
		company_id = user.company_id or False
		if company_id:
			res = company_id.default_sale_warehouse and company_id.default_sale_warehouse.id or None
		return res

	_columns = {
				'picking_list': fields.one2many('dotcom.picking.list','purchase_id','Picking List',readonly=True),
				'report_id': fields.integer('Report'),
				'permite_rascunho': fields.selection([('sim','Sim'),('nao','Nao')],'Permite volta a Rascunho'),
				'default_sell_warehouse': fields.many2one('dotcom.stock.location','Localizacao'),
				}

	_defaults={
		'permite_rascunho':'sim',
		'default_sell_warehouse': lambda self,cr,uid,c: self._get_default_sell_warehouse(cr, uid, context=c),
	}

	def open_wiz(self, cr, uid, ids , context=False):
		return {
			'name': 'Actualização de Produtos',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.stock.product_wizard_compra',
			'type': 'ir.actions.act_window',
			'context': {'compra_id': ids and ids[0]},
			'target':'new',
			}
	def actualizar_armazem_linhas(self,cr,uid,ids,context):
		if context is None:
			context = {}
		model = self.pool.get('dotcom.compra.linha')
		for venda in self.browse(cr,uid,ids,context):
			for line in venda.sales_lines:
				model.write(cr,uid,line.id,{'stock_location':venda.default_purchase_warehouse.id})
		return True
	
	def copy(self, cr, uid,id, vals, context=None):
		
		if context is None:
			context={}
		
		vals['picking_list'] = None
		vals['report_id'] = None
		return super(dotcom_compra, self).copy(cr, uid,id, vals, context=context)
	
	def cancel_now(self, cr, uid, id, context=None):
		if context is None:
			context={}
		report_pool = self.pool.get('dotcom.stock.report')
		for each in self.browse(cr, uid, id, context=context):
			ordem = each and each.report_id
			report_search = report_pool.search(cr,uid,[('ordem','=',ordem), ('state','=','draft')])
			if report_search:
				report_pool.unlink(cr,uid,report_search)
		return super(dotcom_compra, self).cancel_now(cr, uid, id, context=context)
	
	def run_reset(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		# products = []
		to_calculate = []
		ok = True
		for compra in self.browse(cr,uid,ids,context):
			ok = super(dotcom_compra, self).run_reset(cr, uid, [compra.id], context)
			if compra.doc_type.movimenta_stock in ['out','in']:
				signal = 1
				if compra.doc_type.movimenta_stock=='in':
					signal = -1
				elif compra.doc_type.movimenta_stock=='out':
					signal = 1
				else:
					signal = 0
				# origin = compra.doc_type.ref +' '+ compra.document_number
				for linha in compra.purchases_lines:
					if linha.prod_id.type=='product' and linha.stock_location:
						stock_location = linha.stock_location.id
						qty = signal * abs(linha.qty or 0)
						prod_id = linha.prod_id.id
						
						self.pool.get('dotcom.stock.order').stock_reset(cr, uid, produto=prod_id, location=stock_location, origin=compra.id, classe='dotcom.compra', context=context)
						self.pool.get('dotcom.stock.order').check_remaining_qty(cr, uid, prod_id, stock_location, qty, context=context)
						
						# date = time.strftime('%Y-%m-%d')
						# price = linha.unit_price or 0
						pm = linha.prod_id.last_average_cost or 0
						pm = (pm)
						self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
						if prod_id not in to_calculate:
							to_calculate.append(prod_id)
				report_pool = self.pool.get('dotcom.stock.report')
				report_search = report_pool.search(cr,uid,[('ordem','=',compra.report_id)])
				if report_search and len(report_search)>0:
					report_pool.write(cr,uid,report_search, {'state':'draft'})
				picks = []
				for pick in compra.picking_list:
					picks.append(pick.id)
				self.pool.get('dotcom.picking.list').unlink(cr, uid, picks)
			else:
				continue
		self.pool.get('dotcom.stock.entry.wizard').run_products(cr, uid, to_calculate, context=context)
		return ok
	
	def re_post(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		return self.post(cr, uid, ids, context=context)
   
	def post(self, cr, uid, ids ,move_stock = True,context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		compras = self.browse(cr,uid,ids,context)
		res = {}
		for compra in compras:
			# if not compra.report_id:
			#     report_code = self.pool.get('dotcom.stock.order')._get_report_code(cr, uid, self._name, compra.id,context=context)
			#     self.write(cr, uid, compra.id, {'report_id':report_code})
			# else:
			#     report_code = compra.report_id
			# reported = self.pool.get('dotcom.stock.report').search(cr, uid, [('ordem','=',report_code),('state','=','draft')])
			# self.pool.get('dotcom.stock.report').unlink(cr, uid, reported)
			# for picking in compra.picking_list:
			#     self.pool.get('dotcom.picking.list').unlink(cr,uid,[picking.id])
			if move_stock:
				if compra.doc_type.movimenta_stock in ['out','in']:
					report_code = self.pool.get('dotcom.stock.order').check_report(cr, uid, object_name = self._name, object_id = compra.id, context=context)
					logger.info('\n\n\n ORDEM ISSUE NOVO report_code: %s =========' % report_code)

					lst_pm_prod = {}
					lst_qty_prod = {}
					signal = 1
					operacao = compra.doc_type.movimenta_stock
					if compra.doc_type.movimenta_stock=='in':
						signal = 1
					elif compra.doc_type.movimenta_stock=='out':
						signal = -1
					else:
						signal = 0
					number = compra.document_number or self.generate_sequence(cr,uid,compra.id,context)
					update_movement = False
					if compra.doc_type.update_date is True:
						update_movement = True
					self.write(cr,uid,compra.id,{'document_number':number})
					update_last_price = compra.doc_type.update_last_price or False
					update_movement = compra.doc_type.update_date or False
					update_last_cost_price = compra.doc_type.update_last_med_price or False
					model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, self._name, context=context)
					
					my_currency = compra.company_id.currency_id.id or None
					doc_currency = compra.doc_currency.id or None
					all_lines = []
					for line in compra.purchases_lines:
						# type_prod = line.prod_id.type
						prod_id = line.prod_id and line.prod_id.id
						test_location = str(line.stock_location) or ''
						
						if line.prod_id.type=='product':
							if test_location=='' or len(test_location)==0:
								raise osv.except_osv(_('Acção Inválida !'), _('Por favor, selecione uma localização para o producto'))
							else:
								# rep = {}
								prod_id = line.prod_id.id
								stock_location = line.stock_location.id
								qty = signal* (abs(line.qty) or 0)
								date = compra.document_date or time.strftime('%Y-%m-%d'),
								origin = compra.doc_type.ref + ' ' +number
								price = (abs(line.line_total) or 0)# - (abs(line.desconto_comercial) or 0) - (abs(line.desconto_linha) or 0)
								price_unit = abs(line.unit_price or 0)
								logger.info('\n\nQTY IN USE:%s\n\n' % qty)
								desconto = signal* abs(line.desconto_linha or 0)
								desconto = desconto/qty
								logger.info('\n\nDesconto AFT:%s\n\n' % desconto)
								desconto_com = signal* abs(line.desconto_comercial or 0)
								desconto_com = desconto_com / qty
								
								logger.info('\n\nDesconto Comr:%s\n\n' % desconto_com)
								####################################################
								#########ADDED FOR DOTCOM###########################
								####################################################
								tax_id = line.tax_id.id or None
								preco_sem_iva = price_unit
								if line.iva_incluido:
									preco_sem_iva = self._get_preco_sem_iva(cr ,uid, tax_id, price_unit, context=context)
								price_unit = preco_sem_iva - desconto_com - desconto
								####################################################
								#########ADDED FOR DOTCOM###########################
								####################################################

								anterior = 0
								qty_anterior = 0
								
								if lst_pm_prod.has_key(str(prod_id)):
									anterior =  lst_pm_prod[str(prod_id)]
								else:
									anterior = line.prod_id.last_average_cost or 0
								
								if lst_qty_prod.has_key(str(prod_id)):
									qty_anterior =  lst_qty_prod[str(prod_id)]
								else:
									qty_anterior = line.prod_id.stock_qty or 0 or 0
								
								pm = (anterior)
								
								if compra.doc_type.movimenta_stock=='in':
									if update_last_price is True:
										if my_currency == doc_currency:
											self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price_unit)})
										else:
											self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price_unit)})
									if update_last_cost_price is True:
										if my_currency == doc_currency:
											medio_anterior = anterior
											quantidade_anterior = qty_anterior
											try:
												pm = ((medio_anterior*quantidade_anterior) + (price))/(qty+quantidade_anterior)
											except ZeroDivisionError:
												pm = 0
											pm = (pm)
											lst_pm_prod[str(prod_id)] = pm
											lst_qty_prod[str(prod_id)] = qty_anterior+qty
											self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
										else:
											medio_anterior = anterior
											quantidade_anterior = qty_anterior
											try:
												pm = ((medio_anterior*quantidade_anterior) + (price))/(qty+quantidade_anterior)
											except ZeroDivisionError:
												pm = 0
											pm = (pm)
											lst_pm_prod[str(prod_id)] = pm
											lst_qty_prod[str(prod_id)] = qty_anterior+qty
											self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})

								logger.info('\n\n\nPreco medio: %s\n\n\n' % pm)
								if operacao == 'out':
									pm = line.prod_id.last_average_cost
								state='done'
								created_line = self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,operacao,state,prod_id,stock_location,qty,origin,date,price_unit,pm,model,compra.id,None,context, linha_id=line.id)
								all_lines.append(created_line)
								self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
				
								if update_movement is True:
									self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
								
								pick_list = {}
								pick_list['location_id'] = stock_location
								pick_list['prod_id'] = prod_id
								pick_list['purchase_id'] = compra.id
								pick_list['qty'] = qty
								pick_list['date'] = compra.document_date or time.strftime('%Y-%m-%d')
								self.pool.get('dotcom.picking.list').create(cr,uid,pick_list)
								
								res = self.pool.get('dotcom.stock.order').product_list(prod_id, qty, line_id= line and line.id,vals=res) or {}
								#self.pool.get('dotcom.stock.entry.wizard').repost_quantities(cr, uid, [prod_id], context=context)
								#self.pool.get('dotcom.stock.entry.wizard').run(cr, uid, [prod_id], context=context)
								self.pool.get('dotcom.stock.report').browse(cr, uid, all_lines)
								logger.info('\n\n\nCREATED %i PRODUCT LINES::\n%s' % (len(all_lines), all_lines))
						else:
							continue
					self.write(cr, uid, compra.id,{'report_id': report_code})
				else:
					continue
		super(dotcom_compra, self).post(cr,uid,ids,context)
		return res

	def reset(self,cr,uid, ids,context=None):
		if context is None:
		   context = {}
		for document in self.browse(cr,uid,ids):
			if document.permite_rascunho=='nao':
				raise osv.except_osv(_('Acção Inválida !'), _('O documento nao pode ser redefinido para rascunho porque contem produto(s) que possui(em) movimento(s) de actualizacao mais recente!'))
		res = super(dotcom_compra, self).reset(cr, uid,ids,context=context)
	   
		return res
 
dotcom_compra()

class dotcom_stock_report(osv.osv):
	
	def _current_state(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for read in self.read(cr, uid, ids, ['model_id','origin_id','id']):
			model_id = read.get('model_id', (False,))
			model_id = model_id and model_id[0] or False
			origin_id = read.get('origin_id', False)
			modelo = False
			if model_id and origin_id:
				modelo = self.pool.get('ir.model').read(cr, uid, model_id, ['model'])
				modelo = modelo.get('model', False)
			states = self.pool.get(modelo).read(cr, uid, origin_id, ['state'])
			state = states.get('state', False)
			if state in ['draft','reset']:
				res[read['id']] = 'draft'
			else:
				res[read['id']] = 'done'
		return res
	
	_name='dotcom.stock.report'
	_description = 'Document shown on product available stock reports'
	_columns = {
				'location_id': fields.many2one('dotcom.stock.location','Location'),
				'prod_id': fields.many2one('product.product','Product'),
				'model_id': fields.many2one('ir.model','Model',required=True),
				'qty': fields.float('Moved Quantity'),
				'date': fields.date('Movement date'),
				'origin': fields.char('Origin',size=40),
				'created': fields.many2one('dotcom.stock.document','Origin Document'),
				'reset': fields.char('reset',size=40),
				'price': fields.float('Unit Price'),
				'average_cost': fields.float('Average Cost'),
				'origin_id': fields.integer('Origin ID', required=True),
				'linha_id': fields.integer('Linha ID'),
				'ordem':fields.integer('Ordem'),
				'state': fields.selection([
						('draft','Draft'),
						('done','OK'),
						],'State', select=True, readonly=True,),
				'operacao': fields.selection([
						('in','Entrada'),
						('out','Saida'),
						('trans','Transferencia'),
						('reset','Actualizacao'),
						],'Operacao', select=True, readonly=True,),
					
	}
	_order = 'ordem desc'
	_defaults = {'qty':0,'state':'done'}
	_sql_constraints = [('stock_report_unique', 'unique(prod_id,ordem,origin,location_id,origin_id,linha_id)', 'já foi criado um movimento no stock para esse documento!')]

	#def criar(self, cr, uid, values, context=None):
	#    if context is None:
	#        context = {}
	#    
	#

	#def create(self, cr, uid, values, context=None):
	#    if context is None:
	#        context = {}
	#    #model_id = values.get('model_id', None)
	#    #model = self.pool.get('ir.model').browse(cr, uid, model_id)
	#    #model_name = model and model.model
	#    #id = values.get('origin_id', None)
	#    #movimento = self.pool.get(model_name).browse(cr, uid, id)
	#    #report_id = movimento and movimento.report_id or False
	#    #if report_id:
	#    #    values['sequence'] = report_id
	#    #else:
	#    #    totals = self.search(cr, uid, [], count=True)
	#    #    try_again = True
	#    #    while try_again == True:
	#    #        eureka = False
	#    #        for one in ['dotcom.stock.order','dotcom.venda','dotcom.compra']:
	#    #            found = self.pool.get(one).search(cr, uid, [('report_id','=', totals)])
	#    #            if found:
	#    #                eureka = False
	#    #                continue
	#    #            else:
	#    #                eureka = True
	#    #                continue
	#    #        if eureka:
	#    #            try_again = False
	#    #        else:
	#    #            totals += 1
	#    #    values['sequence'] = totals
	#    #    self.pool.get(model_name).write(cr, uid, [id], {'report_id':totals})
	#    return super(dotcom_stock_report, self).create(cr,uid,values,context=context)

dotcom_stock_report()

class dotcom_stock_available(osv.osv):
	
	# def _stock_available(self, cr, uid, ids, name, arg, context=None):
	#     res = {}
	#     for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
	#         # lista = {}
	#         total = 0
	#         query = []
	#         query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
	#         query.append(('location_id','=',available and available.location_id and available.location_id.id))
	#         query.append(('state','=','done'))
	#         reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem DESC')
	#         reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem'])
	#         reads = sorted(reads, key=lambda d: (d['ordem']), reverse=True)
	#         logger.info('Reads: %s' % reads)
	#         for movimento in reads:
	#             # ordem = movimento.get('ordem')
	#             qty = movimento.get('qty', 0)
	#             if movimento.get('reset', False) == 'reset':
	#                 # total = qty
	#                 total = total + qty
	#                 break
	#             else:
	#                 total = total + qty
	#         res[available.id] = total
	#     return res
	
	def _stock_available(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
			total = 0
			query = []
			query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
			cur_location = available and available.location_id and available.location_id.id
			query.append(('state','=','done'))
			reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem DESC')
			reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem', 'location_id'])
			reads = sorted(reads, key=lambda d: (d['ordem']), reverse=True)
			for movimento in reads:
				move_location = movimento.get('location_id', (False,))[0]
				if move_location == cur_location:
					qty = movimento.get('qty', 0)
					if movimento.get('reset', False) == 'reset':
						total = total + qty
						break
					else:
						total = total + qty
				else:
					if movimento.get('reset', False):
						break
			res[available.id] = total
		return res
	
	def _stock_entradas(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
			total = 0
			query = []
			query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
			cur_location = available and available.location_id and available.location_id.id
			query.append(('state','=','done'))
			query.append(('qty','>=',0))
			reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem DESC')
			reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem', 'location_id'])
			reads = sorted(reads, key=lambda d: (d['ordem']), reverse=True)
			for movimento in reads:
				move_location = movimento.get('location_id', (False,))[0]
				if move_location == cur_location:
					qty = movimento.get('qty', 0)
					if movimento.get('reset', False) == 'reset':
						total = total + qty
						break
					else:
						total = total + qty
				else:
					if movimento.get('reset', False):
						break
			res[available.id] = total
		return res
	# 
	# def _stock_entradas(self, cr, uid, ids, name, arg, context=None):
	#     res = {}
	#     for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
	#         # lista = {}
	#         total = 0
	#         query = []
	#         query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
	#         query.append(('location_id','=',available and available.location_id and available.location_id.id))
	#         query.append(('state','=','done'))
	#         query.append(('qty','>=',0))
	#         reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem')
	#         reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem'])
	#         reads = sorted(reads, key=lambda d: (d['ordem']))
	#         for movimento in reads:
	#             # ordem = movimento.get('ordem')
	#             qty = movimento.get('qty', 0)
	#             if movimento.get('reset', False) == 'reset':
	#                 total = qty
	#             else:
	#                 total = total + qty
	#         res[available.id] = total
	#     return res
	
	def _stock_saidas(self, cr, uid, ids, name, arg, context=None):
		res = {}
		for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
			total = 0
			total_saidas =0
			query = []
			query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
			cur_location = available and available.location_id and available.location_id.id
			query.append(('state','=','done'))
			# query.append(('qty','<',0))
			reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem ASC')
			reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','operacao','reset','ordem','location_id'])
			reads = sorted(reads, key=lambda d: (d['ordem']), reverse=False)
			for movimento in reads:
				move_location = movimento.get('location_id', (False,))[0]
				if move_location == cur_location:
					qty = movimento.get('qty', 0)
					logger.info(' \n\n_stock_saidas Qty , movimento.get(operacao, False) =======: %.2f , %s' % (qty,movimento.get('operacao', False)))
					if movimento.get('operacao', False) == 'reset':
						#logger.info('entra no if para zerar=======')
						total = 0
						#total_saidas=0
						#break
					else:
						if qty < 0:
							#logger.info('_stock_saidas qty < 0 =======: %.2f' % qty)
							total += qty
							#logger.info('\n\n\n _stock_saidas total =======: %.2f' % total)
							total_saidas = total
				else:
					if movimento.get('operacao', False) == 'reset':
						#logger.info('entra no else para zerar=======')
						total = 0
						total_saidas=0
						#break
			logger.info('\n\n\n _stock_saidas total =======: %.2f' % total)
			logger.info('\n\n\n _stock_saidas total_saidas =======: %.2f' % total_saidas)
			res[available.id] = total
		return res
	
	# def _stock_saidas(self, cr, uid, ids, name, arg, context=None):
	#     res = {}
	#     for available in self.pool.get('dotcom.stock.available').browse(cr, uid, ids):
	#         # lista = {}
	#         total = 0
	#         query = []
	#         query.append(('prod_id','=',available and available.prod_id and available.prod_id.id))
	#         cur_loc = available and available.location_id and available.location_id.id
	#         query.append(('state','=','done'))
	#         #query.append(('qty','<',0))
	#         reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, query, order='ordem')
	#         reads = self.pool.get('dotcom.stock.report').read(cr, uid, reports_ids, ['qty','reset','ordem', 'location_id'])
	#         reads = sorted(reads, key=lambda d: (d['ordem']))
	#         for movimento in reads:
	#             # ordem = movimento.get('ordem')
	#             qty = movimento.get('qty', 0)
	#             t_loc = movimento.get('location_id', (False,))[0]
	#             if t_loc == cur_loc:
	#                 if movimento.get('reset', False) == 'reset':
	#                     total = 0
	#                 else:
	#                     if qty<0:
	#                         total = total + qty
	#             else:
	#                 if movimento.get('reset', False) == 'reset':
	#                     total = 0
	#         res[available.id] = total
	#     return res
	
	_name='dotcom.stock.available'
	_description = 'Document shown on product available stock reports'
	_columns = {
				'location_id': fields.many2one('dotcom.stock.location','Location'),
				'prod_id': fields.many2one('product.product','Product'),
				#'qty_available': fields.float('Available Quantity'),
				'qty_available': fields.function(_stock_available, method=True, string='Available Quantity',digits=(1,5),type='float', store=False),
				'qty_entradas': fields.function(_stock_entradas, method=True, string='Acumulado Entradas',digits=(1,5), type='float', store=False),
				'qty_saidas': fields.function(_stock_saidas, method=True, string='Acumulado Saidas',digits=(1,5), type='float', store=False),
	}
	_defaults = {'qty_available':0}

dotcom_stock_available()

class dotcom_stock_document(osv.osv):
	
	_name = "dotcom.stock.document"
	_description = "Stock Movement documents configuration"
	_columns = {
				'ref': fields.char('Reference', size=60,required=True),
				'name': fields.char('Name', size=60,required=True),
				'notes': fields.text('Notes'),
				'type': fields.selection([('in','Incoming'),('out','Outgoing'),('trans','Transference'),('reset','Reset')],'Movement Type',required=True),
				'sequencias_ids': fields.one2many('dotcom.sequence','documento_stock_id','Sequencer'),
				'default_sequence': fields.many2one('dotcom.sequence', 'Default Sequence'),
				'update_last_price':fields.boolean('Update Last Cost Price'),
				'update_date':fields.boolean('Update Last Movement Date'),
				'update_last_med_price':fields.boolean('Update Average Cost Price'),
				}

	_rec_name = 'name'
	
	def copy(self, cr, uid,id, vals, context=None):
		if context is None:
			context={}
		document = self.read(cr, uid, id, ['ref','name'], context=context)
		vals['sequencias_ids'] = None
		vals['default_sequence'] = None
		vals['ref'] = document.get('ref','') + _(' (copy)')
		vals['name'] = document.get('name','') + _(' (copy)')
		return super(dotcom_stock_document, self).copy(cr, uid,id, vals, context=context)
	
dotcom_stock_document()

class dotcom_picking_list(osv.osv):
	_name='dotcom.picking.list'
	_description = 'Product picking list for stock management'
	_columns = {
				'location_id': fields.many2one('dotcom.stock.location','Location'),
				'prod_id': fields.many2one('product.product','Product'),
				'sale_id': fields.many2one('dotcom.venda','Origin'),
				'purchase_id': fields.many2one('dotcom.compra','Origin'),
				'qty': fields.float('Moved Quantity'),
				'date': fields.date('Movement date'),
	}
	_order = 'date desc'
	_defaults = {'qty':0}
	
dotcom_picking_list()

class dotcom_stock_verificar(osv.osv):
	
	_name = 'dotcom.stock.verify'
	_description = 'Verificador de links de movimentos de stock'
	_columns = {
		'model_id': fields.many2one('ir.model','Model',required=True),
		'report_id': fields.many2one('dotcom.stock.report','Report ID', required=True, ondelete = 'cascade'),
		'order_id': fields.char('Order ID',size=30,required=True),
		'prod_id': fields.many2one('product.product','Produto',required=True),
		'order_name' : fields.char('Order Name', size=300),
		'code': fields.integer('Priority', required=True),
		'line_id': fields.integer('Line'),
	}
	
	_rec_name = 'code'
	
	#_sql_constraints = [('code_uniq', 'unique(prod_id, report_id)', 'Numero da ordem já utilizado em outro registo'),]

dotcom_stock_verificar()

class dotcom_doc_cancelamento(osv.osv):
	_name = 'dotcom.doc.cancelamento'
	_inherit = 'dotcom.doc.cancelamento'
	_columns = {'stock_id': fields.many2one('dotcom.stock.order', 'Stock', readonly=True, required=False, ondelete='cascade')}
	_defaults = {'stock_id': lambda s, cr, u, c: c.get('stock_id',None),}
	def save(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		res = super(dotcom_doc_cancelamento, self).save(cr, uid, ids, context=context)
		for browse in self.browse(cr, uid, ids):
			tipo = browse.type
			stock_id = False
			if browse.stock_id:
				stock_id = browse.stock_id and browse.stock_id.id or False
				logger.info('TIPO DE RESET: %s\nSTOCK ID: %s' % (tipo,stock_id))
				if browse.type == 'reset':
					self.pool.get('dotcom.stock.order').run_reset(cr, uid, [stock_id] , context=context)
				elif browse.type == 'cancel':
					self.pool.get('dotcom.stock.order').cancel_now(cr, uid, [stock_id] , context=context)
		return res
	
dotcom_doc_cancelamento()

class dotcom_stock_product_wiz(osv.osv_memory):
	_name = 'dotcom.stock.product_wizard'
	_columns = {'product_ids': fields.many2many('product.product','stock_product_update_wiz_rel','wiz_id','product_id','Produtos', domain="[('type','=','product')]"),
				'location_id': fields.many2one('dotcom.stock.location','Localização'),
				'order_id': fields.many2one('dotcom.stock.order', 'Stock Order'),
				}
	_rec_name = 'order_id'
	_defaults = {'order_id': lambda self, cr, uid, c: c.get('order_id')}
	
	def update_products(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		this = self.browse(cr, uid, ids and ids[0])
		each = this and this.order_id or False
		if each:
			cur_id = each.id
			location_id = this.location_id and this.location_id.id or False
			doc_type = each.doc_type and each.doc_type.id or False
			if not location_id:
				raise osv.except_osv(_('Acção Inválida !'), _('Localização por defeito não definida !'))
			deletes = []
			for product in this.product_ids:
				product_id = product.id or False
				change = self.pool.get('dotcom.stock.order.line').onchange_product(cr, uid, [], product_id, location_id, 1, location_id, doc_type, context=context)
				values = {'prod_id': product_id, 'order_id': cur_id, 'doc_type': doc_type, 'location_id': location_id}
				values.update(change.get('value', {}))
				src = self.pool.get('dotcom.stock.order.line').search(cr, uid, [('prod_id','=',product_id),('location_id','=',location_id),('order_id','=',cur_id)])
				logger.info('\nValue: %s' % values)
				if src:
					self.pool.get('dotcom.stock.order.line').write(cr, uid, src and src[0], values)
				else:
					created = self.pool.get('dotcom.stock.order.line').create(cr, uid, values)
					deletes.append(created)
				logger.info('\n\n\nTO APPEND: %s ' % deletes)
			#self.pool.get('dotcom.stock.order').write(cr,uid,cur_id, {'stock_lines': [(6,0,deletes)]})
		else:
			logger.info('Order not found: %s' % each)
		return {'type': 'ir.actions.act_window_close'}



class dotcom_stock_product_wiz_venda(osv.osv_memory):
	_name = 'dotcom.stock.product_wizard_venda'
	_columns = {'product_ids': fields.many2many('product.product','venda_prod_update_wiz_rel','wiz_id','product_id','Produtos', domain="[('type','=','product')]"),
				'location_id': fields.many2one('dotcom.stock.location','Localização'),
				'venda_id': fields.many2one('dotcom.venda', 'Venda'),
				}
	_rec_name = 'venda_id'
	_defaults = {'venda_id': lambda self, cr, uid, c: c.get('venda_id')}
	
	def update_products(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		this = self.browse(cr, uid, ids and ids[0])
		each = this and this.venda_id or False
		if each:
			cur_id = each.id
			location_id = this.location_id and this.location_id.id or False
			doc_type = each.doc_type and each.doc_type.id or False
			if not location_id:
				raise osv.except_osv(_('Acção Inválida !'), _('Localização por defeito não definida !'))
			deletes = []
			for product in this.product_ids:
				product_id = product.id or False
				total_temp= product.list_price
				change = self.pool.get('dotcom.venda.linha').onchange_product(cr, uid, [], product_id, each.partner_id.id, context=context)

				values = {'prod_id': product_id, 'document_top': cur_id,'stock_location': location_id,'total_temp':total_temp,'line_total':total_temp,}
				values.update(change.get('value', {}))
				src = self.pool.get('dotcom.venda.linha').search(cr, uid, [('prod_id','=',product_id),('stock_location','=',location_id),('document_top','=',cur_id)])
				logger.info('\nValue: %s' % values)
				if src:
					self.pool.get('dotcom.venda.linha').write(cr, uid, src and src[0], values)
				else:
					created = self.pool.get('dotcom.venda.linha').create(cr, uid, values)
					deletes.append(created)
				logger.info('\n\n\nTO APPEND: %s ' % deletes)
			#self.pool.get('dotcom.stock.order').write(cr,uid,cur_id, {'stock_lines': [(6,0,deletes)]})
		else:
			logger.info('Venda not found: %s' % each)
		return {'type': 'ir.actions.act_window_close'}

class dotcom_stock_product_wiz_compra(osv.osv_memory):
	_name = 'dotcom.stock.product_wizard_compra'
	_columns = {'product_ids': fields.many2many('product.product','compra_prod_update_wiz_rel','wiz_id','product_id','Produtos', domain="[('type','=','product')]"),
				'location_id': fields.many2one('dotcom.stock.location','Localização'),
				'compra_id': fields.many2one('dotcom.compra', 'Compra'),
				}
	_rec_name = 'compra_id'
	_defaults = {'compra_id': lambda self, cr, uid, c: c.get('compra_id')}
	
	def update_products(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		this = self.browse(cr, uid, ids and ids[0])
		each = this and this.compra_id or False
		if each:
			cur_id = each.id
			location_id = this.location_id and this.location_id.id or False
			doc_type = each.doc_type and each.doc_type.id or False
			if not location_id:
				raise osv.except_osv(_('Acção Inválida !'), _('Localização por defeito não definida !'))
			deletes = []
			for product in this.product_ids:
				product_id = product.id or False
				total_temp= product.list_price
				change = self.pool.get('dotcom.compra.linha').onchange_product(cr, uid, [], product_id, context)

				values = {'prod_id': product_id, 'document_top': cur_id,'stock_location': location_id,'total_temp':total_temp,'line_total':total_temp,}
				values.update(change.get('value', {}))
				src = self.pool.get('dotcom.compra.linha').search(cr, uid, [('prod_id','=',product_id),('stock_location','=',location_id),('document_top','=',cur_id)])
				logger.info('\nValue: %s' % values)
				if src:
					self.pool.get('dotcom.compra.linha').write(cr, uid, src and src[0], values)
				else:
					created = self.pool.get('dotcom.compra.linha').create(cr, uid, values)
					deletes.append(created)
				logger.info('\n\n\nTO APPEND: %s ' % deletes)
			#self.pool.get('dotcom.stock.order').write(cr,uid,cur_id, {'stock_lines': [(6,0,deletes)]})
		else:
			logger.info('compra not found: %s' % each)
		return {'type': 'ir.actions.act_window_close'}

class dotcom_stock_order(osv.osv):

	_name = "dotcom.stock.order"
	_description = "Stock Movement Orders"
	
	def _calc_qty(self, cr, uid, ids, field, arg, context=None):
		res = {}
		for order in self.browse(cr, uid, ids, context=context):
			qty = 0
			qty = sum([line.qty for line in order.stock_lines])
			res[order.id] = qty
		return res
	
	def _get_period_id(self, cr, uid, ids, field, arg, context=None):
		if context is None:
			context = {}
		res = {}
		
		for order in self.browse(cr, uid, ids, context=context):
			period_id = None
			given_date = order and order.date
			fiscal_period = self.pool.get('configuration.period').search(cr,uid,[('closing','=',False),('special','=',False),('date_start','<=',given_date),('date_stop','>=',given_date)],limit=1)
			if fiscal_period and len(fiscal_period)>0:
				period_id = fiscal_period[0]
			res[order.id] = period_id

		return res
	
	_columns = {
				'doc_type': fields.many2one('dotcom.stock.document','Document Type', required=True,readonly=True,states={'draft':[('readonly',False)]}),
				'doc_ref': fields.related('doc_type','ref',type="char",size=128,relation="dotcom.stock.document",string="REF", store=True),
				'sequence_id': fields.many2one('dotcom.sequence','Document Sequence', required=True,readonly=True,states={'draft':[('readonly',False)]}),
				'code': fields.char('Number', size=30, readonly=True),
				'date': fields.date('Date', readonly=True, states={'draft':[('readonly',False)]}),
				'stock_lines': fields.one2many('dotcom.stock.order.line','order_id','Products',readonly=True,states={'draft':[('readonly',False)]}),
				'notes': fields.text('Notes',readonly=True,states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
				'user_id': fields.many2one('res.users', 'User',readonly=True),
				'company_id': fields.many2one('res.company','Company',readonly=True),
				'is_auto': fields.boolean('Is system generated'),
				'is_transfer': fields.boolean('Is a transfer'),
				'currency_id': fields.many2one('res.currency','Currency'),
				'doc_rate': fields.float('Câmbio', readonly=True),
				'exchange_rate': fields.float('Exchange Rate'),
				'total_qty': fields.function(_calc_qty, type='float', string='Quantity', method=True),
				'period_id': fields.function(_get_period_id, type='many2one', obj='configuration.period', string='Período', method=True, store=True),
				'total': fields.float('Total', readonly=True),
				'report_id': fields.integer('Report'),
				'cancelamento_ids': fields.one2many('dotcom.doc.cancelamento','stock_id','Cancelamentos',readonly=True),
				'permite_rascunho': fields.selection([('sim','Sim'),('nao','Nao')],'Permite volta a Rascunho'),
				'state': fields.selection([
						('draft','Draft'),
						('post','Posted'),
						('cancel','Cancelled'),
						('reset','Draft'),
						],'State', select=True, readonly=True,
						help=' * The \'Draft\' state is used when a user is encoding a new and unconfirmed Document, document does have an document number. \
						\n* The \'Posted\' when document is confirmed and all movements where made successfully. \
						\n* The \'Cancelled\' state is used when a user cancels the document.'),
				'print_other_currency': fields.boolean('Imprimir Contra-Valor'),
				'alternative_currency': fields.many2one('res.currency','Moeda',readonly=True, help='Moeda de Contra-Valor',states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
				'alternative_currency_value': fields.float('Câmbio',required=False,readonly=True, help='Câmbio de Contra-Valor', states={'draft':[('readonly',False)],'reset':[('readonly',False)]}),
				#'product_ids': fields.many2many('product.product','stock_product_update_rel','order_id','product_id','Produtos', domain="[('type','=','product')]"),
				#'location_id': fields.many2one('dotcom.stock.location','Localização'),
				#'create_date': fields.datetime('Data de Criacao'),
				}

	_defaults = {
		'exchange_rate': 1.0,
		'permite_rascunho': lambda *a : 'sim',
		'state' : lambda *a : 'draft',
		'is_auto': lambda *a : False,
		'is_transfer': lambda *a : False,
		'date': lambda *a: time.strftime('%Y-%m-%d'),
		'user_id': lambda s, cr, u, c: u,
		'company_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_get(cr, uid, 'dotcom.stock', context=c),
		'currency_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_currency_get(cr, uid, 'dotcom.stock.order', context=c),
	}
	_rec_name = 'code'
	_order = 'date desc'
	
	def open_wiz(self, cr, uid, ids , context=False):
		return {
			'name': 'Actualização de Produtos',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.stock.product_wizard',
			'type': 'ir.actions.act_window',
			'context': {'order_id': ids and ids[0]},
			'target':'new',
			}
	
	def copy(self, cr, uid,id, vals, context=None):
		if context is None:
			context={}
		vals['code'] = None
		vals['state'] = 'draft'
		vals['report_id'] = None
		vals['user_id'] = uid
		vals['total'] = 0.0
		return super(dotcom_stock_order, self).copy(cr, uid,id, vals, context=context)
	
	def product_list(self, prod_id, qty, line_id=None,vals={}):
		res = {}
		res['line'] = line_id
		if vals is None:
			vals = {}
		if vals and vals.has_key(line_id):
			line = vals.get(line_id, {})
			temp = line.get('qty', 0) + qty
			res['qty'] = temp
			res['prod_id'] = prod_id
			vals[line_id] = res
		else:
			res['qty'] = qty
			res['prod_id'] = prod_id
			vals[line_id] = res
		return vals
	
	def get_model_id(self, cr, uid, classe, context=None):
		if context is None:
			context = {}
		model_pool = self.pool.get('ir.model')
		found_id = model_pool.search(cr, uid ,[('model','=',classe)],limit=1)
		if found_id and len(found_id)>0:
			found_id = found_id[0]
		else:
			found_id = None
		return found_id
	
	def on_change_date(self, cr, uid, ids, doc_type, doc_date,state, context=None):
		if context is None:
			context = {}
		self.check_document_last_date(cr, uid, doc_type, doc_date,state)
		return {}
	
	def check_sequences(self, cr, uid, ids, doc_type_id, sequence_id, context=None):
		sequences = self.pool.get('dotcom.sequence').browse(cr,uid,sequence_id,context)
		if sequences.documento_stock_id and sequences.documento_stock_id.id != doc_type_id:
			raise osv.except_osv(_('Acção Inválida !'), _('A sequência selecionada nao pertence a este documento !'))
		return True
	
	def check_lines(self, cr, uid, id, context=None):
		if context is None:
			context = {}
		me = self.browse(cr,uid,id,context=context)
		if me.stock_lines is None or len(me.stock_lines)==0:
			raise osv.except_osv(_('Erro !'), _('O documento deve ter pelo menos uma linha!'))
		return True
	
	def on_change_alternative_currency(self, cr, uid, ids, doc_currency):
		vals = {}
		if doc_currency:
			currency = self.pool.get('res.currency').browse(cr,uid,doc_currency)
			# currency_name = ''
			currency_rate = 1
			if currency and currency.base is False:
				currency_rate = self.pool.get('dotcom.venda').pattern(cr,uid,currency.rate)
			vals = {'value':{'alternative_currency_value':currency_rate}}
		return vals
	
	def onchange_line(self, cr, uid, ids, stock_lines,context=None):
		if context is None:
			context = {}
		logger.info('STOCK_LINE: %s\nCONTEXT: %s' % (stock_lines, context))
		return {}
	
	def check_document_last_date(self, cr, uid, doc_type, doc_date,state):
		now = datetime.now()
		given_date = datetime(*(time.strptime(doc_date, '%Y-%m-%d')[0:6]))
		
		res = False

		if given_date>now:
			#logger.info('Document date is after system date, preparing ERROR Message')
			self.notificar_accao_invalida('A data do documento nao pode ser posterior a data actual !')
		else:
			lst_last_doc = self.search(cr,uid,[('doc_type','=',doc_type),('state','in',['post'])],order='date desc',limit=1)
			#logger.info('FOUND ID: %s' % str(lst_last_doc))
			res = True
			
			if lst_last_doc and len(lst_last_doc)>0:
				documento = self.browse(cr,uid,lst_last_doc)[0]
				last_documento_date = datetime(*(time.strptime(documento.date, '%Y-%m-%d')[0:6]))
				res = True
				logger.info('IF: %s <  %s and %s != "reset"' % (given_date, last_documento_date,state))
				if given_date<last_documento_date and state != 'reset':
					res = False
				logger.info('res: %s' % (res))
				if res is False:
					#logger.info('Current date is before last document date, preparing ERROR Message')
					self.notificar_accao_invalida('A data do documento nao pode ser anterior a data do ultimo movimento')
				else:
					logger.info('Current date and end date is OK, SAVING!')
			else:
				logger.info('Just Continue!')

		return res
	
	def on_change_doc_type(self, cr, uid, ids,doc_type,is_transfer, context=None):
		if context is None:
			context = {}
		doc = self.pool.get('dotcom.stock.document').browse(cr,uid,doc_type)
		val = {}
		doc_type = doc
		sequence = doc_type.default_sequence and doc_type.default_sequence.id or False
		if sequence:
			val.update({'sequence_id':sequence})
		else:
			val.update({'sequence_id':None})
		if doc.type=='trans':
			val['is_transfer'] = True
		else:
			val['is_transfer'] = False
		self.write(cr,uid,ids,val)
		return {'value':val}
		
	def on_change_rate_base(self, cr, uid, ids, currency_id, moeda_primaria_id):
		if currency_id == moeda_primaria_id:
			return {'value': {'doc_currency': 1}}
		else:
			rate = self.pool.get('res.currency').browse(cr, uid, currency_id).rate or ''
			return {'value': {'doc_currency': rate}}
	
	def on_change_currency(self, cr, uid, ids, currency, context=None):
		if context is None:
			context = {}
		val = {}
		currency_pool = self.pool.get('res.currency').browse(cr,uid,currency)
		rate = currency_pool.rate or 1
		val.update({'doc_rate':rate})
		self.write(cr,uid,ids,val)
		return {'value':val}
	
	def _check_product(self, cr, uid, product_id, context=None):
		if context is None:
			context={}
		#produto = self.pool.get('product.product').read(cr,uid,[product_id],['type','name'])
		product = self.pool.get('product.product').browse(cr, uid, product_id)
		
		tipo = product.type
		#logger.info('TIPO de Produto: %s' % str(tipo))
		if tipo != 'product':
			nome = str(product.name or '')
			raise osv.except_osv(_('Informação !'), _('O producto %s nao e armazenavel') % nome)
		return True
	
	def check_line_errors(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for one in self.browse(cr, uid, ids, context=context):
			if one.doc_type and one.doc_type.type == 'trans':
				for linha in one.stock_lines:
					location_id = linha.location_id and linha.location_id.id or False
					from_id = linha.from_id and linha.from_id.id or False
					if (location_id and from_id) and (location_id!=from_id):
						continue
					else:
						raise osv.except_osv(_('Informação !'), _('Não pode executar operações sobre a mesma localização!'))
		return True
	
	def check_elders(self, cr, uid, data, doc_type_id, context={}):
		types_pool = self.pool.get('dotcom.stock.document')
		order_pool = self.pool.get('dotcom.stock.order')
		current_document = types_pool.browse(cr, uid, doc_type_id)
		doc_type_type = current_document and current_document.type
		if doc_type_type != 'reset':
			docs = types_pool.search(cr, uid, [('type','=','reset')])
			ooops = order_pool.search(cr, uid, [('doc_type','in',docs),('date','>',data), ('state','!=','draft')])
			if ooops:
				raise osv.except_osv(_('Informação !'), _('Não é permitida a emissão de documentos com data inferior a data da última actualização!'))
		return True
	
	def _get_report_code(self, cr, uid, classe=None, tot=None,context=None):
		if context is None:
			context = {}
		logger.info('\n===============  log controler 7===================')
		counter = self.pool.get('ir.model.data').get_object(cr, uid, 'dotcom_stock', 'stock_counter')
		logger.info('\n===============  log controler 8===================')

		#==========================================================================================
		sql ="select max(ordem) from dotcom_stock_report;"
		cr.execute(sql)
		rows = cr.dictfetchall()
		logger.info('\nGenerating Report Code copy %s' % rows)
		sql_query_result = rows and rows[0]['max']

		logger.info('\nGenerating Report Code sql_query_result %s' % type(sql_query_result))

		logger.info('\nGenerating Report Code copy[] %s' % sql_query_result)
		#==========================================================================================
		if bool(sql_query_result) is not True:
			number=1
		else:   
			number = sql_query_result
			number = number+1
		next_number = number + 1
		self.pool.get('dotcom.stock.sequence').write(cr, uid, counter.id, {'name': next_number})

		try:
			cr.commit()
		except Exception:
			pass
		logger.info('\nGenerating Report Code original %s' % number)
		return number
		# 
		# total1 = self._generate_max(cr, uid, context=context)
		# totals = (total1 or 0) + 1
		# logger.info('Report Code: %s' %totals)
		# return totals
	
	def check_report(self, cr, uid, object_name = '', object_id = False, context={}):
		report_code = False
		logger.info('\n===============  log controler 4===================')
		obj = self.pool.get(object_name).browse(cr, uid, object_id)
		logger.info('\n===============  log controler 5===================')
		if not obj.report_id:
			logger.info('\n===============  log controler 6===================')
			report_code = self.pool.get('dotcom.stock.order')._get_report_code(cr, uid, object_name, object_id, context=context)
			logger.info('\n===============  log controler 12===================')
			# self.pool.get(object_name).write(cr, uid, object_id, {'report_id':report_code})
		else:
			logger.info('\nReading Current Report Code')
			report_code = obj and obj.report_id
		logger.info('\nCleaning Drafts with Report Code: %s' % report_code)
		model_id = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, object_name, context=context)
		reported = self.pool.get('dotcom.stock.report').search(cr, uid, [('model_id','=',model_id),('ordem','=',report_code),('state','=','draft')])
		self.pool.get('dotcom.stock.report').unlink(cr, uid, reported)
		return report_code
	
	def post(self, cr, uid, ids, move_stock=True, context=None):
		if context is None:
			context = {}

		val = {}
		res = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		self.check_transaction(cr, uid, ids, context=context)
		self.check_line_errors(cr, uid, ids, context=context)
		
		product_lista = []
		for order in self.browse(cr,uid,ids):
			
			id_line = order.id
			doc_type_id = order.doc_type.id
			group_validator.check_stock_permissions(cr, uid, doc=doc_type_id, action='post', context=context, alert=True)
			
			data = order.date 
			self.check_elders(cr, uid, data, doc_type_id, context=context)
			
			seq_id = order.sequence_id.id
			operacao = order.doc_type.type
			if order.doc_type.type=='reset':
				open_documents = self.search(cr, uid, [('state','in',['draft','reset']),('id','!=',order.id)])
				error = False
				if open_documents:
					#   VERIFICA SE HÁ DOCUMENTOS DE MOVIMENTO DE STOCK EM ABERTO
					error = True
				else:
					#   LISTA DE TODOS DOCUMENTOS DA GESTAO COMERCIAL QUE MOVIMENTAM STOCK:
					doc_type = self.pool.get('documento.tipo').search(cr, uid, [('movimenta_stock','!=','do_not')])
					
					#   VERIFICA SE HÁ DOCUMENTOS DE VENDAS EM ABERTO
					if doc_type:
						vendas = self.pool.get('dotcom.venda').search(cr, uid, [('state','in',['draft','reset']),('doc_type','in',doc_type)])
						if vendas:
							error = True
						else:
							#   MESMA VERIFICAÇAO PARA DOCUMENTOS DE COMPRAS
							if not error:
								compras = self.pool.get('dotcom.compra').search(cr, uid, [('state','in',['draft','reset']),('doc_type','in',doc_type)])
								if compras:
									error = True
				#   EM CASO DE ERRO, NOTIFICAR O USUÁRIO
				if error:
					raise osv.except_osv(_('Informaçäo !'), _('Por favor, regularize todos documentos em rascunho!'))
				
			#   VERIFICA SE A SEQUENCIA DO DOCUMENTO CORRESPONDE AO TIPO DE DOCUMENTO
			self.check_sequences(cr, uid, [id_line], doc_type_id, seq_id, context=context)
			
			#   VERIFICA A EXISTENCIA DE LINHAS A MOVIMENTAR PELO DOCUMENTO
			self.check_lines(cr, uid, id_line,context=context)
			
			#   LE O ID DO MODELO DO DOCUMENTO EM CAUSA
			model = self.get_model_id(cr, uid, self._name, context=context)
			
			#   GERA O CODIGO OU ORDEM DO MOVIMENTO DE STOCK
			report_code = self.check_report(cr, uid, object_name=self._name, object_id = id_line, context=context)
			logger.info('\n\n\n ORDEM ISSUE NOVO report_code: %s =========' % report_code)
			# if not order.report_id:
			#     report_code = self._get_report_code(cr, uid, self._name, order.id,context=context)
			#     self.write(cr, uid, order.id, {'report_id':report_code})
			# else:
			#     report_code = order.report_id
			# 
			##   LISTA TODOS DOCUMENTOS COM MESMA REFERENCIA EM ####RASCUNHO#### E OS ELIMINA
			#reported = self.pool.get('dotcom.stock.report').search(cr, uid, [('ordem','=',report_code),('state','=','draft')])
			#self.pool.get('dotcom.stock.report').unlink(cr, uid, reported)
			#
			for line in order.stock_lines:
				#   VERIFICA SE O PRODUCTO É ARMAZENÁVEL
				self._check_product(cr, uid, line.prod_id.id, context=context)
				
				#   VERIFICA SE AS QUANTIDADES DOS PRODUTOS ESTÃO DISPONIVEIS
				if order.doc_type.type in ['out']:
					prod_id = line.prod_id.id
					location_id = line.location_id.id
					qty = abs(line.qty) or 0
					self.check_remaining_qty(cr,uid, prod_id, location_id, -1*qty, context=context)
				elif order.doc_type.type in ['trans']:
					prod_id = line.prod_id.id or None
					location_id = line.from_id.id or None
					qty = abs(line.qty) or 0
					self.check_remaining_qty(cr,uid, prod_id, location_id, -1*qty, context=context)
			
			#   VERIFICA A DATA DO ULTIMO DOCUMENTO
			self.check_document_last_date(cr,uid,order.doc_type.id,order.date,order.state)
			
			#   GERA OU LÊ A SEQUENCIA DO DOCUMENTO
			code = order.code or self.generate_sequence(cr,uid,order.id,context)
			val = {'code':code,'state':'post', 'report_id': report_code}
			signal = 1
			
			# DEFINE SINAL A ADICIONAR AS QUANTIDADES EXISTENTES
			if order.doc_type.type=='out':
				signal = -1
			else:
				signal = 1
				
			# Verifica Duplicidade de registos em actualizações
			if order.doc_type.type=='reset':
				mapa = []
				for line in order.stock_lines:
					if line.prod_id.id in mapa:
						producto = str(line.prod_id.name or '')
						raise osv.except_osv(_('Informação !'), _('O producto %s esta repetido nas linhas do documento' % producto))
						break
					else:
						mapa.append(line.prod_id.id)
						continue

			my_currency = order.company_id.currency_id.id
			doc_currency = order.currency_id.id
			exchange_rate = order.doc_rate or 1
			
			logger.info('\nMy Currency: %s\nDocument Currency: %s\nExchange Rate: %s' % (my_currency,doc_currency,exchange_rate))
			
			update_date = order.doc_type.update_date or False
			update_last_price = order.doc_type.update_last_price or False
			update_last_cost_price = order.doc_type.update_last_med_price or False
			lst_pm_prod = {}
			lst_qty_prod = {}
			# lst_qty_warehouse = {}
			
			#   DEFINE PARA 0 AS QUANTIDADES SE O MOVIMENTO DE STOCK FOR DE ACTUALIZAÇÃO
			if order.doc_type.type=='reset':
				products = []
				for line in order.stock_lines:
					products.append(line.prod_id.id)
				availables = self.pool.get('dotcom.stock.available').search(cr,uid,[('prod_id','in',products)])
				if availables and len(availables)>0:
					self.pool.get('dotcom.stock.available').unlink(cr,uid,availables)
				for product in products:
					self.pool.get('product.product').write(cr,uid,[product],{'stock_qty':0,'last_cost_price':0,'last_average_cost':0})
			
			totalizador = 0
			
			for line in order.stock_lines:
				
				logger.info('\n++++++++++++++++Processing LINE %s++++++++++++++++\n' % (line.id))
				
				# rep = {}
				prod_id = line.prod_id.id
				location_id = line.location_id.id
				qty = abs(line.qty) or 0
				date = order.date or time.strftime('%Y-%m-%d'),
				origin = order.doc_type.ref + ' ' +code
				from_id = line.from_id and line.from_id.id or None
				price = line.un_price or 0
				anterior = 0
				qty_anterior = 0
				
				if lst_pm_prod.has_key(str(prod_id)):
					anterior =  lst_pm_prod[str(prod_id)]
				else:
					anterior = line.prod_id.last_average_cost or 0
				
				if lst_qty_prod.has_key(str(prod_id)):
					qty_anterior =  lst_qty_prod[str(prod_id)]
				else:
					qty_anterior = line.prod_id.stock_qty or 0 or 0

				pm = (anterior)
				
				if order.doc_type.type=='in':
					
					#   ACTUALIZAÇÃO DE VALORES DE ACORDO COM OS SETTINGS DO TIPO DE DOCUMENTO
					
					#   Actualizar último preço
					logger.info('\n++++++++++=====++++++update_last_price  %s+++++++++====+++++++\n' % (update_last_price ))
					if update_last_price is True:
						if my_currency == doc_currency:
							logger.info('\n++++++++++=====++++++price same exchange  %s+++++++++====+++++++\n' % (price ))
							logger.info('\n++++++++++=====++++++price same exchange prod_id %s+++++++++====+++++++\n' % (prod_id ))
							self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price)})
							logger.info('\n++++++++++=====++++++ price different last_cost_price browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_cost_price))
							
						else:
							logger.info('\n++++++++++=====++++++price different exchange  %s+++++++++====+++++++\n' % (price ))
							logger.info('\n++++++++++=====++++++price different exchange prod_id %s+++++++++====+++++++\n' % (prod_id ))
							self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price*exchange_rate)})
							logger.info('\n++++++++++=====++++++ price different last_cost_price browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_cost_price))
							
					# Actualizar PREÇO DE CUSTO ÚLTIMO
					logger.info('\n++++++++++=====++++++update_last_cost_price  %s+++++++++====+++++++\n' % (update_last_cost_price ))
					if update_last_cost_price is True:
						if my_currency == doc_currency:
							medio_anterior = anterior
							quantidade_anterior = qty_anterior
							try:
								pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
							except ZeroDivisionError:
								pm = 0
							pm = (pm)
							lst_pm_prod[str(prod_id)] = pm
							lst_qty_prod[str(prod_id)] = qty_anterior+qty
							logger.info('\n++++++++++=====++++++ write 1 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
							logger.info('\n++++++++++=====++++++ write 1 last_average_cost prod_id  %s+++++++++====+++++++\n' % (prod_id ))
							self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
							logger.info('\n++++++++++=====++++++ write 1 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))
						else:
							medio_anterior = anterior
							quantidade_anterior = qty_anterior
							try:
								pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
							except ZeroDivisionError:
								pm = 0
							pm = (pm)
							lst_pm_prod[str(prod_id)] = pm
							lst_qty_prod[str(prod_id)] = qty_anterior+qty
							logger.info('\n++++++++++=====++++++ write 2 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
							logger.info('\n++++++++++=====++++++ write 2 last_average_cost prod_id  %s+++++++++====+++++++\n' % (pm ))
							self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
							logger.info('\n++++++++++=====++++++ write 2 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))

				
				elif order.doc_type.type=='reset':
					
					if my_currency == doc_currency:
						medio_anterior = anterior
						quantidade_anterior = qty_anterior
						pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
						pm = (pm)
						lst_pm_prod[str(prod_id)] = pm
						lst_qty_prod[str(prod_id)] = qty_anterior+qty
						
						self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm,'last_purchase':date,'last_cost_price':(price or 0)})
					else:
						medio_anterior = anterior
						quantidade_anterior = qty_anterior
						try:
							pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
						except ZeroDivisionError:
							pm = 0
						pm = (pm)
						lst_pm_prod[str(prod_id)] = pm
						lst_qty_prod[str(prod_id)] = qty_anterior+qty
						self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm,'last_purchase':date,'last_cost_price':(price*exchange_rate or 0)})

				#pm = (pm)
				
				# VERIFICAR REQUISITOS PARA TRANSFERENCIAS
				if order.doc_type.type=='trans' and (line.from_id is False or line.from_id is None):
					self.notificar_accao_invalida('''Por Favor, preencha o campo origem do producto: %s! ''' % str(line.prod_id.name or ''))
				from_id = line.from_id.id
				
				price_temp = price
				if my_currency != doc_currency:
					price_temp = price * exchange_rate
				
				if order.doc_type.type=='trans':
					# NO CASO DE TRANSFERENCIA
					# CRIAR MOVIMENTO DE STOCK (SAIDA)
					state='done'
					self.create_report(cr,uid,report_code,operacao,state,prod_id,from_id,-1*qty,origin,date,price_temp,pm,model,order.id,order.id,context, linha_id=line.id)
					
					# MOVER STOCK (SAIDA)
					self.move_stock(cr,uid,prod_id,from_id,-1*qty,context)
					
					logger.info('\n++++++++++++++++Sent %i to %s++++++++++++++++\n' % (qty, location_id))
					
					# CRIAR MOVIMENTO DE STOCK (ENTRADA)
					self.create_report(cr,uid,report_code,operacao,state,prod_id,location_id,qty,origin,date,price_temp,pm,model,order.id,order.id,context, linha_id=line.id)
					
					# MOVER STOCK (ENTRADA)
					self.move_stock(cr,uid,prod_id,location_id,qty,context)
					
					#   DEFINIR PRECO UNITARIOS DA LINHA PARA 'NULL'
					self.pool.get('dotcom.stock.order.line').write(cr, uid, [line.id], {'un_price':None})
					logger.info('\n++++++++++++++++Received %i from %s++++++++++++++++\n' % (qty, from_id))
				else:
					
					#   ENTRADA OU SAIDA DE STOCK
					
					# CRIAR MOVIMENTO DE ENTRADA/SAIDA DE STOCK
					logger.info('\n++++++++++=====++++++ write 2 operacao   %s+++++++++====+++++++\n' % (operacao ))
					if operacao == 'out':
						pm = line.prod_id.last_average_cost
					logger.info('\n++++++++++=====++++++ write 2 pm   %s+++++++++====+++++++\n' % (pm ))
					state='done'
					self.create_report(cr,uid,report_code,operacao,state,prod_id,location_id,signal*qty,origin,date,price_temp,pm,model,from_id = order.id, order_id = order.id,context=context, linha_id=line.id)
					
					# MOVER STOCK (ENTRADA/SAIDA)
					self.move_stock(cr,uid,prod_id,location_id,signal*qty,context)
					
					#   CASO O DOCUMENTO SEJA DE ACTUALIZACAO, DEFINIR QUANTIDADES PARA A QUANTIDADE DA LINHA DA ORDEM DE STOCK
					if order.doc_type.type=='reset':
						self.pool.get('product.product').write(cr, uid, [prod_id], {'stock_qty':abs(qty)})
						#   DEFINIR QUANTIDADES A 0 PARA OUTROS ARMAZENS/LOCATIONS
						#self.reset_stock_locations(cr, uid, location_id, prod_id, context=context)
				
				# VERIFICA SE DEVE ACTUALIZAR A DATA DA ULTIMA COMPRA
				if update_date is True:
					self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
				totalizador = totalizador + (qty * price)

				qty = signal*abs(qty)
				#   LISTA DE PRODUCTOS TRANSACIONADOS E SUAS QUANTIDADES
				res = self.product_list(prod_id, qty, line_id= line and line.id, vals=res) or {}
				if prod_id not in product_lista:
					product_lista.append(prod_id)

				logger.info('\nlast_cost_price browse  %s&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_cost_price))
				logger.info('\nlast_average_cost browse  %s&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))


			val['total'] = totalizador
			self.write(cr,uid,id_line,val)
			
			# CASO NAO SEJA UMA TRANSFERENCIA, LIMPA O CAMPO DE ORIGEM
			if order.doc_type.type != 'trans':
				lines = []
				for line in order.stock_lines:
					lines.append(line.id)
				availables = self.pool.get('dotcom.stock.order.line').write(cr,uid,lines,{'from_id':None})
		
		#   EXECUTA REPROCESSAMENTO TOTAL DE STOCK (QUANTIDADES/LOCALIZACOES)
		
		#self.pool.get('dotcom.stock.entry.wizard').run(cr, uid, product_lista, context=context)     


		#self.pool.get('dotcom.stock.entry.wizard').repost_quantities(cr, uid, product_lista, context=context)
		
		logger.info('\n\nLISTA DE PRODUTOS:\n%s\n\n' % product_lista)
		self.remove_unavailables(cr, uid, product_lista, report_code, context=context)
		
		for di in ids:
			message = _("Order Posted")
			self.log(cr, uid, di, message)

		return res
	
	def remove_unavailables(self, cr, uid, product_list, order, context=None):
		if context is None:
			context = {}
		src = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','not in',product_list),('ordem','=',order)])
		if src:
			self.pool.get('dotcom.stock.report').unlink(cr, uid, src)
			logger.info('\n\n\n\n**********************Unavailable moves removed**********************\n%s\n********************************************' % src)
		return src
	
	def reset_stock_locations(self, cr, uid, location_id, product_id, context=None):
		if context is None:
			context = {}
		locations = self.pool.get('dotcom.stock.available').search(cr, uid, [('location_id','!=',location_id),('prod_id','=',product_id)])
		logger.info('Resetting on Locations: %s' % locations)
		if locations:
			for locale in self.pool.get('dotcom.stock.available').browse(cr, uid, locations):
				logger.info('Resetting on Location: %s\n' % locale.location_id.name)    
				self.pool.get('dotcom.stock.available').write(cr, uid, locations,{'qty_available':0})
		return True

	def check_remaining_qty(self, cr, uid, product, warehouse, qty, context=None):
		if context is None:
			context={}
		found = False
		check = self.pool.get('res.company')._should_check_stock(cr, uid, context=context)
		if warehouse:
			product_obj = self.pool.get('product.product').browse(cr,uid,product)
			if product_obj:
				warehouse_obj = self.pool.get('dotcom.stock.location').browse(cr,uid,warehouse)
				for house in product_obj.stock_available_ids:
					location = house.location_id and house.location_id.id
					if warehouse == location:
						found=True
						if check:
							if qty<0:
								logger.info('\n supostamentte menor que zero (Saida)================= \n%s' % qty)
								logger.info('\n house.qty_available disponivel qty: ================= \n%s' % house.qty_available)
								logger.info('\n abs(qty) quantidade a comparar com stock disponivel ================= \n%s' % abs(qty))
								logger.info('\n abs(qty) quantidade a comparar com stock disponivel ================= \n%s' % abs(qty))
								if house.qty_available < (-1*qty):
									logger.info('\n inside ============================ if %s < %s:\n' %(house.qty_available,(-1*qty)))
									product_name =  product_obj.name or 'product'
									warehouse = warehouse_obj.name or ''
									self.notificar_accao_invalida('Quantidade do producto %s indisponível na localização %s' % (product_name, warehouse))
								else:
									break
							break
					else:
						continue
				if check:    
					if qty<0:
						if found is False:
							prod_name = product_obj.name or ''
							warehouse = warehouse_obj.name or ''
							self.notificar_accao_invalida('O producto %s nao esta disponivel na localização %s' % (prod_name,warehouse))
		else:
			self.notificar_accao_invalida('Por favor, selecione uma localização para o producto!')
		return found
	
	def check_transaction(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for each in self.browse(cr, uid, ids):
			res = {}
			tipo = each.doc_type and each.doc_type.type
			if tipo == 'trans':
				for line in each.stock_lines:
					product = line.prod_id and line.prod_id.id
					product_name = line.prod_id and line.prod_id.name
					warehouse = line.location_id and line.location_id.id
					ware = line.location_id and line.location_id.name
					if res.has_key(warehouse):
						if res.get(warehouse):
							lista = res.get(warehouse)
							if product in lista:
								self.notificar_accao_invalida('O producto %s esta repetido para o armazem %s' % (str(product_name),str(ware)))
							else:
								lista.append(product)
								res[warehouse] = lista
						else:
							lista = [product]
							res[warehouse] = lista
		return True
	
	def check_stock_exit(self, cr, uid, product, quantity, warehouse, context=None):
		if context is None:
			context = {}
		available = self.pool.get('dotcom.stock.available')
		product_obj = self.pool.get('product.product').browse(cr,uid,product)
		values = available.search(cr,uid,[('prod_id','=',product),('location_id','=',warehouse)])
		check = self.pool.get('res.company')._should_check_stock(cr, uid, context=context)
		if check:
			if values and len(values)>0:
				for value in values:
					actual_availability = available.browse(cr,uid,value)
					if actual_availability.qty<quantity:
						self.notificar_accao_invalida('Quantidade do producto %s indisponível na localização selecionada' % str(product_obj.name) or 'product')
					else:
						break
			else:
				self.notificar_accao_invalida('Quantidade do producto %s indisponível na localização selecionada' % str(product_obj.name or 'product'))
		return True
	
	def _generate_max(self, cr, uid, context=None):
		cr.execute('select max(ordem) from dotcom_stock_report')
		res = cr.fetchone()
		return (res and res[0]) or False
	
	def create_report_verifier(self, cr, uid, report={}, report_id = None, context={}):
		if context is None:
			context = {}
		
		res = {}
		res['model_id'] = report.get('model_id', None)
		res['prod_id'] = report.get('prod_id', None)
		res['report_id'] = report_id or False
		res['order_id'] = report.get('origin_id', None)
		res['order_name'] = report.get('origin', '')
		res['code'] = report.get('ordem', None)
		res['line_id'] = report.get('linha_id', None)
		
		self.pool.get('dotcom.stock.verify').create(cr, uid, res)
		return True
	
	def create_report(self, cr, uid, report_id,operacao,state, prod_id, location_id,qty,origin,date,unit_price,average_cost,model_id,from_id = None, order_id=None, context=None, linha_id=None):
		if context is None:
			context = {}
		rep = {}
		reset = ''
		report_pool = self.pool.get('dotcom.stock.report')
		
		rep['prod_id'] = prod_id
		rep['location_id'] = location_id
		rep['qty'] = qty or 0
		rep['date'] = date or time.strftime('%Y-%m-%d'),
		rep['origin'] = origin
		rep['price'] = unit_price or 0
		rep['average_cost'] = average_cost or 0
		rep['model_id'] = model_id
		rep['origin_id'] = from_id
		rep['ordem'] = report_id
		rep['operacao'] = operacao
		if state =='reset':
			state='draft'
		elif state == 'done' or state == 'post' or state == 'validated':
			state='done'
		rep['state'] = state
		rep['linha_id'] = linha_id or None
		
		logger.info('\nCreating REPORT: fj================= \n%s' % rep)
		results = report_pool.search(cr, uid, [('ordem','=',report_id),('operacao','=',operacao),('qty','=',qty),('model_id','=',model_id),('origin_id','=',from_id),('prod_id','=',prod_id),('linha_id','=',linha_id)])
		if results:
			id_rep = results and results[0]
			report_pool.write(cr, uid, id_rep, rep)
		else:
			# CRIACAO DE MOVIMENTO DE STOCK
			if order_id is not None:
				reset_pool = self.pool.get('dotcom.stock.order')
				font = reset_pool.browse(cr,uid,order_id)
				
				if font.doc_type.type=='reset':
					reset = 'reset'
				rep['reset']=reset
		
			id_rep = report_pool.create(cr,uid,rep)
			logger.info('\n\nA criar Movimento de Stock com o ID: %s' % id_rep)
		var = self.pool.get('dotcom.stock.verify').search(cr, uid, [('report_id','=',id_rep),('order_id','=',report_id),('model_id','=',model_id)])
		if not var:
			self.create_report_verifier(cr, uid, report = rep, report_id=id_rep)
		return id_rep

	def move_stock(self, cr, uid, prod_id,location_id,qty,context=None):
		if context is None:
			context = {}
		available_pool = self.pool.get('dotcom.stock.available')
		product_pool = self.pool.get('product.product')
		available = {}
		result = {}
		lst_availables = available_pool.search(cr,uid,[('prod_id','=',prod_id),('location_id','=',location_id)])
		
		logger.info('\n\nLST AVAILABLES: %s\n' % lst_availables)
		
		if lst_availables:
			for lst in lst_availables:
				
				result = available_pool.browse(cr, uid, lst, context=context)
				qty_available = result and result.qty_available or 0#result[0]['qty_available']
				logger.info('\n\nReading qty available: %s\n' % qty_available)
				available_pool.write(cr,uid,lst,{'qty_available':qty_available + qty})
				new_qty_available = qty_available + qty
				logger.info('\n\nWriting new availability: %i' % new_qty_available)
		else:
			#   CRIA QUANTIDADES DISPONIVEIS NO ARMAZEM/LOCATION DEFINIDO
			available = {}
			available['prod_id'] = prod_id
			available['location_id'] = location_id
			available['qty_available'] = qty
			created = available_pool.create(cr,uid,available)
			logger.info('\n\nCreated: %s\n' % created)
			
		#   CALCULA E ESCREVE A QUANTIDADE TOTAL DO PRODUTO
		logger.info('\n\nLoading Product: %s\n' % prod_id)
		product = product_pool.browse(cr,uid,prod_id)
		stock = product.stock_qty or 0
		product_pool.write(cr,uid,[prod_id],{'stock_qty':stock+qty})
		logger.info('\n\nWriting Product STOCK: %s\n' % prod_id)
		
		return result
	
	def stock_reset(self, cr, uid, produto=None, location=None, origin=None, classe='dotcom.venda', context=None):
		if context is None:
			context = {}
		venda = self.pool.get(classe).browse(cr, uid, origin, context=context)
		if venda.doc_type.movimenta_stock != 'do_not':
			model = self.get_model_id(cr, uid, classe, context=context)
			movements = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto)], order = 'ordem DESC')
			# movements = sorted(movements, reverse=True)
			logger.info('Found Movements :%s' % movements)
			logger.info('Movimento ID :%s' % venda and venda.id)
			order_class = self.get_model_id(cr, uid, 'dotcom.stock.order', context=context)
			# res = False
			if movements:
				for one in movements:
					origin_id = self.pool.get('dotcom.stock.report').browse(cr, uid, one).origin_id or None
					classe_id = self.pool.get('dotcom.stock.report').browse(cr, uid, one).model_id.id or None
					logger.info('Origin :%s' % origin_id)
					if origin_id == origin and model==classe_id:
						# res = True
						break
					else:
						if classe_id == order_class:
							check1 = self.pool.get('dotcom.stock.report').browse(cr, uid, one)
							check = self.pool.get('dotcom.stock.order').browse(cr, uid, check1.origin_id)
							doc_type = check and check.doc_type
							tipo = doc_type and doc_type.type
							if tipo not in ['reset']:
								continue
							else:
								prod_name = self.pool.get('product.product').browse(cr, uid, produto).name or ''
								order = check.doc_type and check.doc_type.ref
								order_number = check.code or ''
								prob = '%s %s' % (order, order_number)
								raise osv.except_osv(_('Acção Inválida !'), _('O documento nao pode ser redefinido para rascunho porque o produto %s possui um movimento de actualizacao mais recente %s !' % (prod_name, prob)))
								break
						else:
							continue
		return {}
	
	def check_reset_lines(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for movimento in self.browse(cr,uid,ids):
			for line in movimento.stock_lines:
				product = line and line.prod_id.id or None
				model = self.get_model_id(cr, uid, 'dotcom.stock.order', context=context)
				movements = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',product),('model_id','=',model)], order = 'ordem DESC')
				# movements = sorted(movements, reverse=True)
				logger.info('Found Movements :%s' % movements)
				logger.info('Movimento ID :%s' % movimento and movimento.id)
				# res = False
				if movements:
					for one in movements:
						origin_id = self.pool.get('dotcom.stock.report').browse(cr, uid, one).origin_id or None
						logger.info('Origin :%s' % origin_id)
						if origin_id == movimento.id:
							# res = True
							break
						else:
							check1 = self.pool.get('dotcom.stock.report').browse(cr, uid, one)
							check = self.pool.get('dotcom.stock.order').browse(cr, uid, check1.origin_id)
							doc_type = check and check.doc_type
							tipo = doc_type and doc_type.type
							if tipo not in ['reset']:
								continue
							else:
								prod_name = self.pool.get('product.product').browse(cr, uid, product).name or ''
								order = check.doc_type and check.doc_type.ref
								order_number = check.code or ''
								prob = '%s %s' % (order, order_number)
								raise osv.except_osv(_('Acção Inválida !'), _('O documento nao pode ser redefinido para rascunho porque o produto %s possui um movimento de actualizacao mais recente %s !' % (prod_name, prob)))
								break
				else:
					continue
		return {}
	
	def run_reset(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		to_calculate = []
		for each in self.browse(cr, uid, ids):
			doc_type = each and each.doc_type
			group_validator.check_stock_permissions(cr, uid, doc=doc_type.id, action='reset', context=context, alert=True)
			tipo = doc_type and doc_type.type
			if tipo == 'reset':
				continue
			else:
				self.check_reset_lines(cr, uid, [each.id], context=context)
		for value in ids:
			movimento = self.browse(cr,uid,value)
			signal = 1
			if movimento.doc_type.type=='out':
				signal = 1
			elif movimento.doc_type.type=='in':
				signal = -1
			
			if movimento.doc_type.type in ['in','out']:
				for mov in movimento.stock_lines:
					qty = signal * (abs(mov.qty) or 0)
					warehouse_id = mov.location_id.id or None
					prod = mov.prod_id.id
					self.check_remaining_qty(cr,uid,prod, warehouse_id, qty, context=context)
				for line in movimento.stock_lines:
					qty = signal * (abs(line.qty) or 0)
					warehouse_id = line.location_id.id or None
					product_id = line.prod_id.id or None                  
					
					for available in line.prod_id.stock_available_ids:
						if available.location_id.id == warehouse_id:
							new_qty = (available.qty_available or 0) + qty
							prod_qty = line.prod_id.stock_qty + qty
							self.pool.get('dotcom.stock.available').write(cr,uid,available.id,{'qty_available':new_qty})
							self.pool.get('product.product').write(cr,uid,[product_id],{'stock_qty':prod_qty})
							break
						else:
							continue
					if product_id not in to_calculate:
						to_calculate.append(product_id)
				self.write(cr,uid,movimento.id,{'state':'reset','user_id':uid})
			elif movimento.doc_type.type=='trans':
				for mov in movimento.stock_lines:
					if mov.qty>0:
						qty = -1*abs(mov.qty) or 0
					else:
						qty = abs(mov.qty) or 0
					warehouse_id = mov.location_id and mov.location_id.id or None
					prod = mov.prod_id and mov.prod_id.id
					self.check_remaining_qty(cr,uid,prod, warehouse_id, qty, context=context)
				for line in movimento.stock_lines:
					qty = line.qty or 0
					to_id = line.location_id.id or None
					product_id = line.prod_id.id or None
					from_id = line.from_id.id or None
					self.move_stock(cr, uid, product_id, from_id, qty, context=context)
					self.move_stock(cr, uid, product_id, to_id, -1*qty, context=context)
					if product_id not in to_calculate:
						to_calculate.append(product_id)
				self.write(cr,uid,movimento.id,{'state':'reset','user_id':uid})
			else:
				raise osv.except_osv(_('Informação !'), _('''Não e permitida Devolucao à Rascunho de documentos de actualizacao de Stock! \nCrie uma nova actualizacao de Stocks!'''))
			report_pool = self.pool.get('dotcom.stock.report')
			report_search = report_pool.search(cr,uid,[('ordem','=',movimento.report_id)])
			if report_search:
				report_pool.write(cr,uid,report_search, {'state':'draft'})
		self.pool.get('dotcom.stock.entry.wizard').run_products(cr, uid, to_calculate, context=context)
		
		for di in ids:
			message = _("Stock Order Reset")
			self.log(cr, uid, di, message)
		return True
	
	def reset(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		resets = {}
		resets['user_id'] = uid
		resets['motivo'] = ' '
		resets['stock_id'] = ids and ids[0] or None
		required = self.pool.get('res.company')._get_require_motivo(cr, uid, tipo='reset')
		resets['required'] = required or False
		for document in self.browse(cr,uid,ids):
			if document.permite_rascunho=='nao':
				raise osv.except_osv(_('Acção Inválida !'), _('O documento nao pode ser redefinido para rascunho porque contem produto(s) que possui(em) movimento(s) de actualizacao mais recente!'))


		if required:
			return {
			'name': _("Motivos de Cancelamento"),
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.doc.cancelamento',
			'res_id': False,
			'target' : 'new',
			'nodestroy': True,
			'context': resets,
			}
		else:
			res = self.pool.get('dotcom.doc.cancelamento').create(cr, uid, resets)
			return self.pool.get('dotcom.doc.cancelamento').save(cr, uid, [res], context=context)
	
	def cancel_now(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		for one in self.browse(cr, uid, ids):
			doc_type = one and one.doc_type and one.doc_type.id
			group_validator.check_stock_permissions(cr, uid, doc=doc_type, action='cancel', context=context, alert=True)
		report_pool = self.pool.get('dotcom.stock.report')
		for each in self.browse(cr, uid, ids, context=context):
			ordem = each and each.report_id
			report_search = report_pool.search(cr,uid,[('ordem','=',ordem), ('state','=','draft')])
			if report_search:
				report_pool.unlink(cr,uid,report_search)
		self.write(cr,uid,ids,{'state':'cancel'})
		for di in ids:
			message = _("Stock Order Canceled")
			self.log(cr, uid, di, message)
		return True
	
	def cancel(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		
		resets = {}
		#resets['stock_id'] = ids and ids[0] or None
		resets['user_id'] = uid
		resets['motivo'] = ' '
		resets['type'] = 'cancel'
		resets['stock_id'] = ids and ids[0] or None
		required = self.pool.get('res.company')._get_require_motivo(cr, uid, tipo='cancel')
		resets['required'] = required or False
		if required:
			return {
			'name': _("Motivos de Cancelamento"),
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'dotcom.doc.cancelamento',
			'res_id': False,
			'target' : 'new',
			'nodestroy': True,
			'context':resets,
			}
		else:
			res = self.pool.get('dotcom.doc.cancelamento').create(cr, uid, resets)
			return self.pool.get('dotcom.doc.cancelamento').save(cr, uid, [res], context=context)
	
	def unlink(self, cr, uid, ids, context=None):
		if context is None:
			context = {}
		self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
		invoices = self.read(cr, uid, ids, ['state','code'], context=context)
		unlink_ids = []
		for t in invoices:
			if t['state'] in ('draft') and t['code']== False:
				unlink_ids.append(t['id'])
			else:
				raise osv.except_osv(_('Informação !'), _('''Não e possivel apagar documentos emitidos'''))
		for doc in unlink_ids:
			documento = self.browse(cr,uid,doc)
			for linha in documento.stock_lines:
				self.pool.get('dotcom.stock.order.line').unlink(cr,uid,linha.id)
		osv.osv.unlink(self, cr, uid, unlink_ids, context=context)
		for di in ids:
			message = _("Stock Order Deleted")
			self.log(cr, uid, di, message)
		return True
	
	def notificar_accao_invalida(self,message):
		raise osv.except_osv(_('Acção Inválida !'), _(message))
		return True
	
	def notificar_erro(self,message):
		raise osv.except_osv(_('Erro !'), _(message))
		return True
	
	def notificar_atencao(self,message):
		raise osv.except_osv(_('Aviso !'), _(message))
		return True

	def generate_sequence(self, cr, uid, document_id,context=None):
		documento_pool = self.pool.get('dotcom.stock.order')
		documento = documento_pool.browse(cr,uid,document_id)
		logger.info('====================Preparing sequence processor stock')
		doc_number = ''
		if documento.code is False or documento.code=='':
			#logger.info('Looking for sequencer')
			sequence_id = documento.sequence_id.id
			if sequence_id:
				sequence_obj = self.pool.get('dotcom.sequence')
				sequence = sequence_obj.browse(cr,uid,sequence_id)

				# now = datetime.now()
				# year = int(now.year)
				
				#logger.info('Calculating Sequences')
				
				day = str(documento.date)
				doc_date = datetime(*(time.strptime(day, '%Y-%m-%d')[0:6]))
				date_year = doc_date.strftime('%Y')
				
				#logger.info('SEQUENCE ID: %i' % int(sequence.fiscal_year_id.code))
				if (int(sequence.fiscal_year_id.code)!=int(date_year)):
					#logger.info('Sequence fiscal year doesnt work with the selected date, please change your doc date')
					self.notificar_accao_invalida('A data selecionada nao corresponde ao ano fiscal')
					#break
				else:
					#logger.info('Sequence Generated')
					#logger.info('SEQUENCE ID: %s' % str(sequence_id))

					doc_number = sequence_obj.next_by_code(cr, uid, sequence.code) or sequence_obj.next_by_id(cr, uid, sequence_id)
					#logger.info('GENERATED SEQUENCE: %s' % str(doc_number))
		else:
			doc_number = documento.code
			#logger.info('FIELD ALREADY HAS A NUMBER: %s ' % str(doc_number))
		
		documento_pool.write(cr,uid,documento.id,{'code':doc_number})
		return doc_number
	
dotcom_stock_order()

class dotcom_stock_order_line(osv.osv):

	def _get_total_line(self, cr, uid, ids, field, arg, context=None):
		if context is None:
			context = {}
		res = {}
		for linha in self.read(cr, uid, ids, ['qty','un_price', 'id']):
			total = linha.get('qty',0.0) * linha.get('un_price',0.0)
			res[linha.get('id',False)] = total
		return res
	
	def _check_for_transfer(self, cr, uid, ids, field, arg, context=None):
		if context is None:
			context = {}
		res = {}
		it_is = False
		for linha in self.browse(cr,uid,ids,context):
			if linha.order_id.doc_type.type == 'trans':
				it_is = True
			res[linha.id] = it_is
		return res

	
	_name = "dotcom.stock.order.line"
	_description = "Stock Movement Orders"
	_columns = {
				'prod_id': fields.many2one('product.product','Product',domain=[('type','=','product')], required=True),
				'qty': fields.float('Quantity',digits=(1,3),required=True),
				'order_id': fields.many2one('dotcom.stock.order','Order'),
				'location_id': fields.many2one('dotcom.stock.location','Location', required=True),
				'from_id': fields.many2one('dotcom.stock.location','From', required=False),
				'description': fields.char('Description',size=360, readonly=False),
				'prod_uom': fields.related('prod_id','uom_id',type="many2one",relation="product.uom",string="UOM", store=True, readonly=False),
				'un_price': fields.float('Unit Price', digits_compute=dp.get_precision('Account')),
				'readonly_stat': fields.function(_check_for_transfer, type='boolean', string='Document is Transfer', method=True),
				'doc_type': fields.many2one('dotcom.stock.document', 'Documento'),
				'sequence': fields.integer('#', readonly=True,),
				'total': fields.function(_get_total_line, type="float", string="Total", store=False, readonly=True),
				}
	_order = 'sequence ASC'
	_defaults = {
		'qty': 1,
		'doc_type': lambda self, cr, uid, c: c.get('doc_type', None),
	}
	
	_sql_constraints = [('qty_ntlwgt_zero', 'CHECK (qty>0)', 'The quantity cannot be equal or lower than 0!')]
	
	def onchange_qty(self, cr, uid, ids,uom_id, qty, context=None):
		if context is None:
			context = {}
		val = {}
		if uom_id:
			
			qtd = validator.qty_rounding(cr, uid, uom_id, qty, context=context)
			
			val['qty'] = qtd
			
		return {'value':val}
		
	def onchange_location(self, cr, uid, ids, from_id, to_id, context=None):
		if context is None:
			context = {}
		if from_id in [False, None] or to_id in [False, None]:
			return {}
		else:
			if from_id == to_id:
				raise osv.except_osv(_('Acção Inválida !'), _('Não pode executar operações sobre a mesma localização!'))
			return {}
		
	def processar_campos(self, cr, uid, ids, prod_id, location_id, qty, uom_id,from_id, doc_type,context=None):
		if context is None:
			context = {}
		# val = {}
		fase1 = self.onchange_product(cr, uid, ids, prod_id, location_id, qty, from_id, doc_type, context=context).get('value', {})
		fase2 = self.onchange_qty(cr, uid, ids, uom_id, qty, context=context).get('value', {})
		self.onchange_location(cr, uid, ids, from_id, location_id, context=context)
		res = dict(fase1.items() + fase2.items())
		return {'value':res}
	
	def onchange_product(self, cr, uid, ids, prod_id, location_id, qty, from_id, doc_type,context=None):
		if context is None:
			context = {}
		val = {}
		
		logger.info('PRODUCT: %s\nLocation: %s\nQty: %s\nDoc Type: %s' % (prod_id, location_id, qty, doc_type))
		if prod_id and location_id and qty and doc_type:
			doc = self.pool.get('dotcom.stock.document').browse(cr, uid, doc_type)
			tipo = doc.type
			logger.info('Tipo de Documento de Stock: %s' % tipo)
			if tipo == 'out':
				self.pool.get('dotcom.venda.linha').on_change_location(cr, uid, [], location_id, prod_id, qty, context=context)
			elif tipo == 'trans':
				self.pool.get('dotcom.venda.linha').on_change_location(cr, uid, [], from_id, prod_id, qty, context=context)
			
		if prod_id:
			product_obj = self.pool.get('product.product')
			product = product_obj.browse(cr,uid,prod_id,context)
			if product:
				prod_uom = product.uom_id.id or product.uos_id.id
				prod_name = product.name

				val['prod_uom']= prod_uom
				val['description']= prod_name
			
			warehouse_ids = []
			warehouse_id = None
			for warehouse in product.stock_available_ids:
				warehouse_ids.append(warehouse.location_id.id)
			if warehouse_ids and len(warehouse_ids)>0:
				warehouse_id = warehouse_ids[0]
			else:
				warehouse_id = warehouse_ids or None
			val.update({'stock_location':warehouse_id})
			
			last_cost_price = product.last_cost_price or 0
			val.update({'un_price':last_cost_price})
		logger.info('val de Documento de Stock: %s' % val)
		return {'value':val}
	
	def create(self, cr, uid, values, context=None):
		if context is None:
			context = {}

		top = values.get('order_id', None)
		created = self.search(cr, uid, [('order_id','=',top)], count=True) or 0
		sequence = created + 1
		values['sequence'] = sequence
		
		if values.has_key('order_id'):
			doc_id = values['order_id']
			documento = ''
			if doc_id:
				documento = self.pool.get('dotcom.stock.order').browse(cr,uid,doc_id).doc_type
				if documento.type == 'trans' and values.has_key('from_id') is False:
					raise osv.except_osv(_('Erro !'), _('Por favor, selecione uma localização para o producto!'))
		return super(dotcom_stock_order_line, self).create(cr,uid,values,context=context)

dotcom_stock_order_line()