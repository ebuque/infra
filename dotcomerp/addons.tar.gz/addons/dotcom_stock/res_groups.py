# -*- coding: utf-8 -*-
import time
from lxml import etree
import netsvc
from osv import osv, fields
import decimal_precision as dp
from tools.translate import _

class res_groups(osv.osv):
    _name = 'res.groups'
    _inherit = 'res.groups'
    _columns = {
                'documento_stock_ids': fields.many2many('dotcom.stock.document','group_documento_stock_rel','group_id','documento_stock_id','Documentos de Stock'),
                }
    
res_groups()