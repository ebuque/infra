# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('REAJUSTE DE STOCK')

class jasper_stock_fix_wizard(osv.osv_memory):
    _name='stock.fix.wizard'

    def _generate_max(self, cr, uid, context=None):
        cr.execute('select max(ordem) from dotcom_stock_report')
        res = cr.fetchone()
        base = (res and res[0]) or 0
        return base+1

    def run(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        all = sorted(self.pool.get('dotcom.stock.report').search(cr, uid, []))
        INT = '\nA iniciar processamento de %i movimentos de Stock' % len(all)
        logger.info(INT)
        
        order_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order', context=context)
        venda_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.venda', context=context)
        compra_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.compra', context=context)
        
        logger.info('Classes\nOrdens: %s\nVendas: %s\nCompras:%s\n' % (order_model, venda_model, compra_model))
        
        stock = {}
        vendas = {}
        compras = {}
        
        for id in all:
            each = self.pool.get('dotcom.stock.report').browse(cr, uid, id)
            
            model_id = each.model_id.id
            model = each.model_id.model
            origin = each.origin_id
            found = False
            order = None
            
            logger.info('Writing on %s \n ID: %s' % (model, origin))

            if model_id == order_model:
                if stock.has_key(origin):
                    order = stock.get(origin, None)
                else:
                    order = self.pool.get('dotcom.stock.order').browse(cr, uid, origin).report_id
                    if not order:
                        order = self._generate_max(cr, uid, context=context)
                    stock[origin] = order
                self.pool.get('dotcom.stock.report').write(cr, uid, id, {'ordem':order})
                
            elif model_id == venda_model:
                if vendas.has_key(origin):
                    order = vendas.get(origin, None)
                else:
                    order = self.pool.get('dotcom.venda').browse(cr, uid, origin).report_id
                    if not order:
                        order = self._generate_max(cr, uid, context=context)
                    vendas[origin] = order
                self.pool.get('dotcom.stock.report').write(cr, uid, id, {'ordem':order})
                
            elif model_id == compra_model:
                if compras.has_key(origin):
                    order = compras.get(origin, None)
                else:
                    order = self.pool.get('dotcom.compra').browse(cr, uid, origin).report_id
                    if not order:
                        order = self._generate_max(cr, uid, context=context)
                    compras[origin] = order
                self.pool.get('dotcom.stock.report').write(cr, uid, id, {'ordem':order})
            
            self.pool.get(model).write(cr, uid, [origin], {'report_id':order})
            logger.info('\nOrder ID %s\n++++++++++++++++++++++++++++++++++++++' % order)
        final = '\nProcessados %i movimentos de Stock\n' % len(all)
        logger.info(final)
        for di in ids:
            message = final
            self.log(cr, uid, di, message)
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
   
jasper_stock_fix_wizard()