# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_stock_wizard_inventory(osv.osv_memory):
    _name='jasper.stock.wizard.inventory'

    _columns ={
        
        'warehouse_ids': fields.many2many('dotcom.stock.location','stock_location_inventory_reports','wizard_id','location_id','Locations'),

        'product_ids': fields.many2many('product.product','product_stock_inventory_print','wizard_id','product_id','Products', domain=[('type','=','product')]),
        'report_type':fields.selection([("pdf","PDF"),
                                        ("xls","Excel"),
                                        ("html","HTML")
                                        ],'Type'),
        'print_no_stock': fields.boolean('Incluir produtos/localizacoes sem stock'),
        'group':fields.selection([
                                ("warehouse","Warehouse"),
                                ("product","Product"),
                                ("category","Categoria de Produto"),
                                ],'Group By'),
        'price':fields.selection([
                                ("unit","Unit Price"),
                                ("pcm","Average Cost Price"),
                                ("pcu","Preço de Custo Último"),
                                ("pcp","Preço de Custo Padräo"),
                                ],'Price'),
        'date': fields.date('Data'),
        'category_id': fields.many2one('product.category','Categoria de Producto'),
        }
    _defaults ={
        'report_type': lambda *a: 'pdf',
        'group': lambda *a: 'warehouse',
        'price': lambda *a: 'unit',
        'print_no_stock': lambda *a: False,
        'date': lambda *a: time.strftime('%Y-%m-%d'),
    }
    
    def start_report(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,)[-1]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'dotcom_inventory_stock',
            'datas':{
                    'model':'dotcom.stock.report',
                    'id':context.get('active_ids') and context.get('active_ids')[0] or False,
                    'ids':context.get('active_ids') and context.get('active_ids') or [],
                    'report_type':data['report_type'],
                    'form':data
            },
            'nodestroy':False,
        }
 
jasper_stock_wizard_inventory()