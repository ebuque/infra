# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_stock_extracto_artigo_wizard(osv.osv_memory):
    _name='jasper.stock.extracto.artigo.wizard'

    _columns ={
        'warehouse_id': fields.many2many('dotcom.stock.location','stock_location_reports','wizard_id','location_id','Locations'),
        'date_from': fields.date('From'),
        'date_to': fields.date('To'),
        'category_id': fields.many2one('product.category','Categoria de Producto'),
        'product_id': fields.many2many('product.product','product_stock_print','wizard_id','product_id','Products', domain=[('type','=','product')]),
        'report_type':fields.selection([("pdf","PDF"),
                                        ("xls","Excel"),
                                        ("html","HTML")
                                        ],'Type'),
        }
    _defaults ={
        'report_type': lambda *a: 'pdf',
        'date_from': lambda *a: datetime.now().strftime('%Y-01-01'),
        'date_to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
    }
    
    def start_report(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,)[-1]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'dotcom_stock_extracto_artigo',
            'datas':{
                    'model':'dotcom.stock.report',
                    'id':context.get('active_ids') and context.get('active_ids')[0] or False,
                    'ids':context.get('active_ids') and context.get('active_ids') or [],
                    'report_type':data['report_type'],
                    'form':data
            },
            'nodestroy':False,
        }
 
jasper_stock_extracto_artigo_wizard()