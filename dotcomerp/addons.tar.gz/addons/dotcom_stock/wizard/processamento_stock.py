# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_stock_reprocessamento_wizard(osv.osv):
    _name='stock.reprocessamento.wizard'

    _columns ={
            'name': fields.char('Name', size=120, invisible=True),
            'product_ids': fields.many2many('product.product','product_stock_processing_rel','wizard_id','product_id','Products', domain=[('type','=','product')]),
        }
    _defaults = {'name': time.strftime('%Y-%m-%d')}
    
    def run(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        products = ids or []
        for product in products:
            actual_med = 0
            actual_qty = 0
            prod_last_price = 0
            prod = self.pool.get('product.product').browse(cr, uid, product)
            movimentos = []
            movimentos = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',product), ('state','!=','draft')], order='ordem asc')
            
            for movimento in movimentos:
                moved = self.pool.get('dotcom.stock.report').browse(cr,uid,movimento)
                model = moved.model_id.model
                doc_type = self.pool.get(model).browse(cr,uid,moved.origin_id).doc_type or False
                if doc_type:
                    updates = doc_type.update_last_med_price or False
                    if updates:
                        medio_anterior = actual_med
                        quantidade_anterior = actual_qty
                        qty = moved.qty or 0
                        price = moved.price or 0
                        try:
                            pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                        except ZeroDivisionError:
                            pm = 0
                        actual_med = pm
                        actual_qty = quantidade_anterior + qty
                        vals = {}
                        vals['average_cost'] = pm
                        self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)
                    else:
                        vals = {}
                        vals['average_cost'] = actual_med
                        quantidade_anterior = actual_qty
                        qty = moved.qty or 0
                        actual_qty = quantidade_anterior + qty
                        self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)
                    last_price = doc_type.update_last_price or False
                    if last_price:
                        prod_last_price = moved.price or 0
                    
                    if model == 'dotcom.stock.order':
                        if doc_type.type == 'reset':
                            prod_last_price = moved.price or 0
                            actual_med = moved.price or 0
                            actual_qty = moved.qty or 0
                self.pool.get('dotcom.stock.report').write(cr, uid, movimento, {'average_cost':actual_med})
            self.pool.get('product.product').write(cr,uid,[product],{'stock_qty':actual_qty,'last_average_cost':actual_med,'last_cost_price':prod_last_price})
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
    
    def calculate(self, cr, uid,ids, context={}):
        data = self.pool.get('dotcom.stock.entry.wizard').read(cr,uid,ids,['product_ids'])
        res = False
        if data:
            res = self.run(cr, uid, data[0]['product_ids'] or [], context=context)
            now = self.verificar_drafts(cr, uid, data[0]['product_ids'] or [], context=context)
            then = self.repost_quantities(cr, uid, data[0]['product_ids'], context=context)
        for di in ids:
            message = _("Stock Reprocess completed")
            self.log(cr, uid, di, message)
        return res
    
    def run_products(self, cr, uid,ids, context={}):
        res = self.run(cr, uid, ids or [], context=context)
        now = self.verificar_drafts(cr, uid, ids or [], context=context)
        then = self.repost_quantities(cr, uid, ids or [], context=context)
        for di in ids:
            message = _("Products Updated")
            self.log(cr, uid, di, message)
        return res
    
    def verificar_drafts(self, cr, uid, ids, context={}):
        for product in ids:
            produto = self.pool.get('product.product').browse(cr, uid, product)
            for movimento in produto.stock_report_ids:
                classe = movimento.model_id and movimento.model_id.model
                class_obj = self.pool.get(classe).browse(cr, uid, movimento.origin_id)
                state = class_obj and class_obj.state or ''
                if state in ['draft','reset']:
                    self.pool.get('dotcom.stock.report').write(cr, uid, [movimento and movimento.id], {'state':'draft'})
                elif state == 'cancel':
                    self.pool.get('dotcom.stock.report').unlink(cr, uid, [movimento and movimento.id])
        return False
    
    def repost_quantities(self, cr, uid, ids, context={}):
        if context is None:
            context = {}
        if ids:
            availability = self.pool.get('dotcom.stock.available')
            for produto in self.pool.get('product.product').browse(cr, uid, ids):
                lista = {}
                qty_available = 0
                total = 0
                reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto and produto.id), ('state','!=','draft')], order='ordem asc')
                #reports_ids = sorted(reports_ids)
                for movimento in self.pool.get('dotcom.stock.report').browse(cr, uid, reports_ids):
                    origin_classe = movimento and movimento.model_id and movimento.model_id.model
                    origin_id = movimento and movimento.origin_id or None
                    qty_available = 0
                    is_not_act = True
                    if origin_classe == 'dotcom.stock.order':
                        this = self.pool.get(origin_classe).browse(cr, uid, origin_id)
                        this_doc_type = this and this.doc_type
                        if this_doc_type and this_doc_type.type == 'reset':
                            is_not_act = False
                    location = movimento.location_id and movimento.location_id.id
                    
                    if is_not_act:
                        if lista.has_key(location):
                            qty_available = lista.get(location) + movimento.qty or 0
                        else:
                            qty_available = movimento.qty or 0
                    else:
                        qty_available = movimento.qty or 0
                        prod_id = movimento.prod_id.id
                        self.pool.get('dotcom.stock.order').reset_stock_locations(cr, uid, location, prod_id, context=context)
                        lista = {}
                    lista[location] = qty_available
                result = availability.search(cr, uid, [('prod_id','=',produto.id)])
                availability.unlink(cr, uid, result)
                for locale in lista:
                    new = {}
                    new['prod_id'] = produto and produto.id
                    new['location_id'] = locale
                    new['qty_available'] = lista.get(locale)
                    total = total + lista.get(locale)
                    availability.create(cr, uid, new, context=context)
                self.pool.get('product.product').write(cr, uid, [produto and produto.id],{'stock_qty':total})
        return False
jasper_stock_reprocessamento_wizard()