# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_stock_vendas_wizard(osv.osv_memory):
    _name='jasper.stock.vendas.wizard'

    _columns ={
        'warehouse_ids': fields.many2many('dotcom.stock.location','stock_location_report_vendas','wizard_id','location_id','Localizações'),
        'document_ids': fields.many2many('documento.tipo','stock_document_report_vendas','wizard_id','location_id','Documentos', domain=[('tipo_doc','=','sales')]),
        'category_id': fields.many2one('product.category','Categoria de Producto'),
        'price': fields.selection([
                                    ("last_cost_price","Preço de Custo Último"),
                                    ("last_average_cost","Preço de Custo Médio"),
                                    ("pcp","Preço de Custo Padrão"),
                                ],'Preço de Custo'),
        'date_from': fields.date('De'),
        'date_to': fields.date('Para'),
        'product_ids': fields.many2many('product.product','product_stock_print_vendas','wizard_id','product_id','Produtos'),
        }
    _defaults ={
        'date_from': lambda *a: datetime.now().strftime('%Y-01-01'),
        'date_to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'price': lambda *a: 'pcp',
    }
    
    def start_report(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,)[-1]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'dotcom_stock_venda',
            'datas':{
                    'model':'dotcom.stock.report',
                    'id':context.get('active_ids') and context.get('active_ids')[0] or False,
                    'ids':context.get('active_ids') and context.get('active_ids') or [],
                    'report_type':'pdf',
                    'form':data
            },
            'nodestroy':False,
        }
 
jasper_stock_vendas_wizard()