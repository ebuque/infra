# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class dotcom_stock_entry(osv.osv):
    _name='dotcom.stock.entry.wizard'

    _columns ={
        'compra_ids': fields.many2many('dotcom.compra','stock_entry_compras_rel','wizard_id','compra_id','Compras'),
        'venda_ids': fields.many2many('dotcom.venda','stock_entry_vendas_rel','wizard_id','venda_id','Vendas'),
        'stock_ids': fields.many2many('dotcom.stock.order','stock_entry_stock_rel','wizard_id','order_id','Stock'),
        
        'product_ids': fields.many2many('product.product','product_stock_processing_rel','wizard_id','product_id','Products', domain=[('type','=','product')]),
        
        'tipo_obj': fields.selection([('sale','Vendas'),('purchase','Compras'),('stock','Stock')],'Movimentos'),
        #, - Removed from tipo_obj
        'tipo_action': fields.selection([('products','Filtrar Produtos'),('all_products','Todos Produtos')],'Tipo',required=True),
        
        'general_processing': fields.boolean('Processar todos movimentos'),
        'name': fields.char('Name', size=120, invisible=True),
        }
    
    _defaults = {
        'general_processing': False,
        'name': time.strftime('%Y-%m-%d')
        }
    
    def on_change_bool(self, cr, uid, ids, boolean, tipo, context=None):
        if context is None:
            context = {}
        if tipo:
            return {}
        else:
            if boolean == True:
                return {'value': {'tipo_action': 'products'}}
            else:
                return {}
    
    def process(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = {}
        products = []
        move_stock = True
        for each in self.browse(cr, uid, ids):
            # if each.general_processing == False:
            if each.tipo_action == 'products':
                    res = self.calculate(cr, uid, ids, context=context)
                # else:
                #     if each.tipo_obj == 'purchase':
                #         res = self.process_purchase(cr, uid, ids, context=context)
                #     elif each.tipo_obj == 'sale':
                #         res = self.process_sale(cr, uid, ids, context=context)
                #     elif each.tipo_obj == 'stock':
                #         vals = []
                #         for one in each.stock_ids:
                #             vals.append(one.id)
                #         if vals:
                #             res = self.process_stock(cr, uid, vals, context=context)
                #continue
            else:
                products = self.pool.get('product.product').search(cr, uid, [('type','=','product')])
                logger.info('\n\n\nA REPOR ORDEM\n')
                self.repor_ordem(cr, uid, context=context)
                logger.info('\n\n\nA RUNNING\n')
                res = self.run(cr, uid, products or [], context=context)
                logger.info('\n\n\nA VERIFICAR DRAFTS\n')
                now = self.verificar_drafts(cr, uid, products or [], context=context)
                logger.info('\n\n\nA REPOSTING QTYs\n')
                then = self.repost_quantities(cr, uid, products, context=context)
                break
        return res
    
    def repor_ordem(self, cr, uid, context=None):
        if context is None:
            context = {}
        movimentos = self.pool.get('dotcom.stock.report').search(cr, uid, [], order = 'id ASC')
        vendas = {}
        compras = {}
        stock = {}

        vendas_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.venda', context=context)
        compras_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.compra', context=context)
        stock_model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, 'dotcom.stock.order', context=context)
        order = 0
        for movimento in self.pool.get('dotcom.stock.report').browse(cr, uid, movimentos):
            current_model_id = movimento.model_id and movimento.model_id.id or False
            movimento_id = movimento and movimento.id
            logger.info('\nProcessing Movimento: %s' % movimento_id)
            object_id = movimento.origin_id or None
            if current_model_id == vendas_model:
                if vendas.has_key(object_id):
                    order_number = vendas.get(object_id, None)
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id,{'ordem': order_number})
                else:
                    order = order + 1
                    vendas[object_id] = order
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id, {'ordem': order})
            elif current_model_id == compras_model:
                if compras.has_key(object_id):
                    order_number = compras.get(object_id, None)
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id,{'ordem': order_number})
                else:
                    order = order + 1
                    compras[object_id] = order
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id, {'ordem': order})
            else:
                if stock.has_key(object_id):
                    order_number = stock.get(object_id, None)
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id,{'ordem': order_number})
                else:
                    order = order + 1
                    stock[object_id] = order
                    self.pool.get('dotcom.stock.report').write(cr, uid, movimento_id, {'ordem': order})
        return True
    
    def process_stock(self, cr, uid, ids, context=None):
        if context is None:
            context = {}

        val = {}
        res = {}
        self.pool.get('dotcom.licence').check_expiry(cr,uid,'dotcom_cm',context)
        self.pool.get('dotcom.stock.order').check_transaction(cr, uid, ids, context=context)
        self.pool.get('dotcom.stock.order').check_line_errors(cr, uid, ids, context=context)
        product_lista = []
        for order in self.pool.get('dotcom.stock.order').browse(cr,uid,ids):
            
            id_line = order.id
            
            doc_type_id = order.doc_type.id
            
            #   VERIFICA A EXISTENCIA DE LINHAS A MOVIMENTAR PELO DOCUMENTO
            self.pool.get('dotcom.stock.order').check_lines(cr, uid, id_line,context=context)
            
            #   LE O ID DO MODELO DO DOCUMENTO EM CAUSA
            model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, self._name, context=context)
            
            #   GERA O CODIGO OU ORDEM DO MOVIMENTO DE STOCK
            if not order.report_id:
                report_code = self.pool.get('dotcom.stock.order')._get_report_code(cr, uid, 'dotcom.stock.order', order.id,context=context)
                self.pool.get('dotcom.stock.order').write(cr, uid, order.id, {'report_id':report_code})
            else:
                report_code = order.report_id
            
            for line in order.stock_lines:
                #   VERIFICA SE O PRODUCTO É ARMAZENÁVEL
                self.pool.get('dotcom.stock.order')._check_product(cr, uid, line.prod_id.id, context=context)
                
                #   VERIFICA SE AS QUANTIDADES DOS PRODUTOS ESTÃO DISPONIVEIS
                if order.doc_type.type in ['out']:
                    prod_id = line.prod_id.id
                    location_id = line.location_id.id
                    qty = abs(line.qty) or 0
                    self.pool.get('dotcom.stock.order').check_remaining_qty(cr,uid, prod_id, location_id, -1*qty, context=context)
                elif order.doc_type.type in ['trans']:
                    prod_id = line.prod_id.id or None
                    location_id = line.from_id.id or None
                    qty = abs(line.qty) or 0
                    self.pool.get('dotcom.stock.order').check_remaining_qty(cr,uid, prod_id, location_id, -1*qty, context=context)
            
            signal = 1
            
            # DEFINE SINAL A ADICIONAR AS QUANTIDADES EXISTENTES
            if order.doc_type.type=='out':
                signal = -1
            else:
                signal = 1
                
            if order.doc_type.type=='reset':
                mapa = []
                for line in order.stock_lines:
                    if line.prod_id.id in mapa:
                        producto = str(line.prod_id.name or '')
                        raise osv.except_osv(_('Informacao !'), _('O producto %s esta repetido nas linhas do documento' % producto))
                        break
                    else:
                        mapa.append(line.prod_id.id)
                        continue

            my_currency = order.company_id.currency_id.id
            doc_currency = order.currency_id.id
            exchange_rate = order.exchange_rate or 1
            
            update_date = order.doc_type.update_date or False
            update_last_price = order.doc_type.update_last_price or False
            update_last_cost_price = order.doc_type.update_last_med_price or False
            lst_pm_prod = {}
            lst_qty_prod = {}
            lst_qty_warehouse = {}
            
            #   DEFINE PARA 0 AS QUANTIDADES SE O MOVIMENTO DE STOCK FOR DE ACTUALIZAÇÃO
            if order.doc_type.type=='reset':
                products = []
                for line in order.stock_lines:
                    products.append(line.prod_id.id)
                availables = self.pool.get('dotcom.stock.available').search(cr,uid,[('prod_id','in',products)])
                if availables and len(availables)>0:
                    self.pool.get('dotcom.stock.available').unlink(cr,uid,availables)
                for product in products:
                    self.pool.get('product.product').write(cr,uid,[product],{'stock_qty':0,'last_cost_price':0,'last_average_cost':0})
            
            totalizador = 0
            
            for line in order.stock_lines:
                
                logger.info('\n++++++++++++++++Processing LINE %s++++++++++++++++\n' % (line.id))
                
                rep = {}
                prod_id = line.prod_id.id
                location_id = line.location_id.id
                qty = abs(line.qty) or 0
                date = order.date or time.strftime('%Y-%m-%d'),
                origin = order.code#order.doc_type.ref + ' ' +code
                from_id = line.from_id and line.from_id.id or None
                price = line.un_price or 0
                anterior = 0
                qty_anterior = 0
                
                if lst_pm_prod.has_key(str(prod_id)):
                    anterior =  lst_pm_prod[str(prod_id)]
                else:
                    anterior = line.prod_id.last_average_cost or 0
                
                if lst_qty_prod.has_key(str(prod_id)):
                    qty_anterior =  lst_qty_prod[str(prod_id)]
                else:
                    qty_anterior = line.prod_id.stock_qty or 0 or 0

                pm = (anterior)
                
                if order.doc_type.type=='in':
                    #   ACTUALIZAÇÃO DE VALORES DE ACORDO COM OS SETTINGS DO TIPO DE DOCUMENTO
                    
                    #   Actualizar último preço
                    logger.info('\n++++++++++=====++++++update_last_price  %s+++++++++====+++++++\n' % (update_last_price ))
                    if update_last_price is True:
                        if my_currency == doc_currency:
                            logger.info('\n++++++++++=====++++++price same exchange  %s+++++++++====+++++++\n' % (price ))
                            logger.info('\n++++++++++=====++++++price same exchange prod_id %s+++++++++====+++++++\n' % (prod_id ))
                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price)})
                            logger.info('\n++++++++++=====++++++ price different last_cost_price browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_cost_price))
                            
                        else:
                            logger.info('\n++++++++++=====++++++price different exchange  %s+++++++++====+++++++\n' % (price ))
                            logger.info('\n++++++++++=====++++++price different exchange prod_id %s+++++++++====+++++++\n' % (prod_id ))
                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price*exchange_rate)})
                            logger.info('\n++++++++++=====++++++ price different last_cost_price browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_cost_price))
                            
                    # Actualizar PREÇO DE CUSTO ÚLTIMO
                    logger.info('\n++++++++++=====++++++update_last_cost_price  %s+++++++++====+++++++\n' % (update_last_cost_price ))
                    if update_last_cost_price is True:
                        if my_currency == doc_currency:
                            medio_anterior = anterior
                            quantidade_anterior = qty_anterior
                            try:
                                pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                            except ZeroDivisionError:
                                pm = 0
                            pm = (pm)
                            lst_pm_prod[str(prod_id)] = pm
                            lst_qty_prod[str(prod_id)] = qty_anterior+qty
                            logger.info('\n++++++++++=====++++++ write 1 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
                            logger.info('\n++++++++++=====++++++ write 1 last_average_cost prod_id  %s+++++++++====+++++++\n' % (prod_id ))
                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                            logger.info('\n++++++++++=====++++++ write 1 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))
                        else:
                            medio_anterior = anterior
                            quantidade_anterior = qty_anterior
                            try:
                                pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
                            except ZeroDivisionError:
                                pm = 0
                            pm = (pm)
                            lst_pm_prod[str(prod_id)] = pm
                            lst_qty_prod[str(prod_id)] = qty_anterior+qty
                            logger.info('\n++++++++++=====++++++ write 2 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
                            logger.info('\n++++++++++=====++++++ write 2 last_average_cost prod_id  %s+++++++++====+++++++\n' % (pm ))
                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                            logger.info('\n++++++++++=====++++++ write 2 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))

                    #======================================================================================================
                    # #   ACTUALIZAÇÃO DE VALORES DE ACORDO COM OS SETTINGS DO TIPO DE DOCUMENTO
                    
                    # #   Actualizar último preço
                    # if update_last_price is True:
                    #     if my_currency == doc_currency:
                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price)})
                    #     else:
                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price*exchange_rate)})
                            
                    # # Actualizar PREÇO DE CUSTO ÚLTIMO
                    # if update_last_cost_price is True:
                    #     if my_currency == doc_currency:
                    #         medio_anterior = anterior
                    #         quantidade_anterior = qty_anterior
                    #         pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                    #         pm = (pm)
                    #         lst_pm_prod[str(prod_id)] = pm
                    #         lst_qty_prod[str(prod_id)] = qty_anterior+qty
                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                    #     else:
                    #         medio_anterior = anterior
                    #         quantidade_anterior = qty_anterior
                    #         pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
                    #         pm = (pm)
                    #         lst_pm_prod[str(prod_id)] = pm
                    #         lst_qty_prod[str(prod_id)] = qty_anterior+qty
                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                
                elif order.doc_type.type=='reset':
                    
                    if my_currency == doc_currency:
                        medio_anterior = anterior
                        quantidade_anterior = qty_anterior
                        pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                        pm = (pm)
                        lst_pm_prod[str(prod_id)] = pm
                        lst_qty_prod[str(prod_id)] = qty_anterior+qty
                        
                        self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm,'last_purchase':date,'last_cost_price':(price or 0)})
                    else:
                        medio_anterior = anterior
                        quantidade_anterior = qty_anterior
                        pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
                        pm = (pm)
                        lst_pm_prod[str(prod_id)] = pm
                        lst_qty_prod[str(prod_id)] = qty_anterior+qty
                        self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm,'last_purchase':date,'last_cost_price':(price*exchange_rate or 0)})

                #pm = (pm)
                
                # VERIFICAR REQUISITOS PARA TRANSFERENCIAS
                if order.doc_type.type=='trans' and (line.from_id is False or line.from_id is None):
                    self.pool.get('dotcom.stock.order').notificar_accao_invalida('''Por Favor, preencha o campo origem do producto: %s! ''' % str(line.prod_id.name or ''))
                from_id = line.from_id.id
                
                if order.doc_type.type=='trans':
                    # NO CASO DE TRANSFERENCIA
                    # CRIAR MOVIMENTO DE STOCK (SAIDA)
                    self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,prod_id,from_id,-1*qty,origin,date,price,pm,model,order.id,order.id,context, linha_id=line.id)
                    
                    # MOVER STOCK (SAIDA)
                    self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,from_id,-1*qty,context)
                    logger.info('\n++++++++++++++++Sent %i to %s++++++++++++++++\n' % (qty, location_id))
                    
                    # CRIAR MOVIMENTO DE STOCK (ENTRADA)
                    self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,prod_id,location_id,qty,origin,date,price,pm,model,order.id,order.id,context, linha_id=line.id)
                    
                    # MOVER STOCK (ENTRADA)
                    self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,location_id,qty,context)
                    
                    #   DEFINIR PRECO UNITARIOS DA LINHA PARA 'NULL'
                    self.pool.get('dotcom.stock.order.line').write(cr, uid, [line.id], {'un_price':None})
                    logger.info('\n++++++++++++++++Received %i from %s++++++++++++++++\n' % (qty, from_id))
                else:
                    
                    #   ENTRADA OU SAIDA DE STOCK
                    
                    # CRIAR MOVIMENTO DE ENTRADA/SAIDA DE STOCK
                    self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,prod_id,location_id,signal*qty,origin,date,price,price,model,order.id,order.id,context, linha_id=line.id)
                    
                    # MOVER STOCK (ENTRADA/SAIDA)
                    self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,location_id,signal*qty,context)
                    
                    #   CASO O DOCUMENTO SEJA DE ACTUALIZACAO, DEFINIR QUANTIDADES PARA A QUANTIDADE DA LINHA DA ORDEM DE STOCK
                    if order.doc_type.type=='reset':
                        self.pool.get('product.product').write(cr, uid, [prod_id], {'stock_qty':abs(qty)})
                        #   DEFINIR QUANTIDADES A 0 PARA OUTROS ARMAZENS/LOCATIONS
                        self.pool.get('dotcom.stock.order').reset_stock_locations(cr, uid, location_id, prod_id, context=context)
                
                # VERIFICA SE DEVE ACTUALIZAR A DATA DA ULTIMA COMPRA
                if update_date is True:
                    self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
                totalizador = totalizador + (qty * price)

                qty = signal*abs(qty)
                #   LISTA DE PRODUCTOS TRANSACIONADOS E SUAS QUANTIDADES
                res = self.pool.get('dotcom.stock.order').product_list(prod_id, qty, line_id= line and line.id, vals=res) or {}
                if prod_id not in product_lista:
                    product_lista.append(prod_id)
            val['total'] = totalizador
            self.pool.get('dotcom.stock.order').write(cr,uid,id_line,val)
            
            # CASO NAO SEJA UMA TRANSFERENCIA, LIMPA O CAMPO DE ORIGEM
            if order.doc_type.type != 'trans':
                lines = []
                for line in order.stock_lines:
                    lines.append(line.id)
                availables = self.pool.get('dotcom.stock.order.line').write(cr,uid,lines,{'from_id':None})
        
        #   EXECUTA REPROCESSAMENTO TOTAL DE STOCK (QUANTIDADES/LOCALIZACOES)
        self.run(cr, uid, product_lista, context=context)        
        self.repost_quantities(cr, uid, product_lista, context=context)
       
        return res
    
    def process_sale(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
            
        report_id = None
        res = {}
        classe_name = 'dotcom.venda'
        products = []
        move_stock = True
        for each in self.browse(cr, uid, ids):
            for venda in each.venda_ids:
                if not venda.report_id:
                    report_id = venda.report_id
                    report_code = self.pool.get('dotcom.stock.order')._get_report_code(cr, uid, classe_name, venda.id,context=context)
                    self.pool.get(classe_name).write(cr, uid, venda.id, {'report_id':report_code})
                    report_id = report_code
                else:
                    report_code = venda.report_id
                model_id = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, classe_name, context=context)
                reported = self.pool.get('dotcom.stock.report').search(cr, uid, [('model_id','=',model_id),('ordem','=',report_code),('state','=','draft')])
                self.pool.get('dotcom.stock.report').unlink(cr, uid, reported)
                for picking in venda.picking_list:
                    self.pool.get('dotcom.picking.list').unlink(cr,uid,[picking.id])
                if move_stock:
                    if venda.doc_type.movimenta_stock in ['out','in']:
                        lst_pm_prod = {}
                        lst_qty_prod = {}
                        signal = 1
                        if venda.doc_type.movimenta_stock=='in':
                            signal = 1
                        elif venda.doc_type.movimenta_stock=='out':
                            signal = -1
                        else:
                            signal = 0
                        
                        number = venda.document_number or self.pool.get(classe_name).generate_sequence(cr,uid,venda.id,context)
                        update_movement = False
                        if venda.doc_type.update_date is True:
                            update_movement = True
                        data = venda.document_date or time.strftime('%Y-%m-%d'),
                        
                        update_last_price = venda.doc_type.update_last_price or False
                        update_last_cost_price = venda.doc_type.update_last_med_price or False
                        
                        all_lines = []
                        
                        for line in venda.sales_lines:
                            if line.prod_id.type=='product' and line.opened:
                                rep = {}
                                prod_id = line.prod_id.id
                                stock_location = line.stock_location and line.stock_location.id
                                qty = signal* (abs(line.qty) or 0)
                                
                                self.pool.get('dotcom.stock.order').check_remaining_qty(cr, uid, prod_id, stock_location, qty, context=context)
                                
                                date = data
                                origin = venda.doc_type and venda.doc_type.ref + ' ' +number
                                price = (abs(line.line_total) or 0)
                                price_unit = abs(line.unit_price or 0)
                                logger.info('\n\nQTY IN USE:%s\n\n' % qty)
                                desconto = signal* abs(line.desconto_linha or 0)
                                desconto = desconto/qty
                                logger.info('\n\nDesconto AFT:%s\n\n' % desconto)
                                desconto_com = signal* abs(line.desconto_comercial or 0)
                                desconto_com = desconto_com / qty
                                logger.info('\n\nDesconto Comr:%s\n\n' % desconto_com)
                                anterior = 0
                                qty_anterior = 0
                                
                                if lst_pm_prod.has_key(str(prod_id)):
                                    anterior =  lst_pm_prod[str(prod_id)]
                                else:
                                    anterior = line.prod_id.last_average_cost or 0
                                
                                if lst_qty_prod.has_key(str(prod_id)):
                                    qty_anterior =  lst_qty_prod[str(prod_id)]
                                else:
                                    qty_anterior = line.prod_id.stock_qty or 0 or 0
                                pm = (anterior)
                                my_currency = venda.company_id.currency_id.id or None
                                doc_currency = venda.doc_currency.id or None
                                
                                ####################################################
                                #########ADDED FOR DOTCOM###########################
                                ####################################################
                                tax_id = line.tax_id.id or None
                                preco_sem_iva = price_unit
                                if line.iva_incluido:
                                    preco_sem_iva = self.pool.get('dotcom.venda')._get_preco_sem_iva(cr ,uid, tax_id, price_unit, context=context)
                                price_unit = preco_sem_iva - desconto_com - desconto
                                ####################################################
                                #########ADDED FOR DOTCOM###########################
                                ####################################################
                                
                                if venda.doc_type.movimenta_stock=='in':

                                    # Actualizar PCU
                                    logger.info('\n++++++++++=====++++++update_last_price  %s+++++++++====+++++++\n' % (update_last_price ))
                                    if update_last_price is True:
                                        if my_currency == doc_currency:
                                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
                                        else:
                                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
                                    # Actualizar PCM
                                    if update_last_cost_price is True:
                                        if my_currency == doc_currency:
                                            medio_anterior = anterior
                                            quantidade_anterior = qty_anterior
                                            pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
                                            pm = (pm)
                                            lst_pm_prod[str(prod_id)] = pm
                                            lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                                        else:
                                            medio_anterior = anterior
                                            quantidade_anterior = qty_anterior
                                            try:
                                                pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
                                            except ZeroDivisionError:
                                                pm = 0
                                            pm = (pm)
                                            lst_pm_prod[str(prod_id)] = pm
                                            lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                            self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                                    #=======================================================================================================================
                                    # if update_last_price is True:
                                    #     if my_currency == doc_currency:
                                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
                                    #     else:
                                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':price_unit})
                                    # if update_last_cost_price is True:
                                    #     if my_currency == doc_currency:
                                    #         medio_anterior = anterior
                                    #         quantidade_anterior = qty_anterior
                                    #         pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
                                    #         pm = (pm)
                                    #         lst_pm_prod[str(prod_id)] = pm
                                    #         lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                                    #     else:
                                    #         medio_anterior = anterior
                                    #         quantidade_anterior = qty_anterior
                                    #         pm = ((medio_anterior*quantidade_anterior) + price)/(qty+quantidade_anterior)
                                    #         pm = (pm)
                                    #         lst_pm_prod[str(prod_id)] = pm
                                    #         lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                    #         self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                                
                                created_line = self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,prod_id,stock_location,qty,origin,date,price_unit,pm,model,venda.id,None,context, linha_id=line.id)
                                
                                all_lines.append(created_line)
                                
                                self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
                                if update_movement is True:
                                    self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
                                
                                pick_list = {}
                                pick_list['location_id'] = stock_location
                                pick_list['prod_id'] = prod_id
                                pick_list['sale_id'] = venda.id
                                pick_list['qty'] = qty
                                pick_list['date'] = venda.document_date or time.strftime('%Y-%m-%d')
                                pick_id = self.pool.get('dotcom.picking.list').create(cr,uid,pick_list)
                                
                                res = self.pool.get('dotcom.stock.order').product_list(prod_id, qty, line_id= line and line.id,vals=res) or {}
                                if prod_id not in products:
                                    products.append(prod_id)
                            else:
                                continue
                    else:
                        continue
        self.repost_quantities(cr, uid, products, context=context)
        return {'return': True, 'type': 'ir.actions.act_window_close'}
    
    def process_purchase(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = {}
        classe_name = 'dotcom.compra'
        products = []
        move_stock = True
        for each in self.browse(cr, uid, ids):
            for compra in each.compra_ids:
                if not compra.report_id:
                    report_code = self.pool.get('dotcom.stock.order')._get_report_code(cr, uid, classe_name, compra.id,context=context)
                    self.pool.get(classe_name).write(cr, uid, compra.id, {'report_id':report_code})
                else:
                    report_code = compra.report_id
                reported = self.pool.get('dotcom.stock.report').search(cr, uid, [('ordem','=',report_code),('state','=','draft')])
                self.pool.get('dotcom.stock.report').unlink(cr, uid, reported)
                for picking in compra.picking_list:
                    self.pool.get('dotcom.picking.list').unlink(cr,uid,[picking.id])
                if move_stock:
                    if compra.doc_type.movimenta_stock in ['out','in']:
                        lst_pm_prod = {}
                        lst_qty_prod = {}
                        signal = 1
                        if compra.doc_type.movimenta_stock=='in':
                            signal = 1
                        elif compra.doc_type.movimenta_stock=='out':
                            signal = -1
                        else:
                            signal = 0
                        number = compra.document_number or self.pool.get(classe_name).generate_sequence(cr,uid,compra.id,context)
                        update_movement = False
                        if compra.doc_type.update_date is True:
                            update_movement = True
                        #self.write(cr,uid,compra.id,{'document_number':number})
                        update_last_price = compra.doc_type.update_last_price or False
                        update_movement = compra.doc_type.update_date or False
                        update_last_cost_price = compra.doc_type.update_last_med_price or False
                        model = self.pool.get('dotcom.stock.order').get_model_id(cr, uid, classe_name, context=context)
                        
                        my_currency = compra.company_id.currency_id.id or None
                        doc_currency = compra.doc_currency.id or None
                        for line in compra.purchases_lines:
                            type_prod = line.prod_id.type
                            prod_id = line.prod_id and line.prod_id.id
                            test_location = str(line.stock_location) or ''
                            
                            if line.prod_id.type=='product':
                                if test_location=='' or len(test_location)==0:
                                    raise osv.except_osv(_('Accao Invalida !'), _('Por favor, selecione uma localizacao para o producto'))
                                else:
                                    rep = {}
                                    prod_id = line.prod_id.id
                                    stock_location = line.stock_location.id
                                    qty = signal* (abs(line.qty) or 0)
                                    date = compra.document_date or time.strftime('%Y-%m-%d'),
                                    origin = compra.doc_type.ref + ' ' +number
                                    price = (abs(line.line_total) or 0)# - (abs(line.desconto_comercial) or 0) - (abs(line.desconto_linha) or 0)
                                    price_unit = abs(line.unit_price or 0)
                                    logger.info('\n\nQTY IN USE:%s\n\n' % qty)
                                    desconto = signal* abs(line.desconto_linha or 0)
                                    desconto = desconto/qty
                                    logger.info('\n\nDesconto AFT:%s\n\n' % desconto)
                                    desconto_com = signal* abs(line.desconto_comercial or 0)
                                    desconto_com = desconto_com / qty
                                    
                                    logger.info('\n\nDesconto Comr:%s\n\n' % desconto_com)
                                    ####################################################
                                    #########ADDED FOR DOTCOM###########################
                                    ####################################################
                                    tax_id = line.tax_id.id or None
                                    preco_sem_iva = price_unit
                                    if line.iva_incluido:
                                        preco_sem_iva = self.pool.get('dotcom.compra')._get_preco_sem_iva(cr ,uid, tax_id, price_unit, context=context)
                                    price_unit = preco_sem_iva - desconto_com - desconto
                                    ####################################################
                                    #########ADDED FOR DOTCOM###########################
                                    ####################################################
    
                                    anterior = 0
                                    qty_anterior = 0
                                    
                                    if lst_pm_prod.has_key(str(prod_id)):
                                        anterior =  lst_pm_prod[str(prod_id)]
                                    else:
                                        anterior = line.prod_id.last_average_cost or 0
                                    
                                    if lst_qty_prod.has_key(str(prod_id)):
                                        qty_anterior =  lst_qty_prod[str(prod_id)]
                                    else:
                                        qty_anterior = line.prod_id.stock_qty or 0 or 0
                                    
                                    pm = (anterior)
                                    
                                    if compra.doc_type.movimenta_stock=='in':
                                        if update_last_price is True:
                                            if my_currency == doc_currency:
                                                self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price_unit)})
                                            else:
                                                self.pool.get('product.product').write(cr,uid,[prod_id],{'last_cost_price':(price_unit)})
                                        if update_last_cost_price is True:
                                            if my_currency == doc_currency:
                                                medio_anterior = anterior
                                                quantidade_anterior = qty_anterior
                                                pm = ((medio_anterior*quantidade_anterior) + (price))/(qty+quantidade_anterior)
                                                pm = (pm)
                                                lst_pm_prod[str(prod_id)] = pm
                                                lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                                self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                                            else:
                                                medio_anterior = anterior
                                                quantidade_anterior = qty_anterior
                                                pm = ((medio_anterior*quantidade_anterior) + (price))/(qty+quantidade_anterior)
                                                pm = (pm)
                                                lst_pm_prod[str(prod_id)] = pm
                                                lst_qty_prod[str(prod_id)] = qty_anterior+qty
                                                self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
    
                                    logger.info('\n\n\nPreco medio: %s\n\n\n' % pm)
    
                                    self.pool.get('dotcom.stock.order').create_report(cr,uid,report_code,prod_id,stock_location,qty,origin,date,price_unit,pm,model,compra.id,None,context, linha_id=line.id)
                                    self.pool.get('dotcom.stock.order').move_stock(cr,uid,prod_id,stock_location,qty,context)
                    
                                    if update_movement is True:
                                        self.pool.get('product.product').write(cr,uid,[prod_id],{'last_purchase':date})
                                    
                                    pick_list = {}
                                    pick_list['location_id'] = stock_location
                                    pick_list['prod_id'] = prod_id
                                    pick_list['purchase_id'] = compra.id
                                    pick_list['qty'] = qty
                                    pick_list['date'] = compra.document_date or time.strftime('%Y-%m-%d')
                                    pick_id = self.pool.get('dotcom.picking.list').create(cr,uid,pick_list)
                                    
                                    res = self.pool.get('dotcom.stock.order').product_list(prod_id, qty, line_id= line and line.id,vals=res) or {}
                                    logger.info('\n\n\n\nRESULTADO: %s' % res)
                                    if prod_id not in products:
                                        products.append(prod_id)
        self.repost_quantities(cr, uid, products, context=context)
        return {'return': True, 'type': 'ir.actions.act_window_close'}
    
    def run(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        products = ids or []
        logger.info('\n\n\n\n products=======================: %s' % products)
        logger.info('\n\n\n\n products STOCK REENTREE RUN=======================')
        for product in products:
            logger.info('\n\n\n\n product=======================: %s' % product)
            produto_objecto=  self.pool.get('product.product').browse(cr,uid,product)
            actual_med = 0
            actual_qty = 0
            prod_last_price = 0

            # prod = self.pool.get('product.product').browse(cr, uid, product)

            #MInes============================================================
            anterior = 0
            qty_anterior = 0
            #=================================================================
            movimentos = []
            movimentos = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',product), ('state','!=','draft')], order='ordem asc')
            logger.info('\n\n\n\n movimentos=======================: %s' % movimentos)
            for movimento in movimentos:
                logger.info('\n\n\n\n movimento=======================: %s' % movimento)
                moved = self.pool.get('dotcom.stock.report').browse(cr,uid,movimento)
                logger.info('\n\n\n\n moved=======================: %s' % moved)
                model = moved.model_id.model
                #logger.info('\n\n\n\n model=======================: %s' % model)
                #logger.info('\n\n\n\n moved.origin_id=======================: %s' % moved.origin_id)
                doc_type = False
                try: #Fx
                    doc_obj = self.pool.get(model).browse(cr,uid,moved.origin_id) or False
                    #logger.info('\n>>>____________(doc_obj)____________<<<: %s\n' % str(doc_obj))
                    #logger.info('\n>>>____________(doc_obj.doc_type)____________<<<: %s\n' % str(doc_obj.doc_type))
                    doc_type = doc_obj.doc_type or False
                except Exception as e:
                    logger.info('\n>>>_____( stock_reentry.py Exception )_____<<<')
                    logger.info('\n>>>____________(ERRO)____________<<<: %s\n' % str(e))
                if doc_type:
                    # my_currency = doc_obj.company_id.currency_id.id
                    # doc_currency = doc_obj.currency_id.id
                    # exchange_rate = doc_obj.doc_rate or 1
                    updates = doc_type.update_last_med_price or False
                    #==========codigo para pegar ultimo preco==============================================================================================
                    sql ="select average_cost from dotcom_stock_report where prod_id = "+str(product)+" and ordem = (select max(ordem) from dotcom_stock_report where prod_id = "+str(product)+" and ordem < "+str(moved.ordem)+" );"
                    cr.execute(sql)
                    rows = cr.dictfetchall()
                    logger.info('\n ======================    preco anterior %s' % rows)
                    sql_query_result_price = rows and rows[0]['average_cost']
                    medio_anterior = sql_query_result_price or 0
                    #===========================================================================================================================================
                    if moved.operacao == 'out':
                        self.pool.get('product.product').write(cr,uid,[product],{'last_average_cost':medio_anterior})
                        self.pool.get('dotcom.stock.report').write(cr,uid,[movimento],{'average_cost':medio_anterior})


                    elif updates:
                        #===========================================================================================================================================
                        #if my_currency == doc_currency:
                        
                        

                        #==========codigo para pegar ultima quantidade==============================================================================================
                        #logger.info('\n ===================================================================SQL QUERY INICIO =============================================================')
                        sql ="select qty from dotcom_stock_report where prod_id = "+str(product)+" and ordem = (select max(ordem) from dotcom_stock_report where prod_id = "+str(product)+" and ordem < "+str(moved.ordem)+" );"
                        cr.execute(sql)
                        rows = cr.dictfetchall()
                        logger.info('\n ======================    quantidade anterior %s' % rows)
                        logger.info('\n++++++++++=====++++++ write 1 moved.qty   %s+++++++++====+++++++\n' % (moved.qty ))
                        sql_query_result_qty = rows and rows[0]['qty']
                        #logger.info('\n ===================================================================SQL QUERY FIM=============================================================')

                        quantidade_anterior = sql_query_result_qty or 0
                        
                        qty = moved.qty or 0
                        price = moved.price or 0
                        try:
                            pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                        except ZeroDivisionError:
                            pm = 0
                        pm = (pm)

                        logger.info('\n++++++++++=====++++++ write 1 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
                        logger.info('\n++++++++++=====++++++ write 1 medio_anterior  %s+++++++++====+++++++\n' % (medio_anterior ))
                        logger.info('\n++++++++++=====++++++ write 1 price  %s+++++++++====+++++++\n' % (price ))
                        actual_med=pm
                        self.pool.get('product.product').write(cr,uid,[product],{'last_average_cost':pm})
                        #logger.info('\n++++++++++=====++++++ write 1 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))
                        vals = {}
                        vals['average_cost'] = pm
                        #logger.info('\n++++++++++=====++++++ write 1 movimento  %s+++++++++====+++++++\n' % (movimento ))
                        #logger.info('\n++++++++++=====++++++ write 1 vals  %s+++++++++====+++++++\n' % (vals ))
                        self.pool.get('dotcom.stock.report').write(cr,uid,[movimento],vals)
                        # else:
                        #     medio_anterior = anterior
                        #     quantidade_anterior = qty_anterior
                        #     try:
                        #         pm = ((medio_anterior*quantidade_anterior) + (qty*price*exchange_rate))/(qty+quantidade_anterior)
                        #     except ZeroDivisionError:
                        #         pm = 0
                        #     pm = (pm)
                        #     lst_pm_prod[str(prod_id)] = pm
                        #     lst_qty_prod[str(prod_id)] = qty_anterior+qty
                        #     logger.info('\n++++++++++=====++++++ write 2 last_average_cost  %s+++++++++====+++++++\n' % (pm ))
                        #     logger.info('\n++++++++++=====++++++ write 2 last_average_cost prod_id  %s+++++++++====+++++++\n' % (pm ))
                        #     self.pool.get('product.product').write(cr,uid,[prod_id],{'last_average_cost':pm})
                        #     logger.info('\n++++++++++=====++++++ write 2 last_average_cost browse  %s+++++++++====+++++++\n' % (self.pool.get('product.product').browse(cr,uid,prod_id).last_average_cost))
                        #     vals = {}
                        #     vals['average_cost'] = pm
                        #     self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)
                    else:
                        vals = {}
                        vals['average_cost'] = actual_med
                        quantidade_anterior = actual_qty
                        qty = moved.qty or 0
                        actual_qty = quantidade_anterior + qty
                        self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)

                    #===========================================================================================================================================
                    # updates = doc_type.update_last_med_price or False
                    # if updates:
                    #     medio_anterior = actual_med
                    #     quantidade_anterior = actual_qty
                    #     qty = moved.qty or 0
                    #     price = moved.price or 0
                    #     try:
                    #         pm = ((medio_anterior*quantidade_anterior) + (qty*price))/(qty+quantidade_anterior)
                    #     except ZeroDivisionError:
                    #         pm = 0
                    #     actual_med = pm
                    #     actual_qty = quantidade_anterior + qty
                    #     vals = {}
                    #     vals['average_cost'] = pm
                    #     self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)
                    # else:
                    #     vals = {}
                    #     vals['average_cost'] = actual_med
                    #     quantidade_anterior = actual_qty
                    #     qty = moved.qty or 0
                    #     actual_qty = quantidade_anterior + qty
                    #     self.pool.get('dotcom.stock.report').write(cr,uid,movimento,vals)



                    last_price = doc_type.update_last_price or False
                    if last_price:
                        prod_last_price = moved.price or 0
                    
                    if model == 'dotcom.stock.order':
                        if doc_type.type == 'reset':
                            prod_last_price = moved.price or 0
                            actual_med = moved.price or 0
                            actual_qty = moved.qty or 0
                            self.pool.get('dotcom.stock.report').write(cr, uid, movimento, {'average_cost':actual_med})
            self.pool.get('product.product').write(cr,uid,[product],{'stock_qty':actual_qty,'last_average_cost':actual_med,'last_cost_price':prod_last_price})
        return {'view_mode' : 'tree,form','type': 'ir.actions.act_window_close'}
    
    def calculate(self, cr, uid,ids, context={}):
        data = self.pool.get('dotcom.stock.entry.wizard').read(cr,uid,ids,['product_ids'])
        res = False
        if data:
            res = self.run(cr, uid, data[0]['product_ids'] or [], context=context)
            self.verificar_drafts(cr, uid, data[0]['product_ids'] or [], context=context)
            self.repost_quantities(cr, uid, data[0]['product_ids'], context=context)
        for di in ids:
            message = _("Stock Reprocess completed")
            self.log(cr, uid, di, message)
        return res
    
    def run_products(self, cr, uid,ids, context={}):
        res = self.run(cr, uid, ids or [], context=context)
        self.verificar_drafts(cr, uid, ids or [], context=context)
        self.repost_quantities(cr, uid, ids or [], context=context)
        for di in ids:
            message = _("Products Updated")
            self.log(cr, uid, di, message)
        return res
    
    def verificar_drafts(self, cr, uid, ids, context={}):
        for product in ids:
            produto = self.pool.get('product.product').browse(cr, uid, product)
            for movimento in produto.stock_report_ids:
                classe = movimento.model_id and movimento.model_id.model
                class_obj = self.pool.get(classe).browse(cr, uid, movimento.origin_id)
                state = class_obj and class_obj.state or ''
                if state in ['draft','reset']:
                    self.pool.get('dotcom.stock.report').write(cr, uid, [movimento and movimento.id], {'state':'draft'})
                elif state == 'cancel':
                    self.pool.get('dotcom.stock.report').unlink(cr, uid, [movimento and movimento.id])
                else:
                    self.pool.get('dotcom.stock.report').write(cr, uid, [movimento and movimento.id], {'state':'done'})
        return False
    
    def repost_quantities(self, cr, uid, ids, context={}):
        if context is None:
            context = {}
        if ids:
            availability = self.pool.get('dotcom.stock.available')
            for produto in self.pool.get('product.product').browse(cr, uid, ids):
                lista = {}
                qty_available = 0
                total = 0
                reports_ids = self.pool.get('dotcom.stock.report').search(cr, uid, [('prod_id','=',produto and produto.id), ('state','!=','draft')], order='ordem asc')
                #reports_ids = sorted(reports_ids)
                for movimento in self.pool.get('dotcom.stock.report').browse(cr, uid, reports_ids):
                    origin_classe = movimento and movimento.model_id and movimento.model_id.model
                    origin_id = movimento and movimento.origin_id or None
                    qty_available = 0
                    is_not_act = True
                    if origin_classe == 'dotcom.stock.order':
                        this = self.pool.get(origin_classe).browse(cr, uid, origin_id)
                        this_doc_type = this and this.doc_type
                        if this_doc_type and this_doc_type.type == 'reset':
                            is_not_act = False
                    location = movimento.location_id and movimento.location_id.id
                    
                    if is_not_act:
                        if lista.has_key(location):
                            qty_available = lista.get(location) + movimento.qty or 0
                        else:
                            qty_available = movimento.qty or 0
                    else:
                        qty_available = movimento.qty or 0
                        prod_id = movimento.prod_id.id
                        self.pool.get('dotcom.stock.order').reset_stock_locations(cr, uid, location, prod_id, context=context)
                        lista = {}
                    lista[location] = qty_available
                result = availability.search(cr, uid, [('prod_id','=',produto.id)])
                availability.unlink(cr, uid, result)
                for locale in lista:
                    new = {}
                    new['prod_id'] = produto and produto.id
                    new['location_id'] = locale
                    new['qty_available'] = lista.get(locale)
                    total = total + lista.get(locale)
                    logger.info('\n++++++++++=====++++++  repost_quantities dict new   %s+++++++++====+++++++\n' % (new ))
                    availability.create(cr, uid, new, context=context)
                self.pool.get('product.product').write(cr, uid, [produto and produto.id],{'stock_qty':total})
        return False
dotcom_stock_entry()