# -*- encoding: utf-8 -*-
from osv import fields,osv
import time
from datetime import datetime
from dateutil.relativedelta import *
from tools.translate import _
import logging
logger = logging.getLogger('jasper_print')

class jasper_stock_entrada_saida_wizard(osv.osv_memory):
    _name='jasper.stock.entrada.saida.wizard'

    _columns ={
        'warehouse_ids': fields.many2many('dotcom.stock.location','stock_location_report_ee','wizard_id','location_id','Locations'),
        'document_ids': fields.many2many('documento.tipo','stock_document_report_ee','wizard_id','location_id','Documentos', domain=[('movimenta_stock','!=','do_not')]),
        'stock_document_ids': fields.many2many('dotcom.stock.document','stock_document_stock_report_ee','wizard_id','stock_document_id','Documentos'),
        'category_id': fields.many2one('product.category','Categoria de Producto'),
        'kind': fields.selection([
                                    ("in","Stock Entrance"),
                                    ("out","Stock Exit"),
                                    ("both","Both")
                                ],'Type'),
        'group': fields.selection([
                                    ("product","Product"),
                                    ("warehouse","Stock Location"),
                                ],'Group By'),
        'price': fields.selection([
                                    ("unit","Unit Price"),
                                    ("pcm","Average Cost Price"),
                                ],'Price'),
        'date_from': fields.date('From'),
        'date_to': fields.date('To'),
        'product_ids': fields.many2many('product.product','product_stock_print_ee','wizard_id','product_id','Products', domain=[('type','=','product')]),
        }
    _defaults ={
        'date_from': lambda *a: datetime.now().strftime('%Y-01-01'),
        'date_to': lambda *a: datetime.now().strftime('%Y-%m-%d'),
        'kind': lambda *a: 'in',
        'group': lambda *a: 'product',
        'price': lambda *a: 'unit',
    }
    
    def start_report(self, cr, uid,ids, context={}):
        data = self.read(cr,uid,ids,)[-1]
        return {
            'type': 'ir.actions.report.xml',
            'report_name': 'dotcom_stock_entrada_saida',
            'datas':{
                    'model':'dotcom.stock.report',
                    'id':context.get('active_ids') and context.get('active_ids')[0] or False,
                    'ids':context.get('active_ids') and context.get('active_ids') or [],
                    'report_type':'pdf',
                    'form':data
            },
            'nodestroy':False,
        }
 
jasper_stock_entrada_saida_wizard()