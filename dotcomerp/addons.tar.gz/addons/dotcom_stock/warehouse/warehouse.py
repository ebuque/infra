# -*- coding: utf-8 -*-
import time
from lxml import etree
import netsvc
from osv import osv, fields
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_stock_location')

class dotcom_stock_location(osv.osv):
    #
    #def get_name(self, cr, uid, ids, context=None):
    #    if not len(ids):
    #        return []
    #    reads = self.read(cr, uid, ids, ['name','ref'], context=context)
    #    res = []
    #    for record in reads:
    #        name = record['ref']
    #        if record['name']:
    #            name = name +' / '+ record['name']
    #        res.append((record['id'], name))
    #    return res
    #
    #def _name_get_fnc(self, cr, uid, ids, prop, unknow_none, context=None):
    #    res = self.get_name(cr, uid, ids, context=context)
    #    return dict(res)
    
    def name_get(self, cr, uid, ids, context=None):
        if not len(ids):
            return []
        res = []
        logger.info('\nids name_get: %s' % ids)
        for obj in self.browse(cr, uid, ids, context=context):
            p_name = '[' + obj.ref + '] ' or ''
            p_name += obj.name
            res.append((obj.id,p_name))
        return res


    _name = "dotcom.stock.location"
    _description = "Warehouse and Stock Locations"
    _columns = {
        'ref': fields.char('Ref', size=64, required=True, translate=False, select=True),
        'name': fields.char('Name', size=64, required=True, translate=True, select=True),
        #'complete_name': fields.function(_name_get_fnc, type="char", string='Name'),
        'parent_id': fields.many2one('dotcom.stock.location','Parent Category', select=True, ondelete='cascade'),
        'child_id': fields.one2many('dotcom.stock.location', 'parent_id', string='Child Categories'),
        'sequence': fields.integer('Sequence', select=True, help="Gives the sequence order when displaying a list of product categories."),
        'parent_left': fields.integer('Left Parent', select=1),
        'parent_right': fields.integer('Right Parent', select=1),
        'active': fields.boolean('Active'),
    }
    
    _defaults = {'active': True}
    
    #_rec_name = 'ref'
    
    def name_search(self, cr, uid, name, args=None, operator='ilike', context=None, limit=100):
        if not args:
            args = []
        ids = self.search(cr, uid, [('ref', 'ilike', name)] + args, limit=limit, context=context)
        logger.info('\nids name_search: %s' % ids)
        if ids:
            return self.name_get(cr, uid, ids, context)
        else:
            ids = self.search(cr, uid, [('name', 'ilike', name)] + args, limit=limit, context=context)
            if ids:
                return self.name_get(cr, uid, ids, context)
        return super(dotcom_stock_location,self).name_search(cr, uid, name, args, operator=operator, context=context, limit=limit)

    _parent_name = "parent_id"
    _parent_store = True
    _parent_order = 'sequence, name'
    _order = 'parent_left'
    
    _sql_constraints = [('warehouse_unique', 'unique(ref)', 'This ref must be unique on the system.'),]
    
    def _check_recursion(self, cr, uid, ids, context=None):
        level = 100
        while len(ids):
            cr.execute('select distinct parent_id from dotcom_stock_location where id IN %s',(tuple(ids),))
            ids = filter(None, map(lambda x:x[0], cr.fetchall()))
            if not level:
                return False
            level -= 1
        return True

    _constraints = [
        (_check_recursion, 'Error ! You cannot create recursive categories.', ['parent_id'])
    ]
    def child_get(self, cr, uid, ids):
        return [ids]

    def copy(self, cr, uid, id, default=None, context=None):
        if default is None:
            default = {}
        ref = self.read(cr, uid, [id], ['ref'], context)[0]['ref']
        name = self.read(cr, uid, [id], ['name'], context)[0]['name']
        default.update({'ref':ref+_('(Copy)'),'name':name+_('(Copy)')})
        return super(dotcom_stock_location, self).copy(cr, uid, id, default, context)
        
dotcom_stock_location()