# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2014 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


{
    'name': 'Changelog',
    'version': '1',
    'description': """Gestão de Versões - DotComERP""",
    'author': 'DotCom, LDA',
    'category': 'Hidden',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcom.co.mz',
    'depends': ['base'],
    'init_xml': [],
    'update_xml':['view/changelog_view.xml','security/ir.model.access.csv',
                  'data/1_3.xml', 'data/1_3_1.xml', 'data/1_3_2.xml', 'data/1_3_3.xml', 'data/1_3_4.xml', 'data/1_3_5.xml', 'data/1_3_6.xml'],
    'demo_xml': [],
    'test': [],
    'installable': True,
    'complexity': 'easy',
    'auto_install': True,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: