# -*- coding: utf-8 -*-

#  DotERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#  


import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('dotcom_notification')
import re

import sys  
reload(sys)  
sys.setdefaultencoding('utf8')

class dotcom_notification_mailinglist(osv.osv):
    _name='dotcom.notification.maillist'
    _description = 'Notification Setup Mailing List'
    _columns = {
                'name': fields.char('Nome', size=90),
                'mail': fields.char('eMail', size=60),
                'active': fields.boolean('Activo'),
    }
    _sql_constraints = [('mail_unique','unique(mail)','O email já se encontra registado no sistema!')]
    
    def _check_mail(self, cr, uid, ids):
        for mail in self.browse(cr, uid, ids):
            if re.match("^[a-zA-Z0-9._%-]+@[a-zA-Z0-9._%-]+.[a-zA-Z]{2,6}$", mail.mail or ''):
                return True
            else:
                return False

    _constraints = [(_check_mail,'O endereço de email é inválido!', ['mail'])]
    _defaults = {'active': True}
    
    def name_search(self,cr,uid,name='',args=[],operator='ilike',context={},limit=80):
        ids = []
        if name and len(name) == 2:
            ids = self.search(cr, uid,[('mail', '=', name)] + args,limit=limit, context=context)
        if not ids:
            ids = self.search(cr, uid,[('name', operator, name)] + args,limit=limit, context=context)
        return self.name_get(cr,uid,ids)

dotcom_notification_mailinglist()

class dotcom_notification(osv.osv):
    
    def unlink(self, cr ,uid, ids, context=None):
        if context is None:
            context = {}
        for one in self.browse(cr, uid, ids):
            if one.cron_id:
                self.pool.get('ir.cron').unlink(cr, uid, [one.cron_id.id], context=context)
        return super(dotcom_notification, self).unlink(cr, uid, ids, context=context)
    
    _name='dotcom.notification'
    _description = 'Notification Setup'
    _columns = {
                'ref': fields.char('Ref', size=30, required=True),
                'name': fields.char('Nome', size=300, required=True),
                'cron_id': fields.many2one('ir.cron','Cronology Job', on_delete='cascade'),
                'action_type_mail':fields.boolean('E-mail'),
                'action_type_pop':fields.boolean('Pop-Up'),
                'mail_list_ids': fields.many2many('dotcom.notification.maillist','notification_mail_rel','notification_id','mail_id','Emails'),
                'users_mail_list': fields.many2many('res.users','notification_user_mail_rel','notification_id','user_id','Emails Internos'),
                'running': fields.boolean('Activo'),
                'mail_text': fields.text('Email'),
                
                'partner_message_subject' : fields.char('Assunto', size= 90),
                'partner_message_header' : fields.text('Cabeçalho da mensagem'),
                'partner_message_body' : fields.text('Corpo da Mensagem'),
                'partner_message_foot' : fields.text('Rodapé da Mensagem'),
                
                'user_message_subject' : fields.char('Assunto', size= 90),
                'user_message_header' : fields.text('Cabeçalho da mensagem'),
                'user_message_group' : fields.text('Agrupador dos detalhes'),
                'user_message_body' : fields.text('Corpo da Mensagem'),
                'user_message_foot' : fields.text('Rodapé da Mensagem'),
                
                'request_message_subject' : fields.char('Assunto', size= 90),
                'request_message_body' : fields.text('Corpo da Mensagem'),
                
                'run_auto': fields.boolean('Calendarizar'),
                
                'nextcall': fields.datetime('Próxima Execução'),
                'interval_number': fields.integer('Intervalo'),
                'interval_type': fields.selection([('minutes','Minutos'),
                                                    ('hours','Horas'),
                                                    ('work_days','Dias de Trabalho'),
                                                    ('days','Dias'),
                                                    ('weeks','Semanas'),
                                                    ('months','Meses')],'Unidade')
    }
    
    _sql_constraints = [('uniq_ref', 'unique(ref)', 'A referencia deve ser única no sistema!')]
    
    _defaults = {'running':True,
                 'run_auto':True,
                 'nextcall': lambda *a: time.strftime('%Y-%m-%d %H:%M:%S'),
                 'interval_number': 1,
                 'interval_type': 'days',
                 'action_type_mail':False,
                 'action_type_pop':False,
                 'partner_message_header':u'''
__nomeempresa__                 

Estimado(s) __nomecliente__ notifica-se que ************************* com o saldo total de <b> __totalsaldocliente__ __moeda__ </b> a expirar em __datatermino__.
<br>
<table width="769" height="290" border="1">
  <tr>
    <td height="37" align="center"><strong>Tipo de Documento</strong></td>
    <td align="center"><strong>Número</strong></td> 
    <td align="center"><strong>Data Emissão</strong></td>
    <td align="center"><strong>Data Vencimento</strong></td>
    <td align="center"><strong>Total Documento</strong></td>
    <td align="center"><strong>Saldo</strong></td>
  </tr>
        ''',
                'partner_message_body': u'''
  <tr>
    <td align="left">__tipodocumento__</td>
    <td align="center">__numerodocumento__</td>
    <td align="center">__datadocumento__</td>
    <td align="center">__datatermino__</td>
    <td align="right">__totaldocumento__</td>
    <td align="right">__saldodocumento__</td>
  </tr>
        ''',
                'partner_message_foot': u'''
</table>
<br>
<br>
DotComERP<br>
__data__
                ''',
                'user_message_header':u'''
__nomeempresa__

Notifica-se que os seguintes clientes possuem documentos a expirar em __datatermino__, com um saldo total de <b> __totalsaldocliente__ __moeda__ </b>.
<br>
<table width="769" height="290" border="1">
  <tr>
    <td height="37" align="center"><strong>Tipo de Documento</strong></td>
    <td align="center"><strong>Número</strong></td> 
    <td align="center"><strong>Data Emissão</strong></td>
    <td align="center"><strong>Data Vencimento</strong></td>
    <td align="center"><strong>Total Documento</strong></td>
    <td align="center"><strong>Saldo</strong></td>
  </tr>
        ''',
                'user_message_group': u'''
  <tr>
    <td colspan="6" align="left"><strong>__nomecliente__</strong></td>
  </tr>

                 ''',
                'user_message_body': u'''
  <tr>
    <td align="left">__tipodocumento__</td>
    <td align="center">__numerodocumento__</td>
    <td align="center">__datadocumento__</td>
    <td align="center">__datatermino__</td>
    <td align="right">__totaldocumento__</td>
    <td align="right">__saldodocumento__</td>
  </tr>
        ''',
                'user_message_foot': u'''
</table>
<br>
<br>
DotComERP<br>
__data__
                ''',
                'request_message_body': u'''
O Cliente __nomecliente__ possui a __tipodocumento__ numero __numerodocumento__, com o saldo de __totalsaldocliente__ __moeda__ \nem aberto tendo como data limite __datatermino__.
                '''
                }
    
    def _check_user_popup(self, cr, uid, ids):
        for notification in self.browse(cr, uid, ids):
            if notification.action_type_pop and (notification.users_mail_list is None or notification.users_mail_list is False):
                return False
            else:
                return True
    
    def parse_message(self, cr, uid, message, values={}):
        res = message
        for each in values:
            campo = values.get(each)
            try:
                if type(campo) is list:
                    campo = str(values.get(each))
                if type(campo) not in [str, unicode]:
                    campo = str(values.get(each))
            except Exception:
                pass
            res = res.replace(each, str(campo))
        return res
    
    def cron_run(self, cr, uid, my_id=(), context=None):
        if context is None:
            context = {}
        ids = []
        
        # logger.info('\nIDS %s / Type %s' % (my_id, type(my_id)))
        
        if type(my_id) in [int, long]:
            ids.append(my_id)
        elif type(my_id) == tuple:
            for one in my_id:
                ids.append(one)
        else:
            ids = my_id
        return self.run(cr, uid, ids, context=context)
    
    def create(self, cr, uid, vals, context=None):
        if context is None:
            context = {}
        vals['cron_id'] = None
        me = super(dotcom_notification, self).create(cr, uid, vals, context=context)
        if vals.get('run_auto') == True:
            cron_act = self.update_cron(cr, uid, [me], context=context)
            self.write(cr, uid, me, {'cron_id':cron_act})
        return me
    
    def create_cron(self, cr, uid, id, context=None):
        if context is None:
            context = {}
        res = None
        if id:
            me = self.browse(cr, uid, id)
            
            cron = {}
            cron['name'] = me.name or ''
            cron['active'] = True
            cron['user_id'] = uid or None
            cron['interval_number'] = me.interval_number or 1
            cron['interval_type'] = me.interval_type or 'days'
            cron['numbercall'] = 5
            cron['doall'] = True
            cron['model'] = 'dotcom.notification'
            cron['function'] = 'cron_run'
            cron['args'] = '(my_id=[%i])' % int(id)
            cron['nextcall'] = me.nextcall or time.strftime('%Y-%m-%d %H:%M:%S')
            
            cron_action = self.pool.get('ir.cron').create(cr, uid, cron)
            res = cron_action
        return res
    
    def update_cron(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        for id in ids:
            res = None
            if id:
                me = self.browse(cr, uid, id)
                
                if me.run_auto == True:
                    now = datetime.now()
                    given_date = datetime(*(time.strptime(me.nextcall, '%Y-%m-%d %H:%M:%S'))[0:6])
                    if given_date<now:
                        raise osv.except_osv(_('Invalid action !'), _('Por favor defina uma data válida para a próxima execução!'))
                cron = {}
                cron['name'] = 'Notificacao: %s' % me.ref or ''
                cron['active'] = me.run_auto or False
                cron['user_id'] = uid or None
                cron['interval_number'] = me.interval_number or 1
                cron['interval_type'] = me.interval_type or 'days'
                cron['numbercall'] = -1
                cron['doall'] = True
                cron['model'] = 'dotcom.notification'
                cron['function'] = 'cron_run'
                cron['args'] = '([%s])' % id
                cron['nextcall'] =  me.nextcall or time.strftime('%Y-%m-%d %H:%M:%S')
                
                if me.cron_id:
                    self.pool.get('ir.cron').write(cr, uid, [me.cron_id.id], cron)
                    res = me.cron_id.id
                else:
                    cron_action = self.pool.get('ir.cron').create(cr, uid, cron)
                    res = cron_action   
        return res
    

    def write(self, cr, uid, ids, vals, context=None):
        if context is None:
            context = {}
        this = super(dotcom_notification, self).write(cr, uid, ids, vals,context=context)
        if vals.has_key('nextcall') or vals.has_key('interval_number') or vals.has_key('interval_type') or vals.has_key('run_auto'):
            self.update_cron(cr, uid, ids, context=context)
        return this
            #if vals.has_key('run_auto'):
            #    should_i = vals.has_key('run_auto')
            #    for id in ids:
            #        cron_id = self.browse(cr, uid, id).cron_id
            #        if cron_id:
            #            self.pool.get('ir.cron').write(cr, uid, cron_id and cron_id.id, {'active':should_i})
            #        else:
            #            self.create_cron(cr, uid, id, context=context)

    def _check_mail(self, cr, uid, mail):
        #for mail in self.browse(cr, uid, ids):
        if mail:
            if re.match("^[a-zA-Z0-9._%-]+@[a-zA-Z0-9._%-]+.[a-zA-Z]{2,6}$", mail or ''):
                return True
            else:
                return False
        else:
            return False

    def send_mail(self, cr, uid, server = None,message_to = [], mail_message='', subject='',report=[], attachs = [],images=[], context=None):
        if context is None:
            context = {}
        if not server:
            servers = self.pool.get('email.smtpclient').search(cr, uid, [('state','=','confirm')],order='priority')
            server = servers and servers[0]
        if server:
            if message_to:
                receivers = []
                for each in message_to:
                    if each and self._check_mail(cr, uid, each):
                        receivers.append(each)
                if receivers:
                    self.pool.get('email.smtpclient').send_email(cr, uid, server, receivers, subject, body=mail_message, attachments=attachs, reports=report,images=images)
            return True
        else:
            return False
            
    def send_request(self, cr, uid, to = [], message='', subject = '', context = None):
        if context is None:
            context = {}
        request = {}
        request['name'] = subject
        request['act_from'] = uid
        request['state'] = 'waiting'
        request['priority'] = '1'
        request['date_sent'] = time.strftime('%Y-%m-%d %H:%M:%S')
        request['active'] = True
        request['body'] = message
        for user in to:
            request['act_to'] = user
            self.pool.get('res.request').create(cr, uid, request)
        return True

    def run(self, cr, uid,ids, message_to = [], mail_message='', popup_to = [],popup_message='', subject='', report=[], attachs = [],images=[], context=None):
        if context is None:
            context = {}
        #if type(ids) == tuple:
        #    ids = [ids[0]]
        #
        #if type(ids) != list:
        #    a = []
        #    a.append(ids)
        #    ids = a
        #
        #logger.info('\nIDS %s / Type %s' % (ids, type(ids)))
        
        for each in self.browse(cr, uid, ids):
            # receive = []
            if each.action_type_pop and bool(popup_message):
                request = {}
                request['name'] = subject
                request['act_from'] = uid
                request['state'] = 'waiting'
                request['priority'] = '1'
                request['date_sent'] = time.strftime('%Y-%m-%d %H:%M:%S')
                request['active'] = True
                request['body'] = popup_message
                for user in popup_to:
                    user_id = None
                    if type(user) == int:
                        user_id = user
                    else:
                        user_id = user and user.id
                    request['act_to'] = user_id
                    self.pool.get('res.request').create(cr, uid, request)
            if each.action_type_mail and bool(mail_message) and bool(message_to) == True:
                servers = self.pool.get('email.smtpclient').search(cr, uid, [('state','=','confirm')],order='priority')
                server = servers and servers[0]
                if server:
                    #logger.info('\nAttachments >>> %s\nReports >>> %s' % (attachs,report))
                    if message_to:
                        receivers = []
                        for each in message_to:
                            if each and self._check_mail(cr, uid, each):
                                receivers.append(each)
                        if receivers:
                            self.pool.get('email.smtpclient').send_email(cr, uid, server, receivers, subject, body=mail_message, attachments=attachs, reports=report,images=images)
                else:
                    raise osv.except_osv(_('Invalid action !'), _(u'Não existe nenhum servidor de email activo'))
        return True

dotcom_notification()
