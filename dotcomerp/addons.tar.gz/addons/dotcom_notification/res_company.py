# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import time
from lxml import etree
import netsvc
from osv import osv, fields
import decimal_precision as dp
from tools.translate import _
import datetime
from dateutil.relativedelta import *
import logging

class res_company(osv.osv):
    
    _name = 'res.company'
    _inherit = 'res.company'
    _columns = {
                'notification_banner': fields.binary('Banner de notificações')
                }
    
res_company()

class res_partner_address(osv.osv):
    
    _name = 'res.partner.address'
    _inherit = 'res.partner.address'
    _columns = {
                'must_notify': fields.boolean('Sujeito a notificações')
                }
    
res_partner_address()