# -*- coding: utf-8 -*-
##############################################################################
#
#    DotComERP, 
#    Copyright (C) 2004-2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


{
    'name': 'Sistema de Notificações',
    'version': '1.2',
    'category': 'Tools',
    'complexity': "easy",
    'sequence': 6,
    'summary': 'User defined notification system',
    'description': """
Quick and Easy Notification System Configuration
============================

This module allows you to manage the notification system on any record in the system as soon as they are altered
or as the administrator defines. 

    """,
    'author': 'DotCom, LDA',
    'images': [],
    'depends': ['base','smtpclient','dotcom_base'],
    'update_xml':['view/res_company_notification.xml',
                  'view/notification_view.xml',
                  'security/dotcom_notification_security.xml',
                  'security/ir.model.access.csv'],
    'installable': True,
    'application': False,
    'auto_install': True,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: