#  -*- coding: utf-8 -*-
#  DotComERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('STOCK_SERIES')

STATES = [('active', 'Activo'),('inactive', 'Inactivo'),('draft', 'Rascunho'), ('posted', 'Emitido'), ('reset', 'Rascunho')]

class dotcom_stock_series(osv.osv):
    
    def return_number(self, cr, uid, line_id, base, count, field='stock_line_id', context=None):
        if context is None:
            context = {}
        name = '%s%s' % (base, count)
        query = []
        query.append(('name','=',name))
        query.append((field,'=',line_id))
        src = self.pool.get('dotcom.stock.order.line.series').search(cr, uid, [query])
        if src:
            return self.return_number(cr,uid,line_id,base, count+1, context=context)
        else:
            return name
    
    _name = 'dotcom.stock.series'
    _columns = {
                'name': fields.char('Numero de Serie', size=60),
                'product_id': fields.many2one('product.product', 'Produto', required=True, domain=[('type','=','product')]),
                'state': fields.selection(STATES, 'Estado', readonly=True),
                
                'stock_line_id': fields.many2one('dotcom.stock.order.line', 'Linha Stock', invisible="1", ondelete="CASCADE"),
                'sale_line_id': fields.many2one('dotcom.venda.linha', 'Linha VENDA', invisible="1", ondelete="CASCADE"),
                'purchase_line_id': fields.many2one('dotcom.compra.linha', 'Linha COMPRA', invisible="1", ondelete="CASCADE"),

                'created_ref': fields.char('Criado Por', size=30, invisible=False, readonly=True),
                'created_obj': fields.char('Object Name', size=60, invisible=True, readonly=True),
                'created_id': fields.integer('Object ID', invisible=True, readonly=True),
                
                'used_ref': fields.char('Utilizado Por', size=30, invisible=False, readonly=True),
                'used_obj': fields.char('Object Name', size=60, invisible=True, readonly=True),
                'used_id': fields.integer('Object ID', invisible=True, readonly=True),
                
                'required': fields.boolean('Required')

    }
    _defaults = {'state': 'active', 'required': True, 'product_id': lambda s, cr, u, c: c.get('prod_id', False),}
    _rec_name = 'name'
    
    def close(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = context.get('to_return', {})
        return res
    
dotcom_stock_series()

class product_product(osv.osv):
    _name = 'product.product'
    _inherit = 'product.product'
    _columns = {
                'allow_series': fields.boolean('Verifica Séries'),
                'series_ids': fields.one2many('dotcom.stock.series', 'product_id', 'Series', readonly=True)
    }
    
    def copy(self, cr, uid, ids, default=None, context = {}):
        if default is None:
            default = {}
        
        default.update({'series_ids': False})
        return super(product_product, self).copy(cr, uid, ids, default, context)
    
product_product()