#  -*- coding: utf-8 -*-
#  DotComERP - DotCom, LDA
#  Maputo, Mozambique (2012)
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#  
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the  nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#  
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import time
from datetime import datetime,timedelta
from lxml import etree
import netsvc
from osv import osv, fields, orm
import decimal_precision as dp
from tools.translate import _
import logging
logger = logging.getLogger('STOCK_SERIES')

class dotcom_compra(osv.osv):
    _name = 'dotcom.compra'
    _inherit = 'dotcom.compra'
    
    def update_series(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        for read in self.read(cr, uid, ids, ['purchases_lines']):
            purchases_lines = read.get('purchases_lines', [])
            self.pool.get('dotcom.compra.linha').update_series(cr, uid, purchases_lines, context=context)
        return {}
    
    def verificar_existe(self, cr, uid, prod_id, serial, id=False, check_state=False):
        query = [('product_id','=',prod_id),('name','=', serial)]
        if check_state:
            query.append(('state','not in',['reset', 'draft']))
        if id:
            query.append(('id','!=', id))
        result = self.pool.get('dotcom.stock.series').search(cr, uid, query, count=True)
        return result
    
    def processar_documento(self, cr, uid, ids, context=None, args={}):
        if context is None:
            context = {}
        for read in self.browse(cr, uid, ids):
            order_type = read.doc_type and read.doc_type.movimenta_stock or False
            code = read.document_number or ''
            cur_state = read.state or 'draft'
            if order_type in ['in','out']:
                for line in read.purchases_lines:
                    allow = line and line.prod_id and line.prod_id.allow_series or False
                    each = line
                    prod_name = line.prod_id and line.prod_id.name or ''

                    if allow:
                        prod_id = line and line.prod_id and line.prod_id.id or False
                        verify = False

                        if order_type == 'in':
                            count = len(line.serie_ids)
                            if count != int(line.qty):
                                raise osv.except_osv(_('Acção Inválida !'), _('A quantidade do producto %s é diferente dos números de série!' % prod_name))
                            for series in line.serie_ids:
                                serial = series and series.name or ''
                                verify = False
                                if cur_state == 'draft':
                                    verify = self.verificar_existe(cr, uid, prod_id, serial, id=series.id)
                                
                                if verify:
                                    raise osv.except_osv(_('Acção Inválida !'), _('Série %s já definida para o produto %s!' % (serial, prod_name)))
                                else:
                                    series_dict = {}
                                    series_dict['product_id'] = prod_id
                                    #field = args.get('line_id', 'stock_line_id')
                                    series_dict['purchase_line_id'] = line.id
                                    series_dict['required'] = True
                                    series_dict['name'] = serial
    
                                    series_dict['state'] = 'draft'
                                    series_dict['created_ref'] = code
                                    series_dict['created_obj'] = 'dotcom.compra'
                                    series_dict['created_id'] = read.id or False
                                    
                                    qr = []
                                    qr.append(('name','=',serial))
                                    qr.append(('product_id','=',prod_id))
                                    qrs = self.pool.get('dotcom.stock.series').search(cr, uid, qr)
                                    if qrs:
                                        self.pool.get('dotcom.stock.series').write(cr,uid, qrs,series_dict)
                                        created_id = qrs and qrs[0]
                                    else:
                                        created_id = self.pool.get('dotcom.stock.series').create(cr, uid, series_dict)
                                    #created_id = self.pool.get('dotcom.stock.series').create(cr, uid, series_dict)
                                    self.pool.get('dotcom.stock.order.line.series').write(cr, uid, series.id, {'serie_id': created_id})
                        else:
                            count = len(line.created_series_ids)
                            if count != line.qty:
                                raise osv.except_osv(_('Acção Inválida !'), _('A quantidade do producto %s é diferente dos números de série!' % prod_name))
                            for series in line.created_series_ids:
                                res = series.id
                                series_dict = {}
                                series_dict['state'] = 'posted'
                                series_dict['used_ref'] = code
                                series_dict['used_obj'] = 'dotcom.compra'
                                series_dict['used_id'] = read.id or False
                                self.pool.get('dotcom.stock.series').write(cr, uid, res, series_dict)  
                    else:
                        continue
            else:
                continue
        return {}
    
    def return_series_ids(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        series_ids = []
        order_type = 'in'
        for read in self.browse(cr, uid, ids):
            order_type = read.doc_type and read.doc_type.movimenta_stock or False
            for line in read.purchases_lines:
                allow = line and line.prod_id and line.prod_id.allow_series or False
                if allow:
                    if order_type == 'in':
                        for series in line.serie_ids:
                            serie_id = series and series.serie_id and series.serie_id.id or False
                            series_ids.append(serie_id)
                    elif order_type == 'out':
                        for line in read.purchases_lines:
                            for serie in line.created_series_ids:
                                series_ids.append(serie.id)
        return (order_type, series_ids)
    
    def run_reset(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        ret_series = self.return_series_ids(cr, uid, ids, context=context)
        series = ret_series and ret_series[1] or []
        order_type = ret_series and ret_series[0] or 'out'
        
        res = super(dotcom_compra, self).run_reset(cr, uid, ids, context=context)
        try:
            if order_type == 'out':
                self.pool.get('dotcom.stock.series').write(cr, uid, series, {'state': 'reset'})
            else:
                for read in self.pool.get('dotcom.stock.series').read(cr, uid, series, ['state', 'used_ref', 'name']):
                    state = read.get('state', 'draft')
                    ref = read.get('used_ref', '')
                    name = read.get('name', '')
                    if state == 'posted':
                        raise osv.except_osv(_('Acção Inválida !'), _('O número de série %s se encontra emitido no documento %s!' % (name, ref)))
                    else:
                        self.pool.get('dotcom.stock.series').write(cr, uid, series, {'state': 'reset'})
        except Exception:
            pass
        return res
    
    def cancel_now(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        ret_series = self.return_series_ids(cr, uid, ids, context=context)
        series = ret_series and ret_series[1] or []
        order_type = ret_series and ret_series[0] or 'out'
        
        res = super(dotcom_compra, self).cancel_now(cr, uid, ids, context=context)
        if order_type == 'out':
            self.pool.get('dotcom.stock.series').write(cr, uid, series, {'state': 'cancel'})
        else:
            for read in self.pool.get('dotcom.stock.series').read(cr, uid, series, ['state', 'used_ref', 'name']):
                state = read.get('state', 'draft')
                ref = read.get('used_ref', '')
                name = read.get('name', '')
                if state == 'posted':
                    raise osv.except_osv(_('Acção Inválida !'), _('O número de série %s se encontra emitido no documento %s!' % (name, ref)))
                else:
                    self.pool.get('dotcom.stock.series').write(cr, uid, series, {'state': 'reset'})
        return res
    
    def update_series(self, cr, uid, ids, ref = '', state = 'posted', context=None):
        if context is None:
            context = {}
        serial_ids = []
        pooler = self.pool.get(self._name)
        for read in pooler.browse(cr, uid, ids):
            code = ''
            try:
                code = read.code or ''
            except Exception:
                code =  read.document_number or ''
            order_type = read.doc_type and read.doc_type.movimenta_stock or False
            for line in read.purchases_lines:
                allow = line and line.prod_id and line.prod_id.allow_series or False
                if allow:
                    for serial in line.serie_ids:
                        series = serial and serial.serie_id
                        serial_ids.append(series and series.id or False)
            write = {'state': state}
            if order_type == 'out':
                write['used_ref'] = ref
            else:
                write['created_ref'] = ref
            self.pool.get('dotcom.stock.series').write(cr, uid, serial_ids, write)
        return True
    
    def post(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        res = super(dotcom_compra, self).post(cr, uid, ids, context=context)
        self.processar_documento(cr, uid, ids, context=context)
        return res
    
dotcom_compra()

class dotcom_compra_linha(osv.osv):
    _name = 'dotcom.compra.linha'
    _inherit = 'dotcom.compra.linha'
    _columns = {
                    'serie_ids': fields.one2many('dotcom.stock.order.line.series', 'purchase_line_id', 'Séries'),
                    'serie_key': fields.char('Base da Série', size=60),
                    'created_series_ids': fields.many2many('dotcom.stock.series', 'purchase_line_series_rel', 'series_id', 'purchase_line_id', 'Processamento de Stocks'),
                    'move_type': fields.related('document_top','doc_type','movimenta_stock', type='char', relation="dotcom.compra",string="Tipo de Movimento", store=False),
                }
    
    _rec_name = 'prod_id'
    
    def copy(self, cr, uid, ids, default=None, context = {}):
        if default is None:
            default = {}
        default.update({'serie_ids': False, 'serie_key': '', 'created_series_ids': False})
        return super(dotcom_compra_linha, self).copy(cr, uid, ids, default, context)
    
    def update_series(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        pools = self.pool.get('dotcom.compra')
        
        for each in self.browse(cr, uid, ids):
            prod_id = each.prod_id and each.prod_id.id or False
            allow = each.prod_id and each.prod_id.allow_series or False
            order_type = each.document_top and each.document_top.doc_type and each.document_top.doc_type.movimenta_stock or False
            base = each.serie_key or ''
            
            if allow and order_type in ['in']:
                qty = int(each.qty or 1)
                if len(each.serie_ids) < qty:
                    qty = qty - len(each.serie_ids)
                    series = {}
                    
                    series['purchase_line_id'] = each.id
                    
                    i = 0
                    count = 0
                    while(i < int(qty)):
                        if base:
                            series['name'] = self.pool.get('dotcom.stock.series').return_number(cr, uid, each.id, base, count, field='purchase_line_id', context=context)
                            cur_id = self.pool.get('dotcom.stock.order.line.series').create(cr, uid, series)
                        i +=1
                    
                    #for i in range(0, qty):
                    #    if base:
                    #        nome = '%s%i' % (base, i)
                    #        series['name'] = nome
                    #    else:
                    #        raise osv.except_osv(_('Acção Inválida !'), _('Código base não definido'))
                    #    cur_id = self.pool.get('dotcom.stock.order.line.series').create(cr, uid, series)
                else:
                    break
        return {}
    
dotcom_compra_linha()