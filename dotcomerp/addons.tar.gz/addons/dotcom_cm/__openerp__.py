# -*- coding: utf-8 -*-
##############################################################################
#
#    DotCom, LDA,
#    Copyright (C) 2012 DotCom, LDA (<http://www.dotcom.co.mz>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


{
    'name': 'DotCom ERP - Commercial Management',
    'version': '1.3',
    'description': '''The Commercial Management Application for DotCOmERP.''',
    'author': 'DotCom, LDA',
    'maintainer': 'DotCom, LDA',
    'website': 'http://www.dotcomerp.co.mz',
    'complexity': 'easy',
    'category': 'DotComERP',
    'depends': ['dotcom_base',
                'dotcom_doc_base',
                'dotcom_licence',
                'dotcom_doc',
                'dotcom_report_repository',
                'dotcom_stock',
                'dotcom_doc_reports',
                'dotcom_notification_cm',
                'dotcom_cm_conversion',
                'dotcom_stock_rules',
                'dotcom_extra_reports',
                'dotcom_multi_currency',
                # 'dotcom_doc_rendas',
                'product_pricelist',
                'dotcom_operacoes_periodicas',
                ],
    'init_xml': [],
    'update_xml':[],
    'demo_xml': [],
    'images' : [],
    'test': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
